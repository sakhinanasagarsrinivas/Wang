import os
import numpy as np
import pandas as pd
import torch
import networkx as nx
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
import logging

class SEMDataset(Dataset):
    """
    Dataset for Scanning Electron Microscopy images
    
    Handles image loading, preprocessing, and feature extraction
    """
    def __init__(self, 
                 csv_file, 
                 root_dir, 
                 patch_size=32, 
                 transform=None,
                 logger=None):
        """
        Initialize the SEM dataset
        
        Args:
            csv_file (str): Path to CSV file with image paths and labels
            root_dir (str): Root directory containing images
            patch_size (int): Size of image patches to extract
            transform (callable, optional): Optional image transformations
            logger (logging.Logger, optional): Logger for tracking dataset operations
        """
        self.logger = logger or logging.getLogger(__name__)
        
        try:
            self.image_labels = pd.read_csv(csv_file)
            self.logger.info(f"Loaded dataset from {csv_file}")
            self.logger.info(f"Total samples: {len(self.image_labels)}")
        except Exception as e:
            self.logger.error(f"Error loading dataset: {e}")
            raise
        
        self.root_dir = root_dir
        self.patch_size = patch_size
        
        self.transform = transform or transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406], 
                std=[0.229, 0.224, 0.225]
            )
        ])
    
    def __len__(self):
        return len(self.image_labels)
    
    def __getitem__(self, idx):
        """
        Retrieve a single item from the dataset
        
        Args:
            idx (int): Index of the item to retrieve
        
        Returns:
            dict: Dictionary containing preprocessed image data and label
        """
        try:
            img_path = os.path.join(self.root_dir, self.image_labels.iloc[idx, 0])
            image = Image.open(img_path).convert('RGB')
            label = self.image_labels.iloc[idx, 1]
            
            patches = self._create_patches(image)
            adjacency_matrix = self._create_adjacency_matrix(patches)
            clique_tree = self._create_clique_tree(patches)
            
            return {
                'patches': patches,
                'label': label,
                'adjacency_matrix': adjacency_matrix,
                'clique_tree': clique_tree
            }
        except Exception as e:
            self.logger.error(f"Error processing item at index {idx}: {e}")
            raise
    
    def _create_patches(self, image):
        """
        Create patches from the input image
        
        Args:
            image (PIL.Image): Input image
        
        Returns:
            torch.Tensor: Extracted image patches
        """
        transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.ToTensor()
        ])
        
        image_tensor = transform(image)
        patches = image_tensor.unfold(1, self.patch_size, self.patch_size) \
                               .unfold(2, self.patch_size, self.patch_size)
        patches = patches.contiguous().view(-1, 3, self.patch_size, self.patch_size)
        
        return patches
    
    def _create_adjacency_matrix(self, patches):
        """
        Create adjacency matrix for image patches
        
        Args:
            patches (torch.Tensor): Image patches
        
        Returns:
            torch.Tensor: Adjacency matrix
        """
        grid_size = int(np.sqrt(len(patches)))
        adjacency = torch.zeros((len(patches), len(patches)))
        
        for i in range(len(patches)):
            row = i // grid_size
            col = i % grid_size
            
            # Connect adjacent patches
            if row > 0:
                adjacency[i, i - grid_size] = 1
            if row < grid_size - 1:
                adjacency[i, i + grid_size] = 1
            if col > 0:
                adjacency[i, i - 1] = 1
            if col < grid_size - 1:
                adjacency[i, i + 1] = 1
        
        return adjacency
    
    def _create_clique_tree(self, patches):
        """
        Create a clique tree representation of patches
        
        Args:
            patches (torch.Tensor): Image patches
        
        Returns:
            torch.Tensor: Clique tree representation
        """
        grid_size = int(np.sqrt(len(patches)))
        G = nx.grid_2d_graph(grid_size, grid_size)
        
        cliques = list(nx.find_cliques(G))
        cliques.sort(key=len, reverse=True)
        
        clique_tree = []
        for clique in cliques[:min(5, len(cliques))]:
            clique_patches = [patches[node[0] * grid_size + node[1]] for node in clique]
            clique_features = torch.stack(clique_patches)
            clique_repr = torch.mean(clique_features, dim=0)
            clique_tree.append(clique_repr)
        
        # Pad to ensure consistent representation
        while len(clique_tree) < 5:
            clique_tree.append(torch.zeros_like(clique_tree[0]))
        
        return torch.stack(clique_tree[:5])

def split_dataset(dataset, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2, random_state=42):
    """
    Split dataset into train, validation, and test sets
    
    Args:
        dataset (torch.utils.data.Dataset): Original dataset
        train_ratio (float): Proportion of dataset for training
        val_ratio (float): Proportion of dataset for validation
        test_ratio (float): Proportion of dataset for testing
        random_state (int): Random seed for reproducibility
    
    Returns:
        tuple: Train, validation, and test datasets
    """
    import numpy as np
    from sklearn.model_selection import train_test_split
    
    total_size = len(dataset)
    
    # Calculate dataset sizes
    test_size = int(total_size * test_ratio)
    val_size = int(total_size * val_ratio)
    train_size = total_size - test_size - val_size
    
    # Get indices
    indices = np.arange(total_size)
    
    # First split: separate test set
    train_val_indices, test_indices = train_test_split(
        indices, 
        test_size=test_size, 
        random_state=random_state
    )
    
    # Second split: separate train and validation sets
    train_indices, val_indices = train_test_split(
        train_val_indices, 
        test_size=val_size, 
        random_state=random_state
    )
    
    # Create subset datasets
    train_dataset = torch.utils.data.Subset(dataset, train_indices)
    val_dataset = torch.utils.data.Subset(dataset, val_indices)
    test_dataset = torch.utils.data.Subset(dataset, test_indices)
    
    return train_dataset, val_dataset, test_dataset