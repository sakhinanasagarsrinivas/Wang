from dataclasses import dataclass
from typing import Optional, Dict, Any
from pathlib import Path

# Dataset configurations from paper Section 4
TRAFFIC_DATASETS = {
    "PeMSD3": {
        "sensors": 358,
        "timesteps": 26208,
        "time_range": "09/2018-11/2018",
        "granularity": "5min",
        "split_ratio": [6, 2, 2]  # train/val/test as per paper
    },
    "PeMSD4": {
        "sensors": 307,
        "timesteps": 16992,
        "time_range": "01/2018-02/2018",
        "granularity": "5min",
        "split_ratio": [6, 2, 2]
    },
    "PeMSD7": {
        "sensors": 883,
        "timesteps": 28224,
        "time_range": "05/2017-08/2017",
        "granularity": "5min",
        "split_ratio": [6, 2, 2]
    },
    "PeMSD8": {
        "sensors": 170,
        "timesteps": 17856,
        "time_range": "07/2016-08/2016",
        "granularity": "5min",
        "split_ratio": [6, 2, 2]
    },
    "METR-LA": {
        "sensors": 207,
        "timesteps": 34272,
        "time_range": "03/2012-06/2012",
        "granularity": "5min",
        "split_ratio": [7, 1, 2]
    },
    "PEMS-BAY": {
        "sensors": 325,
        "timesteps": 52116,
        "time_range": "01/2017-05/2017",
        "granularity": "5min",
        "split_ratio": [7, 1, 2]
    }
}

# Anomaly Detection datasets from paper Section 4
ANOMALY_DATASETS = {
    "SWaT": {
        "sensors": 51,
        "window_size": 25
    },
    "WADI": {
        "sensors": 123,
        "window_size": 25
    },
    "SMAP": {
        "sensors": 25,
        "window_size": 50
    },
    "MSL": {
        "sensors": 55,
        "window_size": 55
    },
    "TEP": {
        "sensors": 52,
        "window_size": 35,
        "fault_types": 20
    },
    "HAI": {
        "sensors": 59,
        "window_size": 30,
        "attack_scenarios": 38
    }
}

@dataclass
class ModelConfig:
    """Model configuration based on paper Section 3.2"""
    model_name: str = "meta-llama/Llama-2-7b"
    lora_r: int = 16  # as per paper
    lora_alpha: int = 32  # as per paper
    lora_dropout: float = 0.05
    max_seq_length: int = 32768  # 32K context length as mentioned in paper
    prompt_pool_size: int = 100
    dtype: str = "bfloat16"

@dataclass
class TrainingConfig:
    """Training configuration based on paper Section 3.2"""
    # Supervised fine-tuning params
    learning_rate: float = 1e-5
    num_epochs: int = 15
    warmup_steps: int = 500
    weight_decay: float = 0.01
    grad_accumulation: int = 2
    batch_size: int = 16
    
    # DPO specific params from paper
    dpo_learning_rate: float = 5.0e-7
    dpo_epochs: int = 3
    beta: float = 0.2  # DPO beta parameter as per paper

@dataclass
class TaskConfig:
    """Task-specific configurations from paper Section 2"""
    # Forecasting (Section 2.1)
    forecast_window_size: int = 12  # τ in paper
    forecast_horizon: int = 12  # ν in paper for multi-step prediction
    
    # Imputation (Section 2.2)
    imputation_window_size: int = 12  # τ for imputation
    imputation_mask_ratio: float = 0.15
    
    # Anomaly Detection (Section 2.3)
    anomaly_window_size: int = 100  # As per datasets
    moving_average_window: int = 10  # wa in paper
    
    # Classification (Section 2.4)
    num_clusters: int = 4  # K in paper for K-means clustering

# Metrics from paper's experiments
METRICS = {
    "forecasting": {
        "mae": "Mean Absolute Error",
        "rmse": "Root Mean Squared Error",
        "mape": "Mean Absolute Percentage Error"
    },
    "anomaly_detection": {
        "precision": "Precision (%)",
        "recall": "Recall (%)",
        "f1": "F1-score (%)",
        "fdr": "Fault Detection Rate (%)"  # For TEP dataset
    },
    "imputation": {
        "mae": "Mean Absolute Error",
        "rmse": "Root Mean Squared Error",
        "mre": "Mean Relative Error"
    },
    "classification": {
        "accuracy": "Classification Accuracy",
        "precision": "Precision per class",
        "recall": "Recall per class",
        "f1": "F1-score per class"
    }
}

# Prompt patterns based on paper Section 3.1
PROMPT_PATTERNS = {
    "forecasting": [
        "trend", "seasonality", "cyclical", "patterns",
        "temporal_dependencies", "spatial_dependencies"
    ],
    "anomaly_detection": [
        "normal_behavior", "anomaly_patterns", "change_points",
        "seasonal_anomalies", "spatial_anomalies"
    ],
    "imputation": [
        "temporal_correlation", "spatial_correlation", 
        "missing_patterns", "value_distributions"
    ],
    "classification": [
        "regime_patterns", "state_transitions",
        "behavioral_modes", "operating_conditions"
    ]
}