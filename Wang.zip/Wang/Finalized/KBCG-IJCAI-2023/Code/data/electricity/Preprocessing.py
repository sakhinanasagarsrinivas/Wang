 
 
import pandas as pd
import numpy as np  

# Read the files' content as Pandas DataFrame.    
X = pd.read_csv('electricity.txt', low_memory=False, na_values=['nan','?'])

X = X.to_numpy()
X = X.astype(np.float32)
np.savez("data.npz", X)
