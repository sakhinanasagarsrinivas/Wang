import torch
import numpy as np
import random
import os

class Helpers:
    """Helper utilities for the molecule generation project"""
    
    @staticmethod
    def set_seed(seed: int = 42):
        """
        Set random seeds for reproducibility
        
        Args:
            seed: Random seed value
        """
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        np.random.seed(seed)
        random.seed(seed)
        
        # For deterministic algorithms in CUDA
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    
    @staticmethod
    def save_checkpoint(
        model: torch.nn.Module, 
        optimizer: torch.optim.Optimizer, 
        filename: str = 'checkpoint.pth'
    ):
        """
        Save model and optimizer state
        
        Args:
            model: PyTorch model
            optimizer: Model optimizer
            filename: Checkpoint filename
        """
        checkpoint = {
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict()
        }
        torch.save(checkpoint, filename)
    
    @staticmethod
    def load_checkpoint(
        model: torch.nn.Module, 
        optimizer: torch.optim.Optimizer, 
        filename: str = 'checkpoint.pth'
    ):
        """
        Load model and optimizer state
        
        Args:
            model: PyTorch model
            optimizer: Model optimizer
            filename: Checkpoint filename
        
        Returns:
            Tuple of (model, optimizer)
        """
        if os.path.exists(filename):
            checkpoint = torch.load(filename)
            model.load_state_dict(checkpoint['model_state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        return model, optimizer
    
    @staticmethod
    def log_results(
        epoch: int, 
        metrics: dict, 
        log_file: str = 'training_log.txt'
    ):
        """
        Log training results
        
        Args:
            epoch: Current training epoch
            metrics: Dictionary of performance metrics
            log_file: Log file path
        """
        with open(log_file, 'a') as f:
            f.write(f"Epoch {epoch}:\n")
            for metric, value in metrics.items():
                f.write(f"{metric}: {value}\n")
            f.write("\n")