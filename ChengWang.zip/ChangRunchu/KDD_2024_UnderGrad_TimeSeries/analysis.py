import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

class AblationStudyAnalysis:
    """
    Analyze and visualize ablation study results
    Corresponds to paper Section E: Ablation Study
    """
    def __init__(self, results_dir='./'):
        self.results_dir = results_dir
        self.results = self._load_results()
    
    def _load_results(self):
        """Load all ablation study result CSVs"""
        results = {}
        for filename in os.listdir(self.results_dir):
            if filename.startswith('ablation_study_') and filename.endswith('.csv'):
                task = filename.split('_')[2]
                dataset = filename.split('_')[3].split('.')[0]
                
                filepath = os.path.join(self.results_dir, filename)
                df = pd.read_csv(filepath, index_col=0)
                
                if task not in results:
                    results[task] = {}
                results[task][dataset] = df
        
        return results
    
    def performance_drop_analysis(self):
        """
        Calculate performance drop for each ablated component
        Matches paper's ablation methodology
        """
        performance_drops = {}
        
        for task, task_results in self.results.items():
            task_drops = {}
            for dataset, df in task_results.items():
                baseline = df.loc['full_framework']
                dataset_drops = {}
                
                # Predefined ablation components
                components = [
                    'without_dpm', 
                    'without_sas', 
                    'without_it', 
                    'without_dpo'
                ]
                
                for component in components:
                    ablated_perf = df.loc[component]
                    drops = {}
                    
                    # Calculate percentage drop for each metric
                    for metric in baseline.index:
                        if metric in ablated_perf.index:
                            drop = ((baseline[metric] - ablated_perf[metric]) / baseline[metric]) * 100
                            drops[metric] = drop
                    
                    dataset_drops[component] = drops
                
                task_drops[dataset] = dataset_drops
            
            performance_drops[task] = task_drops
        
        return performance_drops
    
    def visualize_performance_drops(self):
        """
        Create bar plots showing performance drops
        Mimics visualization style from paper's ablation study
        """
        drops = self.performance_drop_analysis()
        
        for task, task_drops in drops.items():
            plt.figure(figsize=(15, 10))
            
            # Prepare data for plotting
            datasets = list(task_drops.keys())
            components = list(task_drops[datasets[0]].keys())
            
            # Aggregate drops across datasets
            aggregated_drops = {comp: [] for comp in components}
            for dataset in datasets:
                for comp in components:
                    avg_drop = np.mean(list(task_drops[dataset][comp].values()))
                    aggregated_drops[comp].append(avg_drop)
            
            # Plot
            x = np.arange(len(components))
            width = 0.35
            
            plt.bar(x, [np.mean(drops) for drops in aggregated_drops.values()], width)
            plt.title(f'Performance Drop for {task.capitalize()} Task')
            plt.xlabel('Ablated Components')
            plt.ylabel('Average Performance Drop (%)')
            plt.xticks(x, [comp.replace('without_', '').upper() for comp in components])
            
            # Add value labels
            for i, v in enumerate([np.mean(drops) for drops in aggregated_drops.values()]):
                plt.text(i, v, f'{v:.2f}%', ha='center', va='bottom')
            
            plt.tight_layout()
            plt.savefig(f'{task}_performance_drops.png')
            plt.close()
    
    def statistical_significance_test(self):
        """
        Perform statistical significance tests
        Corresponds to ablation study methodology
        """
        from scipy import stats
        
        significance_results = {}
        drops = self.performance_drop_analysis()
        
        for task, task_drops in drops.items():
            task_significance = {}
            
            for component, component_drops in drops[task][list(task_drops.keys())[0]].items():
                # Collect drops across datasets
                all_drops = [list(dataset_drops[component].values()) 
                             for dataset_drops in drops[task].values()]
                all_drops = [drop for sublist in all_drops for drop in sublist]
                
                # One-sample t-test against zero
                t_statistic, p_value = stats.ttest_1samp(all_drops, 0)
                
                task_significance[component] = {
                    't_statistic': t_statistic,
                    'p_value': p_value,
                    'significant': p_value < 0.05,
                    'mean_drop': np.mean(all_drops),
                    'std_drop': np.std(all_drops)
                }
            
            significance_results[task] = task_significance
        
        return significance_results
    
    def generate_comprehensive_report(self):
        """
        Generate a comprehensive report of ablation study results
        """
        performance_drops = self.performance_drop_analysis()
        significance_results = self.statistical_significance_test()
        
        report = "# Agentic RAG Ablation Study Report\n\n"
        
        for task, task_drops in performance_drops.items():
            report += f"## {task.capitalize()} Task Analysis\n\n"
            
            report += "### Performance Drops\n"
            for dataset, dataset_drops in task_drops.items():
                report += f"#### Dataset: {dataset}\n"
                for component, drops in dataset_drops.items():
                    report += f"- **{component}**:\n"
                    for metric, drop in drops.items():
                        report += f"  - {metric}: {drop:.2f}%\n"
            
            report += "\n### Statistical Significance\n"
            for component, stats in significance_results[task].items():
                report += f"#### {component}\n"
                report += f"- Mean Drop: {stats['mean_drop']:.2f}%\n"
                report += f"- Std Dev: {stats['std_drop']:.2f}%\n"
                report += f"- t-statistic: {stats['t_statistic']:.4f}\n"
                report += f"- p-value: {stats['p_value']:.4f}\n"
                report += f"- Statistically Significant: {'Yes' if stats['significant'] else 'No'}\n\n"
        
        # Save report
        with open('ablation_study_report.md', 'w') as f:
            f.write(report)
        
        return report
    
    def export_results_to_latex(self):
        """
        Export ablation study results to LaTeX table format
        """
        performance_drops = self.performance_drop_analysis()
        significance_results = self.statistical_significance_test()
        
        latex_output = "\\begin{table}[htbp]\n"
        latex_output += "\\centering\n"
        latex_output += "\\caption{Ablation Study Results}\n"
        latex_output += "\\label{tab:ablation_study}\n"
        latex_output += "\\begin{tabular}{l|cccc}\n"
        latex_output += "\\hline\n"
        latex_output += "Task & DPM & SAS & IT & DPO \\\\\n"
        latex_output += "\\hline\n"
        
        for task, task_drops in performance_drops.items():
            # Average drops across datasets
            avg_drops = {}
            for dataset, dataset_drops in task_drops.items():
                for component, drops in dataset_drops.items():
                    if component not in avg_drops:
                        avg_drops[component] = []
                    avg_drops[component].extend(list(drops.values()))
            
            # Calculate mean drops
            mean_drops = {
                comp: np.mean(drops) if drops else 0 
                for comp, drops in avg_drops.items()
            }
            
            # Format for LaTeX
            latex_output += (
                f"{task.capitalize()} & "
                f"{mean_drops.get('without_dpm', 0):.2f}\% & "
                f"{mean_drops.get('without_sas', 0):.2f}\% & "
                f"{mean_drops.get('without_it', 0):.2f}\% & "
                f"{mean_drops.get('without_dpo', 0):.2f}\% \\\\\n"
            )
        
        latex_output += "\\hline\n\\end{tabular}\n\\end{table}"
        
        # Save LaTeX table
        with open('ablation_study_table.tex', 'w') as f:
            f.write(latex_output)
        
        return latex_output

def main():
    """Main entry point for ablation study analysis"""
    # Initialize analysis
    analysis = AblationStudyAnalysis()
    
    # Visualize performance drops
    analysis.visualize_performance_drops()
    
    # Generate comprehensive report
    analysis.generate_comprehensive_report()
    
    # Export results to LaTeX
    analysis.export_results_to_latex()
    
    # Print significance results
    significance_results = analysis.statistical_significance_test()
    print("Significance Results:")
    for task, results in significance_results.items():
        print(f"\n{task.capitalize()} Task:")
        for component, stats in results.items():
            print(f"{component}:")
            print(f"  Mean Drop: {stats['mean_drop']:.2f}%")
            print(f"  Significant: {stats['significant']}")

if __name__ == "__main__":
    main()