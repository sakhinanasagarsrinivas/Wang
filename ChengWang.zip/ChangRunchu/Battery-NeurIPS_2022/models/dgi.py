import torch
import torch.nn as nn
import torch.nn.functional as F

class DynamicGraphInference(nn.Module):
    """
    Dynamic Graph Inference (DGI) module as described in Section 3.1.
    Learns the time-evolving discrete graph structure of battery parameters.
    """
    def __init__(self, num_nodes, input_dim, hidden_dim, embed_dim):
        super(DynamicGraphInference, self).__init__()
        self.num_nodes = num_nodes
        self.temperature = 0.05  # temperature parameter γ from paper
        
        # Trainable node embeddings bi ∈ Rd
        self.node_embeddings = nn.Parameter(torch.randn(num_nodes, embed_dim))
        
        # Feature transformation matrix Ws
        self.Ws = nn.Linear(input_dim, embed_dim)
        
        # Fully connected layers for gfc
        self.gfc = nn.Sequential(
            nn.Linear(2 * embed_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 2)  # For θt,k_i,j, k ∈ {0,1}
        )

    def forward(self, x_t):
        batch_size = x_t.size(0)
        
        # Transform features: WsXt_i
        transformed_features = self.Ws(x_t)
        node_features = transformed_features + self.node_embeddings.unsqueeze(0)
        
        # Compute pairwise features
        node_i = node_features.unsqueeze(2).expand(-1, -1, self.num_nodes, -1)
        node_j = node_features.unsqueeze(1).expand(-1, self.num_nodes, -1, -1)
        pair_features = torch.cat([node_i, node_j], dim=-1)
        
        # Compute edge probabilities θt,k_i,j
        edge_logits = self.gfc(pair_features)
        
        # Gumbel-softmax for differentiable sampling (equation 1)
        gumbel_noise = -torch.empty_like(edge_logits).exponential_().log()
        gumbel_logits = (edge_logits + gumbel_noise) / self.temperature
        A_t = F.softmax(gumbel_logits, dim=-1)[..., 0]
        
        return A_t