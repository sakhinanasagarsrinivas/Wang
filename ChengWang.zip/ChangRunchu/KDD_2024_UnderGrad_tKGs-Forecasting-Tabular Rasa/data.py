"""
data.py - Data processing for Temporal Knowledge Graph Forecasting
"""

import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Union
from sklearn.preprocessing import LabelEncoder
from datetime import datetime
import logging
import json
import hashlib
from tqdm import tqdm

from .core import (
    TimeGranularity, DatasetConfig, Quadruple, DatasetStats,
    ValidationError, compute_dataset_stats
)

logger = logging.getLogger(__name__)

class TKGDataset(Dataset):
    """PyTorch Dataset for temporal knowledge graphs"""
    
    def __init__(
        self,
        quadruples: List[Quadruple],
        entity_encoder: LabelEncoder,
        relation_encoder: LabelEncoder,
        window_size: int = 25,
        cache_dir: Optional[Path] = None
    ):
        self.quadruples = sorted(quadruples, key=lambda x: x.timestamp)
        self.entity_encoder = entity_encoder
        self.relation_encoder = relation_encoder
        self.window_size = window_size
        self.cache_dir = cache_dir

        # Create encoded tensors
        self.encoded_data = self._encode_quadruples()
        
        # Cache encodings if cache_dir provided
        if cache_dir:
            self._cache_encodings()

    def _encode_quadruples(self) -> torch.Tensor:
        """Encode quadruples into tensor format"""
        try:
            encoded = []
            for quad in self.quadruples:
                encoded.append([
                    self.entity_encoder.transform([quad.subject])[0],
                    self.relation_encoder.transform([quad.relation])[0],
                    self.entity_encoder.transform([quad.object])[0],
                    int((quad.timestamp - self.quadruples[0].timestamp)
                        .total_seconds() / 86400)  # Convert to days
                ])
            return torch.tensor(encoded, dtype=torch.long)
        except Exception as e:
            logger.error(f"Failed to encode quadruples: {str(e)}")
            raise

    def _get_historical_context(self, idx: int) -> torch.Tensor:
        """Get historical context for given index"""
        current_time = self.encoded_data[idx, 3]
        
        # Find relevant historical facts
        mask = (self.encoded_data[:idx, 3] >= current_time - self.window_size)
        historical = self.encoded_data[:idx][mask][-self.window_size:]
        
        # Pad if necessary
        if len(historical) < self.window_size:
            padding = torch.zeros(
                (self.window_size - len(historical), 4),
                dtype=torch.long
            )
            historical = torch.cat([padding, historical])
            
        return historical

    def __len__(self) -> int:
        return len(self.encoded_data)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        quad = self.encoded_data[idx]
        historical = self._get_historical_context(idx)
        
        return {
            'subject': quad[0],
            'relation': quad[1],
            'object': quad[2],
            'timestamp': quad[3],
            'historical_context': historical
        }

    def _cache_encodings(self) -> None:
        """Cache encoded data"""
        if self.cache_dir:
            cache_path = self.cache_dir / f"encoded_data_{len(self)}.pt"
            torch.save(self.encoded_data, cache_path)
            logger.info(f"Cached encoded data to {cache_path}")

class DataProcessor:
    """Process and prepare temporal knowledge graph data"""
    
    def __init__(
        self,
        config: DatasetConfig,
        data_dir: Union[str, Path],
        cache_dir: Optional[Union[str, Path]] = None
    ):
        self.config = config
        self.data_dir = Path(data_dir)
        self.cache_dir = Path(cache_dir) if cache_dir else None
        
        self.entity_encoder = LabelEncoder()
        self.relation_encoder = LabelEncoder()
        self.stats: Optional[DatasetStats] = None

    def process(self) -> Tuple[TKGDataset, Optional[TKGDataset], TKGDataset]:
        """Process data and create train/val/test datasets"""
        try:
            # Check cache first
            if self.cache_dir and self._check_cache():
                return self._load_from_cache()

            # Load and validate raw data
            quadruples = self._load_data()
            
            # Compute statistics
            self.stats = compute_dataset_stats(quadruples)
            logger.info(f"Dataset statistics:\n{self.stats}")
            
            # Split data
            train, val, test = self._split_data(quadruples)
            
            # Create datasets
            train_dataset = TKGDataset(
                train, self.entity_encoder, self.relation_encoder,
                self.config.window_size, self.cache_dir
            )
            val_dataset = TKGDataset(
                val, self.entity_encoder, self.relation_encoder,
                self.config.window_size, self.cache_dir
            ) if val else None
            test_dataset = TKGDataset(
                test, self.entity_encoder, self.relation_encoder,
                self.config.window_size, self.cache_dir
            )
            
            # Cache if needed
            if self.cache_dir:
                self._cache_datasets(train_dataset, val_dataset, test_dataset)
            
            return train_dataset, val_dataset, test_dataset
            
        except Exception as e:
            logger.error(f"Failed to process data: {str(e)}")
            raise

    def _load_data(self) -> List[Quadruple]:
        """Load raw data based on dataset format"""
        data_path = self.data_dir / f"{self.config.name.lower()}.csv"
        
        if not data_path.exists():
            raise FileNotFoundError(f"Data file not found: {data_path}")
            
        df = pd.read_csv(data_path)
        
        # Validate columns
        required_cols = ['subject', 'relation', 'object', 'timestamp']
        if not all(col in df.columns for col in required_cols):
            raise ValidationError(f"Missing required columns: {required_cols}")
            
        # Convert to quadruples
        quadruples = []
        for _, row in df.iterrows():
            quad = Quadruple(
                subject=str(row['subject']),
                relation=str(row['relation']),
                object=str(row['object']),
                timestamp=pd.to_datetime(row['timestamp'])
            )
            quad.validate()
            quadruples.append(quad)
            
        return quadruples

    def _split_data(
        self,
        quadruples: List[Quadruple]
    ) -> Tuple[List[Quadruple], Optional[List[Quadruple]], List[Quadruple]]:
        """Split data into train/val/test sets"""
        # Sort by time
        quadruples = sorted(quadruples, key=lambda x: x.timestamp)
        
        # Calculate split indices
        train_idx = int(len(quadruples) * self.config.train_ratio)
        val_idx = int(len(quadruples) * (self.config.train_ratio + self.config.val_ratio))
        
        train = quadruples[:train_idx]
        val = quadruples[train_idx:val_idx] if self.config.val_ratio > 0 else None
        test = quadruples[val_idx:]
        
        return train, val, test

    def _cache_datasets(
        self,
        train: TKGDataset,
        val: Optional[TKGDataset],
        test: TKGDataset
    ) -> None:
        """Cache processed datasets"""
        if self.cache_dir:
            cache_data = {
                'config': self.config.__dict__,
                'stats': self.stats.__dict__,
                'entity_encoder': self.entity_encoder,
                'relation_encoder': self.relation_encoder,
                'train': train.encoded_data,
                'test': test.encoded_data
            }
            if val:
                cache_data['val'] = val.encoded_data
                
            torch.save(cache_data, self.cache_dir / "processed_data.pt")
            logger.info(f"Cached processed data to {self.cache_dir}")

    def _check_cache(self) -> bool:
        """Check if cached data exists and is valid"""
        if self.cache_dir:
            cache_path = self.cache_dir / "processed_data.pt"
            return cache_path.exists()
        return False

    def _load_from_cache(self) -> Tuple[TKGDataset, Optional[TKGDataset], TKGDataset]:
        """Load datasets from cache"""
        cache_path = self.cache_dir / "processed_data.pt"
        cache_data = torch.load(cache_path)
        
        # Restore encoders and stats
        self.entity_encoder = cache_data['entity_encoder']
        self.relation_encoder = cache_data['relation_encoder']
        self.stats = DatasetStats(**cache_data['stats'])
        
        # Create datasets
        train = TKGDataset(
            cache_data['train'],
            self.entity_encoder,
            self.relation_encoder,
            self.config.window_size,
            self.cache_dir
        )
        
        val = None
        if 'val' in cache_data:
            val = TKGDataset(
                cache_data['val'],
                self.entity_encoder,
                self.relation_encoder,
                self.config.window_size,
                self.cache_dir
            )
            
        test = TKGDataset(
            cache_data['test'],
            self.entity_encoder,
            self.relation_encoder,
            self.config.window_size,
            self.cache_dir
        )
        
        return train, val