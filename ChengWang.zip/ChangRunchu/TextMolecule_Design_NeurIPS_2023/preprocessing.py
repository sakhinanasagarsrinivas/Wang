from rdkit import Chem
from typing import List, Dict, Optional
import pandas as pd
from langchain.embeddings import OpenAIEmbeddings
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

class MoleculePreprocessor:
    """Class for preprocessing molecular data"""
    
    def __init__(self, scaffold_k: int = 16):
        """
        Args:
            scaffold_k: Number of similar examples to retrieve for scaffold sampling
        """
        self.scaffold_k = scaffold_k
        self.embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
        
    def create_prompt(self, query_text: str, examples: List[Dict[str, str]]) -> str:
        """
        Create a prompt with demonstrations for the LLM
        
        Args:
            query_text: The input text description
            examples: List of example text-SMILES pairs
            
        Returns:
            Formatted prompt string
        """
        prompt = "Below are the textual descriptions – chemical SMILES representation pairs. "
        prompt += "Generate the chemical SMILES representation for the textual description provided below.\n\n"
        
        # Add demonstrations
        for example in examples:
            prompt += f"Text: {example['text']}\n"
            prompt += f"SMILES: {example['smiles']}\n\n"
            
        # Add query
        prompt += f"Text: {query_text}\nSMILES:"
        
        return prompt
    
    def scaffold_sampling(
        self,
        query_text: str,
        text_pool: List[str],
        smiles_pool: List[str]
    ) -> List[Dict[str, str]]:
        """
        Perform scaffold sampling to find similar examples
        
        Args:
            query_text: Input text description
            text_pool: Pool of available text descriptions
            smiles_pool: Pool of available SMILES strings
            
        Returns:
            List of selected examples
        """
        # Get embeddings
        query_embedding = self.embeddings.embed_query(query_text)
        pool_embeddings = self.embeddings.embed_documents(text_pool)
        
        # Calculate similarities
        similarities = cosine_similarity(
            [query_embedding],
            pool_embeddings
        )[0]
        
        # Get top-k indices
        top_k_indices = np.argsort(similarities)[-self.scaffold_k:]
        
        # Create examples
        examples = []
        for idx in top_k_indices:
            examples.append({
                'text': text_pool[idx],
                'smiles': smiles_pool[idx]
            })
            
        return examples
    
    def clean_smiles(self, smiles: str) -> Optional[str]:
        """
        Clean and validate SMILES string
        
        Args:
            smiles: Input SMILES string
            
        Returns:
            Cleaned SMILES string or None if invalid
        """
        try:
            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                return None
            return Chem.MolToSmiles(mol, canonical=True)
        except:
            return None
            
    def process_llm_response(self, response: str) -> List[str]:
        """
        Process LLM response to extract SMILES strings
        
        Args:
            response: Raw LLM response text
            
        Returns:
            List of valid SMILES strings
        """
        # Split response into lines
        lines = response.strip().split('\n')
        
        # Extract SMILES strings
        smiles_list = []
        for line in lines:
            if 'SMILES:' in line:
                smiles = line.split('SMILES:')[1].strip()
                clean_smiles = self.clean_smiles(smiles)
                if clean_smiles:
                    smiles_list.append(clean_smiles)
                    
        return smiles_list