
import torch
import torch.nn as nn
import torch.nn.functional as F

class BatteryDataset(Dataset):
    """
    Dataset class for battery data handling.
    Supports both NASA and UNIBO datasets as mentioned in Section 4.1
    """
    def __init__(self, data_path, dataset_type='NASA', transform=None):
        self.transform = transform
        self.dataset_type = dataset_type
        
        if dataset_type == 'NASA':
            self.data, self.labels = self._load_nasa_data(data_path)
        elif dataset_type == 'UNIBO':
            self.data, self.labels = self._load_unibo_data(data_path)
        else:
            raise ValueError("Dataset type must be either 'NASA' or 'UNIBO'")
            
        self.scaler = StandardScaler()
        self.data = self.scaler.fit_transform(
            self.data.reshape(-1, self.data.shape[-1])
        ).reshape(self.data.shape)

    def _load_nasa_data(self, data_path):
        """Load NASA Randomized Battery Usage Dataset"""
        data = pd.read_csv(data_path)
        # Process voltage, current, charge capacity, temperature, etc.
        return processed_data, labels

    def _load_unibo_data(self, data_path):
        """Load UNIBO Powertools Dataset"""
        data = pd.read_csv(data_path)
        # Process battery parameters
        return processed_data, labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sample = self.data[idx]
        label = self.labels[idx]
        if self.transform:
            sample = self.transform(sample)
        return torch.FloatTensor(sample), torch.FloatTensor([label])