# utils.py

import torch
import numpy as np
import networkx as nx
from typing import Dict, List, Tuple, Optional
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.metrics import precision_score, recall_score, f1_score
import logging

logger = logging.getLogger(__name__)

class RootCauseAnalysis:
    """Root cause analysis using computation hypergraphs"""
    def __init__(self, model, config):
        self.model = model
        self.config = config
        
    def build_computation_graph(self, node_idx: int, k_hops: int = 2) -> nx.DiGraph:
        """Build computation graph for anomaly propagation"""
        # Get attention weights
        with torch.no_grad():
            _, attn_weights = self.model.encoder_convs[0](
                self.model.node_embeddings.unsqueeze(0),
                self.model.structure_learning.H,
                return_attention=True
            )
        
        attn_weights = attn_weights.squeeze(0).cpu().numpy()
        
        # Create directed graph
        G = nx.DiGraph()
        G.add_node(node_idx, level=0)
        
        # BFS to build k-hop neighborhood
        current_level = {node_idx}
        for level in range(k_hops):
            next_level = set()
            for node in current_level:
                # Add high attention edges
                neighbors = np.where(attn_weights[node] > self.config.rca_attention_threshold)[0]
                for neighbor in neighbors:
                    if neighbor not in G:
                        G.add_node(neighbor, level=level+1)
                        G.add_edge(node, neighbor, weight=float(attn_weights[node, neighbor]))
                        next_level.add(neighbor)
            current_level = next_level
            
        return G
        
    def analyze(self, anomaly_idx: int, data: torch.Tensor) -> Dict:
        """Perform root cause analysis"""
        # Build computation graph
        G = self.build_computation_graph(anomaly_idx, self.config.rca_k_hops)
        
        # Get node scores
        scores = self._compute_node_scores(G, data)
        
        # Get top causes
        causes = self._get_top_causes(scores)
        
        # Generate explanation
        explanation = self._generate_explanation(causes, data)
        
        return {
            'graph': G,
            'scores': scores,
            'causes': causes,
            'explanation': explanation
        }
        
    def _compute_node_scores(self, G: nx.DiGraph, data: torch.Tensor) -> Dict[int, float]:
        """Compute importance scores for nodes"""
        scores = {}
        
        # Calculate path-based scores
        for node in G.nodes():
            paths = nx.single_source_dijkstra_path_length(G, node, weight='weight')
            # Score based on path lengths and attention weights
            score = sum(1.0 / (1.0 + length) for length in paths.values())
            # Add temporal correlation
            if data is not None:
                corr = np.corrcoef(data[:, node], data[:, list(paths.keys())].T)[0, 1:]
                score *= np.mean(np.abs(corr))
            scores[node] = score
            
        return scores
        
    def _get_top_causes(self, scores: Dict[int, float], top_k: int = 5) -> List[Tuple[int, float]]:
        """Get top k root causes"""
        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return sorted_scores[:top_k]
        
    def _generate_explanation(self, causes: List[Tuple[int, float]], data: torch.Tensor) -> str:
        """Generate textual explanation for root causes"""
        explanation = "Root cause analysis results:\n"
        
        for node, score in causes:
            # Get temporal patterns
            if data is not None:
                z_scores = zscore(data[:, node].cpu().numpy())
                anomalous = np.abs(z_scores) > 3
                pattern = "shows abnormal behavior" if np.any(anomalous) else "behaves normally"
            else:
                pattern = "unknown behavior"
                
            explanation += f"- Sensor {node}: Score = {score:.3f}, {pattern}\n"
            
        return explanation

class AnomalyAnalytics:
    """Analytics utilities for anomaly detection"""
    
    @staticmethod
    def compute_metrics(
        predictions: np.ndarray,
        targets: np.ndarray,
        anomaly_scores: np.ndarray,
        threshold: float = 0.5
    ) -> Dict[str, float]:
        """Compute anomaly detection metrics"""
        # Binary predictions
        pred_labels = (anomaly_scores > threshold).astype(int)
        true_labels = (np.abs(predictions - targets) > threshold).astype(int)
        
        return {
            'precision': precision_score(true_labels, pred_labels),
            'recall': recall_score(true_labels, pred_labels),
            'f1': f1_score(true_labels, pred_labels),
            'mse': np.mean((predictions - targets) ** 2),
            'mae': np.mean(np.abs(predictions - targets))
        }
        
    @staticmethod
    def plot_anomaly_scores(
        timestamps: np.ndarray,
        anomaly_scores: np.ndarray,
        threshold: float,
        save_path: Optional[str] = None
    ):
        """Plot anomaly scores with threshold"""
        plt.figure(figsize=(12, 6))
        plt.plot(timestamps, anomaly_scores, 'b-', label='Anomaly Score')
        plt.axhline(y=threshold, color='r', linestyle='--', label='Threshold')
        plt.fill_between(timestamps, 
                        anomaly_scores, 
                        threshold,
                        where=(anomaly_scores > threshold),
                        color='red',
                        alpha=0.3,
                        label='Anomalies')
        plt.xlabel('Time')
        plt.ylabel('Anomaly Score')
        plt.title('Anomaly Detection Results')
        plt.legend()
        
        if save_path:
            plt.savefig(save_path)
        plt.close()
        
    @staticmethod
    def plot_sensor_correlations(data: np.ndarray, save_path: Optional[str] = None):
        """Plot correlation matrix between sensors"""
        corr = np.corrcoef(data.T)
        plt.figure(figsize=(10, 8))
        sns.heatmap(corr, cmap='coolwarm', center=0)
        plt.title('Sensor Correlations')
        
        if save_path:
            plt.savefig(save_path)
        plt.close()

class PrescriptiveControl:
    """Prescriptive analytics for anomaly control"""
    def __init__(self, model, config):
        self.model = model
        self.config = config
        
    def optimize_control(
        self,
        anomalous_node: int,
        current_state: torch.Tensor,
        bounds: Optional[Tuple[float, float]] = None
    ) -> Dict:
        """Optimize control action using genetic algorithm"""
        from deap import base, creator, tools, algorithms
        
        bounds = bounds or (0, 1)
        
        # Setup optimization
        creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
        creator.create("Individual", list, fitness=creator.FitnessMin)
        
        toolbox = base.Toolbox()
        toolbox.register("attr_float", np.random.uniform, bounds[0], bounds[1])
        toolbox.register("individual", tools.initRepeat, creator.Individual,
                        toolbox.attr_float, n=1)
        toolbox.register("population", tools.initRepeat, list, toolbox.individual)
        
        def objective(x):
            """Objective function for optimization"""
            with torch.no_grad():
                state_copy = current_state.clone()
                state_copy[anomalous_node] = torch.tensor(x[0], 
                                                        device=current_state.device)
                pred, _ = self.model(state_copy.unsqueeze(0))
                return torch.abs(pred[0, anomalous_node]).item(),
        
        toolbox.register("evaluate", objective)
        toolbox.register("mate", tools.cxTwoPoint)
        toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=0.1, indpb=0.1)
        toolbox.register("select", tools.selTournament, tournsize=3)
        
        # Run optimization
        pop = toolbox.population(n=self.config.control_population_size)
        hof = tools.HallOfFame(1)
        
        pop, logbook = algorithms.eaSimple(
            pop, toolbox,
            cxpb=self.config.control_crossover_rate,
            mutpb=self.config.control_mutation_rate,
            ngen=self.config.control_generations,
            halloffame=hof,
            verbose=False
        )
        
        return {
            'optimal_value': hof[0][0],
            'fitness': hof[0].fitness.values[0],
            'convergence': logbook
        }

def setup_logging(log_file: Optional[str] = None, level: int = logging.INFO):
    """Setup logging configuration"""
    format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    logging.basicConfig(level=level, format=format)
    
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(logging.Formatter(format))
        logging.getLogger().addHandler(file_handler)
        
def set_random_seed(seed: int):
    """Set random seed for reproducibility"""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False