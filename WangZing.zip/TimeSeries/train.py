
import os
import json
import time 
import torch
from utils import *
import numpy as np
from syntheticdataaugmentation import SyntheticDataAugmentation
import logging

import warnings  # Library to handle warnings in Python
# Suppress specific warnings for cleaner output
warnings.simplefilter(action='ignore', category=FutureWarning)

class Trainer:
    """Training class to encapsulate configuration, data loading, model setup, and training process."""

    def __init__(self, config):
        """
        Initializes the Trainer object with the provided configuration.

        Args:
            config (dict): Configuration dictionary containing settings for the training pipeline.
        """
        self.run_settings = config  # Store the configuration settings
        self.model = None  # Placeholder for the model instance
        self.ori_data = None  # Placeholder for the original data to be loaded later

    def validate_options(self):
        """Validates the configuration options to ensure correctness before starting training."""
        # Ensure the latent dimensionality is valid
        if self.run_settings['latent_dim'] <= 0:
            raise ValueError("latent_dim must be a positive integer.")
        # Ensure the number of RNN layers is valid
        if self.run_settings['rnn_layers'] <= 0:
            raise ValueError("rnn_layers must be a positive integer.")
        # Ensure the number of iterations is valid
        if self.run_settings['num_iterations'] <= 0:
            raise ValueError("num_iterations must be a positive integer.")
        # Ensure the batch size is valid
        if self.run_settings['batch_size'] <= 0:
            raise ValueError("batch_size must be a positive integer.")
        # Ensure the metric iteration frequency is valid
        if self.run_settings['metric_iteration'] <= 0:
            raise ValueError("metric_iteration must be a positive integer.")
        # Ensure the number of GPUs is non-negative
        if self.run_settings['num_gpus'] < 0:
            raise ValueError("num_gpus must be a non-negative integer.")
        # Validate the Adam optimizer's beta1 parameter
        if not 0 <= self.run_settings['adam_optimizer_beta1'] <= 1:
            raise ValueError("adam_optimizer_beta1 must be between 0 and 1.")
        # Ensure the learning rate is positive
        if self.run_settings['learning_rate'] <= 0:
            raise ValueError("learning_rate must be positive.")

        # Parse GPU IDs from a comma-separated string
        gpu_id_strings = self.run_settings['accelerator_ids'].split(',')
        self.run_settings['accelerator_ids'] = []  # Initialize GPU ID list
        for gpu_id_string in gpu_id_strings:
            try:
                gpu_id = int(gpu_id_string)  # Convert GPU ID to an integer
                if gpu_id >= 0:  # Ensure the GPU ID is non-negative
                    self.run_settings['accelerator_ids'].append(gpu_id)
            except ValueError:
                raise ValueError(f"Invalid GPU ID: {gpu_id_string}. GPU IDs must be integers.")

        # Check if GPU is selected as the compute target
        if self.run_settings['compute_target'] == 'gpu':
            # Ensure that at least one GPU ID is provided
            if len(self.run_settings['accelerator_ids']) == 0:
                raise ValueError("No valid GPU IDs provided. Set accelerator_ids or use CPU.")
            # Verify that CUDA is available for GPU usage
            if not torch.cuda.is_available():
                raise EnvironmentError("CUDA is not available. Please check your GPU setup or use CPU.")
            # Set the first GPU ID as the active device
            torch.cuda.set_device(self.run_settings['accelerator_ids'][0])

        # Construct the experiment directory path
        if self.run_settings['run_name'] == 'Synthetic_data_Synthesis':
            # Dynamically generate the run name based on model and dataset type
            self.run_settings['run_name'] = f"{self.run_settings['dataset_type']}"
        self.experiment_workspace = os.path.join(self.run_settings['output_dir'], self.run_settings['run_name'])
        config['plots_storage'] = self.experiment_workspace
        
        # Create the experiment directory
        try:
            os.makedirs(self.experiment_workspace, exist_ok=True)
        except Exception as e:
            raise RuntimeError(f"Error creating experiment directory {self.experiment_workspace}: {str(e)}")

        # Save configuration options as a JSON file for reproducibility
        config_file_path = os.path.join(self.experiment_workspace, 'run_settings.json')
        try:
            with open(config_file_path, 'w') as run_settings_file:
                json.dump(self.run_settings, run_settings_file, indent=4)
        except Exception as e:
            raise IOError(f"Error saving options to file {config_file_path}: {str(e)}")

    def load_data(self):
        """Loads the dataset based on configuration settings."""
        try:
            # Validate and retrieve the dataset type
            if self.run_settings['dataset_type'] in ['energy', 'stock']:
                # Load and preprocess data using utility function
                self.ori_data, self.min, self.max, self.reshaped_rawdata, self.rawdata_statistics, self.encoded_columns_indices_mapping, self.one_hot_encoder, self.discrete_columns = retrieve_data_based_on_config(self.run_settings)

                # Update configuration with input dimension and mappings
                # Set the input dimension based on the shape of the loaded original data
                self.run_settings['input_dim'] = np.asarray(self.ori_data).shape[2]
                # Store the mapping of encoded column indices for decoding purposes
                self.run_settings['mappings'] = self.encoded_columns_indices_mapping
                # Store the one-hot encoder used for encoding categorical features
                self.run_settings['one_hot_encoder'] = self.one_hot_encoder
                # Store the list of discrete columns for reference during data generation
                self.run_settings['discrete_columns'] = self.discrete_columns
            else:
                # Raise error for unsupported dataset types
                raise ValueError(f"Unsupported dataset type: {self.run_settings['dataset_type']}")

            # Ensure the loaded dataset is not empty
            if self.ori_data is None or len(self.ori_data) == 0:
                raise ValueError("Loaded data is empty. Please check the data source.")
        except Exception as e:
            raise RuntimeError(f"Error during data loading: {str(e)}")

    def initialize_model(self):
        """Initializes the synthetic data generation model."""
        try:
            # Create a model instance using the configuration and original data
            self.model = SyntheticDataAugmentation(self.run_settings, self.ori_data)
        except Exception as e:
            raise RuntimeError(f"Error initializing the model: {str(e)}")

    def train(self):
        """Trains the model to generate synthetic data."""
        try:
            # Call the model's train method to generate synthetic data
            self.simulated_data = self.model.train()
        except Exception as e:
            raise RuntimeError(f"Error during training: {str(e)}")

    def execute(self):
        """Executes the complete training pipeline."""
        try:
            start_time = time.time()  # Record the start time
            self.validate_options()  # Validate configuration options
            self.load_data()  # Load the dataset
            self.initialize_model()  # Initialize the model
            self.train()  # Train the model

            # Calculate execution time
            execution_time = time.time() - start_time
            print(f"Training completed in {execution_time:.2f} seconds.")

            # Post-process generated synthetic data
            if self.run_settings['dataset_type'] in ['energy', 'stock']:
                # Rescale data back to the original range
                self.simulated_data = self.simulated_data * ((self.max - self.min) + 2e-8) + self.min

                # Total number of columns
                total_columns = len(config["mappings"]) if config["mappings"] is not None else 0

                if total_columns > 0:
                    # Get the original shape of the generated data
                    original_shape = np.asarray(self.simulated_data).shape
                    # Create a new shape with the same number of samples and time steps, but with inferred features
                    new_shape = (original_shape[0], original_shape[1], -1)
                    
                    # Decoding One-Hot Encoded Columns
                    # Flatten the generated data to prepare it for decoding
                    decoded_Syntheticfeatures = decode_one_hot(
                        np.asarray(self.simulated_data).reshape(-1, config['input_dim']),
                        config['mappings'],
                        config['one_hot_encoder'],
                        config['discrete_columns']
                    )
                    # Reshape the decoded features back to the original shape with correct dimensions
                    decoded_Syntheticfeatures = decoded_Syntheticfeatures.reshape(new_shape)

                    # Return the decoded synthetic features along with reshaped raw data and statistics
                    return decoded_Syntheticfeatures, self.reshaped_rawdata, self.rawdata_statistics, self.experiment_workspace
                else:
                    # If there are no columns to decode, return the generated data as-is along with raw data and statistics
                    return self.simulated_data, self.reshaped_rawdata, self.rawdata_statistics, self.experiment_workspace    
 
        except RuntimeError as e:
            print(f"Training failed due to a runtime error: {str(e)}")
        except ValueError as e:
            print(f"Training failed due to a value error: {str(e)}")
        except FileNotFoundError as e:
            print(f"Training failed due to missing file: {str(e)}")
        except Exception as e:
            print(f"Training failed due to an unexpected error: {str(e)}")


if __name__ == '__main__':
    # Example configuration for running the trainer
    config = {
        'dataset_type': 'energy',  # Dataset type (e.g., 'energy(24)' or 'stock(6)')
        'input_dim': 24,  # Input feature dimension
        'seq_len': 24,  # Sequence length for time-series data
        'module': 'gru',  # Model module to use (e.g., GRU-based)
        'latent_dim': 16,  # Latent dimensionality
        'rnn_layers': 2,  # Number of layers in the RNN
        'num_iterations': 4000,  # Number of training iterations
        'batch_size': 128,  # Batch size for training
        'metric_iteration': 500,  # Iteration frequency for logging metrics
        'compute_target': 'gpu',  # Compute target ('gpu' or 'cpu')
        'accelerator_ids': '0',  # Comma-separated list of GPU IDs
        'num_gpus': 1,  # Number of GPUs to use
        'output_dir': './output',  # Output directory for results
        'run_name': 'Synthetic_data_Synthesis',  # Name of the training run
        'seed_value': 42,  # Seed value for reproducibility
        'checkpoint_path': '',  # Path for model checkpoint
        'adam_optimizer_beta1': 0.9,  # Beta1 parameter for Adam optimizer
        'learning_rate': 0.001,  # Learning rate
        'gamma_weight': 1,  # Weight for gamma in loss function
        'mmd_loss_weight': 0.01,
        'mmd_sigma':1,
        'reconstruct_weight': 10,
        'distribution_regularization_weight':0.001,
        'Synthesizer_loss_weight': 100,  # Weight for synthesizer loss
        'missing_percentage': None,
        'isTrain': True,  # Training flag
        'mappings': None,  # Mappings for discrete features
        'one_hot_encoder': None,  # Placeholder for one-hot encoder
        'discrete_columns': None,  # Placeholder for discrete columns
        'plots_storage': ''
    }

    # #Dynamically construct checkpoint_path using other config keys
    # config['checkpoint_path'] = f"{config['output_dir']}/{config['dataset_type']}/train/weights"

    # Set random seed for reproducibility
    torch.manual_seed(config['seed_value'])  # Set the random seed for PyTorch to ensure reproducibility
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config['seed_value'])  # Set the random seed for all GPUs if CUDA is available

    # Create a Trainer instance with the given configuration
    trainer = Trainer(config)  # Initialize the Trainer class with the provided configuration settings

    # Execute the training pipeline if dataset type is supported
    if config['dataset_type'] in ['energy', 'stock']:
        try:
            # Run the training pipeline and get results
            simulated_data, reshaped_rawdata, rawdata_statistics, plots_storage_workspace = trainer.execute()
            print("Synthetic data generated successfully.")
        except Exception as e:
            # Handle exceptions that occur during training execution
            print(f"Execution failed: {str(e)}")

    # Reshape generated data for further analysis
    _, seq_len, num_variables = simulated_data.shape  # Extract sequence length and number of variables from generated data shape
    reshaped_Synthetic_data = simulated_data.reshape(-1, num_variables)  # Reshape the synthetic data for statistical analysis

    # Calculate basic statistics for the generated data
    Syntheticdata_statistics = calculate_basic_statistics(reshaped_Synthetic_data)  # Compute basic statistics for the reshaped synthetic data      

    output_path = plots_storage_workspace  # Default output path

    if not config['isTrain'] == True:
        # Example usage:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        final_path = create_synthetic_folder(plots_storage_workspace)
        if final_path:
            output_path = final_path  # Update output path if folder creation is successful
        else:
            logging.error("Failed to create the Synthetic folder. Using default output path.")

    #Plotting code 
    plot_statistics(rawdata_statistics, Syntheticdata_statistics, len(rawdata_statistics['min']), output_path)
    plot_timeseries(reshaped_rawdata, reshaped_Synthetic_data, reshaped_Synthetic_data.shape[1], output_path)
    plot_violin(reshaped_rawdata, reshaped_Synthetic_data, reshaped_Synthetic_data.shape[1], output_path)
    plot_density(reshaped_rawdata, reshaped_Synthetic_data, reshaped_Synthetic_data.shape[1], output_path)     
    plot_box_whisker(reshaped_rawdata, reshaped_Synthetic_data, reshaped_Synthetic_data.shape[1], output_path)    

    output_file_path = os.path.join(output_path, 'simulated_data.npy')
    np.save(output_file_path, simulated_data)
    print(f"3D simulated data saved as binary file to {output_file_path}")
   