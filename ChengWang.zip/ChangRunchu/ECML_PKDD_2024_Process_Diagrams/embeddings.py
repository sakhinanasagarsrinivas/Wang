from typing import List, Dict, Union, Optional
import torch
import numpy as np
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.schema import Document
from sentence_transformers import SentenceTransformer
import yaml
from pathlib import Path

class EmbeddingManager:
    def __init__(self, config_path: str):
        """
        Initialize embedding manager with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.model = self._initialize_model()
        self.vector_store = self._initialize_vector_store()
        
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
        
    def _initialize_model(self) -> HuggingFaceEmbeddings:
        """Initialize the embedding model."""
        return HuggingFaceEmbeddings(
            model_name=self.config['vector_store']['embedding_model'],
            model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'}
        )
        
    def _initialize_vector_store(self) -> Chroma:
        """Initialize the vector store."""
        return Chroma(
            collection_name=self.config['vector_store']['collection_name'],
            embedding_function=self.model,
            persist_directory=self.config['paths']['processed_data']
        )
        
    def generate_embeddings(self, texts: Union[str, List[str]]) -> np.ndarray:
        """
        Generate embeddings for text or list of texts.
        
        Args:
            texts: Input text or list of texts
            
        Returns:
            Numpy array of embeddings
        """
        if isinstance(texts, str):
            texts = [texts]
            
        embeddings = self.model.embed_documents(texts)
        return np.array(embeddings)
    
    def store_documents(self, documents: List[Document]):
        """
        Store documents in vector store.
        
        Args:
            documents: List of Document objects to store
        """
        self.vector_store.add_documents(documents)
        self.vector_store.persist()
        
    def similarity_search(
        self,
        query: str,
        k: int = 5,
        threshold: float = 0.7
    ) -> List[Document]:
        """
        Perform similarity search for query.
        
        Args:
            query: Query text
            k: Number of results to return
            threshold: Similarity threshold
            
        Returns:
            List of similar documents
        """
        # Get query embedding
        query_embedding = self.model.embed_query(query)
        
        # Search vector store
        results = self.vector_store.similarity_search_by_vector_with_relevance_scores(
            query_embedding,
            k=k
        )
        
        # Filter by threshold
        filtered_results = [
            doc for doc, score in results
            if score >= threshold
        ]
        
        return filtered_results
    
    def batch_encode(
        self,
        texts: List[str],
        batch_size: int = 32
    ) -> np.ndarray:
        """
        Encode texts in batches.
        
        Args:
            texts: List of texts to encode
            batch_size: Batch size for processing
            
        Returns:
            Numpy array of embeddings
        """
        embeddings = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            batch_embeddings = self.generate_embeddings(batch)
            embeddings.append(batch_embeddings)
            
        return np.vstack(embeddings)
    
    def compute_similarity(
        self,
        embedding1: np.ndarray,
        embedding2: np.ndarray
    ) -> float:
        """
        Compute cosine similarity between embeddings.
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
            
        Returns:
            Similarity score
        """
        return float(np.dot(embedding1, embedding2) / 
                   (np.linalg.norm(embedding1) * np.linalg.norm(embedding2)))
    
    def create_index(self, documents: List[Document]):
        """
        Create search index from documents.
        
        Args:
            documents: List of documents to index
        """
        # Clear existing index
        self.vector_store.delete_collection()
        self.vector_store = self._initialize_vector_store()
        
        # Add documents to index
        self.store_documents(documents)
        
    def find_nearest_neighbors(
        self,
        embedding: np.ndarray,
        k: int = 5
    ) -> List[Dict]:
        """
        Find nearest neighbors for an embedding.
        
        Args:
            embedding: Query embedding
            k: Number of neighbors to return
            
        Returns:
            List of nearest neighbors with metadata
        """
        results = self.vector_store.similarity_search_by_vector_with_relevance_scores(
            embedding.tolist(),
            k=k
        )
        
        return [
            {
                'document': doc,
                'score': score
            }
            for doc, score in results
        ]
    
    def save_embeddings(self, embeddings: np.ndarray, path: str):
        """
        Save embeddings to file.
        
        Args:
            embeddings: Embeddings array
            path: Save path
        """
        np.save(path, embeddings)
        
    def load_embeddings(self, path: str) -> Optional[np.ndarray]:
        """
        Load embeddings from file.
        
        Args:
            path: File path
            
        Returns:
            Loaded embeddings array or None if loading fails
        """
        try:
            return np.load(path)
        except Exception as e:
            print(f"Error loading embeddings: {str(e)}")
            return None

    def update_embeddings(
        self,
        documents: List[Document],
        batch_size: int = 32
    ):
        """
        Update embeddings for existing documents.
        
        Args:
            documents: List of documents to update
            batch_size: Batch size for processing
        """
        # Remove existing documents
        ids = [doc.metadata.get('id') for doc in documents if 'id' in doc.metadata]
        self.vector_store.delete(ids)
        
        # Add updated documents
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]
            self.store_documents(batch)