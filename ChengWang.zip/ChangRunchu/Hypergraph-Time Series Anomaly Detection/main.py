# main.py

import argparse
import logging
from pathlib import Path
import json
import torch
from datetime import datetime

from config import ExperimentConfig
from data_processor import DataProcessor
from models import HgAD
from trainer import Trainer
from evaluation import ModelEvaluator
from utils import setup_logging, set_random_seed

def parse_args():
    parser = argparse.ArgumentParser(description='HgAD: Hypergraph Learning based Anomaly Detection')
    
    # Basic arguments
    parser.add_argument('--config', type=str, default='configs/default.json',
                        help='Path to config file')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['SWAT', 'WADI', 'SMAP', 'MSL', 'TEP', 'HAI'],
                        help='Dataset to use')
    parser.add_argument('--mode', type=str, default='train',
                        choices=['train', 'test', 'analyze'],
                        help='Mode of operation')
    
    # Training arguments
    parser.add_argument('--epochs', type=int, help='Number of epochs to train')
    parser.add_argument('--batch_size', type=int, help='Batch size')
    parser.add_argument('--lr', type=float, help='Learning rate')
    
    # Model arguments
    parser.add_argument('--embedding_dim', type=int, help='Embedding dimension')
    parser.add_argument('--hidden_dim', type=int, help='Hidden dimension')
    parser.add_argument('--num_layers', type=int, help='Number of layers')
    
    # Other arguments
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--checkpoint', type=str, help='Path to model checkpoint')
    parser.add_argument('--output_dir', type=str, default='outputs',
                        help='Output directory')
    
    return parser.parse_args()

def main():
    # Parse arguments
    args = parse_args()
    
    # Setup experiment
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    experiment_name = f"{args.dataset}_{timestamp}"
    
    # Create output directory
    output_dir = Path(args.output_dir) / experiment_name
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Setup logging
    setup_logging(output_dir / 'experiment.log')
    logger = logging.getLogger(__name__)
    logger.info(f"Starting experiment: {experiment_name}")
    
    # Set random seed
    set_random_seed(args.seed)
    
    # Load config
    config = ExperimentConfig.load(args.config)
    
    # Update config with command line arguments
    if args.epochs:
        config.model.num_epochs = args.epochs
    if args.batch_size:
        config.model.batch_size = args.batch_size
    if args.lr:
        config.model.learning_rate = args.lr
    if args.embedding_dim:
        config.model.embedding_dim = args.embedding_dim
    if args.hidden_dim:
        config.model.hidden_dim = args.hidden_dim
    if args.num_layers:
        config.model.num_layers = args.num_layers
        
    # Save updated config
    config.save(output_dir / 'config.json')
    
    # Initialize data processor
    data_processor = DataProcessor(config)
    
    # Load data
    train_loader, val_loader, test_loader = data_processor.load_data(args.dataset)
    logger.info(f"Loaded {args.dataset} dataset")
    
    # Get number of nodes (sensors)
    num_nodes = train_loader.dataset.data.size(1)
    
    # Initialize model
    model = HgAD(config.model, num_nodes).to(config.model.device)
    logger.info(f"Initialized model with {sum(p.numel() for p in model.parameters())} parameters")
    
    if args.mode == 'train':
        # Train model
        trainer = Trainer(model, config)
        model = trainer.train(train_loader, val_loader, test_loader)
        
        # Save final model
        torch.save({
            'model_state_dict': model.state_dict(),
            'config': config.to_dict()
        }, output_dir / 'model_final.pt')
        
    elif args.mode == 'test':
        # Load checkpoint
        if args.checkpoint:
            checkpoint = torch.load(args.checkpoint)
            model.load_state_dict(checkpoint['model_state_dict'])
            logger.info(f"Loaded model from {args.checkpoint}")
        else:
            raise ValueError("Checkpoint path required for test mode")
            
    # Evaluate model
    evaluator = ModelEvaluator(model, config, data_processor)
    results = evaluator.evaluate_model(
        test_loader,
        save_dir=output_dir / 'evaluation'
    )
    
    # Save results
    with open(output_dir / 'results.json', 'w') as f:
        json.dump(results, f, indent=4)
        
    logger.info("Experiment completed successfully")

if __name__ == "__main__":
    main()