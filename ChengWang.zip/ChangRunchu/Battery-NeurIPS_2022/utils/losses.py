


# utils/losses.py
class GaussianNLLLoss(nn.Module):
    """
    Gaussian Negative Log Likelihood Loss (equations 6-10)
    """
    def forward(self, mu, log_var, target):
        var = torch.exp(log_var)
        loss = 0.5 * (log_var + (target - mu).pow(2) / var)
        return loss.mean()

