import cv2
import numpy as np
from torchvision import transforms
from typing import Tuple, List
import torch

class ImagePreprocessor:
    def __init__(self, image_size: int = 224):
        self.image_size = image_size
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5],
                              std=[0.5, 0.5, 0.5])
        ])

    def preprocess_image(self, image: np.ndarray) -> torch.Tensor:
        """Preprocess a single image."""
        if len(image.shape) == 2:  # Grayscale
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        return self.transform(image)

class TextPreprocessor:
    def __init__(self, max_length: int = 512):
        self.max_length = max_length
        
    def preprocess_text(self, text: str) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Preprocess text input using LLAMA tokenizer.
        Returns input_ids and attention_mask.
        """
        # Import here to avoid circular imports
        from transformers import LlamaTokenizer
        
        tokenizer = LlamaTokenizer.from_pretrained("meta-llama/Llama-2-7b")
        encoded = tokenizer(
            text,
            padding="max_length",
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt"
        )
        return encoded["input_ids"], encoded["attention_mask"]

def create_patches(image: torch.Tensor, patch_size: int = 32) -> torch.Tensor:
    """Create patches from image for Vision Transformer."""
    B, C, H, W = image.shape
    patches = image.unfold(2, patch_size, patch_size).unfold(3, patch_size, patch_size)
    patches = patches.contiguous().view(B, C, -1, patch_size, patch_size)
    patches = patches.permute(0, 2, 1, 3, 4).contiguous()
    patches = patches.view(B, -1, C * patch_size * patch_size)
    return patches

def prepare_batch(
    images: List[np.ndarray],
    texts: List[str],
    image_processor: ImagePreprocessor,
    text_processor: TextPreprocessor
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Prepare a batch of data for training."""
    processed_images = torch.stack([
        image_processor.preprocess_image(img) for img in images
    ])
    
    input_ids_list = []
    attention_mask_list = []
    
    for text in texts:
        input_ids, attention_mask = text_processor.preprocess_text(text)
        input_ids_list.append(input_ids)
        attention_mask_list.append(attention_mask)
    
    input_ids = torch.cat(input_ids_list, dim=0)
    attention_mask = torch.cat(attention_mask_list, dim=0)
    
    return processed_images, input_ids, attention_mask