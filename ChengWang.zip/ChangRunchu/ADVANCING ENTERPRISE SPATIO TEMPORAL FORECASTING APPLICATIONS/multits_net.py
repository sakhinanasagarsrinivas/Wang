import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple
import numpy as np

from prompt_pool import DynamicPromptPool

class GroupedQueryAttention(nn.Module):
    """Grouped-Query Attention mechanism"""
    def __init__(self, dim: int, num_heads: int = 4, num_groups: int = 3):
        super().__init__()
        self.num_heads = num_heads
        self.num_groups = num_groups
        self.head_dim = dim // num_heads
        
        # Projections
        self.q_proj = nn.Linear(dim, num_groups * self.head_dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, N, C = x.shape
        
        # Project to queries, keys, and values
        q = self.q_proj(x).reshape(B, N, self.num_groups, -1)
        k = self.k_proj(x).reshape(B, N, self.num_heads, -1)
        v = self.v_proj(x).reshape(B, N, self.num_heads, -1)
        
        # Compute attention scores
        scores = torch.einsum('bngd,bnhd->bngh', q, k) / np.sqrt(self.head_dim)
        attn = F.softmax(scores, dim=-1)
        
        # Apply attention to values
        out = torch.einsum('bngh,bnhd->bngd', attn, v)
        out = out.reshape(B, N, -1)
        
        return self.out_proj(out)

class ChebyshevGraphConv(nn.Module):
    """Chebyshev Graph Convolution layer"""
    def __init__(self, in_channels: int, out_channels: int, K: int = 3):
        super().__init__()
        self.K = K
        self.weights = nn.ParameterList([
            nn.Parameter(torch.randn(in_channels, out_channels)) 
            for _ in range(K)
        ])
        
    def forward(self, x: torch.Tensor, laplacian: torch.Tensor) -> torch.Tensor:
        # Compute Chebyshev polynomials
        Tx_0 = x  # T_0(L)x = x
        output = torch.matmul(Tx_0, self.weights[0])
        
        if self.K > 1:
            Tx_1 = torch.matmul(laplacian, x)  # T_1(L)x = Lx
            output += torch.matmul(Tx_1, self.weights[1])
            
            for k in range(2, self.K):
                Tx_2 = 2 * torch.matmul(laplacian, Tx_1) - Tx_0
                output += torch.matmul(Tx_2, self.weights[k])
                Tx_0, Tx_1 = Tx_1, Tx_2
                
        return output

class MultiTsNet(nn.Module):
    """
    MultiTs Net implementation following the ICLR 2024 paper
    """
    def __init__(self, config: Dict):
        super().__init__()
        self.config = config
        
        # Model dimensions
        self.input_dim = config['model']['input_dim']
        self.embedding_dim = config['model']['embedding_dimension']
        self.window_size = config['model']['window_size']
        
        # Dynamic Prompt Pool
        self.prompt_pool = DynamicPromptPool(
            pool_size=config['model']['prompt_pool']['size'],
            embedding_dim=self.embedding_dim
        )
        
        # Time-then-space modeling components
        self.temporal_encoder = self._build_temporal_encoder()
        self.spatial_encoder = self._build_spatial_encoder()
        
        # Graph convolution
        self.graph_conv = ChebyshevGraphConv(
            self.embedding_dim,
            self.embedding_dim,
            K=config['model']['spatial']['chebyshev_order']
        )
        
        # Cross-modal fusion
        self.fusion_layer = nn.Sequential(
            nn.Linear(self.embedding_dim * 3, self.embedding_dim),
            nn.LayerNorm(self.embedding_dim),
            nn.ReLU()
        )
        
        # Output layer
        self.forecast_head = nn.Linear(self.embedding_dim, self.input_dim)
        
    def _build_temporal_encoder(self) -> nn.ModuleList:
        return nn.ModuleList([
            GroupedQueryAttention(
                dim=self.embedding_dim,
                num_heads=self.config['model']['attention']['num_heads'],
                num_groups=self.config['model']['attention']['num_groups']
            ) for _ in range(3)
        ])
        
    def _build_spatial_encoder(self) -> GroupedQueryAttention:
        return GroupedQueryAttention(
            dim=self.embedding_dim,
            num_heads=self.config['model']['attention']['num_heads'],
            num_groups=self.config['model']['attention']['num_groups']
        )
        
    def forward(
        self,
        x: torch.Tensor,
        adj_matrix: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        batch_size, num_nodes, seq_len, features = x.shape
        
        # Initial embedding and prompt retrieval
        x = x.view(batch_size * num_nodes, seq_len, features)
        prompt_embedding, _ = self.prompt_pool(x)
        x = x + prompt_embedding.unsqueeze(1)
        
        # Temporal modeling
        temporal_features = x
        for temporal_layer in self.temporal_encoder:
            temporal_features = temporal_layer(temporal_features)
            
        # Reshape for spatial modeling
        spatial_input = temporal_features.view(batch_size, num_nodes, seq_len, -1)
        spatial_features = self.spatial_encoder(spatial_input)
        
        # Graph convolution if adjacency matrix provided
        if adj_matrix is not None:
            graph_features = self.graph_conv(spatial_features, adj_matrix)
        else:
            graph_features = spatial_features
            
        # Feature fusion
        fused_features = self.fusion_layer(
            torch.cat([
                temporal_features,
                spatial_features,
                graph_features
            ], dim=-1)
        )
        
        # Generate forecast
        forecast = self.forecast_head(fused_features)
        
        return forecast

class UncertainMultiTsNet(MultiTsNet):
    """
    Uncertainty-aware variant of MultiTs Net
    """
    def __init__(self, config: Dict):
        super().__init__(config)
        
        # Uncertainty estimation head
        self.uncertainty_head = nn.Sequential(
            nn.Linear(self.embedding_dim, self.embedding_dim),
            nn.ReLU(),
            nn.Linear(self.embedding_dim, 2 * self.input_dim)  # Mean and log variance
        )
        
    def forward(
        self,
        x: torch.Tensor,
        adj_matrix: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        # Get base features
        features = super().forward(x, adj_matrix)
        
        # Estimate uncertainty parameters
        uncertainty_params = self.uncertainty_head(features)
        mean, log_var = torch.chunk(uncertainty_params, 2, dim=-1)
        
        return {
            'forecast': mean,
            'variance': F.softplus(log_var),
            'features': features
        }
        
    def gaussian_nll_loss(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: torch.Tensor
    ) -> torch.Tensor:
        """
        Calculate Gaussian Negative Log-Likelihood loss
        
        Args:
            predictions: Dictionary containing 'forecast' and 'variance'
            targets: Ground truth values
            
        Returns:
            Gaussian NLL loss value
        """
        mean = predictions['forecast']
        variance = predictions['variance']
        
        # Compute Gaussian NLL loss
        loss = 0.5 * (
            torch.log(variance) +
            ((targets - mean) ** 2) / variance +
            torch.log(torch.tensor(2 * np.pi))
        ).mean()
        
        return loss
        
def custom_loss(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    uncertainty_output: Optional[Dict[str, torch.Tensor]] = None
) -> torch.Tensor:
    """
    Custom loss function for both base and uncertainty-aware models
    
    Args:
        predictions: Model predictions
        targets: Ground truth values
        uncertainty_output: Optional uncertainty parameters
        
    Returns:
        Combined loss value
    """
    # Base loss (Mean Absolute Error)
    base_loss = F.l1_loss(predictions, targets)
    
    if uncertainty_output is not None:
        # Add uncertainty loss component
        mean = uncertainty_output['forecast']
        variance = uncertainty_output['variance']
        
        uncertainty_loss = 0.5 * (
            torch.log(variance) +
            ((targets - mean) ** 2) / variance
        ).mean()
        
        return base_loss + uncertainty_loss
    
    return base_loss