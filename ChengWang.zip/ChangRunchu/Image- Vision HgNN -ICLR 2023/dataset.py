import torch
from torch.utils.data import Dataset
import torchvision.transforms as transforms
import os
from PIL import Image
import numpy as np

class SEMDataset(Dataset):
    """
    Scanning Electron Microscopy (SEM) Dataset
    Follows the dataset description in the paper
    """
    def __init__(self, root_dir, transform=None, train=True):
        self.root_dir = root_dir
        self.transform = transform or self._get_default_transform()
        self.train = train
        
        # Categories as described in the paper
        self.categories = [
            'Biological', 'Tips', 'Fibres', 'Porous Sponge', 
            'Films Coated Surface', 'Patterned surface', 
            'Nanowires', 'Particles', 'MEMS devices', 'Powder'
        ]
        
        # Load image paths and labels
        self.image_paths = []
        self.labels = []
        self._load_dataset()
    
    def _get_default_transform(self):
        """
        Preprocessing transform following paper's description
        - Resize to 256x256
        - Normalize to [-1, 1] range
        """
        return transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        ])
    
    def _load_dataset(self):
        """
        Load dataset following the paper's dataset description
        Handling imbalanced dataset characteristics
        """
        for label, category in enumerate(self.categories):
            category_path = os.path.join(self.root_dir, category)
            for img_name in os.listdir(category_path):
                img_path = os.path.join(category_path, img_name)
                self.image_paths.append(img_path)
                self.labels.append(label)
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        return image, self.labels[idx]