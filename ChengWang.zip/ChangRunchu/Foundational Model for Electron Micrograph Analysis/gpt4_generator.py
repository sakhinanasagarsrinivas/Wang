# data_generation/gpt4_generator.py
import openai
from PIL import Image
import base64
import io
import json
import os
from tqdm import tqdm

class GPT4VisionTeacher:
    """GPT-4V teacher for generating synthetic instruction data"""
    def __init__(self, api_key, prompts_path):
        self.api_key = api_key
        openai.api_key = api_key
        self.prompts = self.load_prompts(prompts_path)
        
    def load_prompts(self, prompts_path):
        with open(prompts_path, 'r') as f:
            return json.load(f)
    
    def encode_image(self, image_path):
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    
    def generate_instruction(self, image_path, task_type):
        """Generate instruction-following data using GPT-4V"""
        base64_image = self.encode_image(image_path)
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4-vision-preview",
                messages=[
                    {
                        "role": "system",
                        "content": self.prompts[task_type]["system"]
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": self.prompts[task_type]["user"]},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_image}"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=500
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating instruction for {image_path}: {e}")
            return None

class SyntheticDataGenerator:
    """Generate synthetic training data using GPT-4V teacher"""
    def __init__(self, config):
        self.config = config
        self.teacher = GPT4VisionTeacher(config.api_key, config.prompts_path)
        
    def generate_dataset(self, image_dir, output_dir, task_type):
        """Generate synthetic dataset for training"""
        os.makedirs(output_dir, exist_ok=True)
        dataset = []
        
        # Process all images in directory
        image_files = [f for f in os.listdir(image_dir) if f.endswith(('.jpg', '.png'))]
        for img_file in tqdm(image_files):
            img_path = os.path.join(image_dir, img_file)
            
            # Generate instruction data
            instruction_data = self.teacher.generate_instruction(img_path, task_type)
            if instruction_data:
                dataset.append({
                    'image_path': img_path,
                    'instruction': instruction_data,
                    'task_type': task_type
                })
        
        # Save dataset
        output_path = os.path.join(output_dir, f'{task_type}_dataset.json')
        with open(output_path, 'w') as f:
            json.dump(dataset, f, indent=2)
        
        return dataset






