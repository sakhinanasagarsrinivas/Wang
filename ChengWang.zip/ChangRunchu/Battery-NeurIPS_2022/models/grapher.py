import torch
import torch.nn as nn
import torch.nn.functional as F

class GrapherModule(nn.Module):
    """
    Grapher module combining GNN and RNN blocks as described in Section 3.2.
    """
    def __init__(self, input_dim, hidden_dim, dropout=0.5):
        super(GrapherModule, self).__init__()
        
        # GNN blocks
        self.gcn1 = GraphConvLayer(input_dim, hidden_dim)
        self.gcn2 = GraphConvLayer(hidden_dim, hidden_dim)
        self.batch_norm1 = nn.BatchNorm1d(hidden_dim)
        self.batch_norm2 = nn.BatchNorm1d(hidden_dim)
        self.dropout = nn.Dropout(dropout)
        
        # RNN block (double-stacked GRU)
        self.gru = nn.GRU(
            input_size=2*hidden_dim,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            dropout=dropout
        )

    def forward(self, x, A_t):
        # First GNN block
        h1 = self.gcn1(x, A_t)
        h1 = self.batch_norm1(h1.transpose(1,2)).transpose(1,2)
        h1 = F.relu(self.dropout(h1))
        
        # Second GNN block
        h2 = self.gcn2(h1, A_t)
        h2 = self.batch_norm2(h2.transpose(1,2)).transpose(1,2)
        h2 = F.relu(self.dropout(h2))
        
        # Concatenate for spatio-temporal features
        h = torch.cat([h1, h2], dim=-1)
        
        # RNN processing
        h_out, _ = self.gru(h)
        
        return h_out

class GraphConvLayer(nn.Module):
    """
    Graph Convolution Layer implementing equation 2.
    """
    def __init__(self, in_dim, out_dim):
        super(GraphConvLayer, self).__init__()
        self.W = nn.Parameter(torch.FloatTensor(in_dim, out_dim))
        self.reset_parameters()
        
    def reset_parameters(self):
        nn.init.xavier_uniform_(self.W)
        
    def forward(self, x, A):
        # Degree normalization
        D = torch.sum(A, dim=-1)
        D = torch.diag_embed(D.pow(-0.5))
        
        # Normalized adjacency matrix
        A_norm = torch.matmul(torch.matmul(D, A), D)
        
        # GCN operation (equation 2)
        support = torch.matmul(x, self.W)
        output = torch.matmul(A_norm, support)
        return output