import argparse
import logging
from pathlib import Path
import torch
from torch.utils.data import DataLoader
import wandb
from typing import Dict, Any

from constants import (
    ModelConfig, 
    TrainingConfig, 
    TaskConfig,
    TRAFFIC_DATASETS,
    ANOMALY_DATASETS
)
from models import MasterAgent
from training import AgentTrainer
from datasets import (
    load_traffic_dataset,
    load_anomaly_dataset
)
from utils import set_seed

def parse_args():
    parser = argparse.ArgumentParser(description='Train Agentic-RAG for Time Series')
    
    # Required arguments
    parser.add_argument('--task', type=str, required=True,
                       choices=['forecasting', 'anomaly_detection', 'imputation', 'classification'],
                       help='Task type to train')
    parser.add_argument('--dataset', type=str, required=True,
                       help='Dataset name (e.g., PeMSD3, METR-LA, SWaT)')
    
    # Data paths
    parser.add_argument('--data_dir', type=str, default='data',
                       help='Base directory for datasets')
    
    # Model configuration
    parser.add_argument('--model_name', type=str, 
                       default='meta-llama/Llama-2-7b',
                       help='Base LLM model name')
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--seq_length', type=int, default=512)
    parser.add_argument('--pred_length', type=int, default=12)
    
    # Training configuration
    parser.add_argument('--epochs', type=int, default=15)
    parser.add_argument('--lr', type=float, default=1e-5)
    parser.add_argument('--dpo_epochs', type=int, default=3)
    parser.add_argument('--dpo_lr', type=float, default=5e-7)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--num_workers', type=int, default=4)
    
    # Experiment tracking
    parser.add_argument('--exp_name', type=str, default=None,
                       help='Experiment name for wandb')
    
    return parser.parse_args()

def setup_experiment(args) -> Dict[str, Any]:
    """Setup experiment configurations"""
    # Set random seed
    set_seed(args.seed)
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create configs
    model_config = ModelConfig(
        model_name=args.model_name
    )
    
    training_config = TrainingConfig(
        learning_rate=args.lr,
        num_epochs=args.epochs,
        batch_size=args.batch_size,
        dpo_learning_rate=args.dpo_lr,
        dpo_epochs=args.dpo_epochs
    )
    
    task_config = TaskConfig()
    if args.task == 'forecasting':
        task_config.forecast_window_size = args.seq_length
        task_config.forecast_horizon = args.pred_length
        
    # Create experiment name if not provided
    exp_name = args.exp_name or f"{args.task}_{args.dataset}_{args.model_name.split('/')[-1]}"
    
    return {
        "model_config": model_config,
        "training_config": training_config,
        "task_config": task_config,
        "exp_name": exp_name
    }

def load_datasets(args, task_config):
    """Load appropriate datasets based on task and dataset name"""
    data_dir = Path(args.data_dir)
    
    if args.dataset in TRAFFIC_DATASETS:
        train_dataset, val_dataset, test_dataset = load_traffic_dataset(
            args.dataset,
            task_config,
            data_dir
        )
    elif args.dataset in ANOMALY_DATASETS:
        train_dataset, val_dataset, test_dataset = load_anomaly_dataset(
            args.dataset,
            task_config,
            data_dir
        )
    else:
        raise ValueError(f"Unknown dataset: {args.dataset}")
        
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers
    )
    
    return train_loader, val_loader, test_loader

def main():
    # Parse arguments
    args = parse_args()
    
    # Setup experiment
    configs = setup_experiment(args)
    logging.info(f"Starting experiment: {configs['exp_name']}")
    
    # Load datasets
    train_loader, val_loader, test_loader = load_datasets(args, configs["task_config"])
    
    # Initialize master agent
    master_agent = MasterAgent(
        model_config=configs["model_config"],
        task_config=configs["task_config"],
        device=args.device
    )
    
    # Get task-specific agent
    agent = master_agent.get_agent(args.task)
    
    # Initialize trainer
    trainer = AgentTrainer(
        agent=agent,
        train_loader=train_loader,
        val_loader=val_loader,
        config=configs["training_config"],
        task_type=args.task,
        experiment_name=configs["exp_name"]
    )
    
    # Training phase
    logging.info("Starting training...")
    trainer.train()
    
    # DPO phase
    if args.dpo_epochs > 0:
        logging.info("Starting DPO training...")
        # Create preference pairs from validation set
        val_predictions = []
        val_targets = []
        agent.eval()
        with torch.no_grad():
            for data, target in val_loader:
                data = data.to(args.device)
                outputs = agent(data)
                val_predictions.extend(outputs["predictions"].cpu())
                val_targets.extend(target.cpu())
                
        val_predictions = torch.stack(val_predictions)
        val_targets = torch.stack(val_targets)
        
        # Create preference pairs based on prediction error
        preferred_data, dispreferred_data = create_preference_pairs(
            val_predictions,
            val_targets
        )
        
        # Create preference dataloaders
        preferred_loader = DataLoader(
            preferred_data,
            batch_size=configs["training_config"].dpo_batch_size,
            shuffle=True
        )
        dispreferred_loader = DataLoader(
            dispreferred_data,
            batch_size=configs["training_config"].dpo_batch_size,
            shuffle=True
        )
        
        # Train with DPO
        trainer.train_with_dpo(preferred_loader, dispreferred_loader)
    
    # Testing phase
    logging.info("Starting testing...")
    test_metrics = trainer.test()
    logging.info(f"Test metrics: {test_metrics}")
    
    # Close wandb
    wandb.finish()

if __name__ == "__main__":
    main()