import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel
from typing import Dict, List, Tuple, Optional

class DynamicPromptPool(nn.Module):
    """
    Dynamic Prompt Pool implementation following the paper's methodology
    """
    def __init__(
        self,
        pool_size: int,
        embedding_dim: int,
        llm_name: str = "meta-llama/Llama-2-7b-chat-hf",
        instruction_llm: str = "meta-llama/Llama-2-70b-chat-hf"
    ):
        super().__init__()
        
        # Pool parameters
        self.pool_size = pool_size
        self.embedding_dim = embedding_dim
        
        # Initialize prompt key-value pairs
        self.prompt_keys = nn.Parameter(torch.randn(pool_size, embedding_dim))
        self.prompt_values = nn.Parameter(torch.randn(pool_size, embedding_dim))
        
        # Projection layers
        self.query_proj = nn.Linear(embedding_dim, embedding_dim)
        self.key_proj = nn.Linear(embedding_dim, embedding_dim)
        self.value_proj = nn.Linear(embedding_dim, embedding_dim)
        
        # Load LLMs
        self.tokenizer = AutoTokenizer.from_pretrained(llm_name)
        self.llm = AutoModel.from_pretrained(llm_name)
        self.instruction_llm = AutoModel.from_pretrained(instruction_llm)
        
        # Initialize MoPE components
        self.initialize_mope()

    def initialize_mope(self):
        """Initialize Mixture of Parameter-Efficient Experts"""
        self.num_experts = 4
        self.expert_rank = 16
        
        # Expert components
        self.expert_weights = nn.Parameter(
            torch.randn(self.num_experts, self.embedding_dim, self.expert_rank)
        )
        self.expert_projections = nn.Parameter(
            torch.randn(self.num_experts, self.expert_rank, self.embedding_dim)
        )
        
        # Router network
        self.router = nn.Sequential(
            nn.Linear(self.embedding_dim, self.embedding_dim // 2),
            nn.ReLU(),
            nn.Linear(self.embedding_dim // 2, self.num_experts),
            nn.Softmax(dim=-1)
        )

    def generate_instruction_data(self, time_series: torch.Tensor) -> str:
        """Generate instruction data using larger LLM"""
        # Extract basic statistics
        stats = self._compute_statistics(time_series)
        
        # Create prompt template
        prompt = f"""Analyze the following time series:
        Mean: {stats['mean']:.2f}
        Std: {stats['std']:.2f}
        Trend: {stats['trend']}
        Describe the key patterns and characteristics."""
        
        # Generate instruction using the larger model
        tokens = self.tokenizer(prompt, return_tensors="pt")
        with torch.no_grad():
            output = self.instruction_llm(**tokens)
            instruction_embedding = output.last_hidden_state.mean(dim=1)
            
        return instruction_embedding

    def _compute_statistics(self, time_series: torch.Tensor) -> Dict:
        """Compute basic time series statistics"""
        mean = time_series.mean().item()
        std = time_series.std().item()
        
        # Simple trend detection
        slope = (time_series[-1] - time_series[0]) / (len(time_series) - 1)
        trend = "increasing" if slope > 0 else "decreasing"
        
        return {"mean": mean, "std": std, "trend": trend}

    def apply_mope(self, x: torch.Tensor) -> torch.Tensor:
        """Apply Mixture of Parameter-Efficient Experts"""
        # Get routing probabilities
        routing_weights = self.router(x)  # [batch_size, num_experts]
        
        # Apply experts
        expert_outputs = []
        for i in range(self.num_experts):
            # Expert-specific transformation
            expert_out = torch.matmul(
                torch.matmul(x, self.expert_weights[i]),
                self.expert_projections[i]
            )
            expert_outputs.append(expert_out)
            
        expert_outputs = torch.stack(expert_outputs, dim=1)
        
        # Combine expert outputs using routing weights
        output = torch.sum(expert_outputs * routing_weights.unsqueeze(-1), dim=1)
        return output

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass for prompt retrieval
        
        Args:
            x: Input tensor [batch_size, seq_length, embedding_dim]
            
        Returns:
            Tuple of (contextualized embedding, attention weights)
        """
        batch_size = x.shape[0]
        
        # Get instruction embedding
        instruction_embedding = self.generate_instruction_data(x)
        
        # Combine with input features
        query = self.query_proj(x.mean(dim=1) + instruction_embedding)
        keys = self.key_proj(self.prompt_keys)
        values = self.value_proj(self.prompt_values)
        
        # Compute attention scores
        attention_scores = torch.matmul(query, keys.transpose(-2, -1))
        attention_scores = attention_scores / torch.sqrt(torch.tensor(self.embedding_dim).float())
        attention_weights = F.softmax(attention_scores, dim=-1)
        
        # Get top-k prompts
        top_k = min(5, self.pool_size)
        top_weights, top_indices = torch.topk(attention_weights, top_k, dim=-1)
        
        # Gather and combine prompts
        selected_prompts = values[top_indices]
        weighted_prompts = selected_prompts * top_weights.unsqueeze(-1)
        combined_prompts = weighted_prompts.sum(dim=1)
        
        # Apply MoPE
        output = self.apply_mope(combined_prompts)
        
        return output, attention_weights
        
    def update_prompt_pool(self, new_patterns: torch.Tensor, importance: torch.Tensor):
        """Update prompt pool with new patterns"""
        with torch.no_grad():
            # Find least relevant prompts
            relevance_scores = torch.norm(self.prompt_values, dim=1)
            _, update_indices = torch.topk(relevance_scores, k=len(new_patterns), largest=False)
            
            # Update prompts
            for i, idx in enumerate(update_indices):
                if i < len(new_patterns):
                    self.prompt_keys.data[idx] = new_patterns[i]
                    self.prompt_values.data[idx] = importance[i] * new_patterns[i]