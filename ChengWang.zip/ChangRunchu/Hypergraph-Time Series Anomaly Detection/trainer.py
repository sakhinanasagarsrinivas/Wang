# trainer.py

import torch
import torch.nn as nn
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler
import numpy as np
from typing import Dict, Any, Optional
from pathlib import Path
import logging
import wandb
from tqdm import tqdm
import time
from datetime import datetime

logger = logging.getLogger(__name__)

class EarlyStopping:
    """Early stopping to prevent overfitting"""
    def __init__(self, patience: int = 7, min_delta: float = 0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False
        
    def __call__(self, val_loss: float) -> bool:
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss > self.best_loss - self.min_delta:
            self.counter += 1
            if self.counter >= self.patience:
                return True
        else:
            self.best_loss = val_loss
            self.counter = 0
        return False

class Trainer:
    """Model trainer class"""
    def __init__(self, model: nn.Module, config: Any):
        self.model = model
        self.config = config
        
        # Setup optimizer
        self.optimizer = self._get_optimizer()
        self.scheduler = self._get_scheduler()
        
        # Loss functions
        self.forecast_criterion = nn.MSELoss()
        self.anomaly_criterion = nn.BCELoss()
        
        # Mixed precision training
        self.scaler = GradScaler() if config.training.use_mixed_precision else None
        
        # Early stopping
        self.early_stopping = EarlyStopping(
            patience=config.model.early_stopping_patience
        )
        
        # Metrics tracking
        self.train_metrics = {}
        self.val_metrics = {}
        self.test_metrics = {}
        
        # Initialize wandb if needed
        if config.training.use_wandb:
            self._init_wandb()
            
    def _get_optimizer(self) -> torch.optim.Optimizer:
        """Get optimizer based on config"""
        if self.config.training.optimizer.lower() == 'adam':
            return optim.Adam(
                self.model.parameters(),
                lr=self.config.model.learning_rate,
                weight_decay=self.config.model.weight_decay
            )
        # Add more optimizers as needed
        raise ValueError(f"Unknown optimizer: {self.config.training.optimizer}")
        
    def _get_scheduler(self) -> Optional[torch.optim.lr_scheduler._LRScheduler]:
        """Get learning rate scheduler based on config"""
        if self.config.training.scheduler == 'reduce_lr_on_plateau':
            return optim.lr_scheduler.ReduceLROnPlateau(
                self.optimizer,
                mode='min',
                factor=self.config.training.scheduler_factor,
                patience=self.config.training.scheduler_patience,
                min_lr=self.config.training.min_lr
            )
        return None
        
    def _init_wandb(self):
        """Initialize Weights & Biases logging"""
        wandb.init(
            project="hgad",
            name=self.config.experiment_name,
            config=self.config.to_dict()
        )
        
    def train_epoch(self, train_loader) -> Dict[str, float]:
        """Train for one epoch"""
        self.model.train()
        total_loss = 0
        total_forecast_loss = 0
        total_anomaly_loss = 0
        
        pbar = tqdm(train_loader, desc='Training')
        for x, y in pbar:
            x, y = x.to(self.config.model.device), y.to(self.config.model.device)
            
            # Forward pass with mixed precision
            with autocast(enabled=self.config.training.use_mixed_precision):
                forecasts, anomaly_scores = self.model(x)
                
                # Compute losses
                forecast_loss = self.forecast_criterion(forecasts, y)
                anomaly_loss = self.anomaly_criterion(
                    anomaly_scores, 
                    (torch.abs(forecasts - y) > self.config.model.anomaly_threshold).float()
                )
                
                loss = (self.config.model.prediction_loss_weight * forecast_loss + 
                       self.config.model.attention_loss_weight * anomaly_loss)
            
            # Backward pass
            self.optimizer.zero_grad()
            if self.scaler is not None:
                self.scaler.scale(loss).backward()
                if self.config.training.clip_grad_norm:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.config.training.max_grad_norm
                    )
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                loss.backward()
                if self.config.training.clip_grad_norm:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.config.training.max_grad_norm
                    )
                self.optimizer.step()
            
            # Update metrics
            total_loss += loss.item()
            total_forecast_loss += forecast_loss.item()
            total_anomaly_loss += anomaly_loss.item()
            
            # Update progress bar
            pbar.set_postfix({
                'loss': loss.item(),
                'forecast_loss': forecast_loss.item(),
                'anomaly_loss': anomaly_loss.item()
            })
        
        # Compute average losses
        avg_loss = total_loss / len(train_loader)
        avg_forecast_loss = total_forecast_loss / len(train_loader)
        avg_anomaly_loss = total_anomaly_loss / len(train_loader)
        
        metrics = {
            'loss': avg_loss,
            'forecast_loss': avg_forecast_loss,
            'anomaly_loss': avg_anomaly_loss
        }
        
        return metrics
    
    @torch.no_grad()
    def evaluate(self, data_loader, prefix: str = 'val') -> Dict[str, float]:
        """Evaluate model"""
        self.model.eval()
        total_loss = 0
        total_forecast_loss = 0
        total_anomaly_loss = 0
        
        predictions = []
        targets = []
        anomaly_scores_list = []
        
        for x, y in data_loader:
            x, y = x.to(self.config.model.device), y.to(self.config.model.device)
            
            # Forward pass
            forecasts, anomaly_scores = self.model(x)
            
            # Compute losses
            forecast_loss = self.forecast_criterion(forecasts, y)
            anomaly_loss = self.anomaly_criterion(
                anomaly_scores,
                (torch.abs(forecasts - y) > self.config.model.anomaly_threshold).float()
            )
            
            loss = (self.config.model.prediction_loss_weight * forecast_loss +
                   self.config.model.attention_loss_weight * anomaly_loss)
            
            # Update metrics
            total_loss += loss.item()
            total_forecast_loss += forecast_loss.item()
            total_anomaly_loss += anomaly_loss.item()
            
            # Store predictions and targets
            predictions.extend(forecasts.cpu().numpy())
            targets.extend(y.cpu().numpy())
            anomaly_scores_list.extend(anomaly_scores.cpu().numpy())
        
        # Compute average losses
        metrics = {
            f'{prefix}_loss': total_loss / len(data_loader),
            f'{prefix}_forecast_loss': total_forecast_loss / len(data_loader),
            f'{prefix}_anomaly_loss': total_anomaly_loss / len(data_loader)
        }
        
        # Compute additional metrics
        predictions = np.array(predictions)
        targets = np.array(targets)
        anomaly_scores = np.array(anomaly_scores_list)
        
        metrics.update(self._compute_metrics(predictions, targets, anomaly_scores, prefix))
        
        return metrics
    
    def _compute_metrics(
        self, 
        predictions: np.ndarray,
        targets: np.ndarray,
        anomaly_scores: np.ndarray,
        prefix: str
    ) -> Dict[str, float]:
        """Compute additional evaluation metrics"""
        from sklearn.metrics import precision_score, recall_score, f1_score
        
        # Compute MSE and MAE
        mse = np.mean((predictions - targets) ** 2)
        mae = np.mean(np.abs(predictions - targets))
        
        # Compute anomaly detection metrics
        anomalies_true = (np.abs(predictions - targets) > self.config.model.anomaly_threshold)
        anomalies_pred = (anomaly_scores > 0.5)
        
        precision = precision_score(anomalies_true, anomalies_pred)
        recall = recall_score(anomalies_true, anomalies_pred)
        f1 = f1_score(anomalies_true, anomalies_pred)
        
        return {
            f'{prefix}_mse': mse,
            f'{prefix}_mae': mae,
            f'{prefix}_precision': precision,
            f'{prefix}_recall': recall,
            f'{prefix}_f1': f1
        }
    
    def train(
        self,
        train_loader,
        val_loader,
        test_loader=None,
        epochs: Optional[int] = None
    ):
        """Complete training pipeline"""
        num_epochs = epochs or self.config.model.num_epochs
        best_val_loss = float('inf')
        best_model_path = None
        
        for epoch in range(num_epochs):
            start_time = time.time()
            
            # Training
            train_metrics = self.train_epoch(train_loader)
            
            # Validation
            val_metrics = self.evaluate(val_loader, prefix='val')
            
            # Testing if available
            if test_loader is not None and epoch % self.config.training.eval_interval == 0:
                test_metrics = self.evaluate(test_loader, prefix='test')
            else:
                test_metrics = {}
            
            # Update learning rate
            if self.scheduler is not None:
                self.scheduler.step(val_metrics['val_loss'])
            
            # Check for early stopping
            if self.early_stopping(val_metrics['val_loss']):
                logger.info(f'Early stopping triggered at epoch {epoch}')
                break
            
            # Save best model
            if val_metrics['val_loss'] < best_val_loss:
                best_val_loss = val_metrics['val_loss']
                best_model_path = self._save_checkpoint(epoch, val_metrics['val_loss'])
            
            # Log metrics
            epoch_time = time.time() - start_time
            metrics = {
                'epoch': epoch,
                'epoch_time': epoch_time,
                'lr': self.optimizer.param_groups[0]['lr'],
                **train_metrics,
                **val_metrics,
                **test_metrics
            }
            
            self._log_metrics(metrics)
            
        # Load best model
        if best_model_path:
            self._load_checkpoint(best_model_path)
            
        return self.model
    
    def _save_checkpoint(self, epoch: int, val_loss: float) -> str:
        """Save model checkpoint"""
        checkpoint_dir = Path(self.config.training.checkpoint_dir)
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        path = checkpoint_dir / f'checkpoint_epoch_{epoch}_{timestamp}.pt'
        
        torch.save({
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict() if self.scheduler else None,
            'val_loss': val_loss,
            'config': self.config.to_dict()
        }, path)
        
        return str(path)
    
    def _load_checkpoint(self, path: str):
        """Load model checkpoint"""
        checkpoint = torch.load(path)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        if self.scheduler and checkpoint['scheduler_state_dict']:
            self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
    
    def _log_metrics(self, metrics: Dict[str, float]):
        """Log metrics to console and wandb if enabled"""
        # Console logging
        log_str = f"Epoch {metrics['epoch']}: "
        log_str += " | ".join([f"{k}: {v:.4f}" for k, v in metrics.items() if k != 'epoch'])
        logger.info(log_str)
        
        # Wandb logging
        if self.config.training.use_wandb:
            wandb.log(metrics)                    