from typing import Dict, Any
import yaml
from pathlib import Path

class Config:
    def __init__(self, config_path: str = 'config.yaml'):
        self.config_path = Path(config_path)
        self.config = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file"""
        if not self.config_path.exists():
            return self._create_default_config()
            
        with open(self.config_path, 'r') as f:
            return yaml.safe_load(f)
            
    def _create_default_config(self) -> Dict[str, Any]:
        """Create default configuration"""
        config = {
            'data_generation': {
                'size': 1000,
                'domains': ['thermodynamics', 'fluid_mechanics', 'mass_transfer', 'reaction_kinetics'],
                'complexities': ['basic', 'intermediate', 'advanced']
            },
            'models': {
                'meta_agent': {
                    'model_name': 'meta-llama/Llama-2-7b-chat-hf',
                    'max_length': 200
                },
                'action_generator': {
                    'model_name': 'meta-llama/Llama-2-7b-chat-hf',
                    'max_length': 100
                },
                'expert_models': {
                    'code_expert': {
                        'model_name': 'deepseek-ai/deepseek-coder-7b-instruct'
                    },
                    'math_expert': {
                        'model_name': 'deepseek-ai/deepseek-math-7b-instruct'
                    }
                }
            },
            'training': {
                'batch_size': 16,
                'learning_rate': 1e-5,
                'epochs': 10
            },
            'evaluation': {
                'metrics': ['tool_usage_awareness', 'pass_rate', 'accuracy', 'recall@k', 'ndcg'],
                'k_values': [1, 3, 5]
            }
        }
        
        # Save default config
        self.save_config(config)
        return config
        
    def save_config(self, config: Dict[str, Any]):
        """Save configuration to YAML file"""
        with open(self.config_path, 'w') as f:
            yaml.dump(config, f)
            
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
                
        return value
        
    def update(self, key: str, value: Any):
        """Update configuration value"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
            
        config[keys[-1]] = value
        self.save_config(self.config)