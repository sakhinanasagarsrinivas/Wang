# train/optimizer.py
import torch
from torch.optim import Optimizer, AdamW
from torch.optim.lr_scheduler import LRScheduler
from transformers import get_scheduler
from typing import Optional, List, Dict

class OptimizerFactory:
    """Factory class for creating optimizers and schedulers."""
    
    @staticmethod
    def create_optimizer(
        model: torch.nn.Module,
        optimizer_type: str = "adamw",
        learning_rate: float = 1e-4,
        weight_decay: float = 0.01,
        eps: float = 1e-8,
        **kwargs
    ) -> Optimizer:
        """Create optimizer with specific configuration."""
        # Get parameters with weight decay handling
        no_decay = ['bias', 'LayerNorm.weight']
        optimizer_grouped_parameters = [
            {
                'params': [p for n, p in model.named_parameters()
                          if not any(nd in n for nd in no_decay)],
                'weight_decay': weight_decay
            },
            {
                'params': [p for n, p in model.named_parameters()
                          if any(nd in n for nd in no_decay)],
                'weight_decay': 0.0
            }
        ]
        
        if optimizer_type.lower() == "adamw":
            optimizer = AdamW(
                optimizer_grouped_parameters,
                lr=learning_rate,
                eps=eps,
                **kwargs
            )
        else:
            raise ValueError(f"Unsupported optimizer type: {optimizer_type}")
            
        return optimizer
    
    @staticmethod
    def create_scheduler(
        optimizer: Optimizer,
        scheduler_type: str = "linear",
        num_warmup_steps: int = 0,
        num_training_steps: int = 0,
        **kwargs
    ) -> LRScheduler:
        """Create learning rate scheduler."""
        return get_scheduler(
            scheduler_type,
            optimizer=optimizer,
            num_warmup_steps=num_warmup_steps,
            num_training_steps=num_training_steps,
            **kwargs
        )

class DyAMoQPEsOptimizer:
    """Specialized optimizer for DyA-MoQPEs components."""
    
    def __init__(
        self,
        model: torch.nn.Module,
        expert_lr: float = 1e-4,
        routing_lr: float = 1e-4,
        expert_weight_decay: float = 0.01,
        routing_weight_decay: float = 0.01
    ):
        # Get expert and routing parameters
        expert_params = []
        routing_params = []
        
        for name, module in model.named_modules():
            if hasattr(module, 'get_expert_parameters'):
                expert_params.extend(module.get_expert_parameters())
            if hasattr(module, 'get_routing_parameters'):
                routing_params.extend(module.get_routing_parameters())
        
        # Create optimizers
        self.expert_optimizer = AdamW(
            expert_params,
            lr=expert_lr,
            weight_decay=expert_weight_decay
        )
        
        self.routing_optimizer = AdamW(
            routing_params,
            lr=routing_lr,
            weight_decay=routing_weight_decay
        )
    
    def zero_grad(self):
        """Zero gradients for all optimizers."""
        self.expert_optimizer.zero_grad()
        self.routing_optimizer.zero_grad()
    
    def step(self):
        """Perform optimization step."""
        self.expert_optimizer.step()
        self.routing_optimizer.step()
    
    def state_dict(self) -> Dict:
        """Get state dict for all optimizers."""
        return {
            'expert_optimizer': self.expert_optimizer.state_dict(),
            'routing_optimizer': self.routing_optimizer.state_dict()
        }
    
    def load_state_dict(self, state_dict: Dict):
        """Load state dict for all optimizers."""
        self.expert_optimizer.load_state_dict(state_dict['expert_optimizer'])
        self.routing_optimizer.load_state_dict(state_dict['routing_optimizer'])

def create_optimizer_and_scheduler(
    model: torch.nn.Module,
    optimizer_config: Dict,
    scheduler_config: Optional[Dict] = None
) -> Tuple[Optimizer, Optional[LRScheduler]]:
    """Helper function to create optimizer and scheduler."""
    optimizer = OptimizerFactory.create_optimizer(
        model=model,
        **optimizer_config
    )
    
    scheduler = None
    if scheduler_config is not None:
        scheduler = OptimizerFactory.create_scheduler(
            optimizer=optimizer,
            **scheduler_config
        )
    
    return optimizer, scheduler