# main.py
import argparse
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoImageProcessor
from torch.utils.data import DataLoader
import logging
import json
import os
from tqdm import tqdm

from models.maemi import MAEMI
from data_generation.microscopy_dataset import MicroscopyDataGenerator, SemDatasetProcessor, InstructionDataset
from trainer.trainer import MAEMITrainer
from config import MAEMIConfig

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def setup_data_generation(args, config):
    """Setup data generation pipeline using GPT-4V"""
    logger.info("Setting up data generation pipeline...")
    
    # Initialize data generator for micrograph analysis
    data_generator = MicroscopyDataGenerator(config)
    
    # Process SEM dataset
    dataset_processor = SemDatasetProcessor(args.data_path, args.output_path)
    sem_dataset = dataset_processor.process_dataset()
    
    # Generate instruction data for different analysis types
    instruction_data = []
    analysis_types = ['base_analysis', 'intra_class', 'inter_class', 'spatial']
    
    for item in tqdm(sem_dataset):
        for analysis_type in analysis_types:
            # Generate instruction based on analysis type
            instruction = data_generator.generate_instruction_data(
                item['path'],
                analysis_type
            )
            if instruction:
                instruction_data.append({
                    **instruction,
                    'category': item['category']
                })
    
    # Save generated instruction dataset
    output_file = Path(args.output_path) / 'instruction_dataset.json'
    with open(output_file, 'w') as f:
        json.dump(instruction_data, f, indent=2)
    
    return output_file

def setup_datasets(data_path, tokenizer, image_processor, config):
    """Setup training, validation, and test datasets"""
    # Load instruction data
    with open(data_path, 'r') as f:
        data = json.load(f)
    
    # Split data into train/val/test
    total_len = len(data)
    train_size = int(0.7 * total_len)
    val_size = int(0.15 * total_len)
    
    train_data = data[:train_size]
    val_data = data[train_size:train_size + val_size]
    test_data = data[train_size + val_size:]
    
    # Create datasets
    train_dataset = InstructionDataset(train_data, tokenizer, image_processor)
    val_dataset = InstructionDataset(val_data, tokenizer, image_processor)
    test_dataset = InstructionDataset(test_data, tokenizer, image_processor)
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers
    )
    
    return train_loader, val_loader, test_loader

def train(model, train_loader, val_loader, config):
    """Train the model following the paper's methodology"""
    trainer = MAEMITrainer(model, config, train_loader, val_loader)
    
    best_val_loss = float('inf')
    for epoch in range(config.num_epochs):
        logger.info(f"Epoch {epoch+1}/{config.num_epochs}")
        
        # Training
        train_losses = trainer.train_epoch()
        logger.info("Training losses:")
        for analysis_type, loss in train_losses.items():
            logger.info(f"{analysis_type}: {loss:.4f}")
        
        # Validation
        val_losses = trainer.validate()
        logger.info("Validation losses:")
        for analysis_type, loss in val_losses.items():
            logger.info(f"{analysis_type}: {loss:.4f}")
        
        # Save checkpoint if validation improves
        val_loss = sum(val_losses.values())
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': trainer.optimizer.state_dict(),
                'val_loss': val_loss,
            }, os.path.join(config.checkpoint_dir, 'best_model.pt'))

def evaluate(model, test_loader, config):
    """Evaluate model on test set"""
    model.eval()
    total_correct = 0
    total_samples = 0
    
    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Evaluating"):
            outputs = model(
                pixel_values=batch['pixel_values'].to(config.device),
                input_ids=batch['input_ids'].to(config.device),
                attention_mask=batch['attention_mask'].to(config.device),
                task='classification'
            )
            
            predictions = outputs.argmax(dim=-1)
            total_correct += (predictions == batch['category'].to(config.device)).sum().item()
            total_samples += predictions.size(0)
    
    accuracy = total_correct / total_samples
    logger.info(f"Test Accuracy: {accuracy:.4f}")
    
    return accuracy

def main(args):
    # Load config
    config = MAEMIConfig()
    
    # Set device
    config.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Initialize tokenizer and image processor
    tokenizer = AutoTokenizer.from_pretrained('meta-llama/Llama-2-7b')
    image_processor = AutoImageProcessor.from_pretrained('google/vit-base-patch16-224')
    
    # Generate instruction data if needed
    if args.generate_data:
        logger.info("Generating instruction data...")
        data_path = setup_data_generation(args, config)
    else:
        data_path = args.data_path
    
    # Setup datasets
    logger.info("Setting up datasets...")
    train_loader, val_loader, test_loader = setup_datasets(
        data_path,
        tokenizer,
        image_processor,
        config
    )
    
    # Initialize model
    logger.info("Initializing MAEMI model...")
    model = MAEMI(config).to(config.device)
    
    # Train model
    if args.train:
        logger.info("Starting training...")
        train(model, train_loader, val_loader, config)
    
    # Evaluate model
    if args.evaluate:
        logger.info("Starting evaluation...")
        # Load best model if available
        if os.path.exists(os.path.join(config.checkpoint_dir, 'best_model.pt')):
            checkpoint = torch.load(os.path.join(config.checkpoint_dir, 'best_model.pt'))
            model.load_state_dict(checkpoint['model_state_dict'])
        
        accuracy = evaluate(model, test_loader, config)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='MAEMI Training and Evaluation')
    parser.add_argument('--data_path', type=str, required=True,
                      help='Path to SEM dataset or instruction data')
    parser.add_argument('--output_path', type=str, required=True,
                      help='Path to save outputs')
    parser.add_argument('--generate_data', action='store_true',
                      help='Generate instruction data using GPT-4V')
    parser.add_argument('--train', action='store_true',
                      help='Train the model')
    parser.add_argument('--evaluate', action='store_true',
                      help='Evaluate the model')
    parser.add_argument('--api_key', type=str,
                      help='OpenAI API key for GPT-4V')
    
    args = parser.parse_args()
    main(args)