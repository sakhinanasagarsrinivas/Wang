import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import logging

# Import custom modules
from config import Config
from dataset import SEMDataset, split_dataset
from models import EMCNet
from utils import (
    ResultLogger, 
    train_epoch, 
    validate, 
    compute_metrics
)

def set_seed(seed):
    """
    Set random seeds for reproducibility
    
    Args:
        seed (int): Random seed value
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def main():
    """
    Main training script for EMCNet project
    Handles dataset preparation, model training, and evaluation
    """
    # Initialize configuration
    config = Config()
    
    # Set random seed for reproducibility
    set_seed(config.random_seed)
    
    # Setup logging
    logger = logging.getLogger('EMCNet_Training')
    
    # Log configuration details
    config.log_config()
    
    # Create result logger
    result_logger = ResultLogger(config)
    
    try:
        # Load dataset
        dataset = SEMDataset(
            csv_file=config.train_csv, 
            root_dir=config.root_dir, 
            patch_size=config.patch_size
        )
        
        # Split dataset
        train_dataset, val_dataset, test_dataset = split_dataset(
            dataset, 
            train_ratio=config.train_ratio,
            val_ratio=config.val_ratio,
            test_ratio=config.test_ratio,
            random_state=config.random_seed
        )
        
        # Create data loaders
        train_loader = torch.utils.data.DataLoader(
            train_dataset, 
            batch_size=config.batch_size, 
            shuffle=True
        )
        val_loader = torch.utils.data.DataLoader(
            val_dataset, 
            batch_size=config.batch_size, 
            shuffle=False
        )
        test_loader = torch.utils.data.DataLoader(
            test_dataset, 
            batch_size=config.batch_size, 
            shuffle=False
        )
        
        # Initialize model
        model = EMCNet(config).to(config.device)
        logger.info(f"Model initialized on {config.device}")
        
        # Loss and optimizer
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(
            model.parameters(), 
            lr=config.learning_rate,
            weight_decay=config.weight_decay
        )
        
        # Learning rate scheduler
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, 
            mode='min', 
            factor=0.1, 
            patience=5,
            verbose=True
        )
        
        # Best validation metrics tracking
        best_val_loss = float('inf')
        best_model_path = os.path.join(config.results_dir, 'best_model.pth')
        
        # Training loop
        for epoch in range(config.epochs):
            logger.info(f"Starting Epoch {epoch + 1}/{config.epochs}")
            
            # Train for one epoch
            train_metrics = train_epoch(
                model, train_loader, criterion, optimizer, 
                config.device, logger
            )
            
            # Validate
            val_metrics = validate(
                model, val_loader, criterion, 
                config.device, logger
            )
            
            # Log epoch results
            result_logger.log_epoch(epoch, train_metrics, val_metrics)
            
            # Learning rate scheduling
            scheduler.step(val_metrics['loss'])
            
            # Model checkpointing
            if val_metrics['loss'] < best_val_loss:
                best_val_loss = val_metrics['loss']
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'loss': best_val_loss
                }, best_model_path)
                logger.info(f"Saved best model at epoch {epoch + 1}")
        
        # Plot training curves
        result_logger.plot_training_curves()
        
        # Load best model for final evaluation
        best_checkpoint = torch.load(best_model_path)
        model.load_state_dict(best_checkpoint['model_state_dict'])
        
        # Final test set evaluation
        test_metrics = validate(
            model, test_loader, criterion, 
            config.device, logger
        )
        
        # Compute comprehensive metrics
        final_metrics = compute_metrics(
            test_metrics['ground_truth'], 
            test_metrics['predictions']
        )
        
        # Save and log final metrics
        result_logger.save_metrics(final_metrics)
        logger.info("Final Test Set Metrics:")
        for metric, value in final_metrics.items():
            logger.info(f"{metric}: {value}")
    
    except Exception as e:
        logger.error(f"Training failed: {e}", exc_info=True)
    
    finally:
        logger.info("Training completed.")

if __name__ == '__main__':
    main()