# models/dya_mopes_manager.py
import torch
import torch.nn as nn
from typing import Dict, List, Optional, Union
from .dya_mopes import DyAMoQPEs, DyAMoQPEsConfig

class DyAMoQPEsManager:
    """Manages DyA-MoQPEs layers across the model."""
    
    def __init__(self, base_model: nn.Module, config: DyAMoQPEsConfig):
        self.base_model = base_model
        self.config = config
        self.dya_mopes_layers: Dict[str, DyAMoQPEs] = {}
        
    def add_dya_mopes_layer(self, module_name: str, module: nn.Module):
        """Add DyA-MoQPEs layer to a specific module."""
        # Create DyA-MoQPEs layer
        dya_mopes = create_dya_mopes_layer(self.config)
        
        # Replace module with DyA-MoQPEs
        parent_name = ".".join(module_name.split(".")[:-1])
        child_name = module_name.split(".")[-1]
        
        if parent_name:
            parent = self.base_model.get_submodule(parent_name)
            setattr(parent, child_name, dya_mopes)
        else:
            setattr(self.base_model, child_name, dya_mopes)
            
        self.dya_mopes_layers[module_name] = dya_mopes
        
    def get_dya_mopes_layer(self, module_name: str) -> Optional[DyAMoQPEs]:
        """Get DyA-MoQPEs layer by module name."""
        return self.dya_mopes_layers.get(module_name)
        
    def set_uniform_rank(self, rank: int):
        """Set all DyA-MoQPEs layers to use the same rank."""
        for layer in self.dya_mopes_layers.values():
            layer.set_expert_ranks(rank)
            
    def get_all_expert_parameters(self) -> List[nn.Parameter]:
        """Get all expert parameters across layers."""
        parameters = []
        for layer in self.dya_mopes_layers.values():
            parameters.extend(layer.get_expert_parameters())
        return parameters
        
    def get_all_routing_parameters(self) -> List[nn.Parameter]:
        """Get all routing network parameters across layers."""
        parameters = []
        for layer in self.dya_mopes_layers.values():
            parameters.extend(layer.get_routing_parameters())
        return parameters
        
    def save_state(self, path: str):
        """Save DyA-MoQPEs states."""
        states = {
            name: layer.state_dict()
            for name, layer in self.dya_mopes_layers.items()
        }
        torch.save(states, path)
        
    def load_state(self, path: str):
        """Load DyA-MoQPEs states."""
        states = torch.load(path)
        for name, state in states.items():
            if name in self.dya_mopes_layers:
                self.dya_mopes_layers[name].load_state_dict(state)
                
    def apply_to_model(self, patterns: List[str]):
        """Apply DyA-MoQPEs to model layers matching patterns."""
        def match_pattern(name: str, patterns: List[str]) -> bool:
            return any(pattern in name for pattern in patterns)
            
        for name, module in self.base_model.named_modules():
            if match_pattern(name, patterns) and isinstance(module, nn.Linear):
                self.add_dya_mopes_layer(name, module)
                
    def get_aux_loss(self) -> torch.Tensor:
        """Calculate total auxiliary loss across all layers."""
        total_loss = torch.tensor(0.0, device=next(self.base_model.parameters()).device)
        
        for layer in self.dya_mopes_layers.values():
            # Get last forward pass auxiliary loss
            if hasattr(layer, 'last_aux_loss'):
                aux_loss = layer.last_aux_loss
                total_loss += aux_loss.get('importance', 0.0) + aux_loss.get('load_balance', 0.0)
                
        return total_loss