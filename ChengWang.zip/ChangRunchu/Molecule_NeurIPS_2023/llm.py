from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from langchain.prompts.chat import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate
)
import torch
import torch.nn as nn
from typing import List, Dict, Optional, Tuple
from transformers import AutoTokenizer, AutoModel
import numpy as np

class MoleculeLanguageProcessor:
    def __init__(
        self,
        llm_model: str = "gpt-3.5-turbo",
        embedding_model: str = "microsoft/deberta-v3-base",
        max_length: int = 512,
        device: str = "cuda"
    ):
        """
        Initialize the Molecule Language Processor
        """
        self.device = device
        self.max_length = max_length
        
        # Initialize LLM
        self.llm = ChatOpenAI(model_name=llm_model, temperature=0)
        self.memory = ConversationBufferMemory()
        
        # Initialize embedding model
        self.tokenizer = AutoTokenizer.from_pretrained(embedding_model)
        self.embedding_model = AutoModel.from_pretrained(embedding_model).to(device)
        
        # Initialize prompts
        self.zero_shot_prompt = self._create_zero_shot_prompt()
        self.few_shot_prompt = self._create_few_shot_prompt()
        
        # Initialize chains
        self.zero_shot_chain = LLMChain(
            llm=self.llm,
            prompt=self.zero_shot_prompt,
            memory=self.memory
        )
        self.few_shot_chain = LLMChain(
            llm=self.llm,
            prompt=self.few_shot_prompt,
            memory=self.memory
        )

    def _create_zero_shot_prompt(self) -> PromptTemplate:
        """Create zero-shot prompt template"""
        template = """Analyze the following molecule in SMILES notation: {smiles}

Please provide detailed information about:
1. Molecular structure (atoms, bonds, functional groups)
2. Physical properties (boiling point, melting point, density)
3. Chemical reactivity and common reactions
4. Applications in medicine, industry, or other fields

Focus on technical accuracy and chemical principles."""

        return PromptTemplate(
            input_variables=["smiles"],
            template=template
        )

    def _create_few_shot_prompt(self) -> PromptTemplate:
        """Create few-shot prompt template"""
        template = """Given these example molecules and their properties:

{examples}

Now, predict the properties for this new molecule: {smiles}
Focus on these specific properties: {target_properties}"""

        return PromptTemplate(
            input_variables=["examples", "smiles", "target_properties"],
            template=template
        )

    def get_molecule_description(self, smiles: str) -> str:
        """Get molecule description using zero-shot prompting"""
        return self.zero_shot_chain.run(smiles=smiles)

    def get_molecule_properties(
        self,
        smiles: str,
        examples: List[Dict],
        target_properties: List[str]
    ) -> str:
        """Get molecule properties using few-shot prompting"""
        examples_text = "\n".join([
            f"SMILES: {ex['smiles']}\nProperties: {ex['properties']}"
            for ex in examples
        ])
        
        return self.few_shot_chain.run(
            examples=examples_text,
            smiles=smiles,
            target_properties=", ".join(target_properties)
        )

    def get_text_embeddings(
        self,
        text: str,
        pooling: str = 'mean'
    ) -> torch.Tensor:
        """
        Get embeddings for text using the embedding model
        
        Args:
            text: Input text
            pooling: Pooling strategy ('mean' or 'cls')
        
        Returns:
            torch.Tensor: Text embeddings
        """
        # Tokenize text
        inputs = self.tokenizer(
            text,
            max_length=self.max_length,
            padding=True,
            truncation=True,
            return_tensors='pt'
        ).to(self.device)
        
        # Get embeddings
        with torch.no_grad():
            outputs = self.embedding_model(**inputs)
            embeddings = outputs.last_hidden_state
            
            # Apply pooling
            if pooling == 'mean':
                # Mean pooling
                attention_mask = inputs['attention_mask']
                mask = attention_mask.unsqueeze(-1).expand(embeddings.size()).float()
                masked_embeddings = embeddings * mask
                summed = torch.sum(masked_embeddings, dim=1)
                counts = torch.clamp(torch.sum(attention_mask, dim=1, keepdim=True), min=1e-9)
                mean_pooled = summed / counts
                return mean_pooled
            else:
                # CLS token pooling
                return embeddings[:, 0, :]

    def process_molecule(
        self,
        smiles: str,
        examples: Optional[List[Dict]] = None,
        target_properties: Optional[List[str]] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Process a molecule to get both zero-shot and few-shot embeddings
        
        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (zero_shot_embedding, few_shot_embedding)
        """
        # Get zero-shot description and embedding
        description = self.get_molecule_description(smiles)
        zero_shot_embedding = self.get_text_embeddings(description)
        
        # Get few-shot prediction and embedding if examples are provided
        if examples and target_properties:
            prediction = self.get_molecule_properties(smiles, examples, target_properties)
            few_shot_embedding = self.get_text_embeddings(prediction)
        else:
            few_shot_embedding = torch.zeros_like(zero_shot_embedding)
        
        return zero_shot_embedding, few_shot_embedding

class TextEncoder(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        num_layers: int = 2,
        dropout: float = 0.1
    ):
        """
        Text encoder for processing LLM outputs
        """
        super().__init__()
        
        self.layers = nn.ModuleList([
            nn.Linear(input_dim if i == 0 else hidden_dim, hidden_dim)
            for i in range(num_layers)
        ])
        
        self.layer_norms = nn.ModuleList([
            nn.LayerNorm(hidden_dim)
            for _ in range(num_layers)
        ])
        
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass"""
        for layer, layer_norm in zip(self.layers, self.layer_norms):
            # Apply layer
            x = layer(x)
            # Apply normalization
            x = layer_norm(x)
            # Apply activation and dropout
            x = torch.relu(x)
            x = self.dropout(x)
        
        return x