import torch
import numpy as np
import pandas as pd
import logging
from typing import Dict, List, Tuple

from constants import (
    ModelConfig, 
    TrainingConfig, 
    TaskConfig,
    TRAFFIC_DATASETS,
    ANOMALY_DATASETS
)
from models import (
    MasterAgent, 
    BaseAgent, 
    ForecastingAgent,
    ImputationAgent,
    AnomalyDetectionAgent,
    ClassificationAgent
)
from training import AgentTrainer
from datasets import (
    load_traffic_dataset,
    load_anomaly_dataset
)
from metrics import calculate_metrics
from utils import set_seed

class AblationStudy:
    """
    Implements ablation study for Agentic RAG framework
    Corresponds to paper Section E: Ablation Study
    """
    def __init__(
        self, 
        task_type: str, 
        dataset: str,
        model_config: ModelConfig,
        task_config: TaskConfig,
        training_config: TrainingConfig,
        device: str = 'cuda'
    ):
        self.task_type = task_type
        self.dataset = dataset
        self.model_config = model_config
        self.task_config = task_config
        self.training_config = training_config
        self.device = device
        
        # Seed for reproducibility
        set_seed(42)
        
        # Load datasets
        self._load_datasets()
        
        # Initialize master agent and specific agent
        self._initialize_agents()
        
    def _load_datasets(self):
        """Load datasets based on task and dataset"""
        if self.dataset in TRAFFIC_DATASETS:
            self.train_loader, self.val_loader, self.test_loader = load_traffic_dataset(
                self.dataset, 
                self.task_config, 
                base_path=Path('data')
            )
        elif self.dataset in ANOMALY_DATASETS:
            self.train_loader, self.val_loader, self.test_loader = load_anomaly_dataset(
                self.dataset, 
                self.task_config, 
                base_path=Path('data')
            )
        else:
            raise ValueError(f"Unsupported dataset: {self.dataset}")
    
    def _initialize_agents(self):
        """Initialize master agent and task-specific agent"""
        master_agent = MasterAgent(
            model_config=self.model_config,
            task_config=self.task_config,
            device=self.device
        )
        self.agent = master_agent.get_agent(self.task_type)
    
    def run_ablation_experiments(self) -> Dict[str, Dict[str, float]]:
        """
        Run ablation experiments by disabling different components
        
        Components to ablate:
        a) Dynamic Prompting Mechanism (DPM)
        b) Sub-Agent Specialization (SAS)
        c) Instruction Tuning (IT)
        d) Direct Preference Optimization (DPO)
        """
        results = {}
        
        # Baseline (Full Framework)
        baseline_results = self._evaluate_agent(self.agent)
        results['full_framework'] = baseline_results
        
        # Ablation: Without Dynamic Prompting Mechanism
        agent_wo_dpm = self._disable_dynamic_prompting()
        results['without_dpm'] = self._evaluate_agent(agent_wo_dpm)
        
        # Ablation: Without Sub-Agent Specialization
        agent_wo_sas = self._use_universal_agent()
        results['without_sas'] = self._evaluate_agent(agent_wo_sas)
        
        # Ablation: Without Instruction Tuning
        agent_wo_it = self._disable_instruction_tuning()
        results['without_it'] = self._evaluate_agent(agent_wo_it)
        
        # Ablation: Without Direct Preference Optimization
        agent_wo_dpo = self._disable_dpo()
        results['without_dpo'] = self._evaluate_agent(agent_wo_dpo)
        
        return results
    
    def _disable_dynamic_prompting(self) -> BaseAgent:
        """Disable dynamic prompting mechanism"""
        agent = type(self.agent)(
            config=self.model_config,
            task_config=self.task_config,
            device=self.device
        )
        
        # Override _enhance_embeddings to return original embeddings
        def dummy_enhance_embeddings(input_embeds):
            return input_embeds
        
        agent._enhance_embeddings = dummy_enhance_embeddings.__get__(agent)
        return agent
    
    def _use_universal_agent(self) -> BaseAgent:
        """Create a universal agent for all tasks"""
        universal_agent = BaseAgent(
            config=self.model_config,
            task_config=self.task_config,
            task_type="universal",
            device=self.device
        )
        return universal_agent
    
    def _disable_instruction_tuning(self) -> BaseAgent:
        """
        Disable instruction tuning by resetting model weights
        or using a non-fine-tuned version
        """
        # Create a fresh agent without instruction tuning
        agent = type(self.agent)(
            config=self.model_config,
            task_config=self.task_config,
            device=self.device
        )
        
        # Reset model to initial pretrained weights
        agent.model.reset_parameters()
        return agent
    
    def _disable_dpo(self) -> BaseAgent:
        """
        Simulate agent without Direct Preference Optimization
        """
        agent = type(self.agent)(
            config=self.model_config,
            task_config=self.task_config,
            device=self.device
        )
        
        # Override loss calculation to remove DPO-specific modifications
        def original_loss_fn(predictions, targets):
            return torch.nn.functional.mse_loss(predictions, targets)
        
        agent.loss_fn = original_loss_fn
        return agent
    
    def _evaluate_agent(self, agent: BaseAgent) -> Dict[str, float]:
        """
        Evaluate agent performance on test dataset
        """
        # Setup trainer
        trainer = AgentTrainer(
            agent=agent,
            train_loader=self.train_loader,
            val_loader=self.val_loader,
            config=self.training_config,
            task_type=self.task_type,
            experiment_name=f"ablation_{self.task_type}_{self.dataset}"
        )
        
        # Train agent
        trainer.train()
        
        # Collect predictions and targets
        predictions = []
        targets = []
        agent.eval()
        
        with torch.no_grad():
            for data, target in self.test_loader:
                data = data.to(self.device)
                target = target.to(self.device)
                
                # Task-specific forward pass
                if self.task_type == 'imputation':
                    outputs = agent(data, mask=torch.ones_like(data), target=target)
                else:
                    outputs = agent(data, target=target)
                
                predictions.extend(outputs['predictions'].cpu().numpy())
                targets.extend(target.cpu().numpy())
        
        # Calculate metrics
        metrics = calculate_metrics(
            predictions=np.array(predictions),
            targets=np.array(targets),
            task_type=self.task_type,
            # Additional task-specific arguments can be added here
        )
        
        return metrics
    
    def save_results(self, results: Dict[str, Dict[str, float]]):
        """
        Save ablation study results to CSV
        """
        # Convert results to DataFrame
        df_results = pd.DataFrame.from_dict(results, orient='index')
        
        # Save to CSV
        filename = f"ablation_study_{self.task_type}_{self.dataset}.csv"
        df_results.to_csv(filename)
        logging.info(f"Ablation study results saved to {filename}")
        
        return df_results

def run_comprehensive_ablation_study(
    tasks: List[str] = ['forecasting', 'anomaly_detection', 'imputation', 'classification'],
    datasets: List[str] = ['PeMSD3', 'METR-LA', 'SWaT']
):
    """
    Run ablation studies across multiple tasks and datasets
    """
    comprehensive_results = {}
    
    for task in tasks:
        task_results = {}
        for dataset in datasets:
            # Setup configurations
            model_config = ModelConfig()
            task_config = TaskConfig()
            training_config = TrainingConfig()
            
            # Customize task config if needed
            if task == 'forecasting':
                task_config.forecast_window_size = 512
                task_config.forecast_horizon = 12
            elif task == 'anomaly_detection':
                task_config.anomaly_window_size = 100
            
            # Run ablation study
            ablation_study = AblationStudy(
                task_type=task,
                dataset=dataset,
                model_config=model_config,
                task_config=task_config,
                training_config=training_config
            )
            
            # Perform ablation experiments
            results = ablation_study.run_ablation_experiments()
            task_results[dataset] = results
            
            # Save results
            ablation_study.save_results(results)
        
        comprehensive_results[task] = task_results
    
    return comprehensive_results

def main():
    """Main entry point for ablation study"""
    logging.basicConfig(level=logging.INFO)
    
    # Run comprehensive ablation study
    comprehensive_results = run_comprehensive_ablation_study()
    
if __name__ == "__main__":
    main()