from dataclasses import dataclass

@dataclass
class VisionHGNNConfig:
    # Dataset Configuration
    dataset_path: str = './data/sem_dataset'
    num_classes: int = 10
    
    # Model Hyperparameters
    feature_dim: int = 128
    patch_size: int = 32
    num_patches: int = 64  # 256x256 image divided into 32x32 patches
    k_nearest: int = 20
    
    # Training Hyperparameters
    batch_size: int = 48
    learning_rate: float = 1e-3
    num_epochs: int = 100
    
    # Model Architecture
    hgat_layers: int = 2
    hgt_layers: int = 2
    num_attention_heads: int = 4