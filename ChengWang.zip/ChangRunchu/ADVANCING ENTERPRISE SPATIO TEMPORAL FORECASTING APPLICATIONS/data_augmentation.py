import torch
import numpy as np
from typing import Tuple, Optional

class TimeSeriesAugmenter:
    """Time series data augmentation techniques"""
    
    @staticmethod
    def add_gaussian_noise(
        x: torch.Tensor,
        mean: float = 0.0,
        std: float = 0.1
    ) -> torch.Tensor:
        """Add Gaussian noise to the time series"""
        noise = torch.normal(mean, std, size=x.shape).to(x.device)
        return x + noise
    
    @staticmethod
    def scaling(
        x: torch.Tensor,
        scaling_factor: float = 1.1
    ) -> torch.Tensor:
        """Scale the time series by a factor"""
        return x * scaling_factor
    
    @staticmethod
    def time_warping(
        x: torch.Tensor,
        sigma: float = 0.2
    ) -> torch.Tensor:
        """Apply random time warping"""
        timestamps = torch.arange(x.shape[1], dtype=torch.float32).to(x.device)
        warped_timestamps = timestamps + torch.normal(0, sigma, size=(x.shape[1],)).to(x.device)
        warped_timestamps = torch.sort(warped_timestamps)[0]
        
        # Interpolate values at warped timestamps
        x_warped = torch.zeros_like(x)
        for i in range(x.shape[0]):
            x_warped[i] = torch.interp(timestamps, warped_timestamps, x[i])
        return x_warped
    
    @staticmethod
    def masking(
        x: torch.Tensor,
        mask_ratio: float = 0.1
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Randomly mask portions of the time series"""
        mask = torch.ones_like(x)
        mask_indices = torch.rand_like(x) < mask_ratio
        mask[mask_indices] = 0
        return x * mask, mask
    
    @staticmethod
    def random_segments(
        x: torch.Tensor,
        num_segments: int = 3
    ) -> torch.Tensor:
        """Generate random continuous segments"""
        seq_length = x.shape[1]
        segment_length = seq_length // num_segments
        
        segments = []
        for i in range(num_segments):
            start_idx = np.random.randint(0, seq_length - segment_length)
            segment = x[:, start_idx:start_idx + segment_length]
            segments.append(segment)
            
        return torch.cat(segments, dim=1)
    
    @staticmethod
    def magnitude_warping(
        x: torch.Tensor,
        sigma: float = 0.2
    ) -> torch.Tensor:
        """Apply random magnitude warping"""
        warping_path = torch.exp(torch.normal(0, sigma, size=(x.shape[1],))).to(x.device)
        return x * warping_path.unsqueeze(0)
    
    @staticmethod
    def frequency_masking(
        x: torch.Tensor,
        mask_ratio: float = 0.1
    ) -> torch.Tensor:
        """Mask frequencies in the Fourier domain"""
        # Convert to frequency domain
        x_fft = torch.fft.fft(x, dim=1)
        
        # Create frequency mask
        mask = torch.ones_like(x_fft)
        mask_indices = torch.rand_like(x_fft.real) < mask_ratio
        mask[mask_indices] = 0
        
        # Apply mask and convert back
        x_fft = x_fft * mask
        return torch.fft.ifft(x_fft, dim=1).real
    
    @staticmethod
    def window_slice(
        x: torch.Tensor,
        reduce_ratio: float = 0.9
    ) -> torch.Tensor:
        """Slice a window of the time series"""
        target_len = int(reduce_ratio * x.shape[1])
        if target_len >= x.shape[1]:
            return x
        
        start = np.random.randint(0, x.shape[1] - target_len)
        return x[:, start:start + target_len]
    
    @staticmethod
    def window_warp(
        x: torch.Tensor,
        window_ratio: float = 0.1,
        scale_range: Tuple[float, float] = (0.5, 2.0)
    ) -> torch.Tensor:
        """Apply warping to a random window"""
        window_size = int(x.shape[1] * window_ratio)
        if window_size < 2:
            return x
            
        start = np.random.randint(0, x.shape[1] - window_size)
        scale = np.random.uniform(scale_range[0], scale_range[1])
        
        x_warped = x.clone()
        x_warped[:, start:start + window_size] *= scale
        return x_warped
    
    def apply_augmentations(
        self,
        x: torch.Tensor,
        augmentation_types: list,
        **kwargs
    ) -> torch.Tensor:
        """Apply multiple augmentations sequentially"""
        x_aug = x.clone()
        
        for aug_type in augmentation_types:
            if aug_type == 'noise':
                x_aug = self.add_gaussian_noise(x_aug, **kwargs)
            elif aug_type == 'scaling':
                x_aug = self.scaling(x_aug, **kwargs)
            elif aug_type == 'time_warp':
                x_aug = self.time_warping(x_aug, **kwargs)
            elif aug_type == 'masking':
                x_aug, _ = self.masking(x_aug, **kwargs)
            elif aug_type == 'magnitude_warp':
                x_aug = self.magnitude_warping(x_aug, **kwargs)
            elif aug_type == 'frequency_mask':
                x_aug = self.frequency_masking(x_aug, **kwargs)
            elif aug_type == 'window_slice':
                x_aug = self.window_slice(x_aug, **kwargs)
            elif aug_type == 'window_warp':
                x_aug = self.window_warp(x_aug, **kwargs)
                
        return x_aug