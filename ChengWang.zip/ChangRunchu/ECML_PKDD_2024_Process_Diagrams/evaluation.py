from typing import Dict, List, Union, Optional, Tuple
import numpy as np
from nltk.translate.bleu_score import sentence_bleu, corpus_bleu
from rouge_score import rouge_scorer
from nltk.translate.meteor_score import meteor_score
from sklearn.metrics import precision_score, recall_score, f1_score
import torch
from pathlib import Path
import yaml
import json

class EvaluationMetrics:
    def __init__(self, config_path: str):
        """
        Initialize evaluation metrics with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
        
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
            
    def calculate_bleu(
        self,
        hypothesis: Union[str, List[str]],
        reference: Union[str, List[str]],
        weights: Tuple[float, ...] = (0.25, 0.25, 0.25, 0.25)
    ) -> Dict[str, float]:
        """
        Calculate BLEU score.
        
        Args:
            hypothesis: Generated text
            reference: Ground truth text
            weights: Weights for n-grams
            
        Returns:
            Dictionary containing BLEU scores
        """
        if isinstance(hypothesis, str):
            hypothesis = [hypothesis]
        if isinstance(reference, str):
            reference = [reference]
            
        # Convert to tokens
        hyp_tokens = [h.split() for h in hypothesis]
        ref_tokens = [[r.split()] for r in reference]
        
        # Calculate BLEU scores
        bleu_1 = corpus_bleu(ref_tokens, hyp_tokens, weights=(1, 0, 0, 0))
        bleu_2 = corpus_bleu(ref_tokens, hyp_tokens, weights=(0.5, 0.5, 0, 0))
        bleu_4 = corpus_bleu(ref_tokens, hyp_tokens, weights=weights)
        
        return {
            'bleu_1': bleu_1,
            'bleu_2': bleu_2,
            'bleu_4': bleu_4
        }
        
    def calculate_rouge(
        self,
        hypothesis: str,
        reference: str
    ) -> Dict[str, Dict[str, float]]:
        """
        Calculate ROUGE scores.
        
        Args:
            hypothesis: Generated text
            reference: Ground truth text
            
        Returns:
            Dictionary containing ROUGE scores
        """
        scores = self.rouge_scorer.score(reference, hypothesis)
        return {
            'rouge1': {
                'precision': scores['rouge1'].precision,
                'recall': scores['rouge1'].recall,
                'fmeasure': scores['rouge1'].fmeasure
            },
            'rouge2': {
                'precision': scores['rouge2'].precision,
                'recall': scores['rouge2'].recall,
                'fmeasure': scores['rouge2'].fmeasure
            },
            'rougeL': {
                'precision': scores['rougeL'].precision,
                'recall': scores['rougeL'].recall,
                'fmeasure': scores['rougeL'].fmeasure
            }
        }
        
    def calculate_meteor(
        self,
        hypothesis: str,
        reference: str
    ) -> float:
        """
        Calculate METEOR score.
        
        Args:
            hypothesis: Generated text
            reference: Ground truth text
            
        Returns:
            METEOR score
        """
        return meteor_score([reference.split()], hypothesis.split())
        
    def calculate_precision_recall_f1(
        self,
        y_true: List[Union[int, str]],
        y_pred: List[Union[int, str]]
    ) -> Dict[str, float]:
        """
        Calculate precision, recall, and F1 scores.
        
        Args:
            y_true: Ground truth labels
            y_pred: Predicted labels
            
        Returns:
            Dictionary containing precision, recall, and F1 scores
        """
        return {
            'precision': precision_score(y_true, y_pred, average='weighted'),
            'recall': recall_score(y_true, y_pred, average='weighted'),
            'f1': f1_score(y_true, y_pred, average='weighted')
        }
        
    def calculate_iou(
        self,
        box1: List[float],
        box2: List[float]
    ) -> float:
        """
        Calculate Intersection over Union for bounding boxes.
        
        Args:
            box1: First bounding box [x1, y1, x2, y2]
            box2: Second bounding box [x1, y1, x2, y2]
            
        Returns:
            IoU score
        """
        # Calculate intersection coordinates
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        
        # Calculate intersection area
        intersection = max(0, x2 - x1) * max(0, y2 - y1)
        
        # Calculate union area
        box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
        box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = box1_area + box2_area - intersection
        
        return intersection / union if union > 0 else 0
        
    def calculate_text_detection_metrics(
        self,
        pred_boxes: List[List[float]],
        true_boxes: List[List[float]],
        iou_threshold: float = 0.5
    ) -> Dict[str, float]:
        """
        Calculate metrics for text detection task.
        
        Args:
            pred_boxes: Predicted bounding boxes
            true_boxes: Ground truth bounding boxes
            iou_threshold: IoU threshold for matching boxes
            
        Returns:
            Dictionary containing text detection metrics
        """
        matches = []
        for pred_box in pred_boxes:
            best_iou = 0
            best_match = None
            for i, true_box in enumerate(true_boxes):
                iou = self.calculate_iou(pred_box, true_box)
                if iou > best_iou:
                    best_iou = iou
                    best_match = i
            if best_iou >= iou_threshold:
                matches.append((best_match, best_iou))
                
        # Calculate metrics
        tp = len(matches)
        fp = len(pred_boxes) - tp
        fn = len(true_boxes) - tp
        
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        return {
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'mean_iou': np.mean([m[1] for m in matches]) if matches else 0
        }
        
    def calculate_ocr_metrics(
        self,
        pred_text: str,
        true_text: str
    ) -> Dict[str, float]:
        """
        Calculate OCR-specific metrics.
        
        Args:
            pred_text: Predicted text
            true_text: Ground truth text
            
        Returns:
            Dictionary containing OCR metrics
        """
        # Character Error Rate (CER)
        cer = self._calculate_edit_distance(pred_text, true_text) / len(true_text)
        
        # Word Error Rate (WER)
        pred_words = pred_text.split()
        true_words = true_text.split()
        wer = self._calculate_edit_distance(
            ' '.join(pred_words),
            ' '.join(true_words)
        ) / len(true_words)
        
        return {
            'cer': cer,
            'wer': wer
        }
        
    def _calculate_edit_distance(self, s1: str, s2: str) -> int:
        """Calculate Levenshtein distance between two strings."""
        if len(s1) < len(s2):
            return self._calculate_edit_distance(s2, s1)
            
        if len(s2) == 0:
            return len(s1)
            
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
            
        return previous_row[-1]
        
    def evaluate_all_metrics(
        self,
        predictions: Dict,
        ground_truth: Dict
    ) -> Dict[str, Dict[str, float]]:
        """
        Calculate all relevant metrics for predictions.
        
        Args:
            predictions: Dictionary containing predictions
            ground_truth: Dictionary containing ground truth
            
        Returns:
            Dictionary containing all evaluation metrics
        """
        metrics = {}
        
        # Text generation metrics
        if 'text' in predictions and 'text' in ground_truth:
            metrics['text_metrics'] = {
                **self.calculate_bleu(predictions['text'], ground_truth['text']),
                **self.calculate_rouge(predictions['text'], ground_truth['text']),
                'meteor': self.calculate_meteor(predictions['text'], ground_truth['text'])
            }
            
        # Classification metrics
        if 'labels' in predictions and 'labels' in ground_truth:
            metrics['classification_metrics'] = self.calculate_precision_recall_f1(
                ground_truth['labels'],
                predictions['labels']
            )
            
        # Text detection metrics
        if 'boxes' in predictions and 'boxes' in ground_truth:
            metrics['detection_metrics'] = self.calculate_text_detection_metrics(
                predictions['boxes'],
                ground_truth['boxes']
            )
            
        # OCR metrics
        if 'ocr_text' in predictions and 'ocr_text' in ground_truth:
            metrics['ocr_metrics'] = self.calculate_ocr_metrics(
                predictions['ocr_text'],
                ground_truth['ocr_text']
            )
            
        return metrics
        
    def save_metrics(self, metrics: Dict, output_path: str):
        """
        Save evaluation metrics to file.
        
        Args:
            metrics: Dictionary containing metrics
            output_path: Path to save metrics
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w') as f:
            json.dump(metrics, f, indent=2)
            
    def load_metrics(self, input_path: str) -> Optional[Dict]:
        """
        Load evaluation metrics from file.
        
        Args:
            input_path: Path to load metrics from
            
        Returns:
            Dictionary containing metrics or None if loading fails
        """
        try:
            with open(input_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading metrics: {str(e)}")
            return None