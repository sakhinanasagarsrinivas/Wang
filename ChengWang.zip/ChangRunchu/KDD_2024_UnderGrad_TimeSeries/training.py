import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.utils.data import DataLoader
from typing import Dict, Any, Optional, List
import wandb
from tqdm import tqdm
import logging
from pathlib import Path
import numpy as np

from constants import (
    TrainingConfig, 
    METRICS, 
    PROMPT_PATTERNS
)
from models import BaseAgent
from metrics import calculate_metrics

class InstructionTuningTrainer:
    """
    Instruction Tuning for Time Series Tasks
    Focuses on task-specific learning format
    """
    def __init__(
        self,
        agent: BaseAgent,
        train_loader: DataLoader,
        val_loader: DataLoader,
        config: TrainingConfig,
        task_type: str
    ):
        self.agent = agent
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.config = config
        self.task_type = task_type
        
        # Task-specific prompt templates
        self.prompt_templates = {
            "forecasting": self._generate_forecasting_prompt,
            "anomaly_detection": self._generate_anomaly_prompt,
            "imputation": self._generate_imputation_prompt,
            "classification": self._generate_classification_prompt
        }
    
    def _generate_forecasting_prompt(self, input_data, target):
        """Generate instruction-like prompt for forecasting"""
        return f"""
        Task: Time Series Forecasting
        Historical Data: {input_data}
        Prediction Goal: Forecast next {len(target)} time steps
        Instructions:
        1. Analyze temporal patterns
        2. Consider seasonality and trends
        3. Provide accurate prediction
        """
    
    def _generate_anomaly_prompt(self, input_data, target):
        """Generate instruction-like prompt for anomaly detection"""
        return f"""
        Task: Time Series Anomaly Detection
        Input Sequence: {input_data}
        Detection Goal: Identify abnormal patterns
        Instructions:
        1. Compare against normal behavior
        2. Flag statistically significant deviations
        3. Provide anomaly confidence score
        """
    
    def _generate_imputation_prompt(self, input_data, mask):
        """Generate instruction-like prompt for imputation"""
        return f"""
        Task: Time Series Data Imputation
        Incomplete Data: {input_data}
        Missing Data Mask: {mask}
        Goal: Reconstruct missing values
        Instructions:
        1. Use contextual information
        2. Preserve temporal dependencies
        3. Fill missing values realistically
        """
    
    def _generate_classification_prompt(self, input_data, target):
        """Generate instruction-like prompt for classification"""
        return f"""
        Task: Time Series Regime Classification
        Input Sequence: {input_data}
        Goal: Determine operational regime
        Instructions:
        1. Analyze sequence characteristics
        2. Identify underlying pattern
        3. Assign most probable regime
        """
    
    def create_instruction_dataset(self):
        """
        Convert raw time series data into instruction-formatted dataset
        Adds task-specific context to raw data
        """
        instruction_data = []
        for data, target in self.train_loader:
            prompt_generator = self.prompt_templates.get(self.task_type)
            if prompt_generator:
                prompt = prompt_generator(data, target)
                instruction_data.append((prompt, data, target))
        
        return instruction_data
    
    def train(self):
        """Perform instruction-based fine-tuning"""
        instruction_dataset = self.create_instruction_dataset()
        
        for epoch in range(self.config.num_epochs):
            epoch_loss = 0
            
            for prompt, data, target in instruction_dataset:
                # Forward pass with instruction context
                outputs = self.agent(data, labels=target)
                loss = outputs["loss"]
                
                # Backward pass
                loss.backward()
                
                epoch_loss += loss.item()
            
            print(f"Epoch {epoch+1}, Loss: {epoch_loss/len(instruction_dataset)}")

class DPOTrainer:
    """
    Direct Preference Optimization for Time Series Tasks
    """
    def __init__(
        self,
        agent: BaseAgent,
        preferred_loader: DataLoader,
        dispreferred_loader: DataLoader,
        config: TrainingConfig
    ):
        self.agent = agent
        self.preferred_loader = preferred_loader
        self.dispreferred_loader = dispreferred_loader
        self.config = config
    
    def _preference_scorer(self, pred, target, task_type):
        """
        Create task-specific preference scoring mechanism
        """
        scorers = {
            "forecasting": lambda p, t: -nn.functional.mse_loss(p, t),
            "anomaly_detection": lambda p, t: torch.sum(p == t).float() / len(t)
        }
        
        return scorers.get(task_type, lambda x, y: 0)(pred, target)
    
    def train(self):
        """
        DPO Training Process
        Compares preferred and dispreferred predictions
        """
        for epoch in range(self.config.dpo_epochs):
            for (pref_data, pref_target), (dispref_data, dispref_target) in zip(
                self.preferred_loader, 
                self.dispreferred_loader
            ):
                # Compute preference scores
                pref_score = self._preference_scorer(pref_data, pref_target, self.agent.task_type)
                dispref_score = self._preference_scorer(dispref_data, dispref_target, self.agent.task_type)
                
                # DPO loss encourages model to prefer better predictions
                dpo_loss = -torch.log(1 + torch.exp(pref_score - dispref_score))
                
                dpo_loss.backward()

class AgentTrainer:
    """Trainer class for agents with enhanced training capabilities"""
    def __init__(
        self,
        agent: BaseAgent,
        train_loader: DataLoader,
        val_loader: DataLoader,
        test_loader: Optional[DataLoader] = None,
        config: TrainingConfig = None,
        task_type: str = None,
        experiment_name: str = None,
        checkpoint_dir: Optional[Path] = None
    ):
        self.agent = agent
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.config = config or TrainingConfig()
        self.task_type = task_type
        self.checkpoint_dir = checkpoint_dir or Path("checkpoints")
        self.checkpoint_dir.mkdir(exist_ok=True)
        
        # Enhanced optimizer configuration
        self.optimizer = self._configure_optimizer()
        
        # Learning rate scheduler (optional)
        self.scheduler = self._configure_scheduler()
        
        # Experiment tracking
        self._setup_experiment_tracking(experiment_name)
        
        # Performance tracking
        self.best_val_loss = float('inf')
        self.best_val_metrics = {}

    def _configure_optimizer(self):
        """Configure optimizer with adaptive parameters"""
        return AdamW(
            self.agent.parameters(),
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
            betas=(0.9, 0.999),  # Improved default betas
            eps=1e-8
        )

    def _configure_scheduler(self):
        """Optional learning rate scheduler"""
        from torch.optim.lr_scheduler import CosineAnnealingLR
        return CosineAnnealingLR(
            self.optimizer, 
            T_max=self.config.num_epochs, 
            eta_min=1e-6
        )

    def _setup_experiment_tracking(self, experiment_name):
        """Setup experiment tracking with wandb"""
        if experiment_name:
            wandb.init(
                project="agentic-rag-time-series",
                name=experiment_name,
                config=vars(self.config)
            )

    def train_epoch(self) -> Dict[str, float]:
        """Enhanced training epoch with gradient accumulation"""
        self.agent.train()
        total_loss = 0
        predictions = []
        targets = []
        
        # Progress bar for training
        pbar = tqdm(self.train_loader, desc=f"Training {self.task_type}")
        
        for batch_idx, (data, target) in enumerate(pbar):
            # Move data to device
            data = data.to(self.agent.device)
            target = target.to(self.agent.device)
            
            # Forward pass
            outputs = self.agent(data, labels=target)
            loss = outputs.get("loss", None)
            
            if loss is None:
                logging.warning(f"No loss found for batch {batch_idx}")
                continue
            
            # Gradient accumulation
            loss = loss / self.config.grad_accumulation
            loss.backward()
            
            # Step optimizer periodically
            if (batch_idx + 1) % self.config.grad_accumulation == 0:
                self.optimizer.step()
                self.optimizer.zero_grad()
                
                # Step scheduler if configured
                if self.scheduler:
                    self.scheduler.step()
            
            # Accumulate loss and track predictions
            total_loss += loss.item() * self.config.grad_accumulation
            predictions.extend(outputs["predictions"].detach().cpu().numpy())
            targets.extend(target.detach().cpu().numpy())
            
            pbar.set_postfix({"loss": loss.item()})
        
        # Calculate metrics
        metrics = calculate_metrics(
            predictions=np.array(predictions),
            targets=np.array(targets),
            task_type=self.task_type
        )
        metrics["loss"] = total_loss / len(self.train_loader)
        
        return metrics

    def validate(self) -> Dict[str, float]:
        """Model validation with comprehensive metric tracking"""
        self.agent.eval()
        total_loss = 0
        predictions = []
        targets = []
        
        with torch.no_grad():
            for data, target in self.val_loader:
                data = data.to(self.agent.device)
                target = target.to(self.agent.device)
                
                outputs = self.agent(data, labels=target)
                total_loss += outputs.get("loss", 0).item()
                
                predictions.extend(outputs["predictions"].detach().cpu().numpy())
                targets.extend(target.detach().cpu().numpy())
        
        # Calculate validation metrics
        metrics = calculate_metrics(
            predictions=np.array(predictions),
            targets=np.array(targets),
            task_type=self.task_type
        )
        metrics["loss"] = total_loss / len(self.val_loader)
        
        return metrics

    def train(self):
        """Comprehensive training loop with early stopping"""
        for epoch in range(self.config.num_epochs):
            logging.info(f"Epoch {epoch+1}/{self.config.num_epochs}")
            
            # Training and validation phases
            train_metrics = self.train_epoch()
            val_metrics = self.validate()
            
            # Combine metrics for logging
            metrics = {
                "epoch": epoch,
                "train_loss": train_metrics["loss"],
                "val_loss": val_metrics["loss"]
            }
            
            # Add additional metrics
            for k, v in train_metrics.items():
                if k != "loss":
                    metrics[f"train_{k}"] = v
            for k, v in val_metrics.items():
                if k != "loss":
                    metrics[f"val_{k}"] = v
            
            # Log metrics
            wandb.log(metrics)
            
            # Early stopping and model checkpointing
            if val_metrics["loss"] < self.best_val_loss:
                self.best_val_loss = val_metrics["loss"]
                self.best_val_metrics = val_metrics
                self.save_checkpoint(epoch, val_metrics["loss"])

    def train_with_dpo(
        self,
        preferred_loader: DataLoader,
        dispreferred_loader: DataLoader
    ):
        """Enhanced Direct Preference Optimization training"""
        logging.info("Starting DPO Training")
        
        # DPO-specific optimizer
        dpo_optimizer = AdamW(
            self.agent.parameters(),
            lr=self.config.dpo_learning_rate
        )
        
        for epoch in range(self.config.dpo_epochs):
            total_dpo_loss = 0
            
            pbar = tqdm(
                zip(preferred_loader, dispreferred_loader),
                desc=f"DPO Epoch {epoch+1}/{self.config.dpo_epochs}"
            )
            
            for (pref_data, _), (dispref_data, _) in pbar:
                pref_data = pref_data.to(self.agent.device)
                dispref_data = dispref_data.to(self.agent.device)
                
                # Compute preference scores
                dpo_loss = self._compute_dpo_loss(pref_data, dispref_data)
                
                dpo_loss.backward()
                dpo_optimizer.step()
                dpo_optimizer.zero_grad()
                
                total_dpo_loss += dpo_loss.item()
                pbar.set_postfix({"dpo_loss": dpo_loss.item()})
            
            # Validate after DPO
            val_metrics = self.validate()
            
            wandb.log({
                "dpo_epoch": epoch,
                "dpo_loss": total_dpo_loss / len(preferred_loader),
                "dpo_val_loss": val_metrics["loss"]
            })

    def _compute_dpo_loss(self, pref_data, dispref_data):
        """
        Compute DPO loss based on task type
        """
        task_dpo_losses = {
            "forecasting": self._forecasting_dpo_loss,
            "anomaly_detection": self._anomaly_dpo_loss,
            # Add other task-specific DPO loss computations
        }
        
        loss_fn = task_dpo_losses.get(self.task_type, lambda x, y: torch.tensor(0.0))
        return loss_fn(pref_data, dispref_data)

    def _forecasting_dpo_loss(self, pref_data, dispref_data):
        """DPO loss for forecasting tasks"""
        pref_loss = nn.functional.mse_loss(pref_data, self.agent(pref_data)["predictions"])
        dispref_loss = nn.functional.mse_loss(dispref_data, self.agent(dispref_data)["predictions"])
        return -torch.log(1 + torch.exp(pref_loss - dispref_loss))

    def _anomaly_dpo_loss(self, pref_data, dispref_data):
        """DPO loss for anomaly detection tasks"""
        pref_pred = self.agent(pref_data)["predictions"]
        dispref_pred = self.agent(dispref_data)["predictions"]
        
        pref_accuracy = torch.mean((pref_pred > 0.5).float())
        dispref_accuracy = torch.mean((dispref_pred > 0.5).float())
        
        return -torch.log(1 + torch.exp(pref_accuracy - dispref_accuracy))

    def test(self) -> Dict[str, float]:
        """Model testing phase"""
        if not self.test_loader:
            logging.warning("No test loader provided")
            return {}
        
        self.agent.eval()
        predictions = []
        targets = []
        
        with torch.no_grad():
            for data, target in self.test_loader:
                data = data.to(self.agent.device)
                target = target.to(self.agent.device)
                
                outputs = self.agent(data, labels=target)
                
                predictions.extend(outputs["predictions"].detach().cpu().numpy())
                targets.extend(target.detach().cpu().numpy())
        
        # Calculate test metrics
        test_metrics = calculate_metrics(
            predictions=np.array(predictions),
            targets=np.array(targets),
            task_type=self.task_type
        )
        
        # Log test metrics
        wandb.log({"test_metrics": test_metrics})
        
        return test_metrics

    def save_checkpoint(self, epoch: int, loss: float):
        """Save model checkpoint with enhanced metadata"""
        checkpoint_path = self.checkpoint_dir / f"{self.task_type}_epoch_{epoch}.pt"
        torch.save({
            'epoch': epoch,
            'model_state_dict': self.agent.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict() if self.scheduler else None,
            'loss': loss,
            'task_type': self.task_type,
            'best_val_metrics': self.best_val_metrics
        }, checkpoint_path)
        logging.info(f"Saved checkpoint to {checkpoint_path}")

    def load_checkpoint(self, checkpoint_path: Path):
        """Load model checkpoint with comprehensive state restoration"""
        checkpoint = torch.load(checkpoint_path)
        
        self.agent.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        
        if self.scheduler and checkpoint['scheduler_state_dict']:
            self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        
        # Restore best validation metrics
        self.best_val_metrics = checkpoint.get('best_val_metrics', {})
        
        return (
            checkpoint['epoch'], 
            checkpoint['loss'], 
            checkpoint.get('task_type')
        )