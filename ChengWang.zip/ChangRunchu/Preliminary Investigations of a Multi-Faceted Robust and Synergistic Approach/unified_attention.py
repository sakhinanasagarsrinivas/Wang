import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Tuple

class UnifiedAttention(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.num_heads = config.num_attention_heads
        self.head_dim = config.embed_dim // config.num_attention_heads
        
        # Linear projections for each modality
        self.image_proj = nn.Linear(config.embed_dim, config.embed_dim)
        self.text_proj = nn.Linear(config.embed_dim, config.embed_dim)
        self.pred_proj = nn.Linear(config.embed_dim, config.embed_dim)
        
        # Attention projections
        self.q_proj = nn.Linear(config.embed_dim, config.embed_dim)
        self.k_proj = nn.Linear(config.embed_dim, config.embed_dim)
        self.v_proj = nn.Linear(config.embed_dim, config.embed_dim)
        
        # Output projection
        self.out_proj = nn.Linear(config.embed_dim, config.embed_dim)
        
        # Layer normalization
        self.norm1 = nn.LayerNorm(config.embed_dim)
        self.norm2 = nn.LayerNorm(config.embed_dim)
        
        # MLP
        self.mlp = nn.Sequential(
            nn.Linear(config.embed_dim, config.embed_dim * 4),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.embed_dim * 4, config.embed_dim),
            nn.Dropout(config.dropout)
        )
        
    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        """Split tensor into multiple attention heads."""
        B, N, D = x.shape
        x = x.reshape(B, N, self.num_heads, self.head_dim)
        return x.permute(0, 2, 1, 3)  # (B, num_heads, N, head_dim)
        
    def _merge_heads(self, x: torch.Tensor) -> torch.Tensor:
        """Merge attention heads back together."""
        B, H, N, D = x.shape
        x = x.permute(0, 2, 1, 3)  # (B, N, num_heads, head_dim)
        return x.reshape(B, N, H * D)
        
    def attention(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, 
                 mask: torch.Tensor = None) -> torch.Tensor:
        """Compute scaled dot-product attention."""
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))
            
        attn_weights = F.softmax(scores, dim=-1)
        output = torch.matmul(attn_weights, v)
        return output
        
    def forward(self, image_embed: torch.Tensor, text_embed: torch.Tensor, 
                pred_embed: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of unified attention.
        
        Args:
            image_embed: Image embeddings (B, D)
            text_embed: Text embeddings (B, D)
            pred_embed: Prediction embeddings (B, D)
            
        Returns:
            Combined cross-modal embedding (B, D)
        """
        # Project each modality
        image_proj = self.image_proj(image_embed).unsqueeze(1)  # (B, 1, D)
        text_proj = self.text_proj(text_embed).unsqueeze(1)     # (B, 1, D)
        pred_proj = self.pred_proj(pred_embed).unsqueeze(1)     # (B, 1, D)
        
        # Concatenate all modalities
        concat_embed = torch.cat([image_proj, text_proj, pred_proj], dim=1)  # (B, 3, D)
        
        # First attention block
        residual = concat_embed
        concat_embed = self.norm1(concat_embed)
        
        # Multi-head attention
        q = self._split_heads(self.q_proj(concat_embed))
        k = self._split_heads(self.k_proj(concat_embed))
        v = self._split_heads(self.v_proj(concat_embed))
        
        attn_output = self.attention(q, k, v)
        attn_output = self._merge_heads(attn_output)
        attn_output = self.out_proj(attn_output)
        
        # First residual connection
        concat_embed = residual + attn_output
        
        # MLP block
        residual = concat_embed
        concat_embed = self.norm2(concat_embed)
        concat_embed = residual + self.mlp(concat_embed)
        
        # Average pool across sequence dimension
        cross_modal_embed = torch.mean(concat_embed, dim=1)
        
        return cross_modal_embed

class HierarchicalUnifiedAttention(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.image_text_attention = UnifiedAttention(config)
        self.final_attention = UnifiedAttention(config)
        
    def forward(self, image_embed: torch.Tensor, text_embed: torch.Tensor, 
                pred_embed: torch.Tensor) -> torch.Tensor:
        """
        Apply hierarchical attention: first between image and text,
        then combine with prediction embedding.
        """
        # First level: image-text attention
        img_text_combined = self.image_text_attention(
            image_embed, text_embed, image_embed)  # Use image as placeholder
            
        # Second level: combine with prediction embedding
        final_embed = self.final_attention(
            img_text_combined, pred_embed, pred_embed)  # Use pred as placeholder
            
        return final_embed