import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import json
import argparse
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.interpolate import interp1d
import time
import os
import math

torch.manual_seed(42)
np.random.seed(42)

class GaussianRandomField:
    def __init__(self, size, length_scale, device='cpu'):
        self.size = size
        self.device = device
        freqs = torch.fft.rfftfreq(size, d=1/size).to(device)
        self.power_spectrum = (1.0 / (2.0 * np.pi * length_scale**2)) * \
                              torch.exp(-0.5 * freqs**2 * length_scale**2)
        self.power_spectrum[0] = 0

    def sample(self, n_samples, mean=0.0, stddev=1.0):
        rand_coeffs = torch.randn(n_samples, self.size // 2 + 1, dtype=torch.cfloat, device=self.device) * np.sqrt(self.size)
        f_coeffs = rand_coeffs * torch.sqrt(self.power_spectrum)
        field = torch.fft.irfft(f_coeffs, n=self.size, norm='ortho')
        field_std = torch.std(field, dim=-1, keepdim=True)
        field = field / (field_std + 1e-8) * stddev
        field += mean
        return field.unsqueeze(-1)

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=512):
        super().__init__()
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, 1, d_model)
        pe[:, 0, 0::2] = torch.sin(position * div_term)
        pe[:, 0, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:x.size(0)]
        return x

class TransformerOperator1D(nn.Module):
    def __init__(self, in_channels, out_channels, embed_dim, num_heads, num_blocks, dropout, seq_len):
        super().__init__()
        self.embed_dim = embed_dim
        self.fc0 = nn.Linear(in_channels, embed_dim)
        self.pos_encoder = PositionalEncoding(embed_dim, max_len=seq_len)
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads,
                                                   dim_feedforward=4*embed_dim,
                                                   dropout=dropout, batch_first=True, activation='gelu')
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_blocks)
        self.fc1 = nn.Linear(embed_dim, embed_dim * 2)
        self.fc2 = nn.Linear(embed_dim * 2, out_channels)
        self.dropout = nn.Dropout(dropout)
        self.apply(self._initialize_weights)

    def _initialize_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)

    def forward(self, x):
        x = self.fc0(x)
        x = x.permute(1, 0, 2)
        x = self.pos_encoder(x)
        x = x.permute(1, 0, 2)
        x = self.transformer_encoder(x)
        x = self.dropout(F.gelu(self.fc1(x)))
        x = self.fc2(x)
        return x

class TransformerNOSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._define_normalization_scales()
        self._setup_grid_and_data_generator()
        self._build_model()

    def _parse_config(self):
        problem_config = self.config['problems'][0]
        self.problem = problem_config['problem_definition']
        self.op_inputs = problem_config['operator_input_specification']
        self.hp_model = self.config['hyperparameters']['transformer_architecture']
        self.hp_train = self.config['hyperparameters']['training']
        self.state_vars = self.problem['state_variables']

    def _define_normalization_scales(self):
        self.T_in_range = self.op_inputs['boundary_conditions_distribution']['T_in']
        self.UA_range = self.op_inputs['scalar_inputs_distribution']['UA']
        self.mdotcp_range = self.op_inputs['scalar_inputs_distribution']['m_dot_Cp']
        self.Th_params = self.op_inputs['function_inputs']['Th_z']['parameters']
        self.T_in_mean = np.mean(self.T_in_range)
        self.Th_mean = self.Th_params['mean']
        self.T_scale = self.Th_mean - self.T_in_mean

    def _setup_grid_and_data_generator(self):
        self.z_domain = self.op_inputs['discretization']['z_domain']
        self.nz = self.op_inputs['discretization']['num_z_points']
        self.z_grid = torch.linspace(self.z_domain[0], self.z_domain[1], self.nz, device=self.device).view(-1, 1)
        grf_params = self.op_inputs['function_inputs']['Th_z']['parameters']
        self.grf = GaussianRandomField(self.nz, grf_params['length_scale'], device=self.device)
        self.grf_mean = grf_params['mean']
        self.grf_std = grf_params['stddev']

    def _build_model(self):
        in_channels = 1 + 1 + len(self.op_inputs['boundary_conditions_distribution']) + len(self.op_inputs['scalar_inputs_distribution'])
        out_channels = len(self.state_vars)
        seq_len = self.op_inputs['discretization']['num_z_points']
        self.model = TransformerOperator1D(
            in_channels=in_channels,
            out_channels=out_channels,
            embed_dim=self.hp_model['embed_dim'],
            num_heads=self.hp_model['num_heads'],
            num_blocks=self.hp_model['num_blocks'],
            dropout=self.hp_model['dropout'],
            seq_len=seq_len
        ).to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.hp_train['learning_rate'],
            weight_decay=self.hp_train['weight_decay']
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=self.hp_train['epochs'])

    def _generate_batch(self, batch_size):
        Th_z_funcs = self.grf.sample(batch_size, self.grf_mean, self.grf_std)
        batch_bcs = torch.rand(batch_size, 1, device=self.device) * (self.T_in_range[1] - self.T_in_range[0]) + self.T_in_range[0]
        batch_ua = torch.rand(batch_size, 1, device=self.device) * (self.UA_range[1] - self.UA_range[0]) + self.UA_range[0]
        batch_mdotcp = torch.rand(batch_size, 1, device=self.device) * (self.mdotcp_range[1] - self.mdotcp_range[0]) + self.mdotcp_range[0]

        Th_z_norm = (Th_z_funcs - self.Th_mean) / self.Th_params['stddev']
        bcs_norm = (batch_bcs - self.T_in_mean) / self.T_scale
        ua_norm = (batch_ua - np.mean(self.UA_range)) / (self.UA_range[1] - self.UA_range[0])
        mdotcp_norm = (batch_mdotcp - np.mean(self.mdotcp_range)) / (self.mdotcp_range[1] - self.mdotcp_range[0])

        grid = self.z_grid.unsqueeze(0).repeat(batch_size, 1, 1) / self.z_domain[1]
        bcs_grid = bcs_norm.unsqueeze(1).repeat(1, self.nz, 1)
        ua_grid = ua_norm.unsqueeze(1).repeat(1, self.nz, 1)
        mdotcp_grid = mdotcp_norm.unsqueeze(1).repeat(1, self.nz, 1)
        model_input = torch.cat([Th_z_norm, grid, bcs_grid, ua_grid, mdotcp_grid], dim=-1)
        return model_input, Th_z_funcs, batch_bcs, batch_ua, batch_mdotcp

    def _physics_residual_loss(self, u_pred_norm, Th_z, T_in, ua, mdotcp):
        dz = (self.z_domain[1] - self.z_domain[0]) / (self.nz - 1)
        du_dz_interior = (u_pred_norm[:, 2:, :] - u_pred_norm[:, :-2, :]) / (2 * dz)
        du_dz_start = (u_pred_norm[:, 1:2, :] - u_pred_norm[:, 0:1, :]) / dz
        du_dz_end = (u_pred_norm[:, -1:, :] - u_pred_norm[:, -2:-1, :]) / dz
        du_dz_norm = torch.cat([du_dz_start, du_dz_interior, du_dz_end], dim=1)

        T_pred = T_in.view(-1, 1, 1) + self.T_scale * u_pred_norm
        lhs = self.T_scale * du_dz_norm.squeeze(-1)
        rhs = (ua.view(-1, 1) / mdotcp.view(-1, 1)) * (Th_z.squeeze(-1) - T_pred.squeeze(-1))
        residual = lhs - rhs
        return torch.mean(residual**2)

    def _bc_loss(self, u_pred_norm, batch_bcs_ignored):
        u_pred_bc = u_pred_norm[:, 0, :]
        return F.mse_loss(u_pred_bc, torch.zeros_like(u_pred_bc))

    def train(self):
        print("--- Starting Transformer NO Training ---")
        start_time = time.time()
        self.model.train()
        
        bc_weight = self.hp_train['loss_weights']['boundary_condition']
        pde_weight = self.hp_train['loss_weights']['pde_residual']
        print(f"Using constant loss weights: PDE={pde_weight}, BC={bc_weight}")

        for epoch in range(self.hp_train['epochs']):
            model_input, Th_z, T_in, ua, mdotcp = self._generate_batch(self.hp_train['batch_size'])
            self.optimizer.zero_grad(set_to_none=True)
            u_pred_norm = self.model(model_input)
            loss_pde = self._physics_residual_loss(u_pred_norm, Th_z, T_in, ua, mdotcp)
            loss_bc = self._bc_loss(u_pred_norm, T_in)
            
            total_loss = pde_weight * loss_pde + bc_weight * loss_bc
            
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.hp_train['gradient_clip_norm'])
            self.optimizer.step()
            self.scheduler.step()
            if (epoch + 1) % 1000 == 0:
                print(f'Epoch [{epoch+1}/{self.hp_train["epochs"]}], Loss: {total_loss.item():.4e}, '
                      f'PDE Loss: {loss_pde.item():.4e}, BC Loss: {loss_bc.item():.4e}, LR: {self.scheduler.get_last_lr()[0]:.2e}')
        elapsed = time.time() - start_time
        print(f"--- Training finished in {elapsed:.2f} seconds ---")

    def evaluate_and_plot(self):
        num_test_cases = self.config['hyperparameters']['evaluation']['test_cases']
        print(f"\n--- Evaluating on {num_test_cases} unseen test cases ---")
        self.model.eval()
        os.makedirs("results_tno", exist_ok=True)
        model_input, Th_z, bcs, ua, mdotcp = self._generate_batch(num_test_cases)
        with torch.no_grad():
            u_tno_norm = self.model(model_input).cpu()
        T_in_broadcast = bcs.cpu().view(-1, 1, 1)
        u_tno = T_in_broadcast + self.T_scale * u_tno_norm
        z_np = self.z_grid.cpu().numpy().flatten()
        Th_z_np = Th_z.cpu().numpy()
        bcs_np = bcs.cpu().numpy()
        ua_np = ua.cpu().numpy()
        mdotcp_np = mdotcp.cpu().numpy()
        fig, axes = plt.subplots(num_test_cases, 1, figsize=(8, 4 * num_test_cases), squeeze=False)
        all_errors = []
        for i in range(num_test_cases):
            params = {'UA': ua_np[i, 0], 'm_dot_Cp': mdotcp_np[i, 0]}
            sol_numerical_np = self.solve_numerically(z_np, bcs_np[i, 0], Th_z_np[i, :, 0], params)
            sol_numerical = torch.from_numpy(sol_numerical_np)
            relative_l2_error = torch.norm(u_tno[i] - sol_numerical) / torch.norm(sol_numerical)
            all_errors.append(relative_l2_error.item())
            print(f"Test Case {i+1} | T_in: {bcs_np[i,0]:.2f} K, UA: {ua_np[i,0]:.1f}, m_dot_Cp: {mdotcp_np[i,0]:.1f} | Rel L2 Error: {relative_l2_error.item():.4e}")
            ax = axes[i, 0]
            ax.plot(z_np, sol_numerical_np[:, 0], 'k-', label='Numerical', linewidth=2)
            ax.plot(z_np, u_tno[i, :, 0], 'r--', label='TNO')
            ax.plot(z_np, Th_z_np[i, :, 0], 'b:', label='$T_h(z)$ (Input)', alpha=0.7)
            ax.set_ylabel('Temperature (K)')
            ax.grid(True, linestyle='--', alpha=0.6)
            ax.set_title(f'Test Case {i+1}')
            if i == num_test_cases - 1:
                ax.set_xlabel(self.problem['independent_variable']['label'])
            ax.legend()
        print(f"\nMean Relative L2 Error over {num_test_cases} cases: {np.mean(all_errors):.4e}")
        fig.suptitle('TNO Generalization on Unseen Heat Exchanger Problems', fontsize=16)
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.savefig("results_tno/tno_generalization_test.pdf")
        plt.close()
        print("\nEvaluation plot saved to results_tno/tno_generalization_test.pdf")

    def solve_numerically(self, z_eval, y0, Th_z_values, params):
        Th_interp = interp1d(z_eval, Th_z_values, bounds_error=False, fill_value="extrapolate")
        def ode_system(z, y):
            scope = {'z': z, 'Th_z': Th_interp(z), 'T': y[0]}
            scope.update(params)
            dydz_str = self.problem['pde']['dTdz']
            dydz = eval(dydz_str, {}, scope)
            return [dydz]
        sol = solve_ivp(ode_system, self.z_domain, [y0], t_eval=z_eval, method='DOP853', rtol=1e-8, atol=1e-10)
        return sol.y.T

def main():
    parser = argparse.ArgumentParser(description="Transformer Neural Operator for Heat Exchanger")
    parser.add_argument(
        "config_file", type=str,
        help="Path to the JSON configuration file.",
        default="problem_config.json", nargs='?'
    )
    args = parser.parse_args()
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    solver = TransformerNOSolver(config)
    solver.train()
    solver.evaluate_and_plot()

if __name__ == "__main__":
    main()