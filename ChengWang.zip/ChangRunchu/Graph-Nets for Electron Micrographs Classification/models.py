import torch
import torch.nn as nn
import torch.nn.functional as F
import logging

class GraphEncoder(nn.Module):
    """
    Graph Encoder with Message Passing and Attention
    Learns representations by propagating information across graph nodes
    """
    def __init__(self, input_dim, hidden_dim, num_layers=6, num_heads=4):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.num_layers = num_layers
        self.master_node_embed = nn.Parameter(torch.randn(1, hidden_dim))
        
        # Graph convolution layers
        self.graph_convs = nn.ModuleList([
            nn.Linear(input_dim if i == 0 else hidden_dim, hidden_dim) 
            for i in range(num_layers)
        ])
        
        # Multi-head attention
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=num_heads)
    
    def forward(self, x, adjacency_matrix):
        """
        Forward pass through the graph encoder
        
        Args:
            x (torch.Tensor): Input node features
            adjacency_matrix (torch.Tensor): Graph adjacency matrix
        
        Returns:
            torch.Tensor: Aggregated graph representation
        """
        batch_size, num_nodes, node_dim = x.shape
        
        # Add virtual master node
        master_node = self.master_node_embed.expand(batch_size, 1, -1)
        x = torch.cat([master_node, x], dim=1)
        
        # Message passing and attention
        for layer in range(self.num_layers):
            # Graph convolution
            x = F.relu(self.graph_convs[layer](x))
            
            # Multi-head attention
            attn_output, _ = self.attention(x, x, x)
            x = x + attn_output
        
        return torch.mean(x, dim=1)

class GraphPoolingLayer(nn.Module):
    """
    Graph Pooling Layer with Node Importance Scoring
    Selects and aggregates most important nodes in the graph
    """
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Projection layer
        self.projection = nn.Linear(input_dim, output_dim)
        
        # Multi-head attention for node refinement
        self.attention = nn.MultiheadAttention(output_dim, num_heads=4)
    
    def forward(self, x, adjacency_matrix):
        """
        Forward pass through the graph pooling layer
        
        Args:
            x (torch.Tensor): Input node features
            adjacency_matrix (torch.Tensor): Graph adjacency matrix
        
        Returns:
            tuple: Pooled features and updated adjacency matrix
        """
        # Project and activate
        x = F.relu(self.projection(x))
        
        # Node importance scoring
        importance_scores = torch.sum(x, dim=-1)
        k = int(x.size(1) * 0.75)  # Keep top 75% nodes
        _, top_indices = torch.topk(importance_scores, k, dim=1)
        
        # Select top nodes
        x_pooled = torch.gather(
            x, 
            1, 
            top_indices.unsqueeze(-1).expand(-1, -1, x.size(-1))
        )
        
        # Attention-based refinement
        attn_output, _ = self.attention(x_pooled, x_pooled, x_pooled)
        x_pooled = x_pooled + attn_output
        
        return x_pooled, adjacency_matrix

class HierarchicalGraphEncoder(nn.Module):
    """
    Hierarchical Graph Encoder with Multiple Pooling Layers
    Progressively reduces graph complexity while capturing multi-scale features
    """
    def __init__(self, input_dim, hidden_dim, num_layers=3):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.graph_layers = nn.ModuleList([
            GraphPoolingLayer(
                input_dim if i == 0 else hidden_dim, 
                hidden_dim
            ) for i in range(num_layers)
        ])
    
    def forward(self, x, adjacency_matrix):
        """
        Forward pass through hierarchical graph encoder
        
        Args:
            x (torch.Tensor): Input node features
            adjacency_matrix (torch.Tensor): Graph adjacency matrix
        
        Returns:
            torch.Tensor: Hierarchical graph representation
        """
        for layer in self.graph_layers:
            x, adjacency_matrix = layer(x, adjacency_matrix)
        
        return torch.mean(x, dim=1)

class CliqueTreeEncoder(nn.Module):
    """
    Clique Tree Encoder with Hierarchical Message Passing
    Captures local structural relationships in graph-like data
    """
    def __init__(self, input_dim, hidden_dim):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Transform input features to hidden dimension
        self.node_transform = nn.Linear(input_dim, hidden_dim)
        
        # Recurrent cell for message passing
        self.gru_cell = nn.GRUCell(hidden_dim, hidden_dim)
    
    def forward(self, clique_tree):
        """
        Forward pass through clique tree encoder
        
        Args:
            clique_tree (torch.Tensor): Input clique tree features
        
        Returns:
            torch.Tensor: Aggregated clique tree representation
        """
        # Transform and activate node features
        clique_tree = F.relu(self.node_transform(clique_tree))
        
        # Bottom-up message passing
        for i in range(len(clique_tree) - 1, -1, -1):
            node = clique_tree[i]
            parent_messages = self._aggregate_parent_messages(clique_tree, i)
            node = self.gru_cell(parent_messages, node)
        
        return clique_tree[0]
    
    def _aggregate_parent_messages(self, clique_tree, node_idx):
        """
        Aggregate messages from other nodes in the clique tree
        
        Args:
            clique_tree (torch.Tensor): Clique tree features
            node_idx (int): Current node index
        
        Returns:
            torch.Tensor: Aggregated parent messages
        """
        messages = []
        for j in range(len(clique_tree)):
            if j != node_idx:
                message = torch.mean(clique_tree[j], dim=0)
                messages.append(message)
        
        return (torch.stack(messages).mean(dim=0) 
                if messages 
                else torch.zeros_like(clique_tree[node_idx]))

class EMCNet(nn.Module):
    """
    Complete EMCNet Architecture
    Combines multiple graph-based encoders for comprehensive representation learning
    """
    def __init__(self, config):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Multiple graph encoders
        self.graph_encoder = GraphEncoder(
            config.input_dim, 
            config.hidden_dim
        )
        self.hierarchical_encoder = HierarchicalGraphEncoder(
            config.input_dim, 
            config.hidden_dim
        )
        self.clique_tree_encoder = CliqueTreeEncoder(
            config.input_dim, 
            config.hidden_dim
        )
        
        # Classification output layers
        self.output_layer = nn.Sequential(
            nn.Linear(config.hidden_dim * 3, config.hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(config.hidden_dim, config.num_classes)
        )
    
    def forward(self, batch):
        """
        Forward pass through the entire EMCNet architecture
        
        Args:
            batch (dict): Input batch containing patches, adjacency matrix, and clique tree
        
        Returns:
            torch.Tensor: Class predictions
        """
        patches = batch['patches']
        adjacency_matrix = batch['adjacency_matrix']
        clique_tree = batch['clique_tree']
        
        # Extract representations from different graph encoders
        graph_repr = self.graph_encoder(patches, adjacency_matrix)
        hierarchical_repr = self.hierarchical_encoder(patches, adjacency_matrix)
        tree_repr = self.clique_tree_encoder(clique_tree)
        
        # Combine representations
        combined_repr = torch.cat([graph_repr, hierarchical_repr, tree_repr], dim=1)
        
        return self.output_layer(combined_repr)