from typing import Dict, Any, List
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import logging

class ActionGenerator:
    def __init__(self, model_name: str = "meta-llama/Llama-2-7b-chat-hf"):
        self.model_name = model_name
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name)
        
    def generate_action(self, query: str, history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate next action based on query and solution history"""
        try:
            # Prepare input context
            context = self._prepare_context(query, history)
            
            # Generate action
            inputs = self.tokenizer(context, return_tensors="pt")
            outputs = self.model.generate(**inputs, max_length=200)
            
            # Parse generated action
            action = self._parse_action(
                self.tokenizer.decode(outputs[0])
            )
            
            return action
            
        except Exception as e:
            logging.error(f"Error generating action: {str(e)}")
            return None
            
    def _prepare_context(self, query: str, history: List[Dict[str, Any]]) -> str:
        """Prepare context for action generation"""
        context = f"""
        Query: {query}
        
        Solution History:
        """
        
        for step in history:
            context += f"""
            Step: {step.get('step_number')}
            Action: {step.get('action')}
            Result: {step.get('result')}
            """
            
        context += "\nNext Action:"

        return context
        
    def _parse_action(self, generated_text: str) -> Dict[str, Any]:
        """Parse generated text into structured action"""
        try:
            # Extract relevant parts from generated text
            lines = generated_text.strip().split('\n')
            action_text = lines[0]
            
            # Parse into components
            action = {
                'type': self._identify_action_type(action_text),
                'description': action_text,
                'parameters': self._extract_parameters(action_text),
                'tool_required': self._identify_required_tool(action_text)
            }
            
            return action
            
        except Exception as e:
            logging.error(f"Error parsing action: {str(e)}")
            return None
            
    def _identify_action_type(self, text: str) -> str:
        """Identify the type of action from text"""
        action_types = {
            'calculate': 'computation',
            'solve': 'computation',
            'generate': 'code_generation',
            'retrieve': 'knowledge_retrieval',
            'search': 'knowledge_retrieval',
            'analyze': 'analysis'
        }
        
        text_lower = text.lower()
        for keyword, action_type in action_types.items():
            if keyword in text_lower:
                return action_type
                
        return 'general'
        
    def _extract_parameters(self, text: str) -> Dict[str, Any]:
        """Extract parameters from action text"""
        # Basic parameter extraction
        parameters = {}
        
        # Look for numeric values
        import re
        numbers = re.findall(r'\d+(?:\.\d+)?', text)
        if numbers:
            parameters['numeric_values'] = numbers
            
        # Look for units
        units = re.findall(r'\b(kg|m3|Pa|K|°C|mol|L)\b', text)
        if units:
            parameters['units'] = units
            
        return parameters
        
    def _identify_required_tool(self, text: str) -> str:
        """Identify the required tool for the action"""
        tool_keywords = {
            'code': 'code_generator',
            'calculate': 'calculator',
            'solve': 'equation_solver',
            'search': 'knowledge_base',
            'retrieve': 'knowledge_base',
            'analyze': 'analyzer'
        }
        
        text_lower = text.lower()
        for keyword, tool in tool_keywords.items():
            if keyword in text_lower:
                return tool
                
        return 'general_tool'