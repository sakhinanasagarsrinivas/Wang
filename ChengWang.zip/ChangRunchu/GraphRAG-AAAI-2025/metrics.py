from typing import List, Dict, Any
import numpy as np
from sklearn.metrics import precision_recall_fscore_support
import logging

class Metrics:
    @staticmethod
    def calculate_tool_usage_awareness(predictions: List[Dict[str, Any]], 
                                     references: List[Dict[str, Any]]) -> float:
        """Calculate Tool Usage Awareness metric"""
        try:
            correct = 0
            total = len(predictions)
            
            for pred, ref in zip(predictions, references):
                if pred['tool_required'] == ref['tool_required']:
                    correct += 1
                    
            return correct / total if total > 0 else 0
            
        except Exception as e:
            logging.error(f"Error calculating TUA: {str(e)}")
            return 0.0
            
    @staticmethod
    def calculate_pass_rate(predictions: List[Dict[str, Any]], 
                          references: List[Dict[str, Any]]) -> float:
        """Calculate Pass Rate metric"""
        try:
            successful = 0
            total = len(predictions)
            
            for pred, ref in zip(predictions, references):
                if pred['status'] == 'success' and pred['result'] == ref['result']:
                    successful += 1
                    
            return successful / total if total > 0 else 0
            
        except Exception as e:
            logging.error(f"Error calculating Pass Rate: {str(e)}")
            return 0.0
            
    @staticmethod
    def calculate_accuracy(predictions: List[Dict[str, Any]], 
                         references: List[Dict[str, Any]]) -> float:
        """Calculate Accuracy metric"""
        try:
            correct = 0
            total = len(predictions)
            
            for pred, ref in zip(predictions, references):
                if pred == ref:  # This might need more sophisticated comparison
                    correct += 1
                    
            return correct / total if total > 0 else 0
            
        except Exception as e:
            logging.error(f"Error calculating Accuracy: {str(e)}")
            return 0.0
            
    @staticmethod
    def calculate_recall_at_k(predictions: List[List[str]], 
                            references: List[List[str]], 
                            k: int) -> float:
        """Calculate Recall@K metric"""
        try:
            recalls = []
            for pred, ref in zip(predictions, references):
                pred_at_k = pred[:k]
                recall = len(set(pred_at_k) & set(ref)) / len(set(ref))
                recalls.append(recall)
                
            return np.mean(recalls)
            
        except Exception as e:
            logging.error(f"Error calculating Recall@K: {str(e)}")
            return 0.0
            
    @staticmethod
    def calculate_ndcg(predictions: List[List[str]], 
                      references: List[List[str]], 
                      k: int) -> float:
        """Calculate NDCG metric"""
        try:
            ndcg_scores = []
            for pred, ref in zip(predictions, references):
                dcg = Metrics._dcg_at_k(pred, ref, k)
                idcg = Metrics._dcg_at_k(ref, ref, k)
                ndcg = dcg / idcg if idcg > 0 else 0
                ndcg_scores.append(ndcg)
                
            return np.mean(ndcg_scores)
            
        except Exception as e:
            logging.error(f"Error calculating NDCG: {str(e)}")
            return 0.0
            
    @staticmethod
    def _dcg_at_k(predicted: List[str], 
                  relevant: List[str], 
                  k: int) -> float:
        """Calculate DCG@K"""
        dcg = 0
        for i, item in enumerate(predicted[:k]):
            rel = 1 if item in relevant else 0
            dcg += rel / np.log2(i + 2)
        return dcg