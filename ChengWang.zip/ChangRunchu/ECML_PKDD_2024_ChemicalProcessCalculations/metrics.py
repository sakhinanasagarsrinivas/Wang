# rait_framework/evaluation/metrics.py
import numpy as np
import logging
from typing import List, Dict, Any, Optional

import nltk
from nltk.translate.bleu_score import sentence_bleu
from rouge import Rouge
import json

class RAITMetrics:
    """
    Comprehensive evaluation metrics for Retrieval-Augmented Instruction-Tuning (RAIT) Framework
    """
    def __init__(self):
        """
        Initialize evaluation metrics with comprehensive logging
        """
        # Logging configuration
        self.logger = logging.getLogger(self.__class__.__name__)
        logging.basicConfig(level=logging.INFO)
        
        # Download necessary NLTK resources
        try:
            nltk.download('punkt', quiet=True)
        except Exception as e:
            self.logger.warning(f"NLTK download error: {e}")
        
        # Initialize ROUGE scorer
        self.rouge_scorer = Rouge()
    
    def evaluate_tool_usage(self, 
                             solutions: List[Dict[str, Any]], 
                             ground_truth: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Comprehensive tool usage evaluation
        
        Args:
            solutions (List[Dict[str, Any]]): Generated solutions
            ground_truth (List[Dict[str, Any]], optional): Ground truth solutions
        
        Returns:
            Dict[str, Any]: Tool usage metrics
        """
        # Analyze tool usage across solutions
        tool_usage_metrics = {
            'total_tools_used': 0,
            'unique_tools': set(),
            'tool_frequency': {},
            'domain_tool_distribution': {}
        }
        
        for solution in solutions:
            # Extract tools from solution
            tools = solution.get('tools_used', [])
            domain = solution.get('domain', 'unknown')
            
            # Update metrics
            tool_usage_metrics['total_tools_used'] += len(tools)
            tool_usage_metrics['unique_tools'].update(tools)
            
            # Track tool frequency
            for tool in tools:
                tool_usage_metrics['tool_frequency'][tool] = \
                    tool_usage_metrics['tool_frequency'].get(tool, 0) + 1
            
            # Track domain-specific tool distribution
            if domain not in tool_usage_metrics['domain_tool_distribution']:
                tool_usage_metrics['domain_tool_distribution'][domain] = {}
            
            for tool in tools:
                domain_tools = tool_usage_metrics['domain_tool_distribution'][domain]
                domain_tools[tool] = domain_tools.get(tool, 0) + 1
        
        # Convert unique tools to list
        tool_usage_metrics['unique_tools'] = list(tool_usage_metrics['unique_tools'])
        
        return tool_usage_metrics
    
    def compute_code_quality_metrics(self, 
                                     generated_solutions: List[str], 
                                     reference_solutions: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Compute code quality metrics
        
        Args:
            generated_solutions (List[str]): Generated code solutions
            reference_solutions (List[str], optional): Reference solutions
        
        Returns:
            Dict[str, Any]: Code quality metrics
        """
        metrics = {
            'bleu_scores': [],
            'code_complexity': [],
            'unique_tokens': [],
            'function_count': []
        }
        
        # Compute metrics for each solution
        for code in generated_solutions:
            try:
                # BLEU score computation
                if reference_solutions:
                    bleu_scores = []
                    for ref in reference_solutions:
                        reference_tokens = [nltk.word_tokenize(ref.lower())]
                        candidate_tokens = nltk.word_tokenize(code.lower())
                        bleu_scores.append(sentence_bleu(reference_tokens, candidate_tokens))
                    metrics['bleu_scores'].append(np.mean(bleu_scores))
                
                # Code complexity (basic estimation)
                import ast
                tree = ast.parse(code)
                
                # Cyclomatic complexity
                complexity = sum(
                    isinstance(node, (ast.If, ast.While, ast.For, ast.Try, ast.ExceptHandler)) 
                    for node in ast.walk(tree)
                )
                metrics['code_complexity'].append(complexity)
                
                # Unique tokens
                unique_tokens = len(set(nltk.word_tokenize(code.lower())))
                metrics['unique_tokens'].append(unique_tokens)
                
                # Function count
                function_count = sum(
                    isinstance(node, ast.FunctionDef) 
                    for node in ast.walk(tree)
                )
                metrics['function_count'].append(function_count)
            
            except Exception as e:
                self.logger.warning(f"Metric computation error: {e}")
                # Add placeholder values for failed computations
                metrics['bleu_scores'].append(0)
                metrics['code_complexity'].append(0)
                metrics['unique_tokens'].append(0)
                metrics['function_count'].append(0)
        
        # Compute aggregate metrics
        return {
            key: {
                'mean': np.mean(values),
                'std': np.std(values),
                'min': np.min(values),
                'max': np.max(values)
            } 
            for key, values in metrics.items()
        }
    
    def compute_retrieval_metrics(self, 
                                  retrieved_contexts: List[List[str]], 
                                  ground_truth_contexts: Optional[List[List[str]]] = None) -> Dict[str, Any]:
        """
        Evaluate retrieval performance
        
        Args:
            retrieved_contexts (List[List[str]]): Retrieved context snippets
            ground_truth_contexts (List[List[str]], optional): Ground truth contexts
        
        Returns:
            Dict[str, Any]: Retrieval performance metrics
        """
        # Similarity and relevance computation
        retrieval_metrics = {
            'avg_context_length': [],
            'context_diversity': [],
            'semantic_coverage': []
        }
        
        from sentence_transformers import SentenceTransformer
        from sklearn.metrics.pairwise import cosine_similarity
        
        # Use sentence transformer for semantic similarity
        embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        for contexts in retrieved_contexts:
            try:
                # Average context length
                retrieval_metrics['avg_context_length'].append(
                    np.mean([len(context.split()) for context in contexts])
                )
                
                # Context diversity (semantic uniqueness)
                context_embeddings = embedding_model.encode(contexts)
                similarity_matrix = cosine_similarity(context_embeddings)
                np.fill_diagonal(similarity_matrix, 0)  # Ignore self-similarity
                diversity_score = 1 - np.mean(similarity_matrix)
                retrieval_metrics['context_diversity'].append(diversity_score)
                
                # Semantic coverage (if ground truth available)
                if ground_truth_contexts:
                    ground_truth_embeddings = embedding_model.encode(
                        [item for sublist in ground_truth_contexts for item in sublist]
                    )
                    coverage_scores = [
                        np.max(cosine_similarity(
                            embedding_model.encode(context).reshape(1, -1), 
                            ground_truth_embeddings
                        )) 
                        for context in contexts
                    ]
                    retrieval_metrics['semantic_coverage'].append(np.mean(coverage_scores))
            
            except Exception as e:
                self.logger.warning(f"Retrieval metric computation error: {e}")
                # Add placeholder values
                retrieval_metrics['avg_context_length'].append(0)
                retrieval_metrics['context_diversity'].append(0)
                retrieval_metrics['semantic_coverage'].append(0)
        
        # Compute aggregate metrics
        return {
            key: {
                'mean': np.mean(values),
                'std': np.std(values),
                'min': np.min(values),
                'max': np.max(values)
            } 
            for key, values in retrieval_metrics.items()
        }
    
    def generate_comprehensive_report(self, 
                                      solutions: List[Dict[str, Any]], 
                                      reference_solutions: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Generate a comprehensive evaluation report
        
        Args:
            solutions (List[Dict[str, Any]]): Generated solutions
            reference_solutions (List[str], optional): Reference solutions
        
        Returns:
            Dict[str, Any]: Comprehensive evaluation report
        """
        # Extract key components
        generated_codes = [sol.get('code', '') for sol in solutions]
        retrieved_contexts = [sol.get('retrieved_context', []) for sol in solutions]
        
        # Compute various metrics
        report = {
            'tool_usage_metrics': self.evaluate_tool_usage(solutions),
            'code_quality_metrics': self.compute_code_quality_metrics(
                generated_codes, 
                reference_solutions
            ),
            'retrieval_metrics': self.compute_retrieval_metrics(
                retrieved_contexts
            )
        }
        
        # Save report to file
        self._save_report(report)
        
        return report
    
    def _save_report(self, report: Dict[str, Any], filename: str = 'rait_evaluation_report.json'):
        """
        Save evaluation report to a JSON file
        
        Args:
            report (Dict[str, Any]): Evaluation report
            filename (str): Output filename
        """
        try:
            with open(filename, 'w') as f:
                json.dump(report, f, indent=2)
            self.logger.info(f"Evaluation report saved to {filename}")
        except Exception as e:
            self.logger.error(f"Error saving report: {e}")