"""
main.py - Main script to run Temporal Knowledge Graph Forecasting
"""

import os
import torch
import logging
from pathlib import Path
import yaml
from datetime import datetime

from core import (
    TimeGranularity,
    DatasetConfig,
    setup_logging
)
from data import DataProcessor
from model import ModelConfig, sLA_tKGF, ModelTrainer

def load_config(config_path: str) -> dict:
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def main():
    # Setup paths
    base_dir = Path(__file__).parent
    data_dir = base_dir / "data"
    cache_dir = base_dir / "cache"
    log_dir = base_dir / "logs"
    output_dir = base_dir / "outputs"
    
    # Create directories
    for dir_path in [data_dir, cache_dir, log_dir, output_dir]:
        dir_path.mkdir(exist_ok=True)
    
    # Setup logging
    setup_logging(log_dir)
    logger = logging.getLogger(__name__)
    
    try:
        # Load configurations
        config = load_config('config.yaml')
        
        # Create dataset config
        dataset_config = DatasetConfig(
            name=config['dataset']['name'],
            time_granularity=TimeGranularity(config['dataset']['time_granularity']),
            train_ratio=config['dataset']['train_ratio'],
            val_ratio=config['dataset']['val_ratio'],
            test_ratio=config['dataset']['test_ratio'],
            window_size=config['dataset']['window_size']
        )
        
        # Process data
        logger.info("Processing dataset...")
        data_processor = DataProcessor(
            config=dataset_config,
            data_dir=data_dir,
            cache_dir=cache_dir
        )
        train_dataset, val_dataset, test_dataset = data_processor.process()
        
        # Create model config
        model_config = ModelConfig(
            hidden_dim=config['model']['hidden_dim'],
            num_layers=config['model']['num_layers'],
            num_heads=config['model']['num_heads'],
            dropout=config['model']['dropout'],
            learning_rate=config['model']['learning_rate'],
            batch_size=config['model']['batch_size'],
            num_epochs=config['model']['num_epochs']
        )
        
        # Setup device
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        logger.info(f"Using device: {device}")
        
        # Create model
        logger.info("Initializing model...")
        model = sLA_tKGF(
            config=model_config,
            num_entities=data_processor.stats.num_entities,
            num_relations=data_processor.stats.num_relations
        ).to(device)
        
        # Create optimizer
        optimizer = torch.optim.Adam(
            model.parameters(),
            lr=model_config.learning_rate
        )
        
        # Create data loaders
        train_loader = torch.utils.data.DataLoader(
            train_dataset,
            batch_size=model_config.batch_size,
            shuffle=True,
            num_workers=4,
            pin_memory=True
        )
        
        val_loader = torch.utils.data.DataLoader(
            val_dataset,
            batch_size=model_config.batch_size,
            shuffle=False,
            num_workers=4,
            pin_memory=True
        ) if val_dataset else None
        
        test_loader = torch.utils.data.DataLoader(
            test_dataset,
            batch_size=model_config.batch_size,
            shuffle=False,
            num_workers=4,
            pin_memory=True
        )
        
        # Create trainer
        trainer = ModelTrainer(
            model=model,
            optimizer=optimizer,
            device=device,
            config=model_config
        )
        
        # Training loop
        logger.info("Starting training...")
        best_val_mrr = 0.0
        for epoch in range(model_config.num_epochs):
            # Train
            train_loss = trainer.train_epoch(train_loader)
            logger.info(f"Epoch {epoch+1}/{model_config.num_epochs}")
            logger.info(f"Training Loss: {train_loss:.4f}")
            
            # Validate
            if val_loader:
                val_metrics = trainer.evaluate(val_loader)
                logger.info("Validation Metrics:")
                for metric, value in val_metrics.items():
                    logger.info(f"  {metric}: {value:.4f}")
                
                # Save best model
                if val_metrics['MRR'] > best_val_mrr:
                    best_val_mrr = val_metrics['MRR']
                    torch.save({
                        'epoch': epoch,
                        'model_state_dict': model.state_dict(),
                        'optimizer_state_dict': optimizer.state_dict(),
                        'metrics': val_metrics,
                    }, output_dir / 'best_model.pt')
        
        # Test
        logger.info("Testing best model...")
        # Load best model
        checkpoint = torch.load(output_dir / 'best_model.pt')
        model.load_state_dict(checkpoint['model_state_dict'])
        
        test_metrics = trainer.evaluate(test_loader)
        logger.info("Test Metrics:")
        for metric, value in test_metrics.items():
            logger.info(f"  {metric}: {value:.4f}")
            
        # Save final results
        results = {
            'test_metrics': test_metrics,
            'best_validation_mrr': best_val_mrr,
            'timestamp': datetime.now().isoformat()
        }
        
        torch.save(results, output_dir / 'test_results.pt')
        logger.info("Training completed successfully")
        
    except Exception as e:
        logger.error(f"Error during execution: {str(e)}")
        raise

if __name__ == "__main__":
    main()