import matplotlib.pyplot as plt
import seaborn as sns
import torch
import numpy as np

def plot_confusion_matrix(cm, classes, title='Confusion Matrix'):
    """
    Plot confusion matrix using seaborn
    
    Args:
    - cm: Confusion matrix
    - classes: List of class names
    - title: Plot title
    
    Returns:
    - Matplotlib figure
    """
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        cm, 
        annot=True, 
        fmt='d', 
        cmap='Blues',
        xticklabels=classes,
        yticklabels=classes
    )
    plt.title(title)
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    return plt.gcf()

def visualize_embeddings(embeddings, labels, title='Embedding Visualization'):
    """
    Visualize high-dimensional embeddings using t-SNE
    
    Args:
    - embeddings: Tensor of embeddings
    - labels: Corresponding labels
    - title: Plot title
    
    Returns:
    - Matplotlib figure
    """
    from sklearn.manifold import TSNE
    
    # Convert to numpy if tensor
    if torch.is_tensor(embeddings):
        embeddings = embeddings.cpu().numpy()
    if torch.is_tensor(labels):
        labels = labels.cpu().numpy()
    
    # Reduce dimensionality
    tsne = TSNE(n_components=2, random_state=42)
    reduced_embeddings = tsne.fit_transform(embeddings)
    
    # Plot
    plt.figure(figsize=(12, 8))
    scatter = plt.scatter(
        reduced_embeddings[:, 0], 
        reduced_embeddings[:, 1], 
        c=labels, 
        cmap='viridis'
    )
    plt.colorbar(scatter)
    plt.title(title)
    plt.xlabel('t-SNE Dimension 1')
    plt.ylabel('t-SNE Dimension 2')
    return plt.gcf()

def plot_training_curves(train_losses, val_losses, train_accuracies, val_accuracies):
    """
    Plot training and validation losses and accuracies
    
    Args:
    - train_losses: List of training losses
    - val_losses: List of validation losses
    - train_accuracies: List of training accuracies
    - val_accuracies: List of validation accuracies
    
    Returns:
    - Matplotlib figure
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
    
    # Loss plot
    ax1.plot(train_losses, label='Train Loss')
    ax1.plot(val_losses, label='Validation Loss')
    ax1.set_title('Training and Validation Loss')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.legend()
    
    # Accuracy plot
    ax2.plot(train_accuracies, label='Train Accuracy')
    ax2.plot(val_accuracies, label='Validation Accuracy')
    ax2.set_title('Training and Validation Accuracy')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Accuracy')
    ax2.legend()
    
    plt.tight_layout()
    return fig