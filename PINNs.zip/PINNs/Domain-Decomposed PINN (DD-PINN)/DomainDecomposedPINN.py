import torch
import torch.nn as nn
import numpy as np
import json
import argparse
import time
import os
from collections import OrderedDict
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import warnings

warnings.filterwarnings("ignore", category=UserWarning, module="torch.autograd")

torch.manual_seed(42)
np.random.seed(42)
plt.style.use('seaborn-v0_8-whitegrid')

class FourierFeatureMapping(nn.Module):
    def __init__(self, input_dim, mapping_size, scale=10.0):
        super().__init__()
        self.register_buffer('B', torch.randn(input_dim, mapping_size) * scale)
    def forward(self, x):
        x_proj = x @ self.B
        return torch.cat([torch.sin(x_proj), torch.cos(x_proj)], dim=-1)

class PINNSubNet(nn.Module):
    def __init__(self, layers, activation_fn, time_domain, use_fourier=False, fourier_size=64, fourier_scale=10.0):
        super().__init__()
        self.time_min, self.time_max = time_domain
        self.use_fourier = use_fourier
        
        input_dim = 1
        if self.use_fourier:
            self.fourier_mapping = FourierFeatureMapping(1, fourier_size, fourier_scale)
            input_dim = fourier_size * 2
        
        net_layers = []
        full_layers = [input_dim] + layers
        for i in range(len(full_layers) - 1):
            net_layers.append((f"linear_{i}", nn.Linear(full_layers[i], full_layers[i+1])))
            if i < len(full_layers) - 2:
                net_layers.append((f"activation_{i}", activation_fn()))
        self.net = nn.Sequential(OrderedDict(net_layers))
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, t):
        t_scaled = 2.0 * (t - self.time_min) / (self.time_max - self.time_min) - 1.0
        if self.use_fourier:
            features = self.fourier_mapping(t_scaled)
        else:
            features = t_scaled
        return self.net(features)

class DDPINNSolver:
    def __init__(self, config):
        problem_details = config['problems'][0]
        hyperparams = config['hyperparameters']
        self.config = {**problem_details, 'hyperparameters': hyperparams}
        
        if torch.cuda.is_available():
            torch.cuda.init()
            for i in range(torch.cuda.device_count()):
                with torch.cuda.device(i):
                    torch.cuda.empty_cache()
            self.device = torch.device("cuda:0")
            torch.cuda.set_device(self.device)
            dummy = torch.randn(10, 10, device=self.device, requires_grad=True)
            loss = dummy.sum()
            loss.backward()
            torch.cuda.synchronize()
            del dummy, loss
            torch.cuda.empty_cache()
            print(f"Using device: {self.device}")
        else:
            self.device = torch.device("cpu")
            print(f"Using device: {self.device}")
            
        self._parse_config()
        self._build_model()

    def _parse_config(self):
        self.problem_name = self.config['problem_id']
        self.state_vars = self.config['state_variables']
        self.num_state_vars = len(self.state_vars)
        self.odes = self.config['odes']
        self.t_domain = torch.tensor(self.config['time_domain'], dtype=torch.float32, device=self.device)
        self.params = self.config.get('parameters', {})
        self.time_inputs = self.config.get('time_varying_inputs', {})
        self.initial_conditions = {k: torch.tensor([v], dtype=torch.float32, device=self.device) for k, v in self.config['initial_conditions'].items()}

        hp = self.config['hyperparameters']
        dd_hp = hp['dd_pinn']
        net_hp = hp['network']
        
        self.num_domains = dd_hp['num_domains']
        self.lr, self.epochs = hp['learning_rate'], hp['epochs']
        self.num_collocation_per_domain = hp['num_collocation_points_per_domain']
        self.loss_weights = hp['loss_weights']
        
        activation_map = {"tanh": nn.Tanh, "relu": nn.ReLU, "gelu": nn.GELU, "silu": nn.SiLU}
        self.activation_fn = activation_map.get(hp['activation_function'], nn.Tanh)
        
        self.network_layers = [net_hp['neurons_per_layer']] * net_hp['hidden_layers'] + [self.num_state_vars]
        self.use_fourier, self.fourier_size, self.fourier_scale = hp['use_fourier_features'], hp['fourier_mapping_size'], hp['fourier_scale']

        self.domain_boundaries = torch.linspace(self.t_domain[0], self.t_domain[1], self.num_domains + 1, dtype=torch.float32, device=self.device)

    def _build_model(self):
        self.sub_nets = nn.ModuleList()
        for i in range(self.num_domains):
            sub_domain = (self.domain_boundaries[i], self.domain_boundaries[i+1])
            subnet = PINNSubNet(self.network_layers, self.activation_fn, sub_domain, 
                              self.use_fourier, self.fourier_size, self.fourier_scale)
            subnet = subnet.to(self.device)
            self.sub_nets.append(subnet)
        
        self.optimizer = torch.optim.AdamW(self.sub_nets.parameters(), lr=self.lr, weight_decay=1e-5)
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=self.epochs, eta_min=1e-6)
        
        if self.device.type == 'cuda':
            test_input = torch.randn(1, 1, device=self.device, requires_grad=True)
            test_output = self.sub_nets[0](test_input)
            test_loss = test_output.sum()
            test_loss.backward()
            torch.cuda.synchronize()
            del test_input, test_output, test_loss

    def _get_ode_rhs(self, t, u):
        scope = {'t': t, **self.params}
        for i, var in enumerate(self.state_vars):
            scope[var] = u[..., i]
        
        t_eval = t.squeeze(-1)
        for name, expr in self.time_inputs.items():
            scope[name] = eval(expr, {'torch': torch}, {'t': t_eval})

        rhs = torch.stack([eval(self.odes[f"d{var}dt"], {}, scope) for var in self.state_vars], dim=-1)
        return rhs

    def calculate_loss(self):
        loss_pde = torch.zeros(1, dtype=torch.float32, device=self.device)
        for i in range(self.num_domains):
            t_min, t_max = self.domain_boundaries[i], self.domain_boundaries[i+1]
            t_coll = t_min + (t_max - t_min) * torch.rand(self.num_collocation_per_domain, 1, dtype=torch.float32, device=self.device)
            t_coll.requires_grad_(True)
            
            u_pred = self.sub_nets[i](t_coll)
            
            du_dt_pred = []
            for j in range(self.num_state_vars):
                grad_output = torch.autograd.grad(
                    outputs=u_pred[:, j],
                    inputs=t_coll,
                    grad_outputs=torch.ones_like(u_pred[:, j]),
                    create_graph=True,
                    retain_graph=True
                )[0]
                du_dt_pred.append(grad_output.squeeze())
            du_dt_pred = torch.stack(du_dt_pred, dim=1)

            rhs = self._get_ode_rhs(t_coll, u_pred)
            loss_pde += torch.mean((du_dt_pred - rhs)**2)
        
        t_ic = self.domain_boundaries[0].view(1, 1)
        u_ic_pred = self.sub_nets[0](t_ic)
        ic_targets = torch.cat([self.initial_conditions[f"{var}"] for var in self.state_vars]).view(1, -1)
        loss_ic = torch.mean((u_ic_pred - ic_targets)**2)
        
        loss_interface = torch.zeros(1, dtype=torch.float32, device=self.device)
        for i in range(1, self.num_domains):
            t_interface = self.domain_boundaries[i].view(1, 1)
            u_prev_domain = self.sub_nets[i-1](t_interface)
            u_curr_domain = self.sub_nets[i](t_interface)
            loss_interface += torch.mean((u_prev_domain - u_curr_domain)**2)
            
        return loss_pde.squeeze(), loss_ic, loss_interface.squeeze()

    def train(self):
        print(f"--- Starting DD-PINN training for {self.problem_name} ---")
        start_time = time.time()
        
        for net in self.sub_nets:
            net.train()
        
        for epoch in range(self.epochs):
            self.optimizer.zero_grad()
            
            loss_pde, loss_ic, loss_interface = self.calculate_loss()
            
            total_loss = (self.loss_weights['ode_residual'] * loss_pde +
                          self.loss_weights['initial_condition'] * loss_ic +
                          self.loss_weights['interface_continuity'] * loss_interface)
            
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.sub_nets.parameters(), 1.0)
            self.optimizer.step()
            self.scheduler.step()
            
            if (epoch + 1) % 5000 == 0 or epoch == 0:
                print(f'Epoch [{epoch+1}/{self.epochs}], Loss: {total_loss.item():.4e}, '
                      f'PDE: {loss_pde.item():.4e}, IC: {loss_ic.item():.4e}, Interface: {loss_interface.item():.4e}')
        
        elapsed_time = time.time() - start_time
        print(f"--- Training finished in {elapsed_time:.2f} seconds ---")

    def solve_numerically(self, t_eval):
        y0 = [self.initial_conditions[f"{var}"].item() for var in self.state_vars]
        
        def ode_system(t, y):
            scope = {'t': t, **self.params}
            for i, var in enumerate(self.state_vars): scope[var] = y[i]
            
            eval_scope = {'t': t, 'sin': np.sin}
            for name, expr in self.time_inputs.items():
                numpy_expr = expr.replace("torch.sin", "sin")
                scope[name] = eval(numpy_expr, {}, eval_scope)

            return [eval(self.odes[f"d{var}dt"], {}, scope) for var in self.state_vars]
            
        sol = solve_ivp(ode_system, self.t_domain.cpu().numpy(), y0, dense_output=True, t_eval=t_eval, method='DOP853', rtol=1e-8, atol=1e-10)
        return sol.y.T

    def predict_full_domain(self, t):
        for net in self.sub_nets:
            net.eval()
            
        with torch.no_grad():
            u_pred = torch.zeros(len(t), self.num_state_vars, dtype=torch.float32, device=self.device)
            for i in range(self.num_domains):
                t_min, t_max = self.domain_boundaries[i], self.domain_boundaries[i+1]
                
                if i == self.num_domains - 1:
                    mask = (t >= t_min) & (t <= t_max)
                else:
                    mask = (t >= t_min) & (t < t_max)

                if torch.any(mask):
                    t_sub = t[mask].view(-1, 1)
                    u_pred[mask] = self.sub_nets[i](t_sub)
        return u_pred.cpu().numpy()

    def evaluate_and_plot_results(self):
        results_dir = "results"
        os.makedirs(results_dir, exist_ok=True)
        base_filename = os.path.join(results_dir, self.problem_name.replace(' ', '_').lower())

        t_plot_np = np.linspace(self.t_domain[0].cpu().numpy(), self.t_domain[1].cpu().numpy(), 1000)
        t_plot_torch = torch.from_numpy(t_plot_np).float().to(self.device)

        u_pinn = self.predict_full_domain(t_plot_torch)
        u_numerical = self.solve_numerically(t_plot_np)

        fig, axes = plt.subplots(self.num_state_vars, 2, figsize=(16, 5 * self.num_state_vars), sharex=True)
        if self.num_state_vars == 1: axes = np.array([axes])

        for j, var in enumerate(self.state_vars):
            ax_sol = axes[j, 0]
            ax_err = axes[j, 1]

            ax_sol.plot(t_plot_np, u_numerical[:, j], 'k-', label='Numerical', linewidth=2.5, alpha=0.8)
            ax_sol.plot(t_plot_np, u_pinn[:, j], 'r--', label='DD-PINN', markersize=3)
            
            for boundary in self.domain_boundaries[1:-1].cpu().numpy():
                ax_sol.axvline(x=boundary, color='gray', linestyle=':', linewidth=1.5)
            
            ax_sol.set_ylabel(var)
            ax_sol.legend()
            ax_sol.set_title(f'Solution for {var}')

            error = np.abs(u_numerical[:, j] - u_pinn[:, j])
            ax_err.plot(t_plot_np, error)
            ax_err.set_yscale('log')
            ax_err.set_ylabel('Absolute Error')
            ax_err.set_title(f'Error for {var}')
            ax_err.grid(True, which="both", ls="--")

        axes[-1, 0].set_xlabel('Time (t)')
        axes[-1, 1].set_xlabel('Time (t)')
        
        fig.suptitle(f'DD-PINN Solution vs. Numerical', fontsize=16)
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plot_filename = f"{base_filename}_solution.pdf"
        plt.savefig(plot_filename)
        plt.close(fig)
        print(f"Evaluation plot saved to {plot_filename}")

def main():
    parser = argparse.ArgumentParser(description="Domain-Decomposed PINN Solver for ODEs")
    parser.add_argument("config_file", type=str, nargs='?', default="problem_config.json", help="Path to the JSON configuration file.")
    args = parser.parse_args()
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    solver = DDPINNSolver(config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()