import os
import numpy as np
import pandas as pd
import torch
from typing import Dict, List, Tuple, Optional
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
import networkx as nx

class TimeSeriesDataset(Dataset):
    """Dataset class for spatio-temporal data processing"""
    
    def __init__(
        self,
        data: np.ndarray,
        window_size: int,
        horizon: int,
        scaler: Optional[StandardScaler] = None,
        missing_rate: float = 0.0,
        missing_type: str = "MCAR"
    ):
        """
        Initialize TimeSeriesDataset
        
        Args:
            data: Raw time series data [timesteps, nodes, features]
            window_size: Historical window length
            horizon: Prediction horizon
            scaler: StandardScaler for normalization
            missing_rate: Proportion of missing values
            missing_type: Type of missing data ("MCAR" or "block")
        """
        self.window_size = window_size
        self.horizon = horizon
        
        # Normalize data if scaler provided
        if scaler is not None:
            data_shape = data.shape
            data = scaler.transform(data.reshape(-1, data_shape[-1])).reshape(data_shape)
        
        # Introduce missing values if specified
        if missing_rate > 0:
            data = self._introduce_missing_values(data, missing_rate, missing_type)
            
        # Create sliding windows
        self.X, self.y = self._create_windows(data)
        
    def _create_windows(self, data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Create sliding windows from time series data"""
        total_windows = len(data) - self.window_size - self.horizon + 1
        
        X = np.zeros((total_windows, self.window_size, *data.shape[1:]))
        y = np.zeros((total_windows, self.horizon, *data.shape[1:]))
        
        for i in range(total_windows):
            X[i] = data[i:i+self.window_size]
            y[i] = data[i+self.window_size:i+self.window_size+self.horizon]
            
        return X, y
        
    def _introduce_missing_values(
        self,
        data: np.ndarray,
        missing_rate: float,
        missing_type: str
    ) -> np.ndarray:
        """Introduce missing values into the dataset"""
        mask = np.ones_like(data)
        
        if missing_type == "MCAR":
            # Missing Completely at Random
            mask = np.random.choice(
                [0, 1],
                size=data.shape,
                p=[missing_rate, 1-missing_rate]
            )
        elif missing_type == "block":
            # Block missing values
            block_size = max(int(self.window_size * 0.2), 1)
            num_blocks = int(missing_rate * len(data) / block_size)
            
            for _ in range(num_blocks):
                start = np.random.randint(0, len(data) - block_size)
                mask[start:start+block_size] = 0
                
        # Apply mask and replace missing values with NaN
        data = data * mask
        data[mask == 0] = np.nan
        
        return data
    
    def __len__(self) -> int:
        return len(self.X)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return torch.FloatTensor(self.X[idx]), torch.FloatTensor(self.y[idx])

class SpatialGraphBuilder:
    """Build spatial dependency graphs for traffic networks"""
    
    @staticmethod
    def build_distance_graph(
        coordinates: np.ndarray,
        threshold: float = 0.1
    ) -> nx.Graph:
        """Build graph based on geographical distances"""
        G = nx.Graph()
        num_nodes = len(coordinates)
        
        for i in range(num_nodes):
            for j in range(i+1, num_nodes):
                dist = np.linalg.norm(coordinates[i] - coordinates[j])
                if dist < threshold:
                    G.add_edge(i, j, weight=1.0/dist)
                    
        return G
    
    @staticmethod
    def build_correlation_graph(
        time_series: np.ndarray,
        threshold: float = 0.5
    ) -> nx.Graph:
        """Build graph based on time series correlations"""
        correlation = np.corrcoef(time_series.reshape(time_series.shape[1], -1))
        G = nx.Graph()
        
        for i in range(len(correlation)):
            for j in range(i+1, len(correlation)):
                if abs(correlation[i,j]) > threshold:
                    G.add_edge(i, j, weight=abs(correlation[i,j]))
                    
        return G
    
    @staticmethod
    def combine_graphs(graphs: List[nx.Graph]) -> nx.Graph:
        """Combine multiple graphs using weighted average"""
        combined = nx.Graph()
        
        # Add all edges from all graphs
        for graph in graphs:
            for u, v, data in graph.edges(data=True):
                if combined.has_edge(u, v):
                    combined[u][v]['weight'] += data['weight']
                else:
                    combined.add_edge(u, v, weight=data['weight'])
        
        # Normalize weights
        for u, v in combined.edges():
            combined[u][v]['weight'] /= len(graphs)
            
        return combined

class DatasetLoader:
    """Main loader class for handling multiple datasets"""
    
    def __init__(self, config: Dict):
        """Initialize with configuration"""
        self.config = config
        self.scalers = {}
        
    def load_dataset(
        self,
        dataset_name: str,
        missing_rate: float = 0.0,
        missing_type: str = "MCAR"
    ) -> Tuple[DataLoader, DataLoader, DataLoader]:
        """Load and preprocess a dataset"""
        # Load raw data
        data_path = os.path.join('data', f'{dataset_name}.csv')
        raw_data = pd.read_csv(data_path).values
        
        # Create scaler
        if dataset_name not in self.scalers:
            self.scalers[dataset_name] = StandardScaler().fit(
                raw_data.reshape(-1, raw_data.shape[-1])
            )
        
        # Split data
        if dataset_name in ['METR-LA', 'PEMS-BAY']:
            split_config = self.config['datasets']['splits']['metr_pems_bay']
        else:
            split_config = self.config['datasets']['splits']['pems']
            
        train_data, val_data, test_data = self._split_data(raw_data, split_config)
        
        # Create datasets
        train_dataset = TimeSeriesDataset(
            train_data,
            self.config['model']['window_size'],
            self.config['model']['forecast_horizon'],
            self.scalers[dataset_name],
            missing_rate,
            missing_type
        )
        
        val_dataset = TimeSeriesDataset(
            val_data,
            self.config['model']['window_size'],
            self.config['model']['forecast_horizon'],
            self.scalers[dataset_name]
        )
        
        test_dataset = TimeSeriesDataset(
            test_data,
            self.config['model']['window_size'],
            self.config['model']['forecast_horizon'],
            self.scalers[dataset_name]
        )
        
        # Create dataloaders
        train_loader = DataLoader(
            train_dataset,
            batch_size=self.config['training']['batch_size'],
            shuffle=True,
            num_workers=4,
            pin_memory=True
        )
        
        val_loader = DataLoader(
            val_dataset,
            batch_size=self.config['training']['batch_size'],
            shuffle=False,
            num_workers=4,
            pin_memory=True
        )
        
        test_loader = DataLoader(
            test_dataset,
            batch_size=self.config['training']['batch_size'],
            shuffle=False,
            num_workers=4,
            pin_memory=True
        )
        
        return train_loader, val_loader, test_loader
    
    def _split_data(
        self,
        data: np.ndarray,
        split_config: Dict[str, float]
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Split data into train, validation, and test sets"""
        n = len(data)
        train_end = int(n * split_config['train'])
        val_end = train_end + int(n * split_config['validation'])
        
        return data[:train_end], data[train_end:val_end], data[val_end:]