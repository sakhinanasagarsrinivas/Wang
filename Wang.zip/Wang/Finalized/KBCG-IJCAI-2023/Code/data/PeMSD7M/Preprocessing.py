

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import numpy as np
import pandas as pd
import pickle
import torch
from torch_geometric.utils.convert import from_scipy_sparse_matrix

def get_adjacency_matrix(distance_df):
    """
    :param distance_df: data frame with three columns: [from, to, distance].
    :param sensor_ids: list of sensor ids.
    :param normalized_k: entries that become lower than normalized_k after normalization are set to zero for sparsity.
    :return:
    """
    
    print(f"route_distances shape={distance_df.shape}")
    distance_df = distance_df.to_numpy()
    edge_attr = torch.nonzero(torch.from_numpy(distance_df))
    edge_attr_values = distance_df[edge_attr[:,0], edge_attr[:,1]]
    
    df = pd.DataFrame({"from" : edge_attr[:,0], "to" : edge_attr[:,1], "cost": edge_attr_values})
    df.to_csv("PeMSD7(M).csv", index=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--distances_filename', type=str, default='PeMSD7_W_228.csv',  help='CSV file containing sensor distances with three columns: [from, to, distance].')
    args = parser.parse_args()

    distance_df = pd.read_csv(args.distances_filename, header=None)
    get_adjacency_matrix(distance_df)


speeds_array = pd.read_csv('PeMSD7_V_228.csv', header=None).to_numpy()
print(f"speeds_array shape={speeds_array.shape}")
speeds_array = np.expand_dims(speeds_array, axis = 2)

np.savez('PeMSD7M', speeds_array)
