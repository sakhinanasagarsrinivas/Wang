


# load numpy array from npy file
from numpy import load
# load array
data = load('data.npy')
print(data.shape)
