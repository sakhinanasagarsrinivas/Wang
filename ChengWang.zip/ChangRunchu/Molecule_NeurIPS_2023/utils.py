import torch
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from typing import List, Tuple, Dict, Optional, Union
import yaml
import json
from pathlib import Path
import logging
from datetime import datetime
import pandas as pd
from sklearn.model_selection import train_test_split

class MolecularScaffold:
    """Handles molecular scaffold operations"""
    
    @staticmethod
    def get_scaffold(mol: Chem.Mol) -> str:
        """Get Murcko scaffold for a molecule"""
        scaffold = Chem.MurckoScaffoldSmiles(mol=mol, includeChirality=True)
        return scaffold

    @staticmethod
    def scaffold_split(
        data: pd.DataFrame,
        smiles_col: str,
        train_size: float = 0.8,
        valid_size: float = 0.1,
        seed: int = 42
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Split dataset based on molecular scaffolds
        
        Args:
            data: DataFrame containing SMILES
            smiles_col: Name of SMILES column
            train_size: Proportion for training set
            valid_size: Proportion for validation set
            seed: Random seed
            
        Returns:
            Tuple of (train_data, valid_data, test_data)
        """
        # Get scaffolds for all molecules
        scaffolds = {}
        for idx, smiles in enumerate(data[smiles_col]):
            mol = Chem.MolFromSmiles(smiles)
            scaffold = MolecularScaffold.get_scaffold(mol)
            if scaffold not in scaffolds:
                scaffolds[scaffold] = [idx]
            else:
                scaffolds[scaffold].append(idx)
                
        # Sort scaffolds by size
        scaffold_sets = [
            scaffold_set 
            for (scaffold, scaffold_set) in sorted(
                scaffolds.items(),
                key=lambda x: (len(x[1]), x[1][0]),
                reverse=True
            )
        ]
        
        # Calculate split sizes
        train_cutoff = int(len(data) * train_size)
        valid_cutoff = int(len(data) * (train_size + valid_size))
        
        # Split datasets
        train_idx = []
        valid_idx = []
        test_idx = []
        
        for scaffold_set in scaffold_sets:
            if len(train_idx) + len(scaffold_set) <= train_cutoff:
                train_idx.extend(scaffold_set)
            elif len(valid_idx) + len(scaffold_set) <= valid_cutoff - len(train_idx):
                valid_idx.extend(scaffold_set)
            else:
                test_idx.extend(scaffold_set)
        
        return data.iloc[train_idx], data.iloc[valid_idx], data.iloc[test_idx]


class ModelUtils:
    """Utility functions for model operations"""
    
    @staticmethod
    def load_config(config_path: str) -> dict:
        """Load configuration from YAML file"""
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        return config
    
    @staticmethod
    def save_checkpoint(
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        epoch: int,
        loss: float,
        path: str
    ):
        """Save model checkpoint"""
        torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': loss,
        }, path)
    
    @staticmethod
    def load_checkpoint(
        model: torch.nn.Module,
        optimizer: Optional[torch.optim.Optimizer],
        path: str
    ) -> Tuple[torch.nn.Module, Optional[torch.optim.Optimizer], int, float]:
        """Load model checkpoint"""
        checkpoint = torch.load(path)
        model.load_state_dict(checkpoint['model_state_dict'])
        if optimizer is not None:
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        return model, optimizer, checkpoint['epoch'], checkpoint['loss']
    
    @staticmethod
    def get_lr_scheduler(
        optimizer: torch.optim.Optimizer,
        scheduler_type: str,
        **kwargs
    ) -> torch.optim.lr_scheduler._LRScheduler:
        """Get learning rate scheduler"""
        if scheduler_type == 'plateau':
            return torch.optim.lr_scheduler.ReduceLROnPlateau(
                optimizer,
                mode='min',
                factor=kwargs.get('factor', 0.1),
                patience=kwargs.get('patience', 10),
                verbose=True
            )
        elif scheduler_type == 'cosine':
            return torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer,
                T_max=kwargs.get('T_max', 100),
                eta_min=kwargs.get('eta_min', 0)
            )
        else:
            raise ValueError(f"Unknown scheduler type: {scheduler_type}")


class DataUtils:
    """Utility functions for data operations"""
    
    @staticmethod
    def create_fingerprints(
        smiles_list: List[str],
        fp_type: str = 'morgan',
        radius: int = 2,
        nBits: int = 2048
    ) -> np.ndarray:
        """Create molecular fingerprints"""
        fps = []
        for smiles in smiles_list:
            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                fps.append(np.zeros(nBits))
                continue
                
            if fp_type == 'morgan':
                fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits)
            elif fp_type == 'maccs':
                fp = AllChem.GetMACCSKeysFingerprint(mol)
            elif fp_type == 'rdkit':
                fp = Chem.RDKFingerprint(mol, fpSize=nBits)
            else:
                raise ValueError(f"Unknown fingerprint type: {fp_type}")
                
            fps.append(np.array(fp))
        
        return np.vstack(fps)
    
    @staticmethod
    def create_similarity_matrix(
        fps: np.ndarray,
        metric: str = 'tanimoto'
    ) -> np.ndarray:
        """Create similarity matrix from fingerprints"""
        n_mols = len(fps)
        sim_matrix = np.zeros((n_mols, n_mols))
        
        for i in range(n_mols):
            for j in range(i, n_mols):
                if metric == 'tanimoto':
                    intersection = np.sum(fps[i] & fps[j])
                    union = np.sum(fps[i] | fps[j])
                    sim = intersection / union if union != 0 else 0
                elif metric == 'cosine':
                    sim = np.dot(fps[i], fps[j]) / (
                        np.linalg.norm(fps[i]) * np.linalg.norm(fps[j])
                    )
                else:
                    raise ValueError(f"Unknown similarity metric: {metric}")
                    
                sim_matrix[i, j] = sim_matrix[j, i] = sim
        
        return sim_matrix


class LogUtils:
    """Utility functions for logging"""
    
    def __init__(self, log_dir: str):
        """Initialize logger"""
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        
        # Create handlers
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = self.log_dir / f'training_{timestamp}.log'
        
        file_handler = logging.FileHandler(log_file)
        console_handler = logging.StreamHandler()
        
        # Create formatters
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        # Initialize metrics storage
        self.metrics = {
            'train_loss': [],
            'val_loss': [],
            'test_metrics': {}
        }
    
    def log_training(self, epoch: int, train_loss: float, val_loss: float):
        """Log training metrics"""
        self.logger.info(
            f"Epoch {epoch}: Train Loss = {train_loss:.4f}, Val Loss = {val_loss:.4f}"
        )
        self.metrics['train_loss'].append(train_loss)
        self.metrics['val_loss'].append(val_loss)
    
    def log_test_metrics(self, metrics: Dict[str, float]):
        """Log test metrics"""
        self.metrics['test_metrics'] = metrics
        for metric_name, value in metrics.items():
            self.logger.info(f"Test {metric_name}: {value:.4f}")
    
    def save_metrics(self):
        """Save metrics to JSON"""
        metrics_file = self.log_dir / 'metrics.json'
        with open(metrics_file, 'w') as f:
            json.dump(self.metrics, f, indent=4)
    
    def log_error(self, error_msg: str):
        """Log error message"""
        self.logger.error(error_msg)