import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
from torchvision import transforms

import networkx as nx
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, 
    precision_recall_fscore_support, 
    confusion_matrix, 
    classification_report
)
from PIL import Image

class Config:
    """Configuration class for EMCNet project"""
    def __init__(self):
        self.train_csv = 'data/train.csv'
        self.root_dir = 'data/images/'
        self.results_dir = 'results/'
        
        # Model Hyperparameters
        self.input_dim = 3  # RGB channels
        self.hidden_dim = 64
        self.num_classes = 10
        self.patch_size = 32
        
        # Training Hyperparameters
        self.batch_size = 24
        self.learning_rate = 1e-3
        self.epochs = 100
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Logging and Reproducibility
        self.random_seed = 42
        
        # Create results directory
        os.makedirs(self.results_dir, exist_ok=True)

class SEMDataset(Dataset):
    """Dataset for Scanning Electron Microscopy images"""
    def __init__(self, csv_file, root_dir, patch_size=32, transform=None):
        self.image_labels = pd.read_csv(csv_file)
        self.root_dir = root_dir
        self.patch_size = patch_size
        
        self.transform = transform or transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    
    def __len__(self):
        return len(self.image_labels)
    
    def __getitem__(self, idx):
        img_path = os.path.join(self.root_dir, self.image_labels.iloc[idx, 0])
        image = Image.open(img_path).convert('RGB')
        label = self.image_labels.iloc[idx, 1]
        
        patches = self._create_patches(image)
        adjacency_matrix = self._create_adjacency_matrix(patches)
        clique_tree = self._create_clique_tree(patches)
        
        return {
            'patches': patches,
            'label': label,
            'adjacency_matrix': adjacency_matrix,
            'clique_tree': clique_tree
        }
    
    def _create_patches(self, image):
        transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.ToTensor()
        ])
        
        image_tensor = transform(image)
        patches = image_tensor.unfold(1, self.patch_size, self.patch_size) \
                               .unfold(2, self.patch_size, self.patch_size)
        patches = patches.contiguous().view(-1, 3, self.patch_size, self.patch_size)
        
        return patches
    
    def _create_adjacency_matrix(self, patches):
        grid_size = int(np.sqrt(len(patches)))
        adjacency = torch.zeros((len(patches), len(patches)))
        
        for i in range(len(patches)):
            row = i // grid_size
            col = i % grid_size
            
            # Connect adjacent patches
            if row > 0:
                adjacency[i, i - grid_size] = 1
            if row < grid_size - 1:
                adjacency[i, i + grid_size] = 1
            if col > 0:
                adjacency[i, i - 1] = 1
            if col < grid_size - 1:
                adjacency[i, i + 1] = 1
        
        return adjacency
    
    def _create_clique_tree(self, patches):
        grid_size = int(np.sqrt(len(patches)))
        G = nx.grid_2d_graph(grid_size, grid_size)
        
        cliques = list(nx.find_cliques(G))
        cliques.sort(key=len, reverse=True)
        
        clique_tree = []
        for clique in cliques[:min(5, len(cliques))]:
            clique_patches = [patches[node[0] * grid_size + node[1]] for node in clique]
            clique_features = torch.stack(clique_patches)
            clique_repr = torch.mean(clique_features, dim=0)
            clique_tree.append(clique_repr)
        
        # Pad to ensure consistent representation
        while len(clique_tree) < 5:
            clique_tree.append(torch.zeros_like(clique_tree[0]))
        
        return torch.stack(clique_tree[:5])

class GraphEncoder(nn.Module):
    """Graph Encoder with Message Passing and Attention"""
    def __init__(self, input_dim, hidden_dim, num_layers=6):
        super().__init__()
        self.num_layers = num_layers
        
        self.master_node_embed = nn.Parameter(torch.randn(1, hidden_dim))
        self.graph_convs = nn.ModuleList([
            nn.Linear(input_dim, hidden_dim) for _ in range(num_layers)
        ])
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=4)
    
    def forward(self, x, adjacency_matrix):
        batch_size, num_nodes, node_dim = x.shape
        
        # Add virtual master node
        master_node = self.master_node_embed.expand(batch_size, 1, -1)
        x = torch.cat([master_node, x], dim=1)
        
        # Message passing
        for layer in range(self.num_layers):
            x = F.relu(self.graph_convs[layer](x))
            attn_output, _ = self.attention(x, x, x)
            x = x + attn_output
        
        return torch.mean(x, dim=1)

class HierarchicalGraphEncoder(nn.Module):
    """Hierarchical Graph Encoder with Pooling"""
    def __init__(self, input_dim, hidden_dim, pooling_ratio=0.75):
        super().__init__()
        self.pooling_ratio = pooling_ratio
        self.graph_layers = nn.ModuleList([
            GraphPoolingLayer(input_dim, hidden_dim) for _ in range(3)
        ])
    
    def forward(self, x, adjacency_matrix):
        for layer in self.graph_layers:
            x, adjacency_matrix = layer(x, adjacency_matrix)
        
        return torch.mean(x, dim=1)

class GraphPoolingLayer(nn.Module):
    """Graph Pooling Layer with Node Importance Scoring"""
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.projection = nn.Linear(input_dim, output_dim)
        self.attention = nn.MultiheadAttention(output_dim, num_heads=4)
    
    def forward(self, x, adjacency_matrix):
        x = F.relu(self.projection(x))
        
        # Node importance scoring
        importance_scores = torch.sum(x, dim=-1)
        k = int(x.size(1) * 0.75)
        _, top_indices = torch.topk(importance_scores, k, dim=1)
        
        # Select top nodes
        x_pooled = torch.gather(x, 1, top_indices.unsqueeze(-1).expand(-1, -1, x.size(-1)))
        
        # Attention-based refinement
        attn_output, _ = self.attention(x_pooled, x_pooled, x_pooled)
        x_pooled = x_pooled + attn_output
        
        return x_pooled, adjacency_matrix

class CliqueTreeEncoder(nn.Module):
    """Clique Tree Encoder with Hierarchical Message Passing"""
    def __init__(self, input_dim, hidden_dim):
        super().__init__()
        self.node_transform = nn.Linear(input_dim, hidden_dim)
        self.gru_cell = nn.GRUCell(hidden_dim, hidden_dim)
    
    def forward(self, clique_tree):
        clique_tree = F.relu(self.node_transform(clique_tree))
        
        # Bottom-up message passing
        for i in range(len(clique_tree) - 1, -1, -1):
            node = clique_tree[i]
            parent_messages = self._aggregate_parent_messages(clique_tree, i)
            node = self.gru_cell(parent_messages, node)
        
        return clique_tree[0]
    
    def _aggregate_parent_messages(self, clique_tree, node_idx):
        messages = []
        for j in range(len(clique_tree)):
            if j != node_idx:
                message = torch.mean(clique_tree[j], dim=0)
                messages.append(message)
        
        return torch.stack(messages).mean(dim=0) if messages else torch.zeros_like(clique_tree[node_idx])

class EMCNet(nn.Module):
    """Complete EMCNet Architecture"""
    def __init__(self, config):
        super().__init__()
        
        self.graph_encoder = GraphEncoder(config.input_dim, config.hidden_dim)
        self.hierarchical_encoder = HierarchicalGraphEncoder(config.input_dim, config.hidden_dim)
        self.clique_tree_encoder = CliqueTreeEncoder(config.input_dim, config.hidden_dim)
        
        self.output_layer = nn.Sequential(
            nn.Linear(config.hidden_dim * 3, config.hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(config.hidden_dim, config.num_classes)
        )
    
    def forward(self, batch):
        patches = batch['patches']
        adjacency_matrix = batch['adjacency_matrix']
        clique_tree = batch['clique_tree']
        
        graph_repr = self.graph_encoder(patches, adjacency_matrix)
        hierarchical_repr = self.hierarchical_encoder(patches, adjacency_matrix)
        tree_repr = self.clique_tree_encoder(clique_tree)
        
        combined_repr = torch.cat([graph_repr, hierarchical_repr, tree_repr], dim=1)
        return self.output_layer(combined_repr)

class ResultLogger:
    """Comprehensive Result Logging and Visualization"""
    def __init__(self, config):
        self.config = config
        self.history = {
            'train_loss': [], 'val_loss': [],
            'train_accuracy': [], 'val_accuracy': []
        }
    
    def log_epoch(self, epoch, train_metrics, val_metrics):
        self.history['train_loss'].append(train_metrics['loss'])
        self.history['val_loss'].append(val_metrics['loss'])
        self.history['train_accuracy'].append(train_metrics['accuracy'])
        self.history['val_accuracy'].append(val_metrics['accuracy'])
    
    def plot_training_curves(self):
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 2, 1)
        plt.plot(self.history['train_loss'], label='Train Loss')
        plt.plot(self.history['val_loss'], label='Val Loss')
        plt.title('Loss Curves')
        plt.legend()
        
        plt.subplot(1, 2, 2)
        plt.plot(self.history['train_accuracy'], label='Train Accuracy')
        plt.plot(self.history['val_accuracy'], label='Val Accuracy')
        plt.title('Accuracy Curves')
        plt.legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.config.results_dir, 'training_curves.png'))
    
    def save_metrics(self, final_metrics):
        with open(os.path.join(self.config.results_dir, 'final_metrics.json'), 'w') as f:
            json.dump(final_metrics, f, indent=4)

def compute_metrics(y_true, y_pred):
    """Compute comprehensive classification metrics"""
    accuracy = accuracy_score(y_true, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average='weighted'
    )
    conf_matrix = confusion_matrix(y_true, y_pred)
    class_report = classification_report(y_true, y_pred)
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'confusion_matrix': conf_matrix.tolist(),
        'classification_report': class_report
    }

def train_epoch(model, dataloader, criterion, optimizer, device):
    """Training loop for a single epoch"""
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    
    for batch in dataloader:
        # Move batch to device
        batch = {k: v.to(device) for k, v in batch.items()}
        labels = batch['label']
        
        # Zero gradients
        optimizer.zero_grad()
        
        # Forward pass
        outputs = model(batch)
        loss = criterion(outputs, labels)
        
        # Backward pass and optimization
        loss.backward()
        optimizer.step()
        
        # Metrics
        total_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
    
    return {
        'loss': total_loss / len(dataloader),
        'accuracy': 100 * correct / total
    }

def validate(model, dataloader, criterion, device):
    """Validation loop"""
    model.eval()
    total_loss = 0
    correct = 0
    total = 0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for batch in dataloader:
            # Move batch to device
            batch = {k: v.to(device) for k, v in batch.items()}
            labels = batch['label']
            
            # Forward pass
            outputs = model(batch)
            loss = criterion(outputs, labels)
            
            # Metrics
            total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    metrics = {
        'loss': total_loss / len(dataloader),
        'accuracy': 100 * correct / total,
        'predictions': all_preds,
        'ground_truth': all_labels
    }
    
    return metrics

def main():
    # Set random seed for reproducibility
    torch.manual_seed(42)
    np.random.seed(42)
    
    # Initialize configuration
    config = Config()
    
    # Create result logger
    result_logger = ResultLogger(config)
    
    # Load dataset
    dataset = SEMDataset(
        csv_file=config.train_csv, 
        root_dir=config.root_dir, 
        patch_size=config.patch_size
    )
    
    # Split dataset
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset, 
        batch_size=config.batch_size, 
        shuffle=True
    )
    val_loader = DataLoader(
        val_dataset, 
        batch_size=config.batch_size, 
        shuffle=False
    )
    
    # Initialize model
    model = EMCNet(config).to(config.device)
    
    # Loss and optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(
        model.parameters(), 
        lr=config.learning_rate
    )
    
    # Learning rate scheduler
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, 
        mode='min', 
        factor=0.1, 
        patience=5
    )
    
    # Training loop
    best_val_loss = float('inf')
    for epoch in range(config.epochs):
        # Train for one epoch
        train_metrics = train_epoch(
            model, train_loader, criterion, optimizer, config.device
        )
        
        # Validate
        val_metrics = validate(
            model, val_loader, criterion, config.device
        )
        
        # Log results
        result_logger.log_epoch(epoch, train_metrics, val_metrics)
        
        # Learning rate scheduling
        scheduler.step(val_metrics['loss'])
        
        # Model checkpointing
        if val_metrics['loss'] < best_val_loss:
            best_val_loss = val_metrics['loss']
            torch.save(
                model.state_dict(), 
                os.path.join(config.results_dir, 'best_model.pth')
            )
        
        # Print epoch summary
        print(f'Epoch {epoch+1}/{config.epochs}')
        print(f'Train Loss: {train_metrics["loss"]:.4f}, Train Acc: {train_metrics["accuracy"]:.2f}%')
        print(f'Val Loss: {val_metrics["loss"]:.4f}, Val Acc: {val_metrics["accuracy"]:.2f}%')
    
    # Final evaluation
    final_metrics = compute_metrics(
        val_metrics['ground_truth'], 
        val_metrics['predictions']
    )
    
    # Save final metrics
    result_logger.save_metrics(final_metrics)
    
    # Plot training curves
    result_logger.plot_training_curves()
    
    # Print final metrics
    print("\nFinal Metrics:")
    print(json.dumps(final_metrics, indent=2))

if __name__ == '__main__':
    main()