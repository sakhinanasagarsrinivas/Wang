

class MAEMI(nn.Module):
    """Complete MAEMI architecture as described in the paper"""
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Vision and text encoders
        self.vision_encoder = VisionEncoder(config)
        self.text_encoder = DyQLoRAFA(config)
        
        # Create alternating attention blocks
        self.layers = nn.ModuleList([
            nn.ModuleList([
                GatedCrossAttention(config),
                SelfAttentionBlock(config)
            ])
            for _ in range(config.num_layers)
        ])
        
        # Task-specific output heads
        self.task_heads = nn.ModuleDict({
            'classification': nn.Linear(config.hidden_dim, config.num_classes),
            'vqa': nn.Linear(config.hidden_dim, config.vocab_size),
            'captioning': nn.Linear(config.hidden_dim, config.vocab_size)
        })
        
        self.final_norm = nn.LayerNorm(config.hidden_dim)
        
    def forward(self, pixel_values, input_ids, attention_mask=None, task='vqa'):
        # Get visual features
        visual_features = self.vision_encoder(pixel_values)
        
        # Get text features with DyQLoRA
        text_features = self.text_encoder(input_ids, attention_mask)
        
        # Process through alternating attention layers
        hidden_states = text_features
        
        for cross_attn, self_attn in self.layers:
            # Cross attention between text and visual features
            cross_output = cross_attn(hidden_states, visual_features, attention_mask)
            
            # Self attention for refined understanding
            hidden_states = self_attn(cross_output, attention_mask)
        
        # Final layer normalization
        hidden_states = self.final_norm(hidden_states)
        
        # Task-specific prediction
        if task in self.task_heads:
            output = self.task_heads[task](hidden_states)
        else:
            raise ValueError(f"Unknown task: {task}")
        
        return output
    
    def generate(self, pixel_values, input_ids, attention_mask=None, max_length=50):
        """Generation for captioning and VQA tasks"""
        batch_size = pixel_values.size(0)
        current_ids = input_ids
        
        for _ in range(max_length):
            outputs = self.forward(
                pixel_values=pixel_values,
                input_ids=current_ids,
                attention_mask=attention_mask,
                task='vqa'  # or 'captioning'
            )
            
            # Get next token predictions
            next_token_logits = outputs[:, -1, :]
            next_token = torch.argmax(next_token_logits, dim=-1)
            
            # Append to current sequence
            current_ids = torch.cat([current_ids, next_token.unsqueeze(-1)], dim=-1)
            
            # Update attention mask
            if attention_mask is not None:
                attention_mask = torch.cat([
                    attention_mask,
                    torch.ones((batch_size, 1), device=attention_mask.device)
                ], dim=-1)
            
            # Check for end of sequence token
            if (next_token == self.config.eos_token_id).any():
                break
        
        return current_ids

# Example usage
def create_maemi_model(config):
    model = MAEMI(config)
    return model

# Training and inference
def train_step(model, batch, optimizer, criterion):
    model.train()
    optimizer.zero_grad()
    
    outputs = model(
        pixel_values=batch["pixel_values"],
        input_ids=batch["input_ids"],
        attention_mask=batch["attention_mask"],
        task=batch["task"]
    )
    
    loss = criterion(outputs.view(-1, outputs.size(-1)), batch["labels"].view(-1))
    loss.backward()
    optimizer.step()
    
    return loss.item()

def inference_step(model, batch):
    model.eval()
    with torch.no_grad():
        outputs = model(
            pixel_values=batch["pixel_values"],
            input_ids=batch["input_ids"],
            attention_mask=batch["attention_mask"],
            task=batch["task"]
        )
    return outputs    