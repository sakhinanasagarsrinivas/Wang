# models/dya_mopes.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional, Tuple, Dict
import math

class QuantizedLinear(nn.Module):
    """Quantized linear layer with low-rank adaptation."""
    def __init__(
        self,
        in_features: int,
        out_features: int,
        rank: int,
        bits: int = 8,
        bias: bool = True,
        device: Optional[torch.device] = None,
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.rank = rank
        self.bits = bits
        
        # Initialize quantized weight
        self.register_buffer(
            'weight_quantized',
            torch.zeros((out_features, in_features), device=device)
        )
        
        # Initialize scaling factors for quantization
        self.register_buffer('scale', torch.ones(1))
        self.register_buffer('zero_point', torch.zeros(1))
        
        # Low-rank adaptation matrices
        self.lora_A = nn.Parameter(torch.zeros((rank, in_features)))
        self.lora_B = nn.Parameter(torch.zeros((out_features, rank)))
        
        if bias:
            self.bias = nn.Parameter(torch.zeros(out_features))
        else:
            self.register_parameter('bias', None)
            
        self.init_weights()
        
    def init_weights(self):
        """Initialize weights with specific scaling."""
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)
        
    def quantize(self, weight: torch.Tensor) -> torch.Tensor:
        """Quantize weights to specified bits."""
        min_val = weight.min()
        max_val = weight.max()
        
        # Calculate scale and zero point
        self.scale = (max_val - min_val) / (2 ** self.bits - 1)
        self.zero_point = min_val
        
        # Quantize
        weight_q = torch.round((weight - self.zero_point) / self.scale)
        
        # Clip to valid range
        weight_q = torch.clamp(weight_q, 0, 2 ** self.bits - 1)
        
        return weight_q
        
    def dequantize(self, weight_q: torch.Tensor) -> torch.Tensor:
        """Dequantize weights."""
        return weight_q * self.scale + self.zero_point
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Dequantize base weights
        weight = self.dequantize(self.weight_quantized)
        
        # Compute low-rank adaptation
        lora_weight = self.lora_B @ self.lora_A
        
        # Combined forward pass
        output = F.linear(x, weight + lora_weight, self.bias)
        return output

class ExpertMLP(nn.Module):
    """Expert MLP with quantized linear layers."""
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        rank: int,
        dropout: float = 0.1
    ):
        super().__init__()
        
        self.fc1 = QuantizedLinear(input_dim, hidden_dim, rank)
        self.fc2 = QuantizedLinear(hidden_dim, output_dim, rank)
        self.dropout = nn.Dropout(dropout)
        self.act = nn.GELU()
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.fc1(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.fc2(x)
        return x

class DyAMoQPEs(nn.Module):
    """Dynamic Adaptation of Mixture of Quantized Parameter-Efficient Experts."""
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        num_experts: int = 8,
        rank_min: int = 4,
        rank_max: int = 16,
        dropout: float = 0.1,
        capacity_factor: float = 1.25,
        eval_capacity_factor: float = 2.0,
        min_capacity: int = 4,
        noisy_gating: bool = True,
        gating_dropout: float = 0.1
    ):
        super().__init__()
        
        self.num_experts = num_experts
        self.rank_min = rank_min
        self.rank_max = rank_max
        self.noisy_gating = noisy_gating
        self.capacity_factor = capacity_factor
        self.eval_capacity_factor = eval_capacity_factor
        self.min_capacity = min_capacity
        
        # Create experts
        self.experts = nn.ModuleList([
            ExpertMLP(input_dim, hidden_dim, output_dim, rank_max)
            for _ in range(num_experts)
        ])
        
        # Gating network
        self.gate = nn.Sequential(
            nn.Linear(input_dim, num_experts),
            nn.Dropout(gating_dropout)
        )
        
        # Dynamic rank sampling parameters
        self.register_buffer('ranks', torch.arange(rank_min, rank_max + 1))
        
    def _compute_capacity(self, batch_size: int, training: bool) -> int:
        """Compute capacity of experts."""
        capacity_factor = self.capacity_factor if training else self.eval_capacity_factor
        capacity = int(batch_size * capacity_factor / self.num_experts)
        return max(capacity, self.min_capacity)
        
    def _sample_rank(self) -> int:
        """Sample rank uniformly from [rank_min, rank_max]."""
        if self.training:
            return torch.randint(self.rank_min, self.rank_max + 1, (1,)).item()
        return self.rank_max
        
    def _noise_gating(self, clean_logits: torch.Tensor) -> torch.Tensor:
        """Add gating noise for load balancing."""
        if self.noisy_gating and self.training:
            noise = torch.rand_like(clean_logits) * 0.1
            return clean_logits + noise
        return clean_logits
        
    def forward(self, inputs: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        Forward pass with dynamic expert routing.
        
        Args:
            inputs: Input tensor of shape (batch_size, input_dim)
            
        Returns:
            tuple: (output, auxiliary_loss)
                - output: Combined expert outputs
                - auxiliary_loss: Dict containing load balancing and importance losses
        """
        batch_size = inputs.shape[0]
        capacity = self._compute_capacity(batch_size, self.training)
        
        # Get gating weights
        gate_logits = self.gate(inputs)
        gating_weights = F.softmax(self._noise_gating(gate_logits), dim=-1)
        
        # Select top-k experts per input
        top_k_gates, top_k_indices = torch.topk(gating_weights, k=2, dim=-1)
        top_k_gates = top_k_gates / top_k_gates.sum(dim=-1, keepdim=True)
        
        # Initialize output tensor
        final_output = torch.zeros_like(inputs)
        
        # Compute load balancing auxiliary loss
        importance = gating_weights.mean(0)
        load = (gating_weights > 0).float().mean(0)
        aux_loss = {
            'importance': -torch.sum(importance * torch.log(importance + 1e-10)),
            'load_balance': torch.sum(load * torch.log(load + 1e-10))
        }
        
        # Process each expert
        for expert_idx in range(self.num_experts):
            # Find relevant inputs for this expert
            expert_mask = (top_k_indices == expert_idx).any(dim=-1)
            if not expert_mask.any():
                continue
                
            # Get expert inputs
            expert_inputs = inputs[expert_mask]
            expert_gates = gating_weights[expert_mask, expert_idx].unsqueeze(-1)
            
            # Sample rank for this forward pass
            rank = self._sample_rank()
            
            # Truncate expert to current rank
            self.experts[expert_idx].fc1.rank = rank
            self.experts[expert_idx].fc2.rank = rank
            
            # Truncate LoRA matrices
            truncated_A1 = self.experts[expert_idx].fc1.lora_A[:rank, :]
            truncated_B1 = self.experts[expert_idx].fc1.lora_B[:, :rank]
            truncated_A2 = self.experts[expert_idx].fc2.lora_A[:rank, :]
            truncated_B2 = self.experts[expert_idx].fc2.lora_B[:, :rank]
            
            # Process inputs through expert
            with torch.set_grad_enabled(self.training):
                expert_output = self.experts[expert_idx](expert_inputs)
                
            # Weight output by expert gate and add to final output
            final_output[expert_mask] += expert_output * expert_gates
            
            # Restore original rank and matrices
            self.experts[expert_idx].fc1.rank = self.rank_max
            self.experts[expert_idx].fc2.rank = self.rank_max
            self.experts[expert_idx].fc1.lora_A.data = torch.cat([
                truncated_A1,
                self.experts[expert_idx].fc1.lora_A[rank:, :]
            ], dim=0)
            self.experts[expert_idx].fc1.lora_B.data = torch.cat([
                truncated_B1,
                self.experts[expert_idx].fc1.lora_B[:, rank:]
            ], dim=1)
            self.experts[expert_idx].fc2.lora_A.data = torch.cat([
                truncated_A2,
                self.experts[expert_idx].fc2.lora_A[rank:, :]
            ], dim=0)
            self.experts[expert_idx].fc2.lora_B.data = torch.cat([
                truncated_B2,
                self.experts[expert_idx].fc2.lora_B[:, rank:]
            ], dim=1)
        
        return final_output, aux_loss

    def set_expert_ranks(self, rank: int):
        """Set all experts to a specific rank."""
        assert self.rank_min <= rank <= self.rank_max
        for expert in self.experts:
            expert.fc1.rank = rank
            expert.fc2.rank = rank

    def get_expert_parameters(self) -> List[torch.nn.Parameter]:
        """Get all expert parameters."""
        parameters = []
        for expert in self.experts:
            parameters.extend([
                expert.fc1.lora_A,
                expert.fc1.lora_B,
                expert.fc2.lora_A,
                expert.fc2.lora_B
            ])
        return parameters

    def get_routing_parameters(self) -> List[torch.nn.Parameter]:
        """Get routing network parameters."""
        return list(self.gate.parameters())

class DyAMoQPEsConfig:
    """Configuration class for DyAMoQPEs."""
    def __init__(
        self,
        input_dim: int = 768,
        hidden_dim: int = 3072,
        output_dim: int = 768,
        num_experts: int = 8,
        rank_min: int = 4,
        rank_max: int = 16,
        dropout: float = 0.1,
        capacity_factor: float = 1.25,
        eval_capacity_factor: float = 2.0,
        min_capacity: int = 4,
        noisy_gating: bool = True,
        gating_dropout: float = 0.1
    ):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.num_experts = num_experts
        self.rank_min = rank_min
        self.rank_max = rank_max
        self.dropout = dropout
        self.capacity_factor = capacity_factor
        self.eval_capacity_factor = eval_capacity_factor
        self.min_capacity = min_capacity
        self.noisy_gating = noisy_gating
        self.gating_dropout = gating_dropout

class DyAMoQPEsOutput:
    """Output class for DyAMoQPEs."""
    def __init__(
        self,
        hidden_states: torch.Tensor,
        aux_loss: Optional[Dict[str, torch.Tensor]] = None,
        expert_counts: Optional[torch.Tensor] = None,
        gates: Optional[torch.Tensor] = None
    ):
        self.hidden_states = hidden_states
        self.aux_loss = aux_loss
        self.expert_counts = expert_counts
        self.gates = gates

def create_dya_mopes_layer(config: DyAMoQPEsConfig) -> DyAMoQPEs:
    """Helper function to create a DyAMoQPEs layer from config."""
    return DyAMoQPEs(
        input_dim=config.input_dim,
        hidden_dim=config.hidden_dim,
        output_dim=config.output_dim,
        num_experts=config.num_experts,
        rank_min=config.rank_min,
        rank_max=config.rank_max,
        dropout=config.dropout,
        capacity_factor=config.capacity_factor,
        eval_capacity_factor=config.eval_capacity_factor,
        min_capacity=config.min_capacity,
        noisy_gating=config.noisy_gating,
        gating_dropout=config.gating_dropout
    )    