from typing import Dict, List, Tuple, Optional, Union
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import cv2
import pytesseract
from pathlib import Path
import yaml
import torch
import torchvision.transforms as transforms
from dataclasses import dataclass
import io

@dataclass
class BoundingBox:
    x1: int
    y1: int
    x2: int
    y2: int
    confidence: float
    label: str

class ImageProcessor:
    def __init__(self, config_path: str):
        """
        Initialize image processor with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.transforms = self._initialize_transforms()
        
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def _initialize_transforms(self) -> Dict:
        """Initialize image transformations for different tasks."""
        captioning_size = tuple(self.config['processing']['image_size']['captioning'])
        ocr_size = tuple(self.config['processing']['image_size']['ocr'])
        
        return {
            'captioning': transforms.Compose([
                transforms.Resize(captioning_size),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                  std=[0.229, 0.224, 0.225])
            ]),
            'ocr': transforms.Compose([
                transforms.Resize(ocr_size),
                transforms.ToTensor()
            ])
        }
    
    def process_image(self, image: Image.Image) -> Dict:
        """
        Process an image through multiple stages.
        
        Args:
            image: PIL Image object
            
        Returns:
            Dictionary containing processed image data
        """
        # Convert to RGB if necessary
        if image.mode != 'RGB':
            image = image.convert('RGB')
            
        # Basic image enhancement
        enhanced_image = self._enhance_image(image)
        
        # Perform OCR
        ocr_results = self._perform_ocr(enhanced_image)
        
        # Detect diagram components
        components = self._detect_components(enhanced_image)
        
        # Prepare images for different tasks
        processed_images = self._prepare_task_specific_images(enhanced_image)
        
        return {
            'image': enhanced_image,
            'ocr_results': ocr_results,
            'components': components,
            'processed_images': processed_images,
            'metadata': self._extract_image_metadata(image)
        }
    
    def _enhance_image(self, image: Image.Image) -> Image.Image:
        """
        Enhance image quality for better processing.
        
        Args:
            image: PIL Image object
            
        Returns:
            Enhanced PIL Image object
        """
        # Convert to numpy array for OpenCV processing
        img_array = np.array(image)
        
        # Denoise
        denoised = cv2.fastNlMeansDenoisingColored(img_array, None, 10, 10, 7, 21)
        
        # Enhance contrast
        lab = cv2.cvtColor(denoised, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        l = clahe.apply(l)
        enhanced_lab = cv2.merge((l, a, b))
        enhanced = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2RGB)
        
        # Convert back to PIL Image
        enhanced_image = Image.fromarray(enhanced)
        
        # Fine-tune enhancement
        enhancer = ImageEnhance.Sharpness(enhanced_image)
        enhanced_image = enhancer.enhance(1.5)
        
        enhancer = ImageEnhance.Contrast(enhanced_image)
        enhanced_image = enhancer.enhance(1.2)
        
        return enhanced_image
    
    def _perform_ocr(self, image: Image.Image) -> Dict:
        """
        Perform OCR on the image.
        
        Args:
            image: PIL Image object
            
        Returns:
            Dictionary containing OCR results
        """
        # Convert to grayscale for OCR
        gray = image.convert('L')
        
        # Apply threshold to improve text detection
        threshold = gray.point(lambda x: 0 if x < 128 else 255, '1')
        
        # Get OCR data with bounding boxes
        ocr_data = pytesseract.image_to_data(threshold, output_type=pytesseract.Output.DICT)
        
        # Process OCR results
        results = []
        n_boxes = len(ocr_data['text'])
        for i in range(n_boxes):
            if int(ocr_data['conf'][i]) > 60:  # Filter low confidence results
                results.append({
                    'text': ocr_data['text'][i],
                    'confidence': float(ocr_data['conf'][i]),
                    'bbox': {
                        'x': ocr_data['left'][i],
                        'y': ocr_data['top'][i],
                        'width': ocr_data['width'][i],
                        'height': ocr_data['height'][i]
                    }
                })
        
        return {
            'text_blocks': results,
            'full_text': ' '.join([r['text'] for r in results])
        }
    
    def _detect_components(self, image: Image.Image) -> List[BoundingBox]:
        """
        Detect diagram components (equipment, lines, etc.).
        
        Args:
            image: PIL Image object
            
        Returns:
            List of detected components with bounding boxes
        """
        # Convert to numpy array
        img_array = np.array(image)
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        
        components = []
        
        # Detect lines
        edges = cv2.Canny(gray, 50, 150)
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, 100, minLineLength=100, maxLineGap=10)
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                components.append(BoundingBox(x1, y1, x2, y2, 1.0, 'line'))
        
        # Detect circles (equipment)
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 20,
                                 param1=50, param2=30, minRadius=20, maxRadius=100)
        if circles is not None:
            circles = np.uint16(np.around(circles))
            for i in circles[0, :]:
                x, y, r = i[0], i[1], i[2]
                components.append(BoundingBox(
                    x-r, y-r, x+r, y+r, 1.0, 'equipment'
                ))
        
        return components
    
    def _prepare_task_specific_images(self, image: Image.Image) -> Dict:
        """
        Prepare images for different tasks.
        
        Args:
            image: PIL Image object
            
        Returns:
            Dictionary containing task-specific processed images
        """
        return {
            'captioning': self.transforms['captioning'](image).to(self.device),
            'ocr': self.transforms['ocr'](image).to(self.device)
        }
    
    def _extract_image_metadata(self, image: Image.Image) -> Dict:
        """
        Extract metadata from image.
        
        Args:
            image: PIL Image object
            
        Returns:
            Dictionary containing image metadata
        """
        return {
            'size': image.size,
            'mode': image.mode,
            'format': image.format if hasattr(image, 'format') else None,
            'dpi': image.info.get('dpi')
        }
    
    def save_image(self, image: Image.Image, output_path: str):
        """
        Save processed image to file.
        
        Args:
            image: PIL Image object
            output_path: Path to save the image
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        image.save(output_path, format='PNG')
    
    def load_image(self, path_or_bytes: Union[str, bytes]) -> Optional[Image.Image]:
        """
        Load image from file path or bytes.
        
        Args:
            path_or_bytes: File path or image bytes
            
        Returns:
            PIL Image object or None if loading fails
        """
        try:
            if isinstance(path_or_bytes, str):
                return Image.open(path_or_bytes)
            elif isinstance(path_or_bytes, bytes):
                return Image.open(io.BytesIO(path_or_bytes))
        except Exception as e:
            print(f"Error loading image: {str(e)}")
            return None

    def extract_symbols(self, image: Image.Image) -> List[Dict]:
        """
        Extract process symbols from the diagram.
        
        Args:
            image: PIL Image object
            
        Returns:
            List of detected symbols with metadata
        """
        # Convert to numpy array
        img_array = np.array(image)
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        
        # Detect symbols using contour detection
        _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        symbols = []
        for contour in contours:
            # Filter small contours
            if cv2.contourArea(contour) > 100:
                x, y, w, h = cv2.boundingRect(contour)
                symbol_img = img_array[y:y+h, x:x+w]
                
                symbols.append({
                    'bbox': {'x': x, 'y': y, 'width': w, 'height': h},
                    'area': cv2.contourArea(contour),
                    'type': self._classify_symbol(symbol_img)
                })
        
        return symbols
    
    def _classify_symbol(self, symbol_img: np.ndarray) -> str:
        """
        Classify type of process symbol.
        
        Args:
            symbol_img: Numpy array containing symbol image
            
        Returns:
            Symbol type classification
        """
        # Basic shape analysis for classification
        height, width = symbol_img.shape[:2]
        aspect_ratio = width / height
        
        # Simple rule-based classification
        if 0.9 < aspect_ratio < 1.1:
            return 'vessel'
        elif aspect_ratio > 2:
            return 'heat_exchanger'
        elif aspect_ratio < 0.5:
            return 'column'
        else:
            return 'unknown'