import torch
import torch.nn as nn
import wandb
import numpy as np
from typing import Dict, Any
from sklearn.model_selection import ParameterGrid
from sklearn.metrics import (
    accuracy_score, 
    precision_recall_fscore_support, 
    confusion_matrix
)

class Trainer:
    def __init__(self, config, model, train_loader, val_loader, test_loader):
        self.config = config
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        
        # Device
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Loss and Optimizer
        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(
            model.parameters(), 
            lr=config.learning_rate, 
            weight_decay=1e-5
        )
        
        # Learning Rate Scheduler
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer, 
            mode='min', 
            factor=0.5, 
            patience=5
        )
    
    def train_epoch(self):
        """
        Train for a single epoch
        """
        self.model.train()
        total_loss = 0
        correct = 0
        total = 0
        
        for batch_idx, (inputs, targets) in enumerate(self.train_loader):
            inputs, targets = inputs.to(self.device), targets.to(self.device)
            
            # Zero the parameter gradients
            self.optimizer.zero_grad()
            
            # Forward pass
            outputs = self.model(inputs)
            loss = self.criterion(outputs, targets)
            
            # Backward and optimize
            loss.backward()
            self.optimizer.step()
            
            # Metrics
            total_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()
        
        return total_loss / len(self.train_loader), 100. * correct / total
    
    def validate(self, loader):
        """
        Validate model on given loader
        """
        self.model.eval()
        total_loss = 0
        correct = 0
        total = 0
        all_predictions = []
        all_targets = []
        
        with torch.no_grad():
            for inputs, targets in loader:
                inputs, targets = inputs.to(self.device), targets.to(self.device)
                
                outputs = self.model(inputs)
                loss = self.criterion(outputs, targets)
                
                total_loss += loss.item()
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
                
                all_predictions.extend(predicted.cpu().numpy())
                all_targets.extend(targets.cpu().numpy())
        
        # Compute detailed metrics
        accuracy = 100. * correct / total
        precision, recall, f1, _ = precision_recall_fscore_support(
            all_targets, all_predictions, average='weighted'
        )
        cm = confusion_matrix(all_targets, all_predictions)
        
        return {
            'loss': total_loss / len(loader),
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'confusion_matrix': cm
        }
    
    def hyperparameter_tuning(self, param_grid):
        """
        Perform hyperparameter tuning using grid search
        """
        best_score = 0
        best_params = None
        
        # Define hyperparameter search space
        param_combinations = list(ParameterGrid(param_grid))
        
        for params in param_combinations:
            # Reset model and optimizer
            self.model = self._reinitialize_model(params)
            self.optimizer = torch.optim.Adam(
                self.model.parameters(), 
                lr=params.get('learning_rate', self.config.learning_rate)
            )
            
            # Train and validate
            val_metrics = self._run_with_params(params)
            
            # Track best configuration
            if val_metrics['f1_score'] > best_score:
                best_score = val_metrics['f1_score']
                best_params = params
            
            # Log results
            wandb.log({
                'params': params,
                **val_metrics
            })
        
        return best_params, best_score
    
    def _reinitialize_model(self, params):
        """
        Reinitialize model with new configuration
        """
        # Update model configuration
        self.config.feature_dim = params.get('feature_dim', self.config.feature_dim)
        self.config.num_attention_heads = params.get('num_attention_heads', self.config.num_attention_heads)
        
        # Reinitialize model
        model = VisionHGNN(self.config).to(self.device)
        return model
    
    def _run_with_params(self, params):
        """
        Run training and validation with specific hyperparameters
        """
        # Training loop
        for epoch in range(self.config.num_epochs):
            train_loss, train_acc = self.train_epoch()
            val_metrics = self.validate(self.val_loader)
            
            # Learning rate scheduling
            self.scheduler.step(val_metrics['loss'])
            
            # Logging
            wandb.log({
                'train_loss': train_loss,
                'train_accuracy': train_acc,
                **val_metrics
            })
        
        return val_metrics
    
    def train(self):
        """
        Full training process with final evaluation
        """
        # Hyperparameter Tuning
        param_grid = {
            'learning_rate': [1e-3, 1e-4, 5e-4],
            'feature_dim': [64, 128, 256],
            'num_attention_heads': [4, 8],
            'weight_decay': [1e-5, 1e-4]
        }
        best_params, _ = self.hyperparameter_tuning(param_grid)
        
        # Retrain with best parameters
        self.model = self._reinitialize_model(best_params)
        self.optimizer = torch.optim.Adam(
            self.model.parameters(), 
            lr=best_params.get('learning_rate', self.config.learning_rate),
            weight_decay=best_params.get('weight_decay', 1e-5)
        )
        
        # Final training
        for epoch in range(self.config.num_epochs):
            train_loss, train_acc = self.train_epoch()
            val_metrics = self.validate(self.val_loader)
            
            # Learning rate scheduling
            self.scheduler.step(val_metrics['loss'])
            
            # Logging
            wandb.log({
                'train_loss': train_loss,
                'train_accuracy': train_acc,
                **val_metrics
            })
        
        # Final Test Set Evaluation
        test_metrics = self.validate(self.test_loader)
        
        # Log final test results
        wandb.log({
            'test_metrics': test_metrics
        })
        
        return test_metrics