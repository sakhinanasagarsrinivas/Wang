
import os  
import math
import torch 
import numpy as np  
import torch.nn as nn  
import torch.optim as optim  
import matplotlib.pyplot as plt
from utils import (FeatureEmbedder, LatentToFeatureReconstructor, LatentSynthesizer,
                   SequentialLatentForecaster, LatentSequenceClassifier, perform_dimensionality_reduction_and_plot,
                   generate_sample_batch, calculate_sequence_lengths, generate_random_sequences)  # Import utility functions and classes used for various tasks.
from missingness import *                

import warnings  # Module to handle warnings.
warnings.simplefilter(action='ignore', category=FutureWarning)  # Suppresses FutureWarning messages.


class RandomSeedHandler:
    """
    A utility class to manage random seeds for reproducibility across PyTorch, CUDA, and numpy.

    Attributes:
    seed : int or None
        The seed value used for random number generation. If None, random seeding is not applied.
    """
    def __init__(self, seed=None):
        # Initializes the class with an optional seed value.
        # If seed is not provided, random seeding is not enforced.
        self.seed = seed

    def configure_torch_seed(self):
        """Configures the seed for PyTorch, ensuring deterministic behavior."""
        try:
            # Sets the seed for generating random numbers in PyTorch for CPU operations.
            torch.manual_seed(self.seed)
            # Sets the seed for generating random numbers in PyTorch for GPU operations (all available GPUs).
            torch.cuda.manual_seed_all(self.seed)
        except Exception as e:
            # Raises an error if seed configuration for PyTorch fails.
            raise RuntimeError(f"Error configuring PyTorch seed: {str(e)}")

    def enable_cudnn_determinism(self):
        """Enables deterministic behavior for cuDNN to ensure reproducibility in CUDA operations."""
        try:
            # Ensures deterministic operations in cuDNN, making CUDA operations reproducible.
            torch.backends.cudnn.deterministic = True
        except Exception as e:
            # Raises an error if enabling cuDNN determinism fails.
            raise RuntimeError(f"Error enabling cuDNN determinism: {str(e)}")

    def initialize_seeds(self):
        """Initializes all relevant seeds if a seed value is provided."""
        try:
            # Checks if the seed is provided and is not equal to -1.
            # If the seed is valid, initializes seeds for PyTorch, numpy, and CUDA determinism.
            if self.seed is not None and self.seed != -1:
                self.configure_torch_seed()  # Configures seed for PyTorch operations.
                self.enable_cudnn_determinism()  # Enables deterministic behavior for cuDNN.
        except Exception as e:
            # Raises an error if any issue occurs during seed initialization.
            raise RuntimeError(f"Error initializing seeds: {str(e)}")

########################################################################            

class FocalLoss(nn.Module):
    def __init__(self, gamma=0.0, alpha=1, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction
        self.bce_loss = nn.BCELoss(reduction='none')  # Use BCE without reduction

    def forward(self, input, target):
        """
        Compute the Focal Loss.
        Args:
        - input (Tensor): Predicted probabilities (after sigmoid), shape (N, *).
        - target (Tensor): Ground truth labels, shape (N, *).

        Returns:
        - loss (Tensor): Scalar loss (if reduction is 'mean' or 'sum') or
                         per-element loss (if reduction is 'none').
        """
        # Ensure the input is in the range (0, 1) (sigmoid probabilities)
        if not torch.all((input >= 0) & (input <= 1)):
            raise ValueError("Input should be probabilities (0 <= input <= 1).")

        # Compute BCE Loss without reduction
        bce_loss = self.bce_loss(input, target)

        # Compute the modulating factor (1 - p_t)^gamma
        pt = torch.where(target == 1, input, 1 - input)  # Probability of the correct class
        focal_term = (1 - pt) ** self.gamma

        # Scale BCE loss with the focal term
        loss = self.alpha * focal_term * bce_loss

        # Apply reduction
        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss

########################################################################

class HybridWassersteinLoss_feature_wise(nn.Module):
    def __init__(self, num_bins=10, w1_weight=0.5, w2_weight=0.5, reduction='mean'):
        """
        HybridWassersteinLoss that computes the Wasserstein distances for each feature independently.

        Args:
            num_bins (int): Number of bins for the histograms.
            w1_weight (float): Weight for the Wasserstein-1 distance.
            w2_weight (float): Weight for the Wasserstein-2 distance.
            reduction (str): Reduction method - 'mean' or 'sum' for aggregating per-feature losses.
        """
        super(HybridWassersteinLoss_feature_wise, self).__init__()
        self.num_bins = num_bins
        self.w1_weight = w1_weight
        self.w2_weight = w2_weight
        self.reduction = reduction

    def forward(self, real, synthetic):
        """
        Args:
            real (Tensor): Real data tensor of shape (batch_size, seq_length, num_features).
            synthetic (Tensor): Synthetic data tensor of the same shape as `real`.

        Returns:
            Tensor: Hybrid Wasserstein loss computed for each feature and aggregated.
        """
        # Ensure real and synthetic have the same shape
        assert real.shape == synthetic.shape, "Real and synthetic tensors must have the same shape."

        num_features = real.shape[-1]
        losses = []

        for i in range(num_features):

            # Extract the i-th feature for real and synthetic data
            real_feature = real[..., i].flatten()
            synthetic_feature = synthetic[..., i].flatten()


            # Compute the minimum and maximum values for the combined real and synthetic data
            min_val = min(real_feature.min().item(), synthetic_feature.min().item())
            max_val = max(real_feature.max().item(), synthetic_feature.max().item())

            # Create bin edges for histograms
            bin_edges = torch.linspace(min_val, max_val, self.num_bins + 1, device=real.device)

            # Compute histograms for real and synthetic data
            real_hist = torch.histc(real_feature, bins=self.num_bins, min=min_val, max=max_val)
            synthetic_hist = torch.histc(synthetic_feature, bins=self.num_bins, min=min_val, max=max_val)

            # Normalize the histograms to create probability distributions
            real_hist = real_hist / real_hist.sum()
            synthetic_hist = synthetic_hist / synthetic_hist.sum()

            # Compute cumulative distribution functions (CDFs) for Wasserstein-1
            real_cdf = torch.cumsum(real_hist, dim=0)
            synthetic_cdf = torch.cumsum(synthetic_hist, dim=0)

            # Wasserstein-1 (W1) Distance: Sum of absolute differences between CDFs
            w1_distance = torch.sum(torch.abs(real_cdf - synthetic_cdf)) / self.num_bins

            # Wasserstein-2 (W2) Distance: Quadratic cost based on bin centers
            bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2  # Midpoints of bins
            w2_distance = torch.sqrt(torch.sum((bin_centers * (real_hist - synthetic_hist)) ** 2))

            # Hybrid loss: weighted combination of W1 and W2
            hybrid_loss = self.w1_weight * w1_distance + self.w2_weight * w2_distance

            losses.append(hybrid_loss)

        losses = torch.stack(losses)

        # Apply reduction: 'mean' or 'sum'
        if self.reduction == 'mean':
            return losses.mean()
        elif self.reduction == 'sum':
            return losses.sum()
        else:
            return losses  # Return per-feature loss if no reduction is specified

########################################################################


def mmd_loss(real_data, synthetic_data, sigma=1.0):
    """Calculates the Maximum Mean Discrepancy (MMD) loss using a Gaussian kernel in PyTorch."""

    # Ensure inputs are PyTorch tensors on the same device
    device = real_data.device
    real_data = real_data.to(device)
    synthetic_data = synthetic_data.to(device)

    # Gaussian kernel calculation in PyTorch
    gamma = 1.0 / (2 * sigma**2)

    # Efficient pairwise squared Euclidean distances in PyTorch (without loops)
    dists_real = torch.cdist(real_data, real_data, p=2).pow(2)  #pairwise squared Euclidean distances.  This is efficient
    dists_synthetic = torch.cdist(synthetic_data, synthetic_data, p=2).pow(2) #pairwise squared Euclidean distances
    dists_cross = torch.cdist(real_data, synthetic_data, p=2).pow(2)    #pairwise squared Euclidean distances

    k_real = torch.exp(-gamma * dists_real)
    k_synthetic = torch.exp(-gamma * dists_synthetic)
    k_cross = torch.exp(-gamma * dists_cross)

    mmd = torch.mean(k_real) + torch.mean(k_synthetic) - 2 * torch.mean(k_cross)
    return mmd

def featurewise_mmd_loss(real_data, synthetic_data, sigma=1.0):
    """Calculates feature-wise MMD loss."""
    num_features = real_data.shape[-1]
    mmd_losses = []
    for i in range(num_features):
        real_feature = real_data[..., i].reshape(-1, 1)  # Extract feature i
        synthetic_feature = synthetic_data[..., i].reshape(-1, 1)
        mmd_losses.append(mmd_loss(real_feature, synthetic_feature, sigma))
    return torch.mean(torch.stack(mmd_losses))                

########################################################################

class SyntheticDataAugmentation:
    """
    Single-class implementation of SyntheticDataAugmentation.

    This class represents a time series generative adversarial network for generating synthetic time series data.

    Attributes:
    config : object
        The configuration object containing various settings for model training and hyperparameters.
    raw_data : ndarray
        The input raw time series data for training.
    """
    def __init__(self, config, raw_data):
        """
        Initializes SyntheticDataAugmentation class with configurations and data.

        Parameters:
        config : object
            Contains settings like learning rate, device type, and number of iterations.
        raw_data : ndarray
            Input time series data.
        """
        try:
            # Apply a fixed seed for reproducibility across training runs.
            self.apply_seed(config['seed_value'])
            self.config = config
            self.raw_data = raw_data

            # Calculate sequence times and the maximum sequence length from raw data.
            self.seq_times, self.max_sequence_length = calculate_sequence_lengths(self.raw_data)
            dataset_size = len(raw_data)  # Total size of the input dataset.

            # Set the computation device based on the configuration (CPU/GPU).
            self.computation_device = torch.device("cuda:0" if torch.cuda.is_available() and self.config['compute_target'] != 'cpu' else "cpu")
            
            # Define directories for saving training and testing outputs.
            self.training_results_path = os.path.join(self.config['output_dir'], self.config['run_name'], 'train')
            self.test_results_path = os.path.join(self.config['output_dir'], self.config['run_name'], 'test')

            # Initialize tracking variables for training progress.
            self.experiment_workspace = config['plots_storage']

            # initialize neural networks
            self.setup_networks()
           
            if self.config['isTrain']:
                self.setup_optimizers()
                self.setup_loss_functions()
                self.step_counter = 0                
                # Add loss tracking lists
                self.losses = {
                    'embedding_Reconstructor': [],
                    'forecaster': [],
                    'Synthesizer': [],
                    'classifier': [],
                    'pretrainingadversarial_loss':[],
                    'discriminatorpretraining_loss':[]
                }     
        except Exception as e:
            raise RuntimeError(f"Error initializing SyntheticDataAugmentation: {str(e)}")

    def apply_seed(self, seed_val):
        """
        Applies the random seed using RandomSeedHandler for reproducibility.

        Parameters:
        seed_val : int
            The seed value to be applied.
        """
        try:
            # Use a specific seed for consistent results in random operations.
            if seed_val and seed_val >= 0:
                seed_manager = RandomSeedHandler(seed=seed_val)
                seed_manager.initialize_seeds()
        except Exception as e:
            raise RuntimeError(f"Error applying seed: {str(e)}")   
            
    def setup_networks(self):
        """
        Sets up the neural networks for various components of SyntheticDataAugmentation.

        This includes models for embedding, reconstruction, synthesis, classification, and forecasting.
        """
        try:
            # FeatureEmbedder: Embeds raw features into a latent space representation.
            self.featureEmbedder = FeatureEmbedder(self.config).to(self.computation_device)
            
            # LatentToFeatureReconstructor: Reconstructs raw features from the latent representation.
            self.latentToFeatureReconstructor = LatentToFeatureReconstructor(self.config).to(self.computation_device)
            
            # LatentSynthesizer: Generates new latent representations based on training data.
            self.latentSynthesizer = LatentSynthesizer(self.config).to(self.computation_device)
            
            # LatentSequenceClassifier: Classifies sequences based on their latent representations.
            self.latentSequenceClassifier = LatentSequenceClassifier(self.config).to(self.computation_device)
            
            # SequentialLatentForecaster: Predicts future latent sequences for forecasting.
            self.sequentialLatentForecaster = SequentialLatentForecaster(self.config).to(self.computation_device)
            
            # Load pre-trained weights if checkpoint paths are provided in the configuration.
            self.load_checkpoint_if_available()
            
        except Exception as e:
            # Catch any exception during network setup and raise a runtime error with a detailed message.
            raise RuntimeError(f"Error setting up networks: {str(e)}")

    def load_checkpoint_if_available(self):
        """
        Loads pre-trained weights if checkpoint paths are provided in the configuration.
        Allows the model to resume training from previously saved states, if applicable.
        """
        if self.config['checkpoint_path']:
            self.load_saved_parameters()        

    def load_saved_parameters(self):
        """
        Loads saved model weights if specified by the configuration.

        Raises:
        FileNotFoundError
            If the pre-trained weights cannot be found for any of the networks.
        """
        for net_name in ['featureEmbedder', 'latentToFeatureReconstructor', 'latentSynthesizer', 'latentSequenceClassifier', 'sequentialLatentForecaster']:
            try:
                # Construct the full path to the saved weights file and load the state dictionary.
                path = os.path.join(self.config['checkpoint_path'], f'{net_name}.pth')
                getattr(self, net_name).load_state_dict(torch.load(path)['model_parameters'])
            except FileNotFoundError:
                raise FileNotFoundError(f"Could not find pre-trained weights for {net_name}")
            except Exception as e:
                raise RuntimeError(f"Error loading weights for {net_name}: {str(e)}")

    def setup_loss_functions(self):
        """
        Initializes loss functions used for training.

        These include mean squared error (MSE) and binary cross-entropy (BCE) losses.
        """
        try:
            self.mean_squared_error = nn.MSELoss()  # Loss for regression tasks.
            self.focal_loss = FocalLoss(gamma=0.0, alpha=1, reduction='mean')  # Loss for classification tasks.
        except Exception as e:
            raise RuntimeError(f"Error setting up loss functions: {str(e)}")

    def setup_optimizers(self):
        """
        Sets up the optimizers for the various components of SyntheticDataAugmentation.

        Configures optimizers with the Adam optimizer and specific hyperparameters from the config.
        """
        try:
            optimizer_settings = {'lr': self.config['learning_rate'], 'betas': (self.config['adam_optimizer_beta1'], 0.999)}
            # Assign separate optimizers to each neural network.
            self.optimizer_embedder = optim.Adam(self.featureEmbedder.parameters(), **optimizer_settings)
            self.optimizer_Reconstructor = optim.Adam(self.latentToFeatureReconstructor.parameters(), **optimizer_settings)
            self.optimizer_Synthesizer = optim.Adam(self.latentSynthesizer.parameters(), **optimizer_settings)
            self.optimizer_classifier = optim.Adam(self.latentSequenceClassifier.parameters(), **optimizer_settings)
            self.optimizer_forecaster = optim.Adam(self.sequentialLatentForecaster.parameters(), **optimizer_settings)

            # Add StepLR learning rate schedulers for all optimizers
            # use StepLR in your code for decaying the learning rate by a constant factor after a predetermined number of epochs
            # learning rate is progressively reduced every 10000 epochs by a factor of 0.75 (0.001, 0.00075, 0.0005625, 0.000421875, 0.00031640625)
            self.scheduler_embedder = torch.optim.lr_scheduler.StepLR(self.optimizer_embedder, step_size=10000, gamma=0.75)
            self.scheduler_Reconstructor = torch.optim.lr_scheduler.StepLR(self.optimizer_Reconstructor, step_size=10000, gamma=0.75)
            self.scheduler_Synthesizer = torch.optim.lr_scheduler.StepLR(self.optimizer_Synthesizer, step_size=10000, gamma=0.75)
            self.scheduler_classifier = torch.optim.lr_scheduler.StepLR(self.optimizer_classifier, step_size=10000, gamma=0.75)
            self.scheduler_forecaster = torch.optim.lr_scheduler.StepLR(self.optimizer_forecaster, step_size=10000, gamma=0.75)

        except Exception as e:
            raise RuntimeError(f"Error setting up optimizers: {str(e)}")
            

    def train_iteration(self, model_names, optimizer_names, forward_methods, backward_method):
        """
        Runs a training iteration for specified models, optimizers, and methods.

        Parameters:
        model_names : list
            List of model names to be trained.
        optimizer_names : list
            List of optimizer names to be used.
        forward_methods : list
            List of forward propagation methods to be called.
        backward_method : str
            The backward propagation method name to be called.
        """
        # Set the specified models to training mode
        for model_name in model_names:
            getattr(self, model_name).train()
        try:
            # Generate input data batch from raw data
            self.input_data, self.time_steps = generate_sample_batch(self.raw_data, self.seq_times, self.config['batch_size'])

            # Convert input_data to a NumPy array if it is a list of arrays
            if not isinstance(self.input_data, torch.Tensor):
                if isinstance(self.input_data, list) and isinstance(self.input_data[0], np.ndarray):
                    # Efficient conversion to a single NumPy array
                    self.input_data = np.array(self.input_data)

            # Convert input data to PyTorch tensor and move to the computation device
            self.tensor_input = torch.tensor(self.input_data, dtype=torch.float32).to(self.computation_device) if not isinstance(self.input_data, torch.Tensor) else self.input_data.to(self.computation_device)

            ### Apply masking function ###
            # Generate the mask
            self.config['missing_percentage'] = random.uniform(1, 2)
            mask_matrix = randomly_execute_mask_function(self.tensor_input, self.config['missing_percentage']).to(self.computation_device)
            # Apply the mask to simulate missing data
            self.masked_input = self.tensor_input * mask_matrix

            # Generate random sequences for the Synthesizer and convert to PyTorch tensor
            self.random_sequences = generate_random_sequences(self.config['batch_size'], self.config['input_dim'], self.time_steps, self.max_sequence_length)
            self.tensor_random_sequences = torch.tensor(self.random_sequences, dtype=torch.float32).to(self.computation_device) if not isinstance(self.random_sequences, torch.Tensor) else self.random_sequences.to(self.computation_device)

            # Run forward propagation for each specified forward method
            for method in forward_methods:
                getattr(self, method)()

            # Zero gradients for each specified optimizer
            for optimizer_name in optimizer_names:
                getattr(self, optimizer_name).zero_grad()

            # Perform backward propagation using the specified backward method
            getattr(self, backward_method)()

            # Step the optimizer to update model weights
            for optimizer_name in optimizer_names:
                getattr(self, optimizer_name).step()
        except RuntimeError as e:
            # Handle runtime errors during training iteration and raise descriptive exception
            raise RuntimeError(f"Training iteration error: {str(e)}")
        except Exception as e:
            # Handle unexpected errors during training iteration and raise descriptive exception
            raise RuntimeError(f"Unexpected error during training iteration: {str(e)}")

    def train(self):
        """
        Main training loop to train SyntheticDataAugmentation components.

        Executes different phases of training (encoder, supervisor, Synthesizer/discriminator).
        """
        try:
            # Check if training is enabled
            if not self.config.get('isTrain', True):  # If training is disabled
                print("Skipping training phases and proceeding directly to synthetic data generation.")
            else:
                # Loop through the specified number of iterations for embedder and reconstructor training phase
                for iteration in range(int(self.config['num_iterations']/2)):
                    # Train the feature embedder and latent-to-feature reconstructor
                    self.train_iteration(
                        ['featureEmbedder', 'latentToFeatureReconstructor'],
                        ['optimizer_embedder', 'optimizer_Reconstructor'],
                        ['propagate_embedding_Reconstructor'], 
                        'backprop_embedding_Reconstructor'
                        )
                    print(f'Encoder training step: {iteration + 1}/{self.config["num_iterations"] // 2}')

                    # Step the learning rate schedulers for embedder and reconstructor
                    self.scheduler_embedder.step()
                    self.scheduler_Reconstructor.step()

                    # Print learning rate at milestones for embedder and reconstructor
                    if iteration % 4000 == 0 or iteration == self.config['num_iterations'] - 1:
                        print(f"Iteration {iteration}: Embedder LR = {self.scheduler_embedder.get_last_lr()[0]}")
                        print(f"Iteration {iteration}: Reconstructor LR = {self.scheduler_Reconstructor.get_last_lr()[0]}")

                # Loop through the specified number of iterations for supervisor training phase
                for iteration in range(int(self.config['num_iterations'] / 2)):
                    # Train the sequential latent forecaster
                    self.train_iteration(
                        ['sequentialLatentForecaster'],
                        ['optimizer_forecaster'],
                        ['propagate_embedding_Reconstructor', 'propagate_forecaster'],
                        'backprop_forecaster'
                        )
                    print(f'Supervisor training step: {iteration + 1}/{self.config["num_iterations"] // 2}')

                    # Step the learning rate scheduler for the forecaster
                    self.scheduler_forecaster.step()

                    # Print learning rate at milestones for forecaster
                    if iteration % 4000 == 0 or iteration == self.config['num_iterations'] - 1:
                        print(f"Iteration {iteration}: Forecaster LR = {self.scheduler_forecaster.get_last_lr()[0]}")
                        

                # Loop through the specified number of iterations for Synthesizer training phase
                for iteration in range(int(self.config['num_iterations'] / 2)):
                    # Train the latent Synthesizer and sequential latent forecaster
                    self.train_iteration(
                        ['latentSynthesizer', 'sequentialLatentForecaster'],  # Models to train
                        ['optimizer_Synthesizer', 'optimizer_forecaster'],  # Corresponding optimizers
                        [
                            'propagate_embedding_Reconstructor',  # Embedding propagation
                            'propagate_forecaster',              # Forecaster propagation
                            'propagate_Synthesizer',             # Synthesizer propagation
                            'propagate_supervised_gen',              # Forecaster propagation
                            'propagate_Reconstructor_gen',        # Reconstructor propagation
                            'propagate_disc_gen'
                        ],
                        'backprop_Synthesizer'  # Backpropagation method
                    )
                 
                    print(f'Synthesizer training step: {iteration + 1}/{self.config["num_iterations"] // 2}')
                    
                    # Step the learning rate schedulers for Synthesizer and forecaster
                    self.scheduler_Synthesizer.step()
                    self.scheduler_forecaster.step()

                    # Log training progress
                    if iteration % 4000 == 0 or iteration == self.config['num_iterations'] - 1:
                        print(f"Iteration {iteration}: Synthesizer LR = {self.scheduler_Synthesizer.get_last_lr()[0]}")
                        print(f"Iteration {iteration}: Forecaster LR = {self.scheduler_forecaster.get_last_lr()[0]}")


                # Loop through the specified number of iterations for discriminator pretraining
                for iteration in range(int(self.config['num_iterations'] / 2)):
                    # Train the latent sequence classifier (discriminator)
                    self.train_iteration(
                        ['latentSequenceClassifier'],  # Model to train
                        ['optimizer_classifier'],  # Corresponding optimizer
                        [
                            'propagate_embedding_Reconstructor',  # Embedding propagation
                            'propagate_Synthesizer',             # Synthesizer propagation
                            'propagate_supervised_gen',              # Forecaster propagation
                            'propagate_classifier',              # Discriminator propagation
                            'propagate_disc_gen',
                        ],
                        'backprop_classifier'  # Backpropagation method
                    )

                  
                    print(f'Discriminator pretraining step: {iteration + 1}/{self.config["num_iterations"] // 2}')
                    
                    # Step the learning rate scheduler for the discriminator
                    self.scheduler_classifier.step()

                    # Log training progress
                    if iteration % 4000 == 0 or iteration == self.config['num_iterations'] - 1:
                        print(f"Iteration {iteration}: Classifier LR = {self.scheduler_classifier.get_last_lr()[0]}")

                #===================================================================================================#
                # Loop through the specified number of iterations for Synthesizer/Discriminator training phase
                for iteration in range(self.config['num_iterations']):
                    # Perform multiple training iterations for Synthesizer and Discriminator networks
                    for _ in range(2):
                        # Train latent Synthesizer and forecaster
                        self.train_iteration(
                            ['latentSynthesizer', 'sequentialLatentForecaster'],
                            ['optimizer_Synthesizer', 'optimizer_forecaster'],
                            ['propagate_embedding_Reconstructor', 'propagate_forecaster', 'propagate_Synthesizer', 'propagate_supervised_gen', 'propagate_Reconstructor_gen', 'propagate_disc_gen'],
                            'backprop_Synthesizer'
                        )
                        # Train feature embedder and reconstructor with alternative backpropagation
                        self.train_iteration(
                            ['featureEmbedder', 'latentToFeatureReconstructor'],
                            ['optimizer_embedder', 'optimizer_Reconstructor'],
                            ['propagate_embedding_Reconstructor', 'propagate_forecaster'],
                            'backprop_embedding_Reconstructor_'
                        )

                    # Train the latent sequence classifier
                    self.train_iteration(
                        ['latentSequenceClassifier'],
                        ['optimizer_classifier'],
                        ['propagate_embedding_Reconstructor', 'propagate_Synthesizer', 'propagate_supervised_gen', 'propagate_classifier', 'propagate_disc_gen'],
                        'backprop_classifier'
                    )
                    print(f'Synthesizer/Discriminator training step: {iteration + 1}/{self.config["num_iterations"]}')

                    # Step the learning rate schedulers for Synthesizer, classifier, and forecaster
                    self.scheduler_Synthesizer.step()
                    self.scheduler_classifier.step()
                    self.scheduler_forecaster.step()

                    # Print learning rate at milestones for Synthesizer, classifier, and forecaster
                    if iteration % 4000 == 0 or iteration == self.config['num_iterations'] - 1:
                        print(f"Iteration {iteration}: Synthesizer LR = {self.scheduler_Synthesizer.get_last_lr()[0]}")
                        print(f"Iteration {iteration}: Classifier LR = {self.scheduler_classifier.get_last_lr()[0]}")
                        print(f"Iteration {iteration}: Forecaster LR = {self.scheduler_forecaster.get_last_lr()[0]}")

                # Save model weights after training is completed
                self.save_model_parameters(self.config['num_iterations'])
                self.plot_training_losses()  # Plot the training losses

            # Generate synthetic data using the trained models
            self.simulated_data = self.generate_synthetic_data(self.config['batch_size'])
            print('Simulated Data Synthesis Completed')

            if self.config.get('isTrain', True):
                # Perform dimensionality reduction and visualization using PCA and t-SNE
                perform_dimensionality_reduction_and_plot(self.raw_data, self.simulated_data, 'pca', self.experiment_workspace)
                perform_dimensionality_reduction_and_plot(self.raw_data, self.simulated_data, 'tsne', self.experiment_workspace)

            # Return the generated synthetic data
            return self.simulated_data    

        except RuntimeError as e:
            # Handle runtime errors during the training process and raise descriptive exception
            raise RuntimeError(f"Error during training process: {str(e)}")
        except Exception as e:
            # Handle unexpected errors during the training process and raise descriptive exception
            raise RuntimeError(f"Unexpected error during training process: {str(e)}")


    def generate_synthetic_data(self, num_samples):
        """
        Generates synthetic time series data using the trained model.

        Parameters:
        num_samples : int
            Number of samples to be generated.

        Returns:
        simulated_data : list
            List of generated time series data.
        """
        # Check if the number of samples is less than or equal to 0, return None if true
        if num_samples <= 0:
            return None

        # Initialize an empty list to store generated data samples
        data_samples = []
        no_iterations = math.ceil(np.asarray(self.raw_data).shape[0]/num_samples)
        try:
            # Loop to generate synthetic data for predetermined number of iterations
            for _ in range(no_iterations):
                # Generate input data and time steps for each sample batch
                self.input_data, self.time_steps = generate_sample_batch(self.raw_data, self.seq_times, self.config['batch_size'])
                
                # Generate random input sequences and convert them to tensors, move to the computation device
                self.tensor_random_sequences = torch.tensor(
                    generate_random_sequences(num_samples, self.config['input_dim'], self.time_steps, self.max_sequence_length),
                    dtype=torch.float32).to(self.computation_device)
                
                # Generate latent variables using the latent synthesizer model
                self.generated_latents = self.latentSynthesizer(self.tensor_random_sequences)
                
                # Forecast the future latent states using the sequential latent forecaster model
                self.forecasted_latents = self.sequentialLatentForecaster(self.generated_latents)
                
                # Convert the generated latent features back to the original feature space, detach from GPU, and convert to numpy array
                simulated_data_curr = self.latentToFeatureReconstructor(self.forecasted_latents).cpu().detach().numpy()
                
                # Append the generated data of the current iteration to the data_samples list
                data_samples.append(simulated_data_curr)
        except RuntimeError as e:
            # Handle runtime errors and raise a descriptive exception if any
            raise RuntimeError(f"Error during Simulated data Synthesis: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise a descriptive exception
            raise RuntimeError(f"Unexpected error during Simulated data Synthesis: {str(e)}")

        try:
            # Stack the generated data from all iterations vertically into one numpy array
            data_samples = np.vstack(data_samples)

            # Create the list of generated time series data, extracting samples with different sequence lengths
            simulated_data = [data_samples[i, :self.seq_times[i], :] for i in range(len(self.seq_times))]
            
            # Return the final generated synthetic time series data
            return simulated_data
        except ValueError as e:
            # Handle value errors during data stacking or transformation and raise a descriptive exception
            raise RuntimeError(f"Error while stacking or transforming synthetic data: {str(e)}")
        except Exception as e:
            # Handle unexpected errors during data processing and raise a descriptive exception
            raise RuntimeError(f"Unexpected error while processing synthetic data: {str(e)}")
 

    def save_model_parameters(self, epoch):
        """
        Saves model weights to disk for future use.

        Parameters:
        epoch : int
            The current epoch or iteration to be saved with the weights.
        """
        # Create a directory path to save model weights, using the training directory and a 'weights' subfolder
        state_save_path = os.path.join(self.training_results_path, 'weights')

        try:
            # Create the 'weights' directory if it does not exist
            os.makedirs(state_save_path, exist_ok=True)

            # Iterate through the list of network components and save their weights to disk
            for net_name in ['featureEmbedder', 'latentToFeatureReconstructor', 'latentSynthesizer', 'latentSequenceClassifier', 'sequentialLatentForecaster']:
                # Save the state dictionary (weights) of each network along with the current epoch number
                torch.save({'epoch': epoch + 1, 'model_parameters': getattr(self, net_name).state_dict()}, f'{state_save_path}/{net_name}.pth')
        except IOError as e:
            # Handle input/output errors during saving and raise a descriptive exception
            raise IOError(f"Error saving model weights: {str(e)}")
        except Exception as e:
            # Handle unexpected errors during saving and raise a descriptive exception
            raise RuntimeError(f"Unexpected error while saving model weights: {str(e)}")

    # Forward propagation methods
    def propagate_embedding_Reconstructor(self):
        """Execute forward pass through embedding and Reconstructor networks."""
        try:
            # Pass the input tensor through the feature embedder to extract latent features for the next time step
            self.latent_features = self.featureEmbedder(self.masked_input)  # Embedding for time t to get z_{t+1}
            
            # Reconstruct the original input at time t using the latent features for time t+1
            self.reconstructed_input = self.latentToFeatureReconstructor(self.latent_features)
        except RuntimeError as e:
            raise RuntimeError(f"Error during propagate_embedding_Reconstructor: {str(e)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during propagate_embedding_Reconstructor: {str(e)}")

    def propagate_forecaster(self):
        """Execute forward pass through forecaster network."""
        try:
            # Pass the latent features through the sequential latent forecaster to obtain supervised latents
            self.supervised_latents = self.sequentialLatentForecaster(self.latent_features)
        except RuntimeError as e:
            # Handle runtime errors during forward propagation and raise descriptive exception
            raise RuntimeError(f"Error during propagate_forecaster: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during propagate_forecaster: {str(e)}")

    def propagate_Synthesizer(self):
        """Execute forward pass through Synthesizer network."""
        try:
            # Pass random input sequences through the synthesizer to generate latent features
            self.generated_latents = self.latentSynthesizer(self.tensor_random_sequences)
        except RuntimeError as e:
            # Handle runtime errors during forward propagation and raise descriptive exception
            raise RuntimeError(f"Error during propagate_Synthesizer: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during propagate_Synthesizer: {str(e)}")

    def propagate_disc_gen(self):
        """Execute forward pass through discriminator using generated data."""
        try:
            # Pass forecasted latents through the classifier to generate fake classifier output
            self.fake_classifier_output = self.latentSequenceClassifier(self.forecasted_latents)
            
            # Pass generated latents through the classifier to generate fake classifier output for generated latents
            self.fake_classifier_output_gen = self.latentSequenceClassifier(self.generated_latents)
        except RuntimeError as e:
            # Handle runtime errors during forward propagation and raise descriptive exception
            raise RuntimeError(f"Error during propagate_disc_gen: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during propagate_disc_gen: {str(e)}")

    def propagate_Reconstructor_gen(self):
        """Execute forward pass through Reconstructor network for generated data."""
        try:
            # Pass forecasted latents through the reconstructor to reconstruct the original input
            self.reconstructed_forecasted_input = self.latentToFeatureReconstructor(self.forecasted_latents)
        except RuntimeError as e:
            # Handle runtime errors during forward propagation and raise descriptive exception
            raise RuntimeError(f"Error during propagate_Reconstructor_gen: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during propagate_Reconstructor_gen: {str(e)}")

    def propagate_supervised_gen(self):
        """Execute forward pass through forecaster network using generated latents."""
        try:
            # Pass the generated latents through the forecaster to obtain forecasted latents
            self.forecasted_latents = self.sequentialLatentForecaster(self.generated_latents)
        except RuntimeError as e:
            # Handle runtime errors during forward propagation and raise descriptive exception
            raise RuntimeError(f"Error during propagate_supervised_gen: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during propagate_supervised_gen: {str(e)}")

    def propagate_classifier(self):
        """Execute forward pass through classifier network for real and generated data."""
        try:
            # Pass latent features through the classifier to generate real classifier output
            self.real_classifier_output = self.latentSequenceClassifier(self.latent_features)
            
            # Pass forecasted latents through the classifier to generate fake classifier output
            self.fake_classifier_output = self.latentSequenceClassifier(self.forecasted_latents)
            
            # Pass generated latents through the classifier to generate fake classifier output for generated latents
            self.fake_classifier_output_gen = self.latentSequenceClassifier(self.generated_latents)
        except RuntimeError as e:
            # Handle runtime errors during forward propagation and raise descriptive exception
            raise RuntimeError(f"Error during propagate_classifier: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during propagate_classifier: {str(e)}")
    
    # Backward propagation methods for calculating and propagating error gradients
    def backprop_embedding_Reconstructor(self):
        """
        """
        try:
            # Calculate mean squared error between reconstructed input and the original input at time t
            self.error_embedding_Reconstructor = self.mean_squared_error(self.reconstructed_input, self.tensor_input) + \
               self.config['distribution_regularization_weight'] * torch.sqrt(torch.mean(torch.abs(torch.sqrt(torch.std(self.reconstructed_input, dim=0) + 1e-6) - torch.sqrt(torch.std(self.tensor_input, dim=0) + 1e-6))) + \
                          torch.mean(torch.abs(torch.mean(self.reconstructed_input, dim=0) - torch.mean(self.tensor_input, dim=0))))
            self.losses['embedding_Reconstructor'].append(self.error_embedding_Reconstructor.item())

            # Backpropagate the error gradient
            self.error_embedding_Reconstructor.backward(retain_graph=True)
        except RuntimeError as e:
            raise RuntimeError(f"Error during backprop_embedding_Reconstructor: {str(e)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during backprop_embedding_Reconstructor: {str(e)}")

    def backprop_embedding_Reconstructor_(self):
        """Alternative backpropagation with combined supervision error.
        """
        try:
            # Calculate mean squared error between reconstructed input and original input tensor
            self.error_embedding_Reconstructor_alt = self.mean_squared_error(self.reconstructed_input, self.tensor_input) + \
               self.config['distribution_regularization_weight'] * torch.sqrt(torch.mean(torch.abs(torch.sqrt(torch.std(self.reconstructed_input, dim=0) + 1e-6) - torch.sqrt(torch.std(self.tensor_input, dim=0) + 1e-6))) + \
                           torch.mean(torch.abs(torch.mean(self.reconstructed_input, dim=0) - torch.mean(self.tensor_input, dim=0))))

            # Calculate supervision error between the predicted latents and target latents (two steps ahead)
            self.supervision_error = self.mean_squared_error(self.supervised_latents[:, :-1, :], self.latent_features[:, 1:, :]) + \
                self.config['distribution_regularization_weight'] * torch.sqrt(torch.mean(torch.abs(torch.sqrt(torch.std(self.supervised_latents[:, :-1, :], dim=0) + 1e-6) - torch.sqrt(torch.std(self.latent_features[:, 1:, :], dim=0) + 1e-6))) + \
                           torch.mean(torch.abs(torch.mean(self.supervised_latents[:, :-1, :], dim=0) - torch.mean(self.latent_features[:, 1:, :], dim=0)))) 

            # Calculate the combined error with different weighting factors
            self.error_combined = (
                self.config['reconstruct_weight'] * torch.sqrt(self.error_embedding_Reconstructor_alt) +
                (1 / self.config['reconstruct_weight']) * self.supervision_error
            )

            # Backpropagate the combined error gradient to update the network weights
            self.error_combined.backward(retain_graph=True)
        except RuntimeError as e:
            # Handle runtime errors during backpropagation and raise descriptive exception
            raise RuntimeError(f"Error during backprop_embedding_Reconstructor_: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during backprop_embedding_Reconstructor_: {str(e)}")

    def backprop_Synthesizer(self):
        """Backpropagation for Synthesizer network considering multiple loss components."""
        try:
            # Calculate unsupervised loss for the Synthesizer using focal_loss for generated fake data
            self.Synthesizer_unsupervised_loss = self.focal_loss(self.fake_classifier_output, torch.ones_like(self.fake_classifier_output))
            
            # Calculate unsupervised loss for the generated latents using focal_loss
            self.Synthesizer_unsupervised_loss_gen = self.focal_loss(self.fake_classifier_output_gen, torch.ones_like(self.fake_classifier_output_gen))

            # Variance Loss Calculation
            # Step 1: Calculate the standard deviation of the reconstructed and original tensors along the specified dimension
            reconstructed_std = torch.std(self.reconstructed_forecasted_input, dim=0)
            original_std = torch.std(self.tensor_input, dim=0)

            # Step 2: Add a small value (epsilon) to prevent undefined square root values
            epsilon = 1e-6
            reconstructed_std_sqrt = torch.sqrt(reconstructed_std + epsilon)
            original_std_sqrt = torch.sqrt(original_std + epsilon)

            # Step 3: Calculate the absolute difference between the square roots of the standard deviations
            variance_diff = torch.abs(reconstructed_std_sqrt - original_std_sqrt)

            # Step 4: Take the mean of the variance difference
            self.Synthesizer_variance_loss = torch.mean(variance_diff)

            # Mean Loss Calculation
            # Step 1: Calculate the mean of the reconstructed and original tensors along the specified dimension
            reconstructed_mean = torch.mean(self.reconstructed_forecasted_input, dim=0)
            original_mean = torch.mean(self.tensor_input, dim=0)

            # Step 2: Calculate the absolute difference between the means
            mean_diff = torch.abs(reconstructed_mean - original_mean)
            
            # Step 3: Take the mean of the mean difference
            self.Synthesizer_mean_loss = torch.mean(mean_diff) + 0.1 * self.mean_squared_error(self.reconstructed_forecasted_input, self.tensor_input)

            # Calculate supervision error between the predicted latents and target latents (two steps ahead)
            self.supervision_error = self.mean_squared_error(self.supervised_latents[:, :-1, :], self.latent_features[:, 1:, :]) + \
                torch.mean(torch.abs(torch.sqrt(torch.std(self.supervised_latents[:, :-1, :], dim=0) + 1e-6) - torch.sqrt(torch.std(self.latent_features[:, 1:, :], dim=0) + 1e-6))) + \
                torch.mean(torch.abs(torch.mean(self.supervised_latents[:, :-1, :], dim=0) - torch.mean(self.latent_features[:, 1:, :], dim=0))) 

            # histogram matching loss
            # histogram_loss = HybridWassersteinLoss(num_bins=10, w1_weight=0.6, w2_weight=0.4)(self.reconstructed_forecasted_input, self.tensor_input) 
            # mmd_loss_val = featurewise_mmd_loss(self.tensor_input,  self.reconstructed_forecasted_input, sigma=self.config['mmd_sigma'])

            # Calculate the overall error for the Synthesizer network with different weighting factors for each component
            self.error_Synthesizer = (
                self.Synthesizer_unsupervised_loss +
                self.Synthesizer_unsupervised_loss_gen * self.config['gamma_weight'] +
                self.Synthesizer_variance_loss * self.config['Synthesizer_loss_weight'] +
                self.Synthesizer_mean_loss * self.config['Synthesizer_loss_weight'] +
                torch.sqrt(self.supervision_error)  
                # mmd_loss_val * self.config['mmd_loss_weight']             
            ) 
            self.losses['Synthesizer'].append(self.error_Synthesizer.item())  # Log loss
            # Backpropagate the Synthesizer error gradient to update the network weights
            self.error_Synthesizer.backward(retain_graph=True)
        except RuntimeError as e:
            # Handle runtime errors during backpropagation and raise descriptive exception
            raise RuntimeError(f"Error during backprop_Synthesizer: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during backprop_Synthesizer: {str(e)}")

    def backprop_forecaster(self):
        """Backpropagation for forecaster network."""
        try:
            self.forecaster_error = self.mean_squared_error(self.supervised_latents[:, :-1, :], self.latent_features[:, 1:, :]) + \
               self.config['distribution_regularization_weight'] * torch.sqrt(torch.mean(torch.abs(torch.sqrt(torch.std(self.supervised_latents[:, :-1, :], dim=0) + 1e-6) - torch.sqrt(torch.std(self.latent_features[:, 1:, :], dim=0) + 1e-6))) + \
                torch.mean(torch.abs(torch.mean(self.supervised_latents[:, :-1, :], dim=0) - torch.mean(self.latent_features[:, 1:, :], dim=0)))) 
            
            # Log the forecaster error
            self.losses['forecaster'].append(self.forecaster_error.item())
            
            # Backpropagate the forecaster error gradient to update the network weights
            self.forecaster_error.backward(retain_graph=True)
        except RuntimeError as e:
            # Handle runtime errors during backpropagation and raise descriptive exception
            raise RuntimeError(f"Error during backprop_forecaster: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during backprop_forecaster: {str(e)}")

    def backprop_classifier(self):
        """Backpropagation for classifier network considering real and generated data losses."""
        try:
            # Calculate classification error for real data using focal_loss
            self.real_classification_error = self.focal_loss(self.real_classifier_output, torch.ones_like(self.real_classifier_output))
            
            # Calculate classification error for fake forecasted latents using focal_loss
            self.fake_classification_error = self.focal_loss(self.fake_classifier_output, torch.zeros_like(self.fake_classifier_output))
            
            # Calculate classification error for generated latents using focal_loss
            self.fake_classification_error_gen = self.focal_loss(self.fake_classifier_output_gen, torch.zeros_like(self.fake_classifier_output_gen))
            
            # Calculate overall classification error with weighting factor for generated data loss
            self.error_classifier = (
                self.real_classification_error +
                self.fake_classification_error +
                self.fake_classification_error_gen * self.config['gamma_weight']
            )
            
            # Backpropagate the classification error if the error exceeds a threshold value
            if self.error_classifier > 0.15:
                self.losses['classifier'].append(self.error_classifier.item())  # Log loss
                self.error_classifier.backward(retain_graph=True)
        except RuntimeError as e:
            # Handle runtime errors during backpropagation and raise descriptive exception
            raise RuntimeError(f"Error during backprop_classifier: {str(e)}")
        except Exception as e:
            # Handle unexpected errors and raise descriptive exception
            raise RuntimeError(f"Unexpected error during backprop_classifier: {str(e)}")

    def plot_training_losses(self):
        """Plot the tracked training losses for each network in log scale."""

        # Create the directory if it doesn't exist
        save_path = self.config['plots_storage']
        os.makedirs(save_path, exist_ok=True)
        
        # Generate the plot
        plt.figure(figsize=(12, 8))
        for key, value in self.losses.items():
            if value:  # Plot only if there are values logged
                plt.plot(value, label=f'{key} loss')

        # Set log scale for the y-axis
        plt.yscale('log')

        plt.xlabel('Training Steps')
        plt.ylabel('Loss (Log Scale)')
        plt.title('Training Losses for Different Networks (Log Scale)')
        plt.legend()
        plt.grid(True, which="both", linestyle="--", linewidth=0.5)

        # Save the plot as a file
        plot_filename = os.path.join(save_path, "training_losses_log_scale.png")
        plt.savefig(plot_filename, bbox_inches='tight')
        print(f"Plot saved to: {plot_filename}")

        # # Optionally, display the plot
        # plt.show()























