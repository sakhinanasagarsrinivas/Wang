import os
import torch
import yaml
import argparse
import logging
from typing import List, Dict, Any

# Import custom modules
import torch.optim as optim
from torch.cuda.amp import GradScaler, autocast

from dataset import create_dataloaders
from preprocessing import MoleculePreprocessor
from llm import MoleculeLLM
from encoder import DualEncoder, PredictionEncoder
from decoder import SMILESDecoder
from attention import HierarchicalMultiHeadAttention
from metrics import MoleculeMetrics
from helpers import Helpers

def load_chebi_data(
    file_path: str, 
    max_samples: int = None
) -> tuple[List[str], List[str]]:
    """
    Load ChEBI-20 dataset for molecule text-to-SMILES generation
    
    Args:
        file_path: Path to the dataset CSV
        max_samples: Optional limit on number of samples
    
    Returns:
        Tuple of (texts, smiles)
    """
    import pandas as pd
    from rdkit import Chem
    
    # Load dataset
    df = pd.read_csv(file_path)
    
    # Validate and clean data
    def validate_smiles(smiles: str) -> bool:
        try:
            mol = Chem.MolFromSmiles(smiles)
            return mol is not None
        except:
            return False
    
    # Filter valid SMILES and descriptions
    df = df[df['smiles'].apply(validate_smiles)]
    df = df[df['text'].notna() & (df['text'] != '')]
    
    # Limit samples if specified
    if max_samples:
        df = df.head(max_samples)
    
    return df['text'].tolist(), df['smiles'].tolist()

class MoleculeGenerationTrainer:
    def __init__(self, config_path: str):
        """
        Initialize training setup
        
        Args:
            config_path: Path to configuration file
        """
        # Setup logging
        logging.basicConfig(
            level=logging.INFO, 
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

        # Load configuration
        with open(config_path, 'r') as f:
            self.config: Dict[str, Any] = yaml.safe_load(f)
        
        # Set random seed
        Helpers.set_seed(self.config['training']['seed'])
        
        # Determine device
        self.device = torch.device(
            'cuda' if torch.cuda.is_available() 
            else 'cpu'
        )
        self.logger.info(f"Using device: {self.device}")

        # Initialize components
        self.preprocessor = MoleculePreprocessor(
            scaffold_k=self.config['model']['scaffold_k']
        )
        
        self.llm = MoleculeLLM(
            model_name=self.config['llm']['model_name'],
            temperature=self.config['llm']['temperature'],
            max_tokens=self.config['llm']['max_tokens']
        )

        # Vocabulary size (estimate - may need adjustment)
        self.vocab_size = 30522

        # Model components
        self.dual_encoder = DualEncoder(
            pretrained_model='bert-base-uncased',
            embedding_dim=self.config['model']['embedding_dim']
        ).to(self.device)

        self.prediction_encoder = PredictionEncoder(
            vocab_size=self.vocab_size,
            embedding_dim=self.config['model']['embedding_dim']
        ).to(self.device)

        self.cross_modal_attention = HierarchicalMultiHeadAttention(
            d_model=self.config['model']['embedding_dim'],
            num_heads=self.config['model']['num_attention_heads']
        ).to(self.device)

        self.decoder = SMILESDecoder(
            vocab_size=self.vocab_size,
            d_model=self.config['model']['embedding_dim'],
            num_layers=6,
            num_heads=self.config['model']['num_attention_heads']
        ).to(self.device)

        # Loss function
        self.criterion = torch.nn.CrossEntropyLoss(ignore_index=-100)

        # Optimizer and learning rate scheduler
        self.optimizer = optim.Adam(
            list(self.dual_encoder.parameters()) +
            list(self.prediction_encoder.parameters()) +
            list(self.cross_modal_attention.parameters()) +
            list(self.decoder.parameters()),
            lr=self.config['training']['learning_rate']
        )

        self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer, 
            mode='min', 
            factor=self.config['training']['learning_rate_decay'],
            patience=self.config['training']['lr_scheduler_patience']
        )

        # Gradient scaler for mixed precision training
        self.scaler = GradScaler()

    def prepare_data(self, texts: List[str], smiles: List[str]):
        """
        Prepare data for training
        
        Args:
            texts: List of molecule descriptions
            smiles: List of SMILES representations
        
        Returns:
            Data loaders
        """
        train_loader, val_loader, test_loader = create_dataloaders(
            texts, 
            smiles, 
            batch_size=self.config['model']['batch_size'],
            train_split=self.config['data']['train_split'],
            val_split=self.config['data']['val_split'],
            seed=self.config['training']['seed']
        )
        
        return train_loader, val_loader, test_loader
    
    def _prepare_batch(self, batch):
        """
        Prepare batch for model input
        
        Args:
            batch: Input batch from dataloader
        
        Returns:
            Prepared inputs for model
        """
        # Prepare text inputs
        text_inputs = {
            'input_ids': batch['text_input_ids'].to(self.device),
            'attention_mask': batch['text_attention_mask'].to(self.device)
        }
        
        # Prepare SMILES inputs and targets
        smiles_input = batch['smiles_input'].to(self.device)
        smiles_target = batch['smiles_target'].to(self.device)
        
        return text_inputs, smiles_input, smiles_target

    def train_epoch(self, train_loader):
        """
        Train for one epoch
        
        Args:
            train_loader: Training data loader
        
        Returns:
            Average loss for the epoch
        """
        self.dual_encoder.train()
        self.prediction_encoder.train()
        self.cross_modal_attention.train()
        self.decoder.train()

        total_loss = 0.0
        for batch in train_loader:
            # Prepare batch
            text_inputs, smiles_input, smiles_target = self._prepare_batch(batch)

            # Zero gradients
            self.optimizer.zero_grad()

            # Mixed precision training
            with autocast():
                # Forward pass
                # Encode text
                org_emb, exp_emb = self.dual_encoder(text_inputs)
                
                # Encode predictions
                pred_emb = self.prediction_encoder(smiles_input)
                
                # Cross-modal attention
                cross_modal_emb = self.cross_modal_attention(
                    org_emb, exp_emb, pred_emb
                )
                
                # Decode
                logits = self.decoder(smiles_input, cross_modal_emb)
                
                # Compute loss
                loss = self.criterion(
                    logits.view(-1, self.vocab_size), 
                    smiles_target.view(-1)
                )

            # Scale loss and backpropagate
            self.scaler.scale(loss).backward()
            self.scaler.step(self.optimizer)
            self.scaler.update()

            total_loss += loss.item()

        return total_loss / len(train_loader)

    def validate(self, val_loader):
        """
        Validate model performance
        
        Args:
            val_loader: Validation data loader
        
        Returns:
            Validation metrics
        """
        self.dual_encoder.eval()
        self.prediction_encoder.eval()
        self.cross_modal_attention.eval()
        self.decoder.eval()

        # Lists to store generated and ground truth SMILES
        all_generated_smiles = []
        all_ground_truth_smiles = []

        with torch.no_grad():
            for batch in val_loader:
                # Prepare batch
                text_inputs, _, _ = self._prepare_batch(batch)
                ground_truth_batch_smiles = batch['smiles']

                # Generate SMILES
                generated_batch_smiles = self._generate_smiles(text_inputs)
                
                all_generated_smiles.extend(generated_batch_smiles)
                all_ground_truth_smiles.extend(ground_truth_batch_smiles)

        # Compute metrics
        metrics = {
            'fingerprint_tanimoto_similarity': MoleculeMetrics.fingerprint_tanimoto_similarity(
                all_generated_smiles, 
                all_ground_truth_smiles
            ),
            'levenshtein_distance': MoleculeMetrics.levenshtein_distance(
                all_generated_smiles, 
                all_ground_truth_smiles
            ),
            'validity_score': MoleculeMetrics.validity_score(all_generated_smiles)
        }

        # Log metrics
        self.logger.info("Validation Metrics:")
        for metric, value in metrics.items():
            self.logger.info(f"{metric}: {value}")

        return metrics

    def _generate_smiles(self, text_inputs):
        """
        Generate SMILES representations for input text
        
        Args:
            text_inputs: Prepared text inputs
        
        Returns:
            List of generated SMILES
        """
        # Encode text
        org_emb, exp_emb = self.dual_encoder(text_inputs)
        
        # Generate initial prediction embedding
        pred_emb = torch.randn(
            org_emb.size(0), 
            self.config['model']['embedding_dim']
        ).to(self.device)
        
        # Cross-modal attention
        cross_modal_emb = self.cross_modal_attention(
            org_emb, exp_emb, pred_emb
        )
        
        # Decode
        generated_smiles = []
        batch_size = text_inputs['input_ids'].size(0)
        
        for i in range(batch_size):
            # Start with special token
            current_input = torch.full(
                (1, 1), 
                self.vocab_size - 1,  # Assuming last token is start token
                dtype=torch.long, 
                device=self.device
            )
            
            generated_seq = []
            max_length = 100  # Adjust as needed
            
            for _ in range(max_length):
                # Decoder forward pass
                logits = self.decoder(current_input, cross_modal_emb[i:i+1])
                
                # Sample from logits
                next_token = torch.argmax(logits[:, -1, :], dim=-1)
                
                # Append to sequence
                generated_seq.append(next_token.item())
                current_input = torch.cat([current_input, next_token.unsqueeze(0)], dim=1)
                
                # Stop if end token
                if next_token.item() == self.vocab_size - 2:  # Assuming second to last token is end token
                    break
            
            # Convert token sequence to SMILES (placeholder)
            generated_smiles.append(self._convert_tokens_to_smiles(generated_seq))
        
        return generated_smiles

    def _convert_tokens_to_smiles(self, token_sequence):
        """
        Convert token sequence to SMILES string
        
        Args:
            token_sequence: List of token indices
        
        Returns:
            SMILES string
        """
        # TODO: Implement proper token-to-SMILES conversion
        # This is a placeholder implementation
        return 'C'  # Dummy SMILES

    def train(self, train_loader, val_loader):
        """
        Full training process
        
        Args:
            train_loader: Training data loader
            val_loader: Validation data loader
        """
        best_val_loss = float('inf')
        
        for epoch in range(self.config['model']['epochs']):
            # Train for one epoch
            train_loss = self.train_epoch(train_loader)
            
            # Validate
            val_metrics = self.validate(val_loader)
            
            # Log results
            val_loss = val_metrics.get('levenshtein_distance', float('inf'))
            self.logger.info(
                f"Epoch {epoch+1}/{self.config['model']['epochs']}: "
                f"Train Loss: {train_loss:.4f}, "
                f"Val Loss: {val_loss:.4f}"
            )
            
            # Learning rate scheduling
            self.scheduler.step(val_loss)
            
            # Checkpointing
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                Helpers.save_checkpoint(
                    {
                        'dual_encoder': self.dual_encoder.state_dict(),
                        'prediction_encoder': self.prediction_encoder.state_dict(),
                        'cross_modal_attention': self.cross_modal_attention.state_dict(),
                        'decoder': self.decoder.state_dict(),
                        'optimizer': self.optimizer.state_dict()
                    },
                    filename='best_model.pth'
                )

    def evaluate(self, test_loader):
        """
        Final model evaluation
        
        Args:
            test_loader: Test data loader
        """
        # Load best model
        # Perform comprehensive evaluation
        test_metrics = self.validate(test_loader)
        
        # Log final test results
        self.logger.info("Final Test Metrics:")
        for metric, value in test_metrics.items():
            self.logger.info(f"{metric}: {value}")

def main():
    # Argument parsing
    parser = argparse.ArgumentParser(description="Molecule Generation Training")
    parser.add_argument(
        '--config', 
        default='config.yaml', 
        help='Path to config file'
    )
    parser.add_argument(
        '--dataset', 
        default='data/chebi20_dataset.csv', 
        help='Path to dataset'
    )
    parser.add_argument(
        '--max_samples', 
        type=int, 
        default=None, 
        help='Maximum number of samples to use'
    )
    args = parser.parse_args()

    # Initialize trainer
    trainer = MoleculeGenerationTrainer(args.config)
    
    # Load data
    texts, smiles = load_chebi_data(
        args.dataset, 
        max_samples=args.max_samples
    )
    
    # Prepare dataloaders
    train_loader, val_loader, test_loader = trainer.prepare_data(texts, smiles)
    
    # Train the model
    trainer.train(train_loader, val_loader)
    
    # Final evaluation
    trainer.evaluate(test_loader)

if __name__ == "__main__":
    main()