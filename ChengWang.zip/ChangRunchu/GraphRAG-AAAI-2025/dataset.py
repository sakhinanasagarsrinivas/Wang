# data/dataset.py
```python
import torch
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
import logging

class ProcessEngineeringDataset(Dataset):
    def __init__(self, 
                 data_path: str,
                 tokenizer: Any,
                 max_length: int = 512,
                 split: str = 'train'):
        """
        Initialize the dataset
        
        Args:
            data_path: Path to the data directory
            tokenizer: Tokenizer for encoding text
            max_length: Maximum sequence length
            split: One of 'train', 'val', or 'test'
        """
        self.data_path = Path(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.split = split
        
        # Load and process data
        self.data = self._load_data()
        self.processed_data = self._process_data()
        
    def _load_data(self) -> pd.DataFrame:
        """Load the dataset from file"""
        try:
            file_path = self.data_path / f"{self.split}.json"
            if not file_path.exists():
                raise FileNotFoundError(f"Data file not found: {file_path}")
                
            df = pd.read_json(file_path)
            logging.info(f"Loaded {len(df)} samples from {file_path}")
            return df
            
        except Exception as e:
            logging.error(f"Error loading data: {str(e)}")
            raise
            
    def _process_data(self) -> List[Dict[str, Any]]:
        """Process the raw data into model-ready format"""
        processed_data = []
        
        for _, row in self.data.iterrows():
            try:
                # Encode question
                question_encoding = self.tokenizer(
                    row['question'],
                    padding='max_length',
                    truncation=True,
                    max_length=self.max_length,
                    return_tensors='pt'
                )
                
                # Encode solution steps
                solution_steps = row.get('solution_steps', [])
                if isinstance(solution_steps, str):
                    solution_steps = [solution_steps]
                    
                steps_encoding = self.tokenizer(
                    solution_steps,
                    padding='max_length',
                    truncation=True,
                    max_length=self.max_length,
                    return_tensors='pt'
                )
                
                # Process tool labels
                tool_labels = row.get('tool_labels', [])
                if isinstance(tool_labels, str):
                    tool_labels = [tool_labels]
                    
                # Create sample dictionary
                sample = {
                    'question_ids': question_encoding['input_ids'].squeeze(),
                    'question_mask': question_encoding['attention_mask'].squeeze(),
                    'steps_ids': steps_encoding['input_ids'].squeeze(),
                    'steps_mask': steps_encoding['attention_mask'].squeeze(),
                    'tool_labels': torch.tensor(self._encode_tool_labels(tool_labels)),
                    'metadata': {
                        'domain': row.get('domain', 'general'),
                        'complexity': row.get('complexity', 'intermediate'),
                        'id': row.get('id', None)
                    }
                }
                
                processed_data.append(sample)
                
            except Exception as e:
                logging.warning(f"Error processing row: {str(e)}")
                continue
                
        return processed_data
        
    def _encode_tool_labels(self, tool_labels: List[str]) -> List[int]:
        """Encode tool labels to integers"""
        tool_mapping = {
            'code_generator': 0,
            'math_solver': 1,
            'knowledge_retriever': 2,
            'general': 3
        }
        
        return [tool_mapping.get(label, 3) for label in tool_labels]
        
    def __len__(self) -> int:
        return len(self.processed_data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return self.processed_data[idx]
        
    @staticmethod
    def collate_fn(batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """Custom collate function for batching"""
        return {
            'question_ids': torch.stack([x['question_ids'] for x in batch]),
            'question_mask': torch.stack([x['question_mask'] for x in batch]),
            'steps_ids': torch.stack([x['steps_ids'] for x in batch]),
            'steps_mask': torch.stack([x['steps_mask'] for x in batch]),
            'tool_labels': torch.stack([x['tool_labels'] for x in batch]),
            'metadata': [x['metadata'] for x in batch]
        }
        
class ProcessEngineeringDataModule:
    def __init__(self,
                 data_dir: str,
                 tokenizer: Any,
                 batch_size: int = 32,
                 max_length: int = 512,
                 num_workers: int = 4):
        """
        Initialize the data module
        
        Args:
            data_dir: Directory containing the data files
            tokenizer: Tokenizer for encoding text
            batch_size: Batch size for dataloaders
            max_length: Maximum sequence length
            num_workers: Number of workers for dataloaders
        """
        self.data_dir = data_dir
        self.tokenizer = tokenizer
        self.batch_size = batch_size
        self.max_length = max_length
        self.num_workers = num_workers
        
        self.train_dataset = None
        self.val_dataset = None
        self.test_dataset = None
        
    def setup(self, stage: Optional[str] = None):
        """Setup datasets for training, validation and testing"""
        if stage == 'fit' or stage is None:
            self.train_dataset = ProcessEngineeringDataset(
                self.data_dir,
                self.tokenizer,
                self.max_length,
                'train'
            )
            
            self.val_dataset = ProcessEngineeringDataset(
                self.data_dir,
                self.tokenizer,
                self.max_length,
                'val'
            )
            
        if stage == 'test' or stage is None:
            self.test_dataset = ProcessEngineeringDataset(
                self.data_dir,
                self.tokenizer,
                self.max_length,
                'test'
            )
            
    def train_dataloader(self) -> DataLoader:
        """Get training dataloader"""
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            collate_fn=ProcessEngineeringDataset.collate_fn
        )
        
    def val_dataloader(self) -> DataLoader:
        """Get validation dataloader"""
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            collate_fn=ProcessEngineeringDataset.collate_fn
        )
        
    def test_dataloader(self) -> DataLoader:
        """Get test dataloader"""
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            collate_fn=ProcessEngineeringDataset.collate_fn
        )
```

# models/meta_agent.py
```python
from typing import Dict, Any, List, Optional
import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer
import logging
from pathlib import Path
import json

class MetaAgent(nn.Module):
    def __init__(self,
                 model_name: str = "meta-llama/Llama-2-7b-chat-hf",
                 device: str = "cuda" if torch.cuda.is_available() else "cpu"):
        """
        Initialize the Meta Agent
        
        Args:
            model_name: Name or path of the pre-trained model
            device: Device to run the model on
        """
        super().__init__()
        self.model_name = model_name
        self.device = device
        
        # Initialize base model and tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.base_model = AutoModel.from_pretrained(model_name)
        
        # Move model to device
        self.base_model.to(device)
        
        # Additional layers for meta-agent specific tasks
        self.action_predictor = nn.Linear(
            self.base_model.config.hidden_size,
            4  # Number of action types
        )
        
        self.tool_selector = nn.Linear(
            self.base_model.config.hidden_size,
            3  # Number of expert models
        )
        
        # Error handling components
        self.error_detector = nn.Linear(
            self.base_model.config.hidden_size,
            1  # Binary classification
        )
        
        self.solution_validator = nn.Linear(
            self.base_model.config.hidden_size,
            1  # Binary classification
        )
        
    def forward(self,
                input_ids: torch.Tensor,
                attention_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Forward pass of the meta agent"""
        # Get base model outputs
        outputs = self.base_model(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        
        # Get sequence representation (CLS token)
        sequence_output = outputs.last_hidden_state[:, 0, :]
        
        # Predict action and tool
        action_logits = self.action_predictor(sequence_output)
        tool_logits = self.tool_selector(sequence_output)
        
        # Error detection and solution validation
        error_prob = torch.sigmoid(self.error_detector(sequence_output))
        solution_valid_prob = torch.sigmoid(self.solution_validator(sequence_output))
        
        return {
            'action_logits': action_logits,
            'tool_logits': tool_logits,
            'error_prob': error_prob,
            'solution_valid_prob': solution_valid_prob
        }
        
    def orchestrate(self, 
                   query: str,
                   solution_history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Orchestrate the problem-solving process
        
        Args:
            query: The input query
            solution_history: History of previous solutions
            
        Returns:
            Dict containing next action and selected tool
        """
        try:
            # Prepare input
            input_text = self._prepare_input(query, solution_history)
            
            # Tokenize
            inputs = self.tokenizer(
                input_text,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=512
            ).to(self.device)
            
            # Get model outputs
            with torch.no_grad():
                outputs = self.forward(**inputs)
                
            # Get predictions
            action_probs = torch.softmax(outputs['action_logits'], dim=-1)
            tool_probs = torch.softmax(outputs['tool_logits'], dim=-1)
            
            # Select action and tool
            action_idx = action_probs.argmax(dim=-1).item()
            tool_idx = tool_probs.argmax(dim=-1).item()
            
            # Check for errors
            if outputs['error_prob'].item() > 0.5:
                return self._handle_error(query, solution_history)
                
            return {
                'action': self._get_action_type(action_idx),
                'tool': self._get_tool_type(tool_idx),
                'confidence': {
                    'action': action_probs.max().item(),
                    'tool': tool_probs.max().item(),
                    'solution_valid': outputs['solution_valid_prob'].item()
                }
            }
            
        except Exception as e:
            logging.error(f"Error in orchestration: {str(e)}")
            return {
                'error': str(e),
                'action': 'error_handling',
                'tool': 'general_expert'
            }
            
    def _prepare_input(self, 
                      query: str,
                      solution_history: List[Dict[str, Any]]) -> str:
        """Prepare input text for the model"""
        input_text = f"Query: {query}\n\n"
        
        if solution_history:
            input_text += "Solution History:\n"
            for step in solution_history:
                input_text += f"Step: {step.get('action', '')}\n"
                input_text += f"Result: {step.get('result', '')}\n\n"
                
        return input_text
        
    def _handle_error(self,
                     query: str,
                     solution_history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Handle detected errors in the solution process"""
        # Analyze error
        error_step = self._identify_error_step(solution_history)
        
        return {
            'action': 'error_correction',
            'tool': 'error_handler',
            'error_step': error_step,
            'recommendation': self._generate_error_recommendation(error_step)
        }
        
    def _identify_error_step(self, 
                           solution_history: List[Dict[str, Any]]) -> Optional[int]:
        """Identify the step where error occurred"""
        for i, step in enumerate(solution_history):
            if 'error' in step or step.get('status') == 'error':
                return i
        return None
        
    def _generate_error_recommendation(self, 
                                     error_step: Optional[int]) -> str:
        """Generate recommendation for error correction"""
        if error_step is None:
            return "General solution refinement recommended"
        return f"Revise step {error_step + 1} and its dependencies"
        
    @staticmethod
    def _get_action_type(idx: int) -> str:
        """Convert action index to action type"""
        action_types = {
            0: 'calculation',
            1: 'retrieval',
            2: 'generation',
            3: 'analysis'
        }
        return action_types.get(idx, 'analysis')
        
    @staticmethod
    def _get_tool_type(idx: int) -> str:
        """Convert tool index to tool type"""
        tool_types = {
            0: 'math_expert',
            1: 'code_expert',
            2: 'knowledge_expert'
        }
        return tool_types.get(idx, 'general_expert')
        
    def save_checkpoint(self, path: str):
        """Save model checkpoint"""
        checkpoint = {
            'model_state_dict': self.state_dict(),
            'model_name': self.model_name,
            'config': {
                'hidden_size': self.base_model.config.hidden_size,
                'num_action_types': self.action_predictor.out_features,
                'num_tool_types': self.tool_selector.out_features
            },
            'tokenizer_config': self.tokenizer.save_pretrained(str(Path(path).parent / 'tokenizer'))
        }
        
        try:
            torch.save(checkpoint, path)
            logging.info(f"Successfully saved checkpoint to {path}")
        except Exception as e:
            logging.error(f"Error saving checkpoint: {str(e)}")
            raise
            
    @classmethod
    def load_checkpoint(cls, path: str, device: Optional[str] = None) -> 'MetaAgent':
        """
        Load model from checkpoint
        
        Args:
            path: Path to checkpoint file
            device: Device to load model on (defaults to CUDA if available)
            
        Returns:
            Loaded MetaAgent instance
        """
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
            
        try:
            # Load checkpoint
            checkpoint = torch.load(path, map_location=device)
            
            # Create new instance
            model = cls(
                model_name=checkpoint['model_name'],
                device=device
            )
            
            # Load state dict
            model.load_state_dict(checkpoint['model_state_dict'])
            
            # Load tokenizer
            tokenizer_path = str(Path(path).parent / 'tokenizer')
            if Path(tokenizer_path).exists():
                model.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
                
            logging.info(f"Successfully loaded checkpoint from {path}")
            return model
            
        except Exception as e:
            logging.error(f"Error loading checkpoint: {str(e)}")
            raise
            
    def train_step(self, 
                  batch: Dict[str, torch.Tensor],
                  optimizer: torch.optim.Optimizer) -> Dict[str, float]:
        """
        Perform a single training step
        
        Args:
            batch: Batch of training data
            optimizer: Optimizer instance
            
        Returns:
            Dict containing loss values
        """
        self.train()
        optimizer.zero_grad()
        
        try:
            # Forward pass
            outputs = self.forward(
                input_ids=batch['question_ids'].to(self.device),
                attention_mask=batch['question_mask'].to(self.device)
            )
            
            # Calculate losses
            action_loss = nn.CrossEntropyLoss()(
                outputs['action_logits'],
                batch['action_labels'].to(self.device)
            )
            
            tool_loss = nn.CrossEntropyLoss()(
                outputs['tool_logits'],
                batch['tool_labels'].to(self.device)
            )
            
            error_loss = nn.BCELoss()(
                outputs['error_prob'].squeeze(),
                batch['error_labels'].to(self.device).float()
            )
            
            solution_loss = nn.BCELoss()(
                outputs['solution_valid_prob'].squeeze(),
                batch['solution_valid_labels'].to(self.device).float()
            )
            
            # Combined loss
            total_loss = action_loss + tool_loss + error_loss + solution_loss
            
            # Backward pass
            total_loss.backward()
            optimizer.step()
            
            return {
                'total_loss': total_loss.item(),
                'action_loss': action_loss.item(),
                'tool_loss': tool_loss.item(),
                'error_loss': error_loss.item(),
                'solution_loss': solution_loss.item()
            }
            
        except Exception as e:
            logging.error(f"Error in training step: {str(e)}")
            raise
            
    @torch.no_grad()
    def validate_step(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """
        Perform a single validation step
        
        Args:
            batch: Batch of validation data
            
        Returns:
            Dict containing validation metrics
        """
        self.eval()
        
        try:
            # Forward pass
            outputs = self.forward(
                input_ids=batch['question_ids'].to(self.device),
                attention_mask=batch['question_mask'].to(self.device)
            )
            
            # Calculate metrics
            action_preds = torch.argmax(outputs['action_logits'], dim=-1)
            tool_preds = torch.argmax(outputs['tool_logits'], dim=-1)
            
            action_acc = (action_preds == batch['action_labels'].to(self.device)).float().mean()
            tool_acc = (tool_preds == batch['tool_labels'].to(self.device)).float().mean()
            
            error_preds = (outputs['error_prob'] > 0.5).float()
            error_acc = (error_preds.squeeze() == batch['error_labels'].to(self.device)).float().mean()
            
            solution_preds = (outputs['solution_valid_prob'] > 0.5).float()
            solution_acc = (solution_preds.squeeze() == batch['solution_valid_labels'].to(self.device)).float().mean()
            
            return {
                'action_accuracy': action_acc.item(),
                'tool_accuracy': tool_acc.item(),
                'error_accuracy': error_acc.item(),
                'solution_accuracy': solution_acc.item()
            }
            
        except Exception as e:
            logging.error(f"Error in validation step: {str(e)}")
            raise
            
    def prepare_batch(self, batch: Dict[str, Any]) -> Dict[str, torch.Tensor]:
        """
        Prepare a batch for training/validation
        
        Args:
            batch: Raw batch data
            
        Returns:
            Processed batch with tensors
        """
        try:
            return {
                'question_ids': batch['question_ids'].to(self.device),
                'question_mask': batch['question_mask'].to(self.device),
                'action_labels': batch['action_labels'].to(self.device),
                'tool_labels': batch['tool_labels'].to(self.device),
                'error_labels': batch['error_labels'].to(self.device),
                'solution_valid_labels': batch['solution_valid_labels'].to(self.device)
            }
        except Exception as e:
            logging.error(f"Error preparing batch: {str(e)}")
            raise
