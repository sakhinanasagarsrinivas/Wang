import warnings
warnings.filterwarnings("ignore")

#################################################################################

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
from torch_geometric.data import Batch
from torch_geometric.data import Data
from torch_geometric.utils import to_dense_adj
from tqdm import tqdm
import numpy as np
from layers import *
from preprocessing import *
import argparse
import configparser

##################################################################################
############################################## Load Data
##################################################################################

#*********************#
DATASET = 'SWaT'  
DEBUG = 'False'   
DEVICE = 'cuda:0'
MODEL = 'MGSL'
#*********************#

#get configuration
config_file = '{}.conf'.format(DATASET)
#print('Read configuration file: %s' % (config_file))
config = configparser.ConfigParser()
config.read(config_file)

args = argparse.ArgumentParser(description='arguments')
args.add_argument('--dataset', default=DATASET, type=str)
args.add_argument('--device', default=DEVICE, type=str, help='indices of GPUs')
args.add_argument('--seed', default=config['train']['seed'], type=int)
args.add_argument('--batch_size', default=config['train']['batch_size'], type=int)
args.add_argument('--epochs', default=config['train']['epochs'], type=int)
args.add_argument('--column_wise', default=config['data']['column_wise'], type=eval)
args.add_argument('--val_ratio', default=config['data']['val_ratio'], type=float)
args.add_argument('--test_ratio', default=config['data']['test_ratio'], type=float)
args.add_argument('--lag', default=config['data']['lag'], type=int)
args.add_argument('--horizon', default=config['data']['horizon'], type=int)
args.add_argument('--num_nodes', default=config['data']['num_nodes'], type=int)
args.add_argument('--num_hyperedges', default=config['data']['num_hyperedges'], type=int)
args.add_argument('--normalizer', default=config['data']['normalizer'], type=str)
args.add_argument('--embed_dim', default=config['model']['embed_dim'], type=int)
args.add_argument('--input_dim', default=config['model']['input_dim'], type=int)
args.add_argument('--output_dim', default=config['model']['output_dim'], type=int)
args.add_argument('--single', default=config['model']['single'], type=eval)
args.add_argument('--forecast_stamps', default=config['model']['forecast_stamps'], type=eval)
args.add_argument('--model', default=MODEL, type=str)
args.add_argument('--debug', default=DEBUG, type=eval)
args.add_argument('--log_dir', default='./', type=str)
args.add_argument('--lr_init', default=config['train']['lr_init'], type=float)
args.add_argument('--lr_decay', default=config['train']['lr_decay'], type=eval)
args.add_argument('--lr_decay_rate', default=config['train']['lr_decay_rate'], type=float)
args.add_argument('--lr_decay_step', default=config['train']['lr_decay_step'], type=str)
#test
args.add_argument('--mae_thresh', default=config['test']['mae_thresh'], type=eval)
args.add_argument('--mape_thresh', default=config['test']['mape_thresh'], type=float)

args = args.parse_args()

init_seed(args.seed)
if torch.cuda.is_available():
    torch.cuda.set_device(int(args.device[5]))
else:
    args.device = 'cpu'

##################################################################################
########################################## Split dataset
##################################################################################

train_loader, val_loader, test_loader, scaler  = get_dataloader(args, normalizer = args.normalizer, tod=False, dow=False, weather=False, single=args.single)

##################################################################################
########################################### Model
###################################################################################

class Encoder(torch.nn.Module):
    def __init__(self, node_num, hyperedge_num, embed_dim):
        super(Encoder, self).__init__()

        self.hypernode_num = node_num
        self.hyperedge_num = hyperedge_num
        self.embed_dim = embed_dim

        self.fc = FeedForward(args.input_dim, self.embed_dim)

        # Graph Structure Learning
        self.node_embeddings = nn.Parameter(torch.randn(self.hypernode_num, self.embed_dim), requires_grad=True)
        self.hyperedge_embeddings = nn.Parameter(torch.randn(self.hyperedge_num, self.embed_dim), requires_grad=True)

        self.num_heads = 2
        self.hypergraph_encoder = STransformer(embed_dim=self.embed_dim, num_heads=self.num_heads, forward_expansion=4, dropout_rate=0, device=args.device)

        self.missing_scheme = 'la_point'

        # Missing Scheme
        if self.missing_scheme == 'la_block':
            self.missing = MissingValues(p_fault=0.0015, p_noise=1, SEED = args.seed)  # Missing data : 1-p_noise
        elif self.missing_scheme == 'la_point':
            self.missing = MissingValues(p_fault=0., p_noise=1, SEED = args.seed) # Missing data : 1-p_noise

        # Output Layer
        self.f_prior = nn.Linear(self.embed_dim, self.embed_dim)
        self.f_learn = nn.Linear(self.embed_dim, self.embed_dim)
        self.end_conv = nn.Conv2d(args.horizon , args.horizon , kernel_size=(1, self.embed_dim), bias=True).to(args.device)
        self.output_layer_gaussian_nll = nn.Linear(1, 2) # mean, var of gaussian distribution

    def forward(self, data):

        #*******************************************************************#
        #**************************   Missing Data  ************************#
        batch_data = Batch.from_data_list([Data(x=x.unsqueeze(0)) for x in data])
        mask = self.missing(batch_data.x)
        mask = torch.from_numpy(mask).to(args.device)
        # print('Missing Data(%):',  1 - (torch.count_nonzero(mask) / torch.count_nonzero(batch_data.x)))
        input_x = self.fc(torch.mul(batch_data.x, mask))
        #*******************************************************************#
         
        #*******************************************************************#
        #*********************** Graph Structure Learning ******************#
        node_embeddings = self.node_embeddings.to(args.device)
        hyperedge_embeddings = self.hyperedge_embeddings.to(args.device)
        learned_graph = torch.mm(node_embeddings, hyperedge_embeddings.transpose(1, 0))
        node_norm = torch.norm(node_embeddings, p=2, dim=1, keepdim=True)
        hyperedge_norm = torch.norm(hyperedge_embeddings, p=2, dim=1, keepdim=True)
        norm = torch.mm(node_norm, hyperedge_norm.transpose(1, 0))
        learned_graph = learned_graph / norm
        learned_graph = (learned_graph + 1) / 2.
        learned_graph = torch.stack([learned_graph, 1-learned_graph], dim=-1)
        # make the adj sparse
        adj = gumbel_softmax(learned_graph, tau=0.01, hard=True)
        adj_learn = adj[:, :, 0].clone().clone().reshape(self.hypernode_num, -1)
        hyperedge_index, _ = dense_to_sparse(adj_learn, self.hypernode_num, self.hyperedge_num, args.batch_size)

        h_learn = self.hypergraph_encoder(input_x.permute(0,2,1,3), input_x.permute(0,2,1,3), input_x.permute(0,2,1,3), hyperedge_index)
        #*******************************************************************#

        #*******************************************************************#
        #************************** Gating Mechanism   *********************#
        g = torch.sigmoid(self.f_prior(input_x) + self.f_learn(h_learn))
        h = g * input_x + (1 - g) * h_learn
        #*******************************************************************#

        #*******************************************************************#
        #**************************** Output  ******************************#
        output = self.end_conv((h)) 
        output = output.reshape(-1, args.forecast_stamps, self.hypernode_num, args.output_dim)
        output = output.permute(0, 1, 2, 3)
        #*******************************************************************#       

        #*******************************************************************#
        #******************* Uncertainty estimation ************************#
        output = output.unsqueeze(-1)
        output = self.output_layer_gaussian_nll(output)  

        return output

model = Encoder(args.num_nodes, args.num_hyperedges, args.embed_dim).to(args.device)

#########################################################################

#########################################################################
########################################## Parameter Count
#########################################################################

from prettytable import PrettyTable

def count_parameters(model):
    table = PrettyTable(["Modules", "Parameters"])
    total_params = 0
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad: continue
        params = parameter.numel()
        table.add_row([name, params])
        total_params+=params
    print(table)
    print(f"Total Trainable Params: {total_params}")
    return total_params
    
count_parameters(model)

#######################################################################
################################################### Training
#######################################################################

#config log path
current_time = datetime.now().strftime('%Y%m%d%H%M%S')
current_dir = os.path.dirname(os.path.realpath(__file__))
log_dir = os.path.join(current_dir,'experiments', args.dataset, current_time)
args.log_dir = log_dir

if os.path.isdir(args.log_dir) == False and not args.debug:
    os.makedirs(args.log_dir, exist_ok=True)
logger = get_logger(args.log_dir, name=args.model, debug=args.debug)
logger.info('Experiment log path in: {}'.format(args.log_dir))

# loss function
criterion = nn.MSELoss()
mae = nn.L1Loss()

# optimizer
optimizer = torch.optim.Adam(params=model.parameters(), lr=args.lr_init, eps=1.0e-8,weight_decay=0, amsgrad=False)
#learning rate decay
lr_scheduler = None
if args.lr_decay:
    print('Applying learning rate decay.')
    lr_decay_steps = [int(i) for i in list(args.lr_decay_step.split(','))]
    lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer=optimizer, milestones=lr_decay_steps, gamma=args.lr_decay_rate)

for epoch in range(args.epochs):

    epoch_rmse = 0
    epoch_mae = 0
    epoch_mape = 0

    for batch_idx, (data, target) in enumerate(tqdm(train_loader)):  

        data = data.to(args.device)
        output = model(data) 

        var = torch.abs(output[:,:,:,:,1]) # variance
        mean = output[:,:,:,:, 0] # mean 
        loss = gaussian_nll_loss(scaler.inverse_transform(mean).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float(), scaler.inverse_transform(var).to(args.device).float())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_rmse += torch.sqrt(criterion(scaler.inverse_transform(output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float())) 
        epoch_mae += mae(scaler.inverse_transform(output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float())
        epoch_mape += MAPE_torch(scaler.inverse_transform(output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float(), mask_value=0.)

    epoch_rmse = epoch_rmse / len(train_loader)
    epoch_mae = epoch_mae / len(train_loader)
    epoch_mape = epoch_mape / len(train_loader)

    with torch.no_grad():

        epoch_val_rmse = 0
        epoch_val_mae = 0
        epoch_val_mape = 0
        
        for batch_idx, (data, target) in enumerate(tqdm(val_loader)): 
            data = data.to(args.device)

            val_output = model(data) 
            var = torch.abs(val_output[:,:,:,:,1]) # variance
            mean = val_output[:,:,:,:, 0] # mean 
            val_loss = gaussian_nll_loss(scaler.inverse_transform(val_output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float(), scaler.inverse_transform(var).to(args.device).float())
            
            #learning rate decay
            if args.lr_decay:
                lr_scheduler.step()

            epoch_val_rmse += torch.sqrt(criterion(scaler.inverse_transform(val_output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float()))
            epoch_val_mae += mae(scaler.inverse_transform(val_output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float())
            epoch_val_mape += MAPE_torch(scaler.inverse_transform(val_output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float(), mask_value=0.)

        epoch_val_rmse = epoch_val_rmse / len(val_loader)
        epoch_val_mae = epoch_val_mae / len(val_loader)
        epoch_val_mape = epoch_val_mape / len(val_loader)

    with torch.no_grad():

        epoch_test_rmse = 0
        epoch_test_mae = 0
        epoch_test_mape = 0

        for batch_idx, (data, target) in enumerate(tqdm(test_loader)):

            data = data.to(args.device)

            test_output = model(data)

            epoch_test_rmse += torch.sqrt(criterion(scaler.inverse_transform(test_output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float()))
            epoch_test_mae += mae(scaler.inverse_transform(test_output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float())
            epoch_test_mape += torch.nan_to_num(MAPE_torch(scaler.inverse_transform(test_output[:,:,:,:, 0]).to(args.device).float(), scaler.inverse_transform(target).to(args.device).float(), mask_value=0.))
            
        epoch_test_rmse =  epoch_test_rmse / len(test_loader)
        epoch_test_mae = epoch_test_mae / len(test_loader)
        epoch_test_mape = epoch_test_mape / len(test_loader)

    logger.info('**********Epoch {}: test_rmse: {:.6f}, test_mae: {:.6f}, test_mape: {:.6f}'.format(epoch + 1, epoch_test_rmse, epoch_test_mae, epoch_test_mape*100))    

#########################################################################################################################

############################################################
################################ Line Plots
############################################################

sensor_index = 12
batch_no = 10

import itertools
import matplotlib.pyplot as plt
import numpy as np

predictions = []
ground_truth = []
uncertainity = []

for batch_idx, (data, target) in enumerate(tqdm(test_loader)):
    
    if batch_idx <= batch_no:  

        model.eval()

        data = data.to(args.device)
        test_output = model(data)

        predictions.append(scaler.inverse_transform(test_output[:,:,:,:, 0]).detach().cpu().numpy()[:, 0, sensor_index,:].reshape(-1).tolist())
        ground_truth.append(scaler.inverse_transform(target[:,:,:,0].unsqueeze(-1)).detach().cpu().numpy()[:, 0, sensor_index,:].reshape(-1).tolist())
        uncertainity.append(scaler.inverse_transform(test_output[:,:,:,:, 1]).detach().cpu().numpy()[:, 0, sensor_index,:].reshape(-1).tolist())    

predictions = np.array(predictions).reshape(-1)
ground_truth = np.array(ground_truth).reshape(-1)
uncertainity = np.array(uncertainity).reshape(-1)

x = np.arange(0,predictions.shape[0],1)
uncertainity_lower = predictions - np.sqrt(uncertainity)/2
uncertainity_upper = predictions + np.sqrt(uncertainity)/2

fig, ax = plt.subplots()
ax.plot(x, predictions, color = 'black', label = 'Predictions')
plt.fill_between(x, uncertainity_lower, uncertainity_upper, color='blue', alpha=0.5)
ax.plot(ground_truth, color = 'red', label = 'Ground Truth')
ax.legend(loc = 'upper left')
ax.set_ylim([0, 800])
plt.show()

np.save('./{}_true.npy'.format(args.dataset), ground_truth)
np.save('./{}_pred.npy'.format(args.dataset), predictions)
np.save('./{}_uncertainity.npy'.format(args.dataset), uncertainity)

#########################################################################################################################
