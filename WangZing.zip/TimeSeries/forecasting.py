
import os
import json
import time 
import torch
import math
import logging
import numpy as np
import seaborn as sns
from utils import *
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from torch.utils.data import random_split
from torch.utils.data import Dataset, DataLoader
from typing import Dict, Union, List, Tuple
from missingness import * 


import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set seeds for reproducibility
def set_seed(seed=42):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# Call the seed initialization function
set_seed(12)

class TorchOneHotEncoder:
    """
    Optimized PyTorch implementation of one-hot encoding with batched operations
    and vectorized processing.
    """
    def __init__(self, sparse: bool = False, device: torch.device = torch.device("cpu")):
        self.sparse = sparse
        self.category_mappings = {}
        self.feature_names = []
        self.fitted = False
        self.device = device
        self._category_offsets = None
        self._total_categories = 0

    def fit(self, data: Union[torch.Tensor, np.ndarray], feature_names: List[str] = None) -> 'TorchOneHotEncoder':
        """
        Learns categories using vectorized operations.
        """
        if isinstance(data, np.ndarray):
            data = torch.from_numpy(data)
        data = data.to(self.device)

        if feature_names is None:
            feature_names = [f"feature_{i}" for i in range(data.shape[1])]
        self.feature_names = feature_names

        # Process all features at once
        unique_values_list = [torch.unique(data[:, i], sorted=True) for i in range(data.shape[1])]
        
        # Store category mappings and calculate offsets
        offset = 0
        self._category_offsets = []
        
        for i, unique_values in enumerate(unique_values_list):
            self.category_mappings[feature_names[i]] = unique_values
            self._category_offsets.append(offset)
            offset += len(unique_values)
        
        self._total_categories = offset
        self.fitted = True
        return self

    def transform(self, data: Union[torch.Tensor, np.ndarray]) -> torch.Tensor:
        """
        Vectorized transform using batch operations.
        """
        if not self.fitted:
            raise ValueError("Encoder must be fitted before transform")

        if isinstance(data, np.ndarray):
            data = torch.from_numpy(data)
        data = data.to(self.device)

        batch_size = data.shape[0]
        result = torch.zeros((batch_size, self._total_categories), device=self.device)

        # Process all features in parallel using vectorized operations
        for i, feature_name in enumerate(self.feature_names):
            unique_values = self.category_mappings[feature_name]
            offset = self._category_offsets[i]
            
            # Use bucketization for faster category matching
            indices = torch.bucketize(data[:, i], unique_values)
            valid_mask = (indices < len(unique_values))
            
            # Compute global indices for the entire batch at once
            global_indices = offset + indices[valid_mask]
            batch_indices = torch.nonzero(valid_mask, as_tuple=True)[0]
            
            # Set values using advanced indexing
            result[batch_indices, global_indices] = 1

        return result if not self.sparse else result.to_sparse()

    def inverse_transform(self, encoded_data: torch.Tensor) -> torch.Tensor:
        """
        Optimized inverse transform using pre-computed offsets.
        """
        if not self.fitted:
            raise ValueError("Encoder must be fitted before inverse_transform")

        if self.sparse and encoded_data.is_sparse:
            encoded_data = encoded_data.to_dense()

        batch_size = encoded_data.shape[0]
        n_features = len(self.feature_names)
        result = torch.zeros((batch_size, n_features), device=self.device)

        # Process all features in parallel
        for i, feature_name in enumerate(self.feature_names):
            unique_values = self.category_mappings[feature_name]
            start_idx = self._category_offsets[i]
            end_idx = start_idx + len(unique_values)
            
            # Extract relevant slice and find active positions
            feature_encoded = encoded_data[:, start_idx:end_idx]
            indices = torch.argmax(feature_encoded, dim=1)
            
            # Map back to original values in one operation
            result[:, i] = unique_values[indices]

        return result

    def get_feature_ranges(self) -> List[Tuple[int, int, int]]:
        """
        Get feature ranges using pre-computed offsets.
        """
        return [(offset, len(self.category_mappings[name]), len(self.category_mappings[name]))
                for offset, name in zip(self._category_offsets, self.feature_names)]


def create_nested_dirs(base_dir, *subdirs):
    path = base_dir
    for subdir in subdirs:
        path = os.path.join(path, subdir)
        os.makedirs(path, exist_ok=True)
    return path

def create_output_directory(dataset_name, config):
    """
    Creates the directory structure for saving results if it does not exist.
    Args:
        dataset_name (str): Name of the dataset (e.g., 'energy' or 'stock').
    Returns:
        str: Path to the forecasting directory where results will be stored.
    """
    # Define the base output directory
    base_output_dir = './output'

    # Create the base output directory if it doesn't exist
    if not os.path.exists(base_output_dir):
        os.makedirs(base_output_dir)

    # Create the dataset-specific directory
    dataset_dir = os.path.join(base_output_dir, dataset_name)
    if not os.path.exists(dataset_dir):
        os.makedirs(dataset_dir)

    # Create the forecasting-specific directory
    directory_path = os.path.join(dataset_dir, config['task'])
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)

    return directory_path

def save_checkpoint(model, optimizer, epoch, loss, dataset_name, config, filename='checkpoint.pth'):
    """
    Save model and optimizer state as a checkpoint in the forecasting directory.
    Args:
        model (nn.Module): The model to save.
        optimizer (Optimizer): The optimizer to save.
        epoch (int): Current training epoch.
        loss (float): Loss value at the checkpoint.
        dataset_name (str): Name of the dataset (e.g., 'energy' or 'stock', 'ETTh1', 'ETTh2', 'ETTm1', 'ETTm2').
        filename (str): Name of the checkpoint file.
    """
    # Create output directory structure
    checkpoint_dir = create_output_directory(dataset_name, config)

    # Save checkpoint
    filepath = os.path.join(checkpoint_dir, filename)
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'loss': loss
    }, filepath)
    print(f"Checkpoint saved: {filepath}")


def load_checkpoint(model, optimizer, dataset_name,  config, filename='checkpoint.pth'):
    """
    Load model and optimizer state from a checkpoint in the forecasting directory.
    Args:
        model (nn.Module): The model to load the state into.
        optimizer (Optimizer): The optimizer to load the state into.
        dataset_name (str): Name of the dataset (e.g., 'energy' or 'stock' or 'ETTh1', 'ETTh2', 'ETTm1', 'ETTm2').
        filename (str): Name of the checkpoint file.
    Returns:
        tuple: (epoch, loss) from the checkpoint.
    """
    # Get checkpoint directory path
    checkpoint_dir = create_output_directory(dataset_name, config)

    # Load checkpoint
    filepath = os.path.join(checkpoint_dir, filename)
    if os.path.exists(filepath):
        checkpoint = torch.load(filepath)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        print(f"Checkpoint loaded: {filepath} (Epoch: {checkpoint['epoch']}, Loss: {checkpoint['loss']:.4f})")
        return checkpoint['epoch'], checkpoint['loss']
    else:
        raise FileNotFoundError(f"Checkpoint not found at: {filepath}")    

# Load checkpoint when isTrain is False
def load_model_and_optimizer(model, config):
    """
    Loads the model and optimizer states from a checkpoint if available.

    Args:
        model (nn.Module): The model to load the state into.
        config (dict): Configuration dictionary containing training parameters.
    """
    dataset_name = config['dataset_type']  # Get dataset name from config
    optimizer = optim.Adam(model.parameters(), lr=config['learning_rate'])
    start_epoch = 0

    try:
        # Use the updated directory structure
        start_epoch, last_loss = load_checkpoint(model, optimizer, dataset_name, config)
        print(f"Checkpoint loaded. Resuming from Epoch {start_epoch}, Last Validation Loss: {last_loss:.4f}")
        return start_epoch, last_loss, optimizer
    except FileNotFoundError:
        raise RuntimeError("No checkpoint found.")          


def load_time_series_data(config):
    """Loads and preprocesses real-world time-series datasets based on the specified configuration.
    """
    
    # Validate configuration attributes
    try:
        dataset_type = config['dataset_type']
        sequence_length = config['seq_len']
    except KeyError as e:
        raise AttributeError(f"Missing required attribute in config: {str(e)}")

    # Validate types of configuration attributes
    if not isinstance(dataset_type, str):
        raise TypeError("dataset_type must be a string.")

    if not isinstance(sequence_length, int) or sequence_length <= 0:
        raise ValueError("seq_len must be a positive integer.")

    # Validate dataset_type value
    if dataset_type not in ['energy', 'stock']:
        raise ValueError("dataset_type must be either 'energy' or 'stock'.")

    # Define base directory and file path
    base_directory = dirname(dirname(abspath(__file__)))
    file_name = f"{dataset_type}_data.csv"
    data_path = os.path.join(base_directory, 'Synthetic', 'data', file_name)

    # Check if data file exists
    if not exists(data_path):
        raise FileNotFoundError(f"Data file {data_path} not found.")

    # Load raw data
    try:
        raw_data = np.loadtxt(data_path, delimiter=",", skiprows=1)
        print(raw_data.shape)
        raw_data = remove_outlier_rows(raw_data, threshold=5.0)
        print(raw_data.shape)
    except Exception as e:
        raise IOError(f"Error loading data from {data_path}: {str(e)}")

    # Validate loaded data
    if raw_data.size == 0:
        raise ValueError("Loaded dataset is empty.")
    if np.isnan(raw_data).any() or np.isinf(raw_data).any():
        raise ValueError("Loaded dataset contains NaN or infinite values.")

    # Create a DataFrame for column classification
    df = pd.DataFrame(raw_data, columns=[f"Column_{i}" for i in range(raw_data.shape[1])])
    discrete_columns, continuous_columns = classify_columns(df)

    if len(discrete_columns) > 0:

        # Reorder the DataFrame with continuous columns first, then discrete columns
        ordered_columns = continuous_columns + discrete_columns
        df = df[ordered_columns]

        # Create encoder
        encoder = TorchOneHotEncoder(device=device)

        # Convert only discrete columns to tensor
        discrete_data = torch.tensor(df[discrete_columns].to_numpy(), dtype=torch.float32).to(device)
        
        # Fit and transform only the discrete columns
        encoder.fit(discrete_data)
        encoded_discrete = encoder.transform(discrete_data)

        # Get feature ranges
        discrete_ranges = encoder.get_feature_ranges()

        # Inverse transform
        decoded_data = encoder.inverse_transform(encoded_discrete)
    else:
        discrete_ranges = None  # Set to None when there are no discrete columns 
        encoder = None

    # Normalize the dataset
    normalized_data, min_vals, max_vals = scale_to_unit_interval(raw_data)
    #  Splits the data into training and test sets.
    normalized_traindata, normalized_testdata = split_data(normalized_data, test_size=0.10)

    # Create overlapping time-series sequences for training data
    train_data_sequences = [
        normalized_traindata[i:i + sequence_length]
        for i in range(0, len(normalized_traindata) - sequence_length + 1)
    ]

    # Error handling for training data
    if len(train_data_sequences) == 0:
        raise ValueError("No valid sequences could be generated with the specified sequence length for training data.")

    # Create overlapping time-series sequences for test data with a half-step overlap
    overlap_step = sequence_length // 2  # Half of the sequence length
    # Add rows to normalized_testdata by appending the last overlap_step rows
    additional_rows = normalized_testdata[-overlap_step:]
    normalized_testdata = np.concatenate((normalized_testdata, additional_rows), axis=0)

    test_data_sequences = [
        normalized_testdata[i:i + sequence_length]
        for i in range(0, len(normalized_testdata) - sequence_length + 1, overlap_step)
    ]

    # Error handling for test data
    if len(test_data_sequences) == 0:
        raise ValueError("No valid sequences could be generated with the specified sequence length for test data.")

    print(f"{dataset_type.capitalize()} dataset loaded successfully.")

    # Ensure that the input dimensions of train and test sequences are consistent
    assert np.asarray(train_data_sequences).shape[2] == np.asarray(test_data_sequences).shape[2], \
        "Mismatch between input dimensions of training and test sequences."

    # Update configuration with dataset attributes and preprocessing details
    config.update({
        'mappings': discrete_ranges,            # Encoded column indices for decoding
        'one_hot_encoder': encoder,                     # One-hot encoder for categorical features
        'discrete_columns': discrete_columns,                   # List of discrete columns for reference
        'min_vals': min_vals,                                   # Minimum values for each feature
        'max_vals': max_vals                                    # Maximum values for each feature
    })


    if config.get('isTrainSyn', False) is True:

        #========================= Load Synthetic data  ===============================#

        # Construct the path dynamically

        directory_path = create_nested_dirs('./output', config['dataset_type'])  # Current working directory
        file_path = os.path.join(directory_path, 'simulated_data.npy')  # Add subdirectory and filename
        # Load the .npy file
        simulated_data = np.load(file_path)

        # Reshape data to combine batch and sequence dimensions for easier processing
        reshaped_simulated_data = simulated_data.reshape(-1, simulated_data.shape[-1])  

        # Compute min and max for each feature in the current dataset
        min_values = reshaped_simulated_data.min(axis=0)  
        max_values = reshaped_simulated_data.max(axis=0)  

        # Get the lowest min and the highest max for each feature
        final_min_vals = np.minimum(min_values, config['min_vals'])  
        final_max_vals = np.maximum(max_values, config['max_vals']) 

        # Avoid division by zero for features with no variation
        range_values = final_max_vals - final_min_vals
        range_values[range_values == 0] = 1

        # Apply min-max scaling using the final min and max values
        simulated_scaled_data = (reshaped_simulated_data - final_min_vals) / range_values  # 

        # Reshape back to the original shape
        simulated_scaled_data = simulated_scaled_data.reshape(simulated_data.shape)  # 
    else:
        simulated_scaled_data = None    

    # Return all processed outputs
    return torch.from_numpy(np.array(train_data_sequences)).float(), torch.from_numpy(np.array(test_data_sequences)).float(), torch.from_numpy(simulated_scaled_data).float() if simulated_scaled_data is not None else None


class TimeSeriesForecastingDataset(Dataset):
    def __init__(self, data, input_seq_len=12, output_seq_len=12):
        """
        A PyTorch Dataset for time series forecasting that handles 3D input data.
        
        Args:
            data: Input data with shape (num_samples, time_steps, features)
            input_seq_len (int): Number of time steps used as input
            output_seq_len (int): Number of time steps to predict
        """
            
        if isinstance(data, np.ndarray):
            self.data = torch.from_numpy(data).float()
        elif isinstance(data, torch.Tensor):
            self.data = data.float()
        else:
            raise ValueError("Data must be a list of arrays, numpy array, or torch tensor")
            
        # Verify the data is 3D
        if len(self.data.shape) != 3:
            raise ValueError(f"Expected 3D data with shape (samples, time_steps, features) but got shape {self.data.shape}")
            
        self.num_samples, self.time_steps, self.num_features = self.data.shape
            
        if input_seq_len < 1 or output_seq_len < 1:
            raise ValueError("Sequence lengths must be positive integers")
            
        if self.time_steps < input_seq_len + output_seq_len:
            raise ValueError(
                f"Time steps {self.time_steps} is too short for "
                f"input_seq_len={input_seq_len} and output_seq_len={output_seq_len}"
            )
            
        self.input_seq_len = input_seq_len
        self.output_seq_len = output_seq_len
        
    def __len__(self):
        """Returns the number of samples in the dataset."""
        return self.num_samples
        
    def __getitem__(self, idx):
        """
        Get a single input-target sequence pair.
        
        Args:
            idx (int): Index of the sample
            
        Returns:
            tuple: (input_seq, target_seq)
                - input_seq (Tensor): Shape (input_seq_len, num_features)
                - target_seq (Tensor): Shape (output_seq_len, num_features)
        """
        if idx < 0:  # Handle negative indexing
            idx = len(self) + idx
            
        if idx >= len(self):
            raise IndexError("Index out of bounds")
        
        # Get the full sequence for this sample
        sequence = self.data[idx]
        
        # Split into input and target sequences
        input_seq = sequence[:self.input_seq_len]
        target_seq = sequence[self.input_seq_len:self.input_seq_len + self.output_seq_len]
        
        return input_seq, target_seq

    @property
    def feature_dim(self):
        """Returns the number of features in the time series data."""
        return self.num_features


class TemporalFeatureForecaster(nn.Module):
    """Forecasts future features from original temporal data using a GRU-based network.
    """

    def __init__(self, config):
        super(TemporalFeatureForecaster, self).__init__()
        try:
            # Check that all required configuration attributes are present, of type int, and positive.
            required_attrs = ['input_dim', 'rnn_layers']
            for attr in required_attrs:
                if attr not in config:
                    raise AttributeError(f"Configuration is missing required attribute '{attr}'.")
                if not isinstance(config[attr], int):
                    raise TypeError(f"Configuration attribute '{attr}' must be an integer.")
                if config[attr] <= 0:
                    raise ValueError(f"Configuration attribute '{attr}' must be a positive integer.")
            
            # Initialize GRU layer for forecasting future features from original temporal data
            self.forecast_rnn = nn.GRU(
                input_size=config['input_dim'],
                hidden_size=config['input_dim'],
                num_layers=config['rnn_layers'],
                dropout=0.05
            )

            # GRU weight initialization function
            def initialize_weights(module):
                """
                Initializes GRU weights using optimal settings for temporal forecasting.
                
                Uses orthogonal initialization with careful scaling:
                - Input weights: Scaled by sqrt(1/hidden_size)
                - Hidden weights: Scaled by 0.95 for gradient stability
                - Reset gate bias: -0.1 to help selective forgetting
                - Update gate bias: +0.1 to promote information flow
                - New gate bias: 0 for unbiased learning
                
                Args:
                    module: nn.Module, should be a GRU layer
                """
                if isinstance(module, nn.GRU):
                    hidden_size = module.hidden_size
                    
                    for name, param in module.named_parameters():
                        if 'weight_ih' in name:
                            # Input-to-hidden weights
                            nn.init.orthogonal_(param.data)
                            # Scale based on input size
                            param.data *= math.sqrt(1. / hidden_size)
                            
                        elif 'weight_hh' in name:
                            # Hidden-to-hidden weights
                            nn.init.orthogonal_(param.data)
                            # Carefully scale recurrent weights to prevent vanishing/exploding gradients
                            param.data *= 0.95  # Slightly less than 1 to ensure stability
                            
                        elif 'bias_ih' in name:
                            # Input-to-hidden bias
                            n = param.size(0)
                            # Split bias for reset, update, and new gates
                            reset_gate_bias = param.data[0:n//3]
                            update_gate_bias = param.data[n//3:2*n//3]
                            new_gate_bias = param.data[2*n//3:]
                            
                            # Initialize reset gate bias to small negative value
                            reset_gate_bias.fill_(-0.1)
                            # Initialize update gate bias to small positive value
                            update_gate_bias.fill_(0.1)
                            # Initialize new gate bias to zero
                            new_gate_bias.fill_(0.0)
                            
                        elif 'bias_hh' in name:
                            # Hidden-to-hidden bias
                            param.data.fill_(0.0)

            self.apply(initialize_weights)
          
            # Calculate the total number of columns (categorical variables)
            self.total_columns = len(config["mappings"]) if config["mappings"] is not None else 0

            if self.total_columns > 0:
                # Optional: Get total number of encoded indices across all columns
                self.total_indices = sum(range_size for _, range_size, _ in config["mappings"])

                # Get discrete ranges for one-hot encoding  (Assuming get_discrete_ranges is defined elsewhere)
                self.discrete_ranges = config["mappings"]

                # Initialize fully connected layer for forecasting to the original continuous feature dimension
                self.forecast_continuous_fc = nn.Linear(config['input_dim'], config['input_dim'] - self.total_columns)

            else:
                # Initialize fully connected layer for forecasting to the original continuous feature dimension
                self.forecast_continuous_fc = nn.Linear(config['input_dim'], config['input_dim'])

            if self.total_columns > 0:
                # Initialize fully connected layer for forecasting to the original discrete feature dimension
                self.forecast_discrete_fc = nn.Linear(config['input_dim'], self.total_indices)

                # Define the Softmax activation using torch.nn
                self.activation_discrete_fn = nn.Softmax(dim=-1)

            # Activation function applied to the continuous features
            self.activation_continuous_fn = nn.LeakyReLU(negative_slope=0.1)

            # Apply weight initialization function to all parameters (Assuming initialize_weights is defined elsewhere)
            self.apply(initialize_weights)

        except AttributeError as attr_err:
            raise AttributeError(f"Initialization error in TemporalFeatureForecaster: {str(attr_err)}")
        except TypeError as type_err:
            raise TypeError(f"Type error in TemporalFeatureForecaster configuration: {str(type_err)}")
        except ValueError as val_err:
            raise ValueError(f"Value error in TemporalFeatureForecaster configuration: {str(val_err)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during TemporalFeatureForecaster initialization: {str(e)}")

    def forward(self, input_data, apply_activation=True):
        """Forecasts future features from original temporal data.
        """
        # Check if input_data is a tensor and has the correct dimensions
        if not isinstance(input_data, torch.Tensor):
            raise TypeError("Input to forward method must be a torch.Tensor.")

        if input_data.dim() != 3:
            raise ValueError("Input tensor must be 3-dimensional (sequence_length, batch_size, input_dim).")

        # Validate that the last dimension of input_data matches the expected input dimension
        expected_input_dim = self.forecast_rnn.input_size
        if input_data.size(-1) != expected_input_dim:
            raise ValueError(
                f"Expected input feature dimension of {expected_input_dim}, but got {input_data.size(-1)}."
            )

        try:
            # Pass original temporal data through the GRU layer for forecasting
            forecast_output, _ = self.forecast_rnn(input_data)
            forecast_output = forecast_output + input_data

            # Pass the RNN output through the fully connected layer for forecasting of continuous features
            forecasted_continuousfeatures = self.forecast_continuous_fc(forecast_output)

            # Add residual connection for continuous features
            continuous_input = input_data[..., :forecasted_continuousfeatures.shape[-1]]
            forecasted_continuousfeatures = forecasted_continuousfeatures + continuous_input

            # Optionally apply the activation function
            if apply_activation:
                forecasted_continuousfeatures = self.activation_continuous_fn(forecasted_continuousfeatures)

            if self.total_columns > 0:
                # Pass the RNN output through the fully connected layer for forecasting of discrete features
                forecasted_discretefeatures = self.forecast_discrete_fc(forecast_output)


                one_hot_results = []
                for start, range_size, num_classes in self.discrete_ranges:

                    end = start + range_size  # Calculate the end index of the current range

                    # Slice the relevant part of the decoded output
                    discretefeatures = forecasted_discretefeatures[..., start:end]  # Shape: [Batch, Seq, range_size]

                    # Apply softmax for differentiability
                    softmax_output = self.activation_discrete_fn(discretefeatures)

                    # Differentiable one-hot encoding using argmax
                    argmax_indices = torch.argmax(softmax_output, dim=-1)  # Shape: [Batch, Seq]

                    one_hot = torch.nn.functional.one_hot(argmax_indices, num_classes=num_classes).to(softmax_output.dtype)  # Ensure dtype consistency

                    # Store one-hot outputs
                    one_hot_results.append(one_hot)

                # Get the original shape of the generated data
                original_shape = torch.cat(one_hot_results, dim=-1).shape

                # Create a new shape with the same number of samples and time steps, but with inferred features
                new_shape = (original_shape[0], original_shape[1], -1)

                # # Decoding One-Hot Encoded Columns,  Reshape the decoded features back to the original shape with correct dimensions  [Batch, Seq, total_discrete_classes]
                total_discrete_columns =  config['one_hot_encoder'].inverse_transform(torch.cat(one_hot_results, dim=-1).reshape(-1, self.total_indices).float()).reshape(new_shape)

                # Concatenate continuous features with discrete one-hot encodings
                forecasted_features = torch.cat((forecasted_continuousfeatures, total_discrete_columns), dim=-1)  # Final concatenation
                
                # print(forecasted_features.requires_grad)
            else:
                forecasted_features = forecasted_continuousfeatures
 
        except Exception as e:
            raise RuntimeError(f"Execution error detected during forward computation in TemporalFeatureForecaster: {str(e)}")

        return forecasted_features


def train_forecaster(model, train_loader, val_loader, config):
    """
    Trains the TemporalFeatureForecaster model and saves checkpoints in the forecasting directory.
    Args:
        model (nn.Module): The model to train.
        train_loader (DataLoader): Training data loader.
        val_loader (DataLoader): Validation data loader.
        config (dict): Configuration dictionary containing training parameters.
    """
    # Loss function and optimizer
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=config['learning_rate'])
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=config['lr_decay_step'], gamma=config['lr_decay_rate'])

    # Early stopping parameters
    best_val_loss = float('inf')  # Initialize to a large value
    patience = config.get('patience', 200)  # Default patience is 100 epochs
    no_improvement_epochs = 0

    # Initialize lists to store losses
    train_losses = []
    val_losses = []
    learning_rates = []  # To store the learning rate per epoch

    dataset_name = config['dataset_type']  # Get dataset name from config

    for epoch in range(config['num_epochs']):
        model.train()
        total_train_loss = 0

        for input_data, target_data in train_loader:
    
            input_data, target_data = input_data.to(device), target_data.to(device)

            optimizer.zero_grad()

            predictions = model(input_data)      
    
            # Scaling for loss computation
            min_vals = torch.tensor(config['min_vals']).to(device)
            max_vals = torch.tensor(config['max_vals']).to(device)
            min_vals = min_vals.view(1, 1, -1)
            max_vals = max_vals.view(1, 1, -1)

            # Length of config['discrete_columns'] to exclude
            exclude_len = len(config['discrete_columns']) 

            if exclude_len > 0:
                continuous_scaled_predictions = predictions[:, :, :-exclude_len] * ((max_vals[:, :, :-exclude_len] - min_vals[:, :, :-exclude_len]) + 2e-8) + min_vals[:, :, :-exclude_len]
                # Concatenate the continuous and discrete predictions
                scaled_predictions = torch.cat((continuous_scaled_predictions, predictions[:, :, -exclude_len:]), dim=-1) # Assuming discrete features don't require scaling                
                continuous_scaled_target_data = target_data[:, :, :-exclude_len] * ((max_vals[:, :, :-exclude_len] - min_vals[:, :, :-exclude_len]) + 2e-8) + min_vals[:, :, :-exclude_len]
                # Concatenate the continuous and discrete predictions
                scaled_target_data = torch.cat((continuous_scaled_target_data, target_data[:, :, -exclude_len:]), dim=-1) # Assuming discrete features don't require scaling
            else:
                # If there are no discrete columns, use the continuous features directly
                scaled_predictions = predictions * ((max_vals - min_vals) + 2e-8) + min_vals
                scaled_target_data = target_data * ((max_vals - min_vals) + 2e-8) + min_vals


            loss = criterion(scaled_predictions, scaled_target_data)
            loss.backward()

            # Apply gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

            optimizer.step()
            total_train_loss += loss.item()

        scheduler.step()
        avg_train_loss = total_train_loss / len(train_loader)
        train_losses.append(avg_train_loss)

        # Get current learning rate and log it
        current_lr = scheduler.get_last_lr()[0]
        learning_rates.append(current_lr)
        print(f"Epoch [{epoch+1}/{config['num_epochs']}], Learning Rate: {current_lr:.6f}")

        # Validation phase
        model.eval()
        total_val_loss = 0
        with torch.no_grad():
            for input_data, target_data in val_loader:
                input_data, target_data = input_data.to(device), target_data.to(device)
                # print(f"input_data device: {input_data.device}, model device: {next(model.parameters()).device}")

                predictions = model(input_data)

                # Length of config['discrete_columns'] to exclude
                exclude_len = len(config['discrete_columns']) 
                if exclude_len > 0:
                    continuous_scaled_predictions = predictions[:, :, :-exclude_len] * ((max_vals[:, :, :-exclude_len] - min_vals[:, :, :-exclude_len]) + 2e-8) + min_vals[:, :, :-exclude_len]
                    # Concatenate the continuous and discrete predictions
                    scaled_predictions = torch.cat((continuous_scaled_predictions, predictions[:, :, -exclude_len:]), dim=-1) # Assuming discrete features don't require scaling
                    continuous_scaled_target_data = target_data[:, :, :-exclude_len] * ((max_vals[:, :, :-exclude_len] - min_vals[:, :, :-exclude_len]) + 2e-8) + min_vals[:, :, :-exclude_len]
                    # Concatenate the continuous and discrete predictions
                    scaled_target_data = torch.cat((continuous_scaled_target_data, target_data[:, :, -exclude_len:]), dim=-1) # Assuming discrete features don't require scaling
                else:
                    # If there are no discrete columns, use the continuous features directly
                    scaled_predictions = predictions * ((max_vals - min_vals) + 2e-8) + min_vals
                    scaled_target_data = target_data * ((max_vals - min_vals) + 2e-8) + min_vals

                loss = criterion(scaled_predictions, scaled_target_data)
                total_val_loss += loss.item()

        avg_val_loss = total_val_loss / len(val_loader)
        val_losses.append(avg_val_loss)

        # Early stopping: Save the best model and check for improvement
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            save_checkpoint(model, optimizer, epoch + 1, best_val_loss, dataset_name, config, filename="best_model.pth")
            no_improvement_epochs = 0  # Reset counter if there's improvement
            print(f"Epoch {epoch + 1}: Validation loss improved to {best_val_loss:.4f}. Saved best model.")
        else:
            no_improvement_epochs += 1
            print(f"Epoch {epoch + 1}: No improvement in validation loss for {no_improvement_epochs} epochs.")

        # Stop training if no improvement for `patience` consecutive epochs
        if no_improvement_epochs >= patience:
            print(f"Early stopping triggered after {patience} epochs with no improvement.")
            break

        # Log progress
        print(f"Epoch [{epoch+1}/{config['num_epochs']}], Train Loss: {avg_train_loss:.4f}, Val Loss: {avg_val_loss:.4f}")

    # Plot the training and validation losses
    plt.figure(figsize=(10, 6))
    plt.plot(train_losses, label='Training Loss')
    plt.plot(val_losses, label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Plot the learning rate per epoch
    plt.figure(figsize=(10, 6))
    plt.plot(learning_rates, label='Learning Rate')
    plt.xlabel('Epoch')
    plt.ylabel('Learning Rate')
    plt.title('Learning Rate per Epoch')
    plt.legend()
    plt.grid(True)
    plt.show()

    return model


def calculate_ema(data, alpha=0.1):
    """
    Calculates the Exponential Moving Average (EMA) of the data in a vectorized manner.

    Args:
        data (torch.Tensor): Input tensor of shape (batch_size, seq_len, num_features).
        alpha (float): Smoothing factor, typically between 0 and 1.

    Returns:
        torch.Tensor: EMA tensor of the same shape as the input data.
    """
    batch_size, seq_len, num_features = data.shape
    ema = torch.zeros_like(data)
    ema[:, 0, :] = data[:, 0, :]

    # Create a weight tensor for broadcasting the EMA calculation
    weights = torch.cumprod(torch.full((seq_len - 1,), (1 - alpha), device=data.device), dim=0)
    weights = torch.cat([torch.ones(1, device=data.device), weights])

    # Compute the EMA for each time step using cumulative sum
    cumulative_sum = torch.cumsum(data * alpha, dim=1)
    ema = cumulative_sum / weights.view(1, -1, 1)

    return ema

def generate_dynamic_threshold_mask_EMA(scaled_predictions, scaled_target_data, alpha=0.1, mad_scaling_factor=1.4826):
    """
    Generates a mask matrix based on dynamic thresholds using EMA and the Median Absolute Deviation (MAD).
    The thresholds are calculated using EMA for smoother and more responsive anomaly detection.

    Args:
        scaled_predictions (torch.Tensor): Predicted values with shape (batch_size, seq_len, num_features).
        scaled_target_data (torch.Tensor): Ground truth values with shape (batch_size, seq_len, num_features).
        alpha (float): Smoothing factor for EMA, typically between 0 and 1 (default: 0.1).
        mad_scaling_factor (float): Scaling factor for MAD to estimate standard deviation (default: 1.4826).

    Returns:
        torch.Tensor: Binary mask where 1 indicates normal points and 0 indicates anomalies.
    """
    # Ensure the input tensors have the correct shape
    if scaled_predictions.shape != scaled_target_data.shape:
        raise ValueError("scaled_predictions and scaled_target_data must have the same shape.")

    # Calculate EMA for the target data (smoothed moving average)
    ema_avg = calculate_ema(scaled_target_data, alpha)  # Shape: (batch_size, seq_len, num_features)

    # Calculate absolute deviations between predictions and targets
    deviations = torch.abs(scaled_predictions - scaled_target_data)  # Shape: (batch_size, seq_len, num_features)

    # Calculate EMA for the absolute deviations (smoothed standard deviation)
    ema_std = calculate_ema(deviations, alpha).clamp(min=1e-8)  # Shape: (batch_size, seq_len, num_features)

    # Compute the Median Absolute Deviation (MAD) feature-wise
    median_deviation = torch.median(deviations, dim=1, keepdim=True)[0]  # Shape: (batch_size, 1, num_features)
    mad = torch.median(torch.abs(deviations - median_deviation), dim=1, keepdim=True)[0]  # Shape: (batch_size, 1, num_features)

    # Estimate dynamic k values from MAD
    dynamic_k = mad_scaling_factor * mad  # Shape: (batch_size, 1, num_features)

    # Expand dynamic_k to match the sequence length dimension
    dynamic_k = dynamic_k.expand_as(scaled_target_data)  # Shape: (batch_size, seq_len, num_features)

    # Calculate dynamic thresholds using EMA for mean and standard deviation
    thresholds = ema_avg + dynamic_k * ema_std  # Shape: (batch_size, seq_len, num_features)

    # Generate mask: 1 for normal points, 0 for anomalies
    mask = (deviations <= thresholds).float()  # Shape: (batch_size, seq_len, num_features)

    return mask


def evaluate_forecaster(model, test_loader):
    """
    Evaluates the TemporalFeatureForecaster on the test set for MSE, RMSE, and MAE.

    Args:
        model (nn.Module): Trained TemporalFeatureForecaster.
        test_loader (DataLoader): DataLoader for test data.

    Returns:
        dict: Dictionary containing MSE, RMSE, and MAE losses.
    """
    model.eval()
    total_mse_loss = 0
    total_mae_loss = 0

    mse_loss_fn = nn.MSELoss(reduction='sum')
    mae_loss_fn = nn.L1Loss(reduction='sum')

    # Initialize lists to store input, target, and predictions
    all_inputs, all_targets, all_predictions, all_masks = [], [], [], []

    with torch.no_grad():
        for input_data, target_data in test_loader:
            input_data, target_data = input_data.to(device), target_data.to(device)

            # Make predictions
            predictions = model(input_data)

            # Convert config['min_vals'] and config['max_vals'] to PyTorch tensors
            min_vals = torch.tensor(config['min_vals']).to(predictions.device)
            max_vals = torch.tensor(config['max_vals']).to(predictions.device)

            # Reshape for broadcasting
            min_vals = min_vals.view(1, 1, -1)
            max_vals = max_vals.view(1, 1, -1)

            # Length of config['discrete_columns'] to exclude
            exclude_len = len(config['discrete_columns']) 


            if exclude_len > 0:
                # Scale predictions and target data back to the original range
                continuous_scaled_predictions = predictions[:, :, :-exclude_len] * ((max_vals[:, :, :-exclude_len] - min_vals[:, :, :-exclude_len]) + 2e-8) + min_vals[:, :, :-exclude_len]
                # Concatenate the continuous and discrete predictions
                scaled_predictions = torch.cat((continuous_scaled_predictions, predictions[:, :, -exclude_len:]), dim=-1) # Assuming discrete features don't require scaling
                continuous_scaled_target_data = target_data[:, :, :-exclude_len] * ((max_vals[:, :, :-exclude_len] - min_vals[:, :, :-exclude_len]) + 2e-8) + min_vals[:, :, :-exclude_len]
                # Concatenate the continuous and discrete predictions
                scaled_target_data = torch.cat((continuous_scaled_target_data, target_data[:, :, -exclude_len:]), dim=-1) # Assuming discrete features don't require scaling
            else:
                # If there are no discrete columns, use the continuous features directly
                scaled_predictions = predictions * ((max_vals - min_vals) + 2e-8) + min_vals
                scaled_target_data = target_data * ((max_vals - min_vals) + 2e-8) + min_vals


            # Compute MSE and MAE losses
            total_mse_loss += mse_loss_fn(scaled_predictions, scaled_target_data).item()
            total_mae_loss += mae_loss_fn(scaled_predictions, scaled_target_data).item()

            # Assume scaled_predictions and scaled_target_data are tensors of shape (batch_size, seq_len, num_features)
            mask = generate_dynamic_threshold_mask_EMA(scaled_predictions, scaled_target_data, alpha=config['alpha'] , mad_scaling_factor = config['mad_scaling_factor'])

            # Detach tensors and move to CPU for storing
            target_data_np = scaled_target_data.detach().cpu().numpy()
            predictions_np = scaled_predictions.detach().cpu().numpy()
            
            # Append to lists
            all_targets.append(target_data_np)
            all_predictions.append(predictions_np)
            all_masks.append(mask.detach().cpu().numpy())

    # Stack all stored data
    all_targets = np.concatenate(all_targets, axis=0)
    all_predictions = np.concatenate(all_predictions, axis=0)  
    all_masks = np.concatenate(all_masks, axis=0)

    # Reshape all_targets and all_predictions to 2D while preserving temporal order
    all_targets_2d = all_targets.reshape(-1, all_targets.shape[2])
    all_predictions_2d = all_predictions.reshape(-1, all_predictions.shape[2])
    all_masks_2d = all_masks.reshape(-1, all_masks.shape[2])

    # Compute average losses
    num_samples = len(test_loader.dataset)
    avg_mse_loss = total_mse_loss / num_samples
    avg_rmse_loss = np.sqrt(avg_mse_loss)
    avg_mae_loss = total_mae_loss / num_samples

    output_path = create_output_directory(config['dataset_type'], config)

    # Save the mask matrix to a .npy file
    mask_output_path = os.path.join(output_path, 'forecast_masks.npy')
    np.save(mask_output_path, all_masks_2d)
    print(f"Mask matrix saved to: {mask_output_path}")

    missingness = calculate_missingness(all_masks_2d)
    print(f"Overall Missingness Percentage: {missingness['overall_missingness_percentage']:.2f}%")
    print("Per-Feature Missingness Percentages:")
    for i, perc in enumerate(missingness['feature_missingness_percentage']):
        print(f"Feature {i}: {perc:.2f}%")


    plt.figure(figsize=(12, 6))
    sns.heatmap(all_masks_2d.T, cmap='coolwarm', cbar_kws={'label': 'Mask (1=Normal, 0=Anomaly)'})
    plt.xlabel('Time Steps')
    plt.ylabel('Features')
    plt.title('Anomaly Mask Heatmap')
    # Save the figure to the specified path
    plt.savefig(os.path.join(output_path, 'results'), dpi=300, bbox_inches='tight')
    plt.show()

    plot_timeseries_with_anomalies(all_targets_2d, all_predictions_2d, all_masks_2d, config['input_dim'], output_path)
    plot_violin(all_targets_2d, all_predictions_2d, config['input_dim'], output_path)
    plot_density(all_targets_2d, all_predictions_2d, config['input_dim'], output_path )     
    plot_box_whisker(all_targets_2d, all_predictions_2d, config['input_dim'], output_path)  

    return {
        'MSE': avg_mse_loss,
        'RMSE': avg_rmse_loss,
        'MAE': avg_mae_loss
    }

if __name__ == '__main__':
    # Example configuration for running the trainer
    config = {
        'dataset_type': 'energy',  # Dataset type (e.g., 'energy(24)' or 'stock(6)'')
        'input_dim': 24,  # Input feature dimension
        'task': 'forecasting', # task type (e.g., 'forecasting')
        'isTrain': True,  # Training with real only!.   
        'isTrainSyn': False, #  Training with real + synthetic data
        'seq_len': 24,  # Sequence length for time-series data
        'input_seq_len': 12,
        'output_seq_len': 12,
        'num_epochs': 500,  # Number of training iterations
        'module': 'gru',  # Model module to use (e.g., GRU-based)
        'latent_dim': 128,  # Latent dimensionality
        'rnn_layers': 2,  # Number of layers in the RNN
        'batch_size': 128,  # Batch size for training
        'learning_rate': 0.01,  # Learning rate
        'mappings': None,  # Mappings for discrete features
        'one_hot_encoder': None,  # Placeholder for one-hot encoder
        'discrete_columns': None,  # Placeholder for discrete columns
        'min_vals': None,
        'max_vals': None,   
        'lr_decay_step': 50,
        'lr_decay_rate': 0.75,
        'mad_scaling_factor':3.0,
        'alpha':0.2
    }

    # Check for GPU availability
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # Call the load_time_series_data function with the configuration
    try:
        train_data, test_data, simulated_data = load_time_series_data(config)
        print("Data successfully loaded and processed.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

    # Concatenate real and synthetic data along the first axis (samples) if synthetic data is available
    if simulated_data is not None:
        # Combine simulated (synthetic) data and real training data into a single dataset
        concatenated_data = torch.cat((simulated_data, train_data), dim=0)
        
        # Create a training dataset using the combined data
        train_dataset = TimeSeriesForecastingDataset(concatenated_data, config['input_seq_len'], config['output_seq_len'])
    else:
        # If no synthetic data is provided, use only the real training data
        train_dataset = TimeSeriesForecastingDataset(train_data, config['input_seq_len'], config['output_seq_len'])

    # Create a test dataset using the real test data
    test_dataset = TimeSeriesForecastingDataset(test_data, config['input_seq_len'], config['output_seq_len'])

    # Define the split sizes for validation and training
    train_size = int(0.90 * len(train_dataset))  # 95% for training
    val_size = len(train_dataset) - train_size   # 5% for validation

    # Split the train_dataset into training and validation sets
    train_dataset, val_dataset = random_split(train_dataset, [train_size, val_size])

    # Create DataLoaders
    train_loader = DataLoader(train_dataset, batch_size=config['batch_size'], shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config['batch_size'], shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=config['batch_size'], shuffle=False)

    # Initialize the model
    model = TemporalFeatureForecaster(config).to(device)

    print(f"Model loaded on: {next(model.parameters()).device}")

    if not config.get('isTrain', False):
        # If not training, load model and optimizer from checkpoint
        try:
            start_epoch, last_loss, optimizer = load_model_and_optimizer(model, config)
        except RuntimeError as e:
            print(f"Error during checkpoint loading: {e}")
    else:
        # If training, initialize optimizer and start training
        optimizer = optim.Adam(model.parameters(), lr=config['learning_rate'])
        trained_model = train_forecaster(
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            config=config
        )
        print("Model training completed successfully.")

    # Evaluate the model and print the losses
    losses = evaluate_forecaster(model, test_loader)

    logger.info(f"MSE Loss: {losses['MSE']:.4f}")
    logger.info(f"RMSE Loss: {losses['RMSE']:.4f}")
    logger.info(f"MAE Loss: {losses['MAE']:.4f}")    
    

