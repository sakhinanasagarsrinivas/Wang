import torch
import torch.nn as nn
from .hypergraph_structure import HypergraphStructureLearning
from .hypergraph_attention import HypergraphAttentionNetwork
from .hypergraph_transformer import HypergraphTransformer
from config.config import VisionHGNNConfig

class VisionHGNN(nn.Module):
    """
    Vision Hypergraph Neural Network
    Implements the full architecture described in the paper
    """
    def __init__(self, config: VisionHGNNConfig):
        super().__init__()
        
        # Hypergraph Structure Learning
        self.hgsl = HypergraphStructureLearning(
            patch_size=config.patch_size,
            feature_dim=config.feature_dim,
            k_nearest=config.k_nearest
        )
        
        # Hypergraph Attention Network
        self.hgat = HypergraphAttentionNetwork(
            feature_dim=config.feature_dim,
            num_heads=config.num_attention_heads,
            num_layers=config.hgat_layers
        )
        
        # Hypergraph Transformer
        self.hgt = HypergraphTransformer(
            feature_dim=config.feature_dim,
            num_heads=config.num_attention_heads,
            num_layers=config.hgt_layers
        )
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(config.feature_dim, config.feature_dim * 2),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(config.feature_dim * 2, config.num_classes)
        )
    
    def forward(self, x):
        # Hypergraph Structure Learning
        patches, hyperedge_indices = self.hgsl(x)
        
        # Hypergraph Attention Network
        hgat_embeddings = self.hgat(patches, hyperedge_indices)
        
        # Hypergraph Transformer
        hgt_embeddings = self.hgt(hgat_embeddings)
        
        # Global pooling
        graph_embedding = hgt_embeddings.mean(dim=1)
        
        # Classification
        predictions = self.classifier(graph_embedding)
        
        return predictions