import torch
import numpy as np
from typing import Dict, List, Tuple, Optional
from pathlib import Path
import json
import yaml
from torch.optim import Adam, AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau
import logging
from tqdm import tqdm

def setup_experiment(
    config_path: str,
    experiment_name: str,
    seed: int = 42
) -> Tuple[Dict, Path]:
    """
    Setup experiment directories and configuration
    
    Args:
        config_path: Path to configuration file
        experiment_name: Name of experiment
        seed: Random seed
        
    Returns:
        Tuple of (config, experiment_dir)
    """
    # Set random seeds
    torch.manual_seed(seed)
    np.random.seed(seed)
    
    # Load configuration
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    # Create experiment directory
    exp_dir = Path(config['paths']['results_dir']) / experiment_name
    exp_dir.mkdir(parents=True, exist_ok=True)
    
    # Save configuration
    with open(exp_dir / 'config.yaml', 'w') as f:
        yaml.dump(config, f)
    
    return config, exp_dir

def get_optimizer(
    model: torch.nn.Module,
    config: Dict
) -> torch.optim.Optimizer:
    """Get optimizer based on configuration"""
    optimizer_config = config['training']['optimizer']
    optimizer_name = optimizer_config.get('name', 'adam').lower()
    
    if optimizer_name == 'adam':
        optimizer = Adam(
            model.parameters(),
            lr=optimizer_config.get('lr', 1e-3),
            weight_decay=optimizer_config.get('weight_decay', 0)
        )
    elif optimizer_name == 'adamw':
        optimizer = AdamW(
            model.parameters(),
            lr=optimizer_config.get('lr', 1e-3),
            weight_decay=optimizer_config.get('weight_decay', 0.01)
        )
    else:
        raise ValueError(f"Unknown optimizer: {optimizer_name}")
    
    return optimizer

def get_scheduler(
    optimizer: torch.optim.Optimizer,
    config: Dict
) -> Optional[torch.optim.lr_scheduler._LRScheduler]:
    """Get learning rate scheduler based on configuration"""
    scheduler_config = config['training'].get('scheduler')
    if scheduler_config is None:
        return None
    
    scheduler_name = scheduler_config.get('name', 'plateau').lower()
    
    if scheduler_name == 'plateau':
        return ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=scheduler_config.get('factor', 0.1),
            patience=scheduler_config.get('patience', 10),
            verbose=True
        )
    else:
        raise ValueError(f"Unknown scheduler: {scheduler_name}")

def train_epoch(
    model: torch.nn.Module,
    train_loader: torch.utils.data.DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    metrics_calculator: Optional[object] = None
) -> Tuple[float, Dict[str, float]]:
    """
    Train for one epoch
    
    Returns:
        Tuple of (average loss, metrics)
    """
    model.train()
    total_loss = 0
    predictions = []
    targets = []
    
    for batch in tqdm(train_loader, desc="Training"):
        optimizer.zero_grad()
        
        # Move batch to device
        batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v 
                for k, v in batch.items()}
        
        # Forward pass
        outputs = model(batch)
        loss = outputs['loss']
        
        # Backward pass
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        
        # Collect predictions and targets for metrics
        predictions.append(outputs['predictions'].detach())
        targets.append(batch['targets'])
    
    avg_loss = total_loss / len(train_loader)
    
    # Calculate metrics
    if metrics_calculator is not None:
        predictions = torch.cat(predictions)
        targets = torch.cat(targets)
        metrics = metrics_calculator.calculate_regression_metrics(targets, predictions)
    else:
        metrics = {}
    
    return avg_loss, metrics

def validate(
    model: torch.nn.Module,
    val_loader: torch.utils.data.DataLoader,
    device: str,
    metrics_calculator: Optional[object] = None
) -> Tuple[float, Dict[str, float]]:
    """
    Validate model
    
    Returns:
        Tuple of (average loss, metrics)
    """
    model.eval()
    total_loss = 0
    predictions = []
    targets = []
    
    with torch.no_grad():
        for batch in tqdm(val_loader, desc="Validation"):
            # Move batch to device
            batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v 
                    for k, v in batch.items()}
            
            # Forward pass
            outputs = model(batch)
            loss = outputs['loss']
            
            total_loss += loss.item()
            
            # Collect predictions and targets for metrics
            predictions.append(outputs['predictions'].detach())
            targets.append(batch['targets'])
    
    avg_loss = total_loss / len(val_loader)
    
    # Calculate metrics
    if metrics_calculator is not None:
        predictions = torch.cat(predictions)
        targets = torch.cat(targets)
        metrics = metrics_calculator.calculate_regression_metrics(targets, predictions)
    else:
        metrics = {}
    
    return avg_loss, metrics

def save_predictions(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    task_names: List[str],
    save_path: Path
):
    """Save predictions to file"""
    predictions_np = predictions.cpu().numpy()
    targets_np = targets.cpu().numpy()
    
    results = {
        'predictions': predictions_np.tolist(),
        'targets': targets_np.tolist(),
        'task_names': task_names
    }
    
    with open(save_path / 'predictions.json', 'w') as f:
        json.dump(results, f)

def setup_logging(log_dir: Path) -> logging.Logger:
    """Setup logging configuration"""
    logger = logging.getLogger('mmf')
    logger.setLevel(logging.INFO)
    
    # Create handlers
    console_handler = logging.StreamHandler()
    file_handler = logging.FileHandler(log_dir / 'training.log')
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)
    
    # Add handlers
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger

def load_model_checkpoint(
    model: torch.nn.Module,
    checkpoint_path: Path,
    device: str
) -> torch.nn.Module:
    """Load model from checkpoint"""
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    return model

def get_model_size(model: torch.nn.Module) -> int:
    """Get number of parameters in model"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def compute_atom_bond_stats(dataset) -> Dict[str, Dict[str, float]]:
    """
    Compute statistics of atom and bond features in dataset
    
    Returns:
        Dictionary containing mean and std of atom/bond features
    """
    atom_features = []
    bond_features = []
    
    for data in dataset:
        atom_features.append(data['node_features'])
        if 'edge_features' in data and len(data['edge_features']) > 0:
            bond_features.append(data['edge_features'])
    
    atom_features = torch.cat(atom_features, dim=0)
    atom_mean = atom_features.mean(dim=0)
    atom_std = atom_features.std(dim=0)
    
    stats = {
        'atom': {
            'mean': atom_mean,
            'std': atom_std
        }
    }
    
    if bond_features:
        bond_features = torch.cat(bond_features, dim=0)
        bond_mean = bond_features.mean(dim=0)
        bond_std = bond_features.std(dim=0)
        stats['bond'] = {
            'mean': bond_mean,
            'std': bond_std
        }
    
    return stats

def evaluate_model(
    model: torch.nn.Module,
    test_loader: torch.utils.data.DataLoader,
    device: str,
    metrics_calculator: object,
    save_dir: Optional[Path] = None
) -> Dict[str, float]:
    """
    Evaluate model on test set
    
    Args:
        model: Model to evaluate
        test_loader: Test data loader
        device: Device to use
        metrics_calculator: Metrics calculator object
        save_dir: Directory to save predictions
        
    Returns:
        Dictionary of metrics
    """
    model.eval()
    predictions = []
    targets = []
    uncertainties = []
    
    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Testing"):
            # Move batch to device
            batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v 
                    for k, v in batch.items()}
            
            # Forward pass
            outputs = model(batch)
            
            predictions.append(outputs['predictions'])
            if 'uncertainty' in outputs:
                uncertainties.append(outputs['uncertainty'])
            targets.append(batch['targets'])
    
    # Concatenate predictions and targets
    predictions = torch.cat(predictions)
    targets = torch.cat(targets)
    
    # Calculate metrics
    metrics = metrics_calculator.calculate_regression_metrics(targets, predictions)
    
    # Calculate uncertainty metrics if available
    if uncertainties:
        uncertainties = torch.cat(uncertainties)
        uncertainty_metrics = metrics_calculator.calculate_uncertainty_metrics(
            targets, predictions, uncertainties
        )
        metrics.update(uncertainty_metrics)
    
    # Save predictions if directory provided
    if save_dir is not None:
        save_predictions(predictions, targets, test_loader.dataset.task_names, save_dir)
    
    return metrics

def get_device(config: Dict) -> str:
    """Get device based on configuration and availability"""
    if torch.cuda.is_available() and config['training'].get('use_cuda', True):
        return 'cuda'
    elif torch.backends.mps.is_available() and config['training'].get('use_mps', True):
        return 'mps'
    return 'cpu'

def aggregate_batch_size(
    base_batch_size: int,
    num_gpus: int,
    scaling_factor: float = 0.75
) -> int:
    """
    Calculate effective batch size for multi-GPU training
    
    Args:
        base_batch_size: Base batch size for single GPU
        num_gpus: Number of GPUs available
        scaling_factor: Factor to scale batch size (to account for memory constraints)
        
    Returns:
        Effective batch size
    """
    return int(base_batch_size * num_gpus * scaling_factor)

def get_learning_rate_range(
    model: torch.nn.Module,
    train_loader: torch.utils.data.DataLoader,
    device: str,
    num_iterations: int = 100,
    start_lr: float = 1e-7,
    end_lr: float = 10,
    plot: bool = False
) -> Tuple[float, float]:
    """
    Find optimal learning rate range using learning rate range test
    
    Args:
        model: Model to test
        train_loader: Training data loader
        device: Device to use
        num_iterations: Number of iterations for test
        start_lr: Starting learning rate
        end_lr: Ending learning rate
        plot: Whether to plot the results
        
    Returns:
        Tuple of (optimal_lr, max_lr)
    """
    model = model.to(device)
    optimizer = Adam(model.parameters(), lr=start_lr)
    
    # Calculate multiplication factor
    mult = (end_lr / start_lr) ** (1 / num_iterations)
    
    losses = []
    lrs = []
    best_loss = float('inf')
    
    for batch in train_loader:
        if len(losses) >= num_iterations:
            break
            
        # Move batch to device
        batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v 
                for k, v in batch.items()}
        
        # Forward and backward passes
        optimizer.zero_grad()
        outputs = model(batch)
        loss = outputs['loss']
        loss.backward()
        
        # Store the values
        losses.append(loss.item())
        lrs.append(optimizer.param_groups[0]['lr'])
        
        # Update best loss
        if loss.item() < best_loss:
            best_loss = loss.item()
        
        # Stop if loss explodes
        if loss.item() > 4 * best_loss:
            break
        
        # Update learning rate
        for param_group in optimizer.param_groups:
            param_group['lr'] *= mult
            
    if plot:
        import matplotlib.pyplot as plt
        plt.plot(lrs, losses)
        plt.xscale('log')
        plt.xlabel('Learning Rate')
        plt.ylabel('Loss')
        plt.show()
    
    # Find optimal learning rate range
    smoothed_losses = np.array(losses)
    optimal_idx = np.argmin(smoothed_losses)
    optimal_lr = lrs[optimal_idx]
    max_lr = lrs[optimal_idx] * 10  # Conservative estimate
    
    return optimal_lr, max_lr