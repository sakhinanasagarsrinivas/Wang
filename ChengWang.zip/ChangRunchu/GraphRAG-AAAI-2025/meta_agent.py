# models/meta_agent.py
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from transformers import AutoModel, AutoTokenizer, get_linear_schedule_with_warmup
from typing import Dict, List, Any, Optional, Tuple
import logging
from pathlib import Path
import json
from tqdm import tqdm
import wandb
from datetime import datetime

class MetaAgent(nn.Module):
    def __init__(self,
                 model_name: str = "meta-llama/Llama-2-7b-chat-hf",
                 device: str = "cuda" if torch.cuda.is_available() else "cpu",
                 config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Meta Agent
        
        Args:
            model_name: Name or path of the pre-trained model
            device: Device to run the model on
            config: Configuration dictionary
        """
        super().__init__()
        self.model_name = model_name
        self.device = device
        self.config = config or self._get_default_config()
        
        # Initialize components
        self._init_model()
        self._init_tokenizer()
        self._init_heads()
        
        # Move model to device
        self.to(device)
        
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            'hidden_size': 768,
            'num_action_types': 4,
            'num_tool_types': 3,
            'max_sequence_length': 512,
            'dropout_rate': 0.1,
            'learning_rate': 2e-5,
            'warmup_steps': 1000,
            'max_grad_norm': 1.0,
            'weight_decay': 0.01
        }
        
    def _init_model(self):
        """Initialize the base model"""
        self.base_model = AutoModel.from_pretrained(self.model_name)
        self.hidden_size = self.base_model.config.hidden_size
        
    def _init_tokenizer(self):
        """Initialize the tokenizer"""
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token
        
    def _init_heads(self):
        """Initialize prediction heads"""
        # Task-specific heads
        self.action_head = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.GELU(),
            nn.Dropout(self.config['dropout_rate']),
            nn.Linear(self.hidden_size, self.config['num_action_types'])
        )
        
        self.tool_head = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.GELU(),
            nn.Dropout(self.config['dropout_rate']),
            nn.Linear(self.hidden_size, self.config['num_tool_types'])
        )
        
        self.error_head = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.GELU(),
            nn.Dropout(self.config['dropout_rate']),
            nn.Linear(self.hidden_size, 1),
            nn.Sigmoid()
        )
        
        self.solution_validator = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.GELU(),
            nn.Dropout(self.config['dropout_rate']),
            nn.Linear(self.hidden_size, 1),
            nn.Sigmoid()
        )
        
    def forward(self,
                input_ids: torch.Tensor,
                attention_mask: torch.Tensor,
                labels: Optional[Dict[str, torch.Tensor]] = None) -> Dict[str, torch.Tensor]:
        """
        Forward pass
        
        Args:
            input_ids: Input token IDs
            attention_mask: Attention mask
            labels: Optional dictionary containing labels
            
        Returns:
            Dictionary containing model outputs and losses
        """
        # Get base model outputs
        outputs = self.base_model(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        
        # Get sequence representation
        sequence_output = outputs.last_hidden_state[:, 0, :]
        
        # Get predictions from each head
        action_logits = self.action_head(sequence_output)
        tool_logits = self.tool_head(sequence_output)
        error_prob = self.error_head(sequence_output)
        solution_valid_prob = self.solution_validator(sequence_output)
        
        outputs_dict = {
            'action_logits': action_logits,
            'tool_logits': tool_logits,
            'error_prob': error_prob,
            'solution_valid_prob': solution_valid_prob
        }
        
        # Calculate losses if labels are provided
        if labels is not None:
            losses = self._calculate_losses(outputs_dict, labels)
            outputs_dict.update(losses)
            
        return outputs_dict
        
    def _calculate_losses(self,
                         outputs: Dict[str, torch.Tensor],
                         labels: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Calculate losses for all tasks"""
        losses = {}
        
        # Action prediction loss
        if 'action_labels' in labels:
            losses['action_loss'] = nn.CrossEntropyLoss()(
                outputs['action_logits'],
                labels['action_labels']
            )
            
        # Tool selection loss
        if 'tool_labels' in labels:
            losses['tool_loss'] = nn.CrossEntropyLoss()(
                outputs['tool_logits'],
                labels['tool_labels']
            )
            
        # Error detection loss
        if 'error_labels' in labels:
            losses['error_loss'] = nn.BCELoss()(
                outputs['error_prob'].squeeze(),
                labels['error_labels'].float()
            )
            
        # Solution validation loss
        if 'solution_valid_labels' in labels:
            losses['solution_loss'] = nn.BCELoss()(
                outputs['solution_valid_prob'].squeeze(),
                labels['solution_valid_labels'].float()
            )
            
        # Calculate total loss
        losses['total_loss'] = sum(losses.values())
        
        return losses
        
    def train_model(self,
                   train_dataloader: DataLoader,
                   val_dataloader: Optional[DataLoader] = None,
                   num_epochs: int = 5,
                   learning_rate: float = 2e-5,
                   warmup_steps: int = 1000,
                   log_wandb: bool = False) -> Dict[str, List[float]]:
        """
        Train the model
        
        Args:
            train_dataloader: Training data loader
            val_dataloader: Validation data loader
            num_epochs: Number of training epochs
            learning_rate: Learning rate
            warmup_steps: Number of warmup steps
            log_wandb: Whether to log to Weights & Biases
            
        Returns:
            Dictionary containing training history
        """
        # Initialize optimizer and scheduler
        optimizer = torch.optim.AdamW(
            self.parameters(),
            lr=learning_rate,
            weight_decay=self.config['weight_decay']
        )
        
        num_training_steps = len(train_dataloader) * num_epochs
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=warmup_steps,
            num_training_steps=num_training_steps
        )
        
        # Initialize logging
        if log_wandb:
            wandb.init(project="meta-agent-training")
            
        # Training history
        history = {
            'train_loss': [],
            'val_loss': [],
            'action_accuracy': [],
            'tool_accuracy': [],
            'error_accuracy': [],
            'solution_accuracy': []
        }
        
        # Training loop
        for epoch in range(num_epochs):
            # Training phase
            self.train()
            train_losses = []
            
            with tqdm(train_dataloader, desc=f'Epoch {epoch+1}/{num_epochs}') as pbar:
                for batch in pbar:
                    # Prepare batch
                    batch = self.prepare_batch(batch)
                    
                    # Forward pass
                    outputs = self.forward(
                        input_ids=batch['input_ids'],
                        attention_mask=batch['attention_mask'],
                        labels=batch
                    )
                    
                    loss = outputs['total_loss']
                    
                    # Backward pass
                    optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(
                        self.parameters(),
                        self.config['max_grad_norm']
                    )
                    optimizer.step()
                    scheduler.step()
                    
                    # Update progress bar
                    train_losses.append(loss.item())
                    pbar.set_postfix({'loss': np.mean(train_losses[-100:])})
                    
                    # Log to wandb
                    if log_wandb:
                        wandb.log({
                            'train_loss': loss.item(),
                            'learning_rate': scheduler.get_last_lr()[0]
                        })
                        
            # Validation phase
            if val_dataloader is not None:
                val_metrics = self.validate(val_dataloader)
                
                # Update history
                history['train_loss'].append(np.mean(train_losses))
                history['val_loss'].append(val_metrics['val_loss'])
                history['action_accuracy'].append(val_metrics['action_accuracy'])
                history['tool_accuracy'].append(val_metrics['tool_accuracy'])
                history['error_accuracy'].append(val_metrics['error_accuracy'])
                history['solution_accuracy'].append(val_metrics['solution_accuracy'])
                
                # Log to wandb
                if log_wandb:
                    wandb.log(val_metrics)
                    
                # Print metrics
                print(f"\nValidation metrics:")
                for metric, value in val_metrics.items():
                    print(f"{metric}: {value:.4f}")
                    
        return history
        
    @torch.no_grad()
    def validate(self, dataloader: DataLoader) -> Dict[str, float]:
        """
        Validate the model
        
        Args:
            dataloader: Validation data loader
            
        Returns:
            Dictionary containing validation metrics
        """
        self.eval()
        val_losses = []
        action_preds = []
        action_labels = []
        tool_preds = []
        tool_labels = []
        error_preds = []
        error_labels = []
        solution_preds = []
        solution_labels = []
        
        for batch in tqdm(dataloader, desc='Validation'):
            # Prepare batch
            batch = self.prepare_batch(batch)
            
            # Forward pass
            outputs = self.forward(
                input_ids=batch['input_ids'],
                attention_mask=batch['attention_mask'],
                labels=batch
            )
            
            # Collect predictions and labels
            val_losses.append(outputs['total_loss'].item())
            
            action_preds.extend(outputs['action_logits'].argmax(dim=-1).cpu().numpy())
            action_labels.extend(batch['action_labels'].cpu().numpy())
            
            tool_preds.extend(outputs['tool_logits'].argmax(dim=-1).cpu().numpy())
            tool_labels.extend(batch['tool_labels'].cpu().numpy())
            
            error_preds.extend((outputs['error_prob'] > 0.5).squeeze().cpu().numpy())
            error_labels.extend(batch['error_labels'].cpu().numpy())
            
            solution_preds.extend((outputs['solution_valid_prob'] > 0.5).squeeze().cpu().numpy())
            solution_labels.extend(batch['solution_valid_labels'].cpu().numpy())
            
        # Calculate metrics
        metrics = {
            'val_loss': np.mean(val_losses),
            'action_accuracy': accuracy_score(action_labels, action_preds),
            'tool_accuracy': accuracy_score(tool_labels, tool_preds),
            'error_accuracy': accuracy_score(error_labels, error_preds),
            'solution_accuracy': accuracy_score(solution_labels, solution_preds)
        }
        
        return metrics
        
    def predict(self, query: str) -> Dict[str, Any]:
        """
        Make predictions for a query
        
        Args:
            query: Input query string
            
        Returns:
            Dictionary containing predictions
        """
        self.eval()
        
        # Tokenize input
        inputs = self.tokenizer(
            query,
            return_tensors='pt',
            max_length=self.config['max_sequence_length'],
            padding=True,
            truncation=True
        ).to(self.device)
        
        # Get predictions
        with torch.no_grad():
            outputs = self.forward(
                input_ids=inputs['input_ids'],
                attention_mask=inputs['attention_mask']
            )
            
        # Process outputs
        predictions = {
            'action': self._get_action_type(outputs['action_logits'].argmax(dim=-1).item()),
            'tool': self._get_tool_type(outputs['tool_logits'].argmax(dim=-1).item()),
            'error_probability': outputs['error_prob'].item(),
            'solution_valid_probability': outputs['solution_valid_prob'].item()
        }
        
        return predictions
        
    @staticmethod
    def _get_action_type(idx: int) -> str:
        """Get action type from index"""
        action_types = {
            0: 'calculate',
            1: 'retrieve',
            2: 'generate',
            3: 'analyze'
        }
        return action_types.get(idx, 'unknown')
        
    @staticmethod
    def _get_tool_type(idx: int) -> str:
        """Get tool type from index"""
        tool_types = {
            0: 'math_expert',
            1: 'code_expert',
            2: 'knowledge_expert'
        }
        return tool_types.get(idx, 'unknown')
