# models/decoder.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple, Dict
from transformers import LlamaForCausalLM, LlamaConfig

class DecoderLayer(nn.Module):
    def __init__(self,
                 hidden_size: int,
                 num_attention_heads: int,
                 intermediate_size: int,
                 dropout: float = 0.1):
        super().__init__()
        
        self.self_attn = nn.MultiheadAttention(hidden_size, num_attention_heads, dropout=dropout)
        self.cross_attn = nn.MultiheadAttention(hidden_size, num_attention_heads, dropout=dropout)
        
        self.linear1 = nn.Linear(hidden_size, intermediate_size)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(intermediate_size, hidden_size)
        
        self.norm1 = nn.LayerNorm(hidden_size)
        self.norm2 = nn.LayerNorm(hidden_size)
        self.norm3 = nn.LayerNorm(hidden_size)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)
        
    def forward(self,
                tgt: torch.Tensor,
                memory: torch.Tensor,
                tgt_mask: Optional[torch.Tensor] = None,
                memory_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Args:
            tgt: target sequence
            memory: encoded source sequence
            tgt_mask: mask for target sequence
            memory_mask: mask for source sequence
        """
        # Self attention
        tgt2 = self.norm1(tgt)
        q = k = v = tgt2
        tgt2 = self.self_attn(q, k, v, attn_mask=tgt_mask)[0]
        tgt = tgt + self.dropout1(tgt2)
        
        # Cross attention
        tgt2 = self.norm2(tgt)
        tgt2 = self.cross_attn(
            query=tgt2,
            key=memory,
            value=memory,
            attn_mask=memory_mask
        )[0]
        tgt = tgt + self.dropout2(tgt2)
        
        # Feed forward
        tgt2 = self.norm3(tgt)
        tgt2 = self.linear2(self.dropout(F.relu(self.linear1(tgt2))))
        tgt = tgt + self.dropout3(tgt2)
        
        return tgt

class Decoder(nn.Module):
    def __init__(self,
                 vocab_size: int,
                 hidden_size: int = 768,
                 num_layers: int = 6,
                 num_attention_heads: int = 8,
                 intermediate_size: int = 2048,
                 max_position_embeddings: int = 512,
                 dropout: float = 0.1,
                 pad_token_id: int = 0):
        super().__init__()
        
        # Token embeddings
        self.token_embedding = nn.Embedding(vocab_size, hidden_size, padding_idx=pad_token_id)
        self.position_embedding = nn.Embedding(max_position_embeddings, hidden_size)
        
        # Decoder layers
        self.layers = nn.ModuleList([
            DecoderLayer(
                hidden_size=hidden_size,
                num_attention_heads=num_attention_heads,
                intermediate_size=intermediate_size,
                dropout=dropout
            )
            for _ in range(num_layers)
        ])
        
        # Output layer
        self.output_layer = nn.Linear(hidden_size, vocab_size, bias=False)
        
        # Layer norm
        self.norm = nn.LayerNorm(hidden_size)
        
        # Initialize parameters
        self.init_weights()
        
    def init_weights(self):
        """Initialize weights."""
        initrange = 0.1
        self.token_embedding.weight.data.uniform_(-initrange, initrange)
        self.output_layer.weight.data.uniform_(-initrange, initrange)
        
    def generate_square_subsequent_mask(self, sz: int) -> torch.Tensor:
        """Generate causal mask for decoder."""
        mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask
        
    def forward(self,
                input_ids: torch.Tensor,
                encoder_hidden_states: torch.Tensor,
                attention_mask: Optional[torch.Tensor] = None,
                encoder_attention_mask: Optional[torch.Tensor] = None,
                labels: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        Forward pass of the decoder.
        
        Args:
            input_ids: Target sequence ids
            encoder_hidden_states: Hidden states from encoder
            attention_mask: Mask for target sequence
            encoder_attention_mask: Mask for encoder states
            labels: Target labels for computing loss
            
        Returns:
            dict containing:
                - logits: Predicted token logits
                - loss: Loss value if labels provided
                - hidden_states: Hidden states from all layers
        """
        
        device = input_ids.device
        seq_len = input_ids.size(1)
        
        # Create position ids
        position_ids = torch.arange(seq_len, dtype=torch.long, device=device).unsqueeze(0)
        
        # Get embeddings
        token_embeddings = self.token_embedding(input_ids)
        position_embeddings = self.position_embedding(position_ids)
        embeddings = token_embeddings + position_embeddings
        
        # Generate causal mask if needed
        if attention_mask is None:
            attention_mask = self.generate_square_subsequent_mask(seq_len).to(device)
            
        # Pass through decoder layers
        hidden_states = embeddings
        all_hidden_states = [hidden_states]
        
        for layer in self.layers:
            hidden_states = layer(
                hidden_states,
                encoder_hidden_states,
                attention_mask,
                encoder_attention_mask
            )
            all_hidden_states.append(hidden_states)
            
        # Final layer norm
        hidden_states = self.norm(hidden_states)
        
        # Get logits
        logits = self.output_layer(hidden_states)
        
        # Calculate loss if labels provided
        loss = None
        if labels is not None:
            loss_fct = nn.CrossEntropyLoss()
            loss = loss_fct(logits.view(-1, logits.size(-1)), labels.view(-1))
            
        return {
            "logits": logits,
            "loss": loss,
            "hidden_states": all_hidden_states
        }
        
    def generate(self,
                encoder_hidden_states: torch.Tensor,
                max_length: int,
                num_beams: int = 4,
                temperature: float = 1.0,
                top_k: int = 50,
                top_p: float = 0.9,
                no_repeat_ngram_size: int = 3) -> torch.Tensor:
        """
        Generate text using beam search and sampling strategies.
        """
        device = encoder_hidden_states.device
        batch_size = encoder_hidden_states.size(0)
        
        # Start with start token
        input_ids = torch.full((batch_size, 1), self.start_token_id, dtype=torch.long, device=device)
        
        # Keep track of scores for beam search
        scores = torch.zeros(batch_size, num_beams, device=device)
        
        for step in range(max_length):
            # Get logits
            outputs = self.forward(input_ids, encoder_hidden_states)
            next_token_logits = outputs["logits"][:, -1, :] / temperature
            
            # Apply top-k and top-p filtering
            next_token_logits = top_k_top_p_filtering(
                next_token_logits,
                top_k=top_k,
                top_p=top_p
            )
            
            # Sample next tokens
            probs = F.softmax(next_token_logits, dim=-1)
            if num_beams > 1:
                # Beam search
                next_scores, next_tokens = torch.topk(probs, num_beams, dim=-1)
                scores = scores.unsqueeze(-1) + next_scores
                scores = scores.view(-1)
                
                # Get top-k beams
                top_scores, top_indices = torch.topk(scores, num_beams)
                scores = top_scores
                beam_indices = top_indices // probs.size(-1)
                next_tokens = next_tokens.view(-1)[top_indices]
                
                # Update input_ids
                input_ids = torch.cat([input_ids[beam_indices], next_tokens.unsqueeze(-1)], dim=-1)
            else:
                # Greedy or sampling
                if temperature == 0:
                    next_tokens = torch.argmax(probs, dim=-1)
                else:
                    next_tokens = torch.multinomial(probs, num_samples=1).squeeze(1)
                
                # Update input_ids
                input_ids = torch.cat([input_ids, next_tokens.unsqueeze(-1)], dim=-1)
            
            # Check for end condition
            if (input_ids == self.eos_token_id).any(dim=-1).all():
                break
            
            # Check for no-repeat n-grams
            if no_repeat_ngram_size > 0:
                banned_batch_ids = []
                for batch_idx in range(input_ids.shape[0]):
                    banned_tokens = self._get_banned_ngram_tokens(
                        input_ids[batch_idx],
                        no_repeat_ngram_size
                    )
                    banned_batch_ids.append(banned_tokens)
                
                for batch_idx, banned_tokens in enumerate(banned_batch_ids):
                    probs[batch_idx, banned_tokens] = 0.0
        
        return input_ids

    def _get_banned_ngram_tokens(self, prev_tokens: torch.Tensor, ngram_size: int) -> List[int]:
        """Get tokens that would form repetitive n-grams."""
        banned_tokens = []
        
        if len(prev_tokens) >= ngram_size:
            # Extract the last n-gram
            generated_ngrams = {}
            prev_tokens_list = prev_tokens.tolist()
            
            for i in range(len(prev_tokens) - ngram_size + 1):
                ngram = tuple(prev_tokens_list[i:i + ngram_size])
                if ngram in generated_ngrams:
                    banned_tokens.extend(generated_ngrams[ngram])
                else:
                    generated_ngrams[ngram] = []
                
                if i == len(prev_tokens) - ngram_size:
                    # Add the next potential token to banned list
                    banned_tokens.extend(generated_ngrams.get(ngram[1:], []))
        
        return banned_tokens

def top_k_top_p_filtering(
    logits: torch.Tensor,
    top_k: int = 0,
    top_p: float = 1.0,
    filter_value: float = -float("Inf"),
    min_tokens_to_keep: int = 1
) -> torch.Tensor:
    """
    Filter a distribution of logits using top-k and/or nucleus (top-p) filtering.
    
    Args:
        logits: Logits distribution of shape (batch_size, vocabulary_size)
        top_k: Keep only top k tokens with highest probability
        top_p: Keep the top tokens with cumulative probability >= top_p
        filter_value: Value to assign to filtered tokens
        min_tokens_to_keep: Minimum number of tokens to keep
    """
    if top_k > 0:
        top_k = min(max(top_k, min_tokens_to_keep), logits.size(-1))
        # Remove all tokens with a probability less than the last token from top-k
        indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
        logits[indices_to_remove] = filter_value

    if top_p < 1.0:
        sorted_logits, sorted_indices = torch.sort(logits, descending=True)
        cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

        # Remove tokens with cumulative probability above the threshold
        sorted_indices_to_remove = cumulative_probs > top_p
        # Shift the indices to the right to keep also the first token above the threshold
        sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
        sorted_indices_to_remove[..., 0] = 0

        # Scatter sorted tensors to original indexing
        indices_to_remove = sorted_indices_to_remove.scatter(dim=1, index=sorted_indices, src=sorted_indices_to_remove)
        logits[indices_to_remove] = filter_value

    return logits

class DecoderConfig:
    """Configuration class for Decoder."""
    def __init__(self,
                 vocab_size: int = 50257,
                 hidden_size: int = 768,
                 num_layers: int = 6,
                 num_attention_heads: int = 8,
                 intermediate_size: int = 2048,
                 max_position_embeddings: int = 512,
                 dropout: float = 0.1,
                 pad_token_id: int = 0,
                 bos_token_id: int = 1,
                 eos_token_id: int = 2):
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.num_attention_heads = num_attention_heads
        self.intermediate_size = intermediate_size
        self.max_position_embeddings = max_position_embeddings
        self.dropout = dropout
        self.pad_token_id = pad_token_id
        self.bos_token_id = bos_token_id
        self.eos_token_id = eos_token_id