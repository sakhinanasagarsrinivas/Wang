import torch
import torch.nn as nn
import torch.nn.functional as F
import openai
from PIL import Image
import base64
import io
from torchvision import transforms

class LMMModule(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.projection = nn.Linear(config.num_classes, config.embed_dim)
        openai.api_key = config.gpt4_api_key
        
    def _encode_image(self, image_tensor):
        """Convert tensor to base64 encoded image."""
        # Convert tensor to PIL Image
        image = transforms.ToPILImage()(image_tensor)
        buffered = io.BytesIO()
        image.save(buffered, format="JPEG")
        img_str = base64.b64encode(buffered.getvalue()).decode()
        return img_str
        
    def get_demonstrations(self, train_dataset, query_image, k=5, strategy="similarity"):
        """Get few-shot demonstrations."""
        if strategy == "random":
            indices = torch.randperm(len(train_dataset))[:k]
            demos = [train_dataset[i] for i in indices]
        else:  # similarity-based
            # Get embeddings for all training images
            query_features = self.extract_features(query_image)
            similarities = []
            
            for i in range(len(train_dataset)):
                sample = train_dataset[i]
                sample_features = self.extract_features(sample['image'])
                similarity = F.cosine_similarity(query_features, sample_features)
                similarities.append((i, similarity))
            
            # Get top-k similar samples
            similarities.sort(key=lambda x: x[1], reverse=True)
            demos = [train_dataset[idx] for idx, _ in similarities[:k]]
            
        return demos

    def extract_features(self, image):
        """Extract features from image using GPT-4V."""
        img_str = self._encode_image(image)
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4-vision-preview",
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": "Extract visual features from this electron micrograph."
                            },
                            {
                                "type": "image_url",
                                "image_url": f"data:image/jpeg;base64,{img_str}"
                            }
                        ]
                    }
                ],
                max_tokens=300
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error extracting features: {e}")
            return ""

    def create_few_shot_prompt(self, demonstrations, query_image):
        """Create prompt with demonstrations and query image."""
        prompt = "Classify the nanomaterial in the electron micrograph. Here are some examples:\n\n"
        
        # Add demonstrations
        for i, demo in enumerate(demonstrations, 1):
            img_str = self._encode_image(demo['image'])
            prompt += f"Example {i}:\n"
            prompt += f"[Image: {img_str}]\n"
            prompt += f"Category: {demo['category']}\n\n"
        
        # Add query image
        query_img_str = self._encode_image(query_image)
        prompt += "Now classify this image:\n"
        prompt += f"[Image: {query_img_str}]\n"
        
        return prompt

    def get_prediction(self, prompt):
        """Get prediction from GPT-4V using few-shot prompt."""
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4-vision-preview",
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in nanomaterial classification."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=50
            )
            prediction = response.choices[0].message.content
            return prediction
        except Exception as e:
            print(f"Error getting prediction: {e}")
            return ""

    def get_prediction_embedding(self, prediction, categories):
        """Convert prediction to embedding."""
        # Create one-hot vector based on prediction
        pred_vector = torch.zeros(self.config.num_classes)
        if prediction in categories:
            pred_idx = categories.index(prediction)
            pred_vector[pred_idx] = 1.0
        
        # Project to embedding space
        pred_embedding = self.projection(pred_vector)
        return pred_embedding

    def forward(self, query_image, train_dataset, categories):
        """Forward pass for LMM module."""
        # Get demonstrations
        demos = self.get_demonstrations(train_dataset, query_image, k=5)
        
        # Create prompt with demonstrations
        prompt = self.create_few_shot_prompt(demos, query_image)
        
        # Get prediction from GPT-4V
        prediction = self.get_prediction(prompt)
        
        # Convert prediction to embedding
        pred_embedding = self.get_prediction_embedding(prediction, categories)
        
        return pred_embedding