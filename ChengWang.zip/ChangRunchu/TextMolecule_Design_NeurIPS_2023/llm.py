from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from typing import List, Dict, Tuple
import torch

class MoleculeLLM:
    """Class for handling LLM interactions"""
    
    def __init__(
        self,
        model_name: str,
        temperature: float,
        max_tokens: int
    ):
        """
        Args:
            model_name: Name of the LLM model to use
            temperature: Temperature for LLM sampling
            max_tokens: Maximum tokens in LLM response
        """
        self.model_name = model_name
        
        # Initialize LLM based on model type
        if "gpt-4" in model_name or "gpt-3.5" in model_name:
            self.llm = ChatOpenAI(
                model_name=model_name,
                temperature=temperature,
                max_tokens=max_tokens
            )
        else:
            self.llm = OpenAI(
                model_name=model_name,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
        # Create prompt template
        self.prompt_template = PromptTemplate(
            input_variables=["examples", "query"],
            template=(
                "Below are the textual descriptions – chemical SMILES representation pairs. "
                "Generate the chemical SMILES representation for the textual description provided below.\n\n"
                "{examples}\n"
                "Text: {query}\n"
                "SMILES:"
            )
        )
        
        # Create LLM chain
        self.chain = LLMChain(
            llm=self.llm,
            prompt=self.prompt_template
        )
        
    def format_examples(self, examples: List[Dict[str, str]]) -> str:
        """Format examples for the prompt"""
        formatted = ""
        for example in examples:
            formatted += f"Text: {example['text']}\n"
            formatted += f"SMILES: {example['smiles']}\n\n"
        return formatted
        
    def generate(
        self,
        query_text: str,
        examples: List[Dict[str, str]]
    ) -> Tuple[List[str], str]:
        """
        Generate SMILES and explanation for input text
        
        Args:
            query_text: Input text description
            examples: List of demonstration examples
            
        Returns:
            Tuple of (list of SMILES predictions, explanation text)
        """
        # Format examples
        formatted_examples = self.format_examples(examples)
        
        # Generate response
        response = self.chain.run({
            "examples": formatted_examples,
            "query": query_text
        })
        
        # Split into predictions and explanation
        parts = response.split("Explanation:")
        if len(parts) > 1:
            predictions_text = parts[0].strip()
            explanation = parts[1].strip()
        else:
            predictions_text = response.strip()
            explanation = ""
            
        # Extract SMILES predictions
        predictions = []
        for line in predictions_text.split('\n'):
            if line.startswith('SMILES:'):
                smiles = line.split('SMILES:')[1].strip()
                predictions.append(smiles)
                
        return predictions, explanation

    def get_embeddings(self, texts: List[str]) -> torch.Tensor:
        """
        Get embeddings for text using the LLM
        
        Args:
            texts: List of input texts
            
        Returns:
            Tensor of embeddings
        """
        embeddings = []
        for text in texts:
            # Generate embedding using LLM's hidden states
            response = self.chain.llm.get_embedding(text)
            embeddings.append(torch.tensor(response))
            
        return torch.stack(embeddings)