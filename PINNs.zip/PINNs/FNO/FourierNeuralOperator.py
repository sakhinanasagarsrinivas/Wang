import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import json
import argparse
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.interpolate import interp1d
import time
import os
from functools import partial
from torch.amp import GradScaler, autocast

torch.manual_seed(42)
np.random.seed(42)

class GaussianRandomField:
    def __init__(self, size, length_scale, device='cpu'):
        self.size = size
        self.device = device
        freqs = torch.fft.rfftfreq(size, d=1/size).to(device)
        self.power_spectrum = (1.0 / (2.0 * np.pi * length_scale**2)) * \
                              torch.exp(-0.5 * freqs**2 * length_scale**2)
        self.power_spectrum[0] = 0

    def sample(self, n_samples, mean=0.0, stddev=1.0):
        rand_coeffs = (torch.randn(n_samples, self.size // 2 + 1, dtype=torch.cfloat, device=self.device) *
                       np.sqrt(self.size))
        f_coeffs = rand_coeffs * torch.sqrt(self.power_spectrum)
        field = torch.fft.irfft(f_coeffs, n=self.size, norm='ortho')
        field_std = torch.std(field, dim=-1, keepdim=True)
        field = field / (field_std + 1e-8) * stddev
        field += mean
        return field.unsqueeze(-1)

class SpectralConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, modes):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes = modes
        self.scale = (1 / (in_channels * out_channels))
        self.weights = nn.Parameter(self.scale * torch.rand(in_channels, out_channels, self.modes, dtype=torch.cfloat))

    def forward(self, x):
        batchsize, n_points, _ = x.shape
        
        with autocast(device_type=x.device.type, enabled=False):
            x_float32 = x.float()
            x_ft = torch.fft.rfft(x_float32, dim=1)
            out_ft = torch.zeros(batchsize, n_points // 2 + 1, self.out_channels,
                               dtype=x_ft.dtype, device=x.device)
            
            weights_float32 = self.weights.cfloat()
            
            out_ft[:, :self.modes, :] = torch.einsum("bmi,iom->bmo",
                                                   x_ft[:, :self.modes, :], weights_float32)
            
            result = torch.fft.irfft(out_ft, n=n_points, dim=1)
        
        return result.to(x.dtype)

class FNOBlock(nn.Module):
    def __init__(self, modes, width):
        super().__init__()
        self.conv = SpectralConv1d(width, width, modes)
        self.w = nn.Conv1d(width, width, 1)
        self.norm = nn.LayerNorm(width)

    def forward(self, x):
        residual = x
        x1 = self.conv(x)
        x2 = self.w(x.permute(0, 2, 1)).permute(0, 2, 1)
        out = self.norm(x1 + x2)
        return F.gelu(out) + residual

class FNO1d(nn.Module):
    def __init__(self, modes, width, in_channels, out_channels, num_blocks):
        super().__init__()
        self.fc0 = nn.Linear(in_channels, width)
        self.fno_blocks = nn.ModuleList([FNOBlock(modes, width) for _ in range(num_blocks)])
        self.fc1 = nn.Linear(width, 128)
        self.fc2 = nn.Linear(128, out_channels)
        self.apply(self._initialize_weights)

    def _initialize_weights(self, m):
        if isinstance(m, (nn.Linear, nn.Conv1d)):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)

    def forward(self, x):
        x = self.fc0(x)
        for block in self.fno_blocks:
            x = block(x)
        x = self.fc1(x)
        x = F.gelu(x)
        x = self.fc2(x)
        return x

class PINOSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")

        self._parse_config()
        self._setup_grid_and_data_generator()
        self._build_model()
        self.scaler = GradScaler(enabled=False)

    def _parse_config(self):
        self.problem = self.config['problem_definition']
        self.op_inputs = self.config['operator_input_specification']
        self.hp_model = self.config['hyperparameters']['fno_architecture']
        self.hp_train = self.config['hyperparameters']['training']
        self.state_vars = self.problem['state_variables']
        self.num_vars = len(self.state_vars)
        self.ic_ranges = self.op_inputs['initial_conditions_distribution']
        self.forcing_func_config = self.op_inputs['function_inputs']['CA0_t']
        self.hp_train['curriculum_schedule'] = self.hp_train.get('curriculum_schedule', {'enabled': False})

    def _setup_grid_and_data_generator(self):
        self.t_domain = self.op_inputs['discretization']['time_domain']
        self.nt = self.op_inputs['discretization']['num_time_points']
        self.t_grid = torch.linspace(self.t_domain[0], self.t_domain[1], self.nt, device=self.device).view(-1, 1)
        grf_params = self.forcing_func_config['parameters']
        self.grf = GaussianRandomField(self.nt, grf_params['length_scale'], device=self.device)
        self.grf_mean = grf_params['mean']
        self.grf_std = grf_params['stddev']

    def _build_model(self):
        in_channels = 1 + self.num_vars + 1
        out_channels = self.num_vars
        self.model = FNO1d(
            modes=self.hp_model['modes'],
            width=self.hp_model['width'],
            in_channels=in_channels,
            out_channels=out_channels,
            num_blocks=self.hp_model['num_blocks']
        ).to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.hp_train['learning_rate'],
            weight_decay=self.hp_train['weight_decay']
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=self.hp_train['epochs'])

    def _generate_batch(self, batch_size):
        forcing_funcs = self.grf.sample(batch_size, self.grf_mean, self.grf_std)
        ics = []
        for var in self.state_vars:
            low, high = self.ic_ranges[var]
            ic = torch.rand(batch_size, 1, 1, device=self.device) * (high - low) + low
            ics.append(ic)
        batch_ics = torch.cat(ics, dim=-1)
        ics_grid = batch_ics.repeat(1, self.nt, 1)
        grid = self.t_grid.unsqueeze(0).repeat(batch_size, 1, 1) / self.t_domain[1]
        model_input = torch.cat([forcing_funcs, ics_grid, grid], dim=-1)
        return model_input, forcing_funcs, batch_ics.squeeze(1)

    def _physics_residual_loss(self, u_pred, forcing_funcs, epoch):
        with autocast(device_type=u_pred.device.type, enabled=False):
            u_pred_float32 = u_pred.float()
            u_ft = torch.fft.rfft(u_pred_float32, dim=1)
            freqs = torch.fft.rfftfreq(self.nt, d=(self.t_domain[1] / self.nt)).to(self.device)
            k_op = (2j * torch.pi) * freqs.view(1, -1, 1)
            du_dt_ft = k_op * u_ft
            du_dt = torch.fft.irfft(du_dt_ft, n=self.nt, dim=1)

        du_dt = du_dt.to(u_pred.dtype)

        V = self.problem['parameters']['V']
        k = self.problem['parameters']['k']
        F_t = float(self.problem['time_varying_parameter']['F_t'])
        CA0_t = forcing_funcs.squeeze(-1)
        CA1 = u_pred[..., 0]
        CA2 = u_pred[..., 1]

        rhs1 = (F_t / V) * (CA0_t - CA1) - k * CA1
        rhs2 = (F_t / V) * (CA1 - CA2) - k * CA2

        residual1 = du_dt[..., 0] - rhs1
        residual2 = du_dt[..., 1] - rhs2

        curriculum_cfg = self.hp_train['curriculum_schedule']
        if curriculum_cfg.get('enabled', False):
            end_epoch = curriculum_cfg.get('end_epoch', self.hp_train['epochs'])
            start_fraction = curriculum_cfg.get('start_fraction', 0.1)
            
            current_progress = min(epoch / end_epoch, 1.0)
            current_fraction = start_fraction + (1.0 - start_fraction) * current_progress
            
            num_points_to_include = max(1, int(self.nt * current_fraction))
            mask = torch.zeros_like(residual1)
            mask[:, :num_points_to_include] = 1.0
            
            masked_residual1 = residual1 * mask
            masked_residual2 = residual2 * mask
            
            loss1 = torch.sum(masked_residual1**2) / (u_pred.shape[0] * num_points_to_include)
            loss2 = torch.sum(masked_residual2**2) / (u_pred.shape[0] * num_points_to_include)
            total_residual_loss = loss1 + loss2
        else:
            total_residual_loss = torch.mean(residual1**2) + torch.mean(residual2**2)
            
        return total_residual_loss

    def _ic_loss(self, u_pred, batch_ics):
        u_pred_ic = u_pred[:, 0, :]
        return F.mse_loss(u_pred_ic, batch_ics)

    def train(self):
        print("--- Starting PINO Training ---")
        start_time = time.time()
        self.model.train()

        annealing_cfg = self.hp_train.get('annealing_schedule', {})
        use_annealing = annealing_cfg.get('enabled', False)
        
        if use_annealing:
            ic_weight_start = self.hp_train['loss_weights']['initial_condition']
            ic_weight_final = annealing_cfg['ic_weight_final']
            annealing_end_epoch = annealing_cfg['annealing_end_epoch']
            print(f"Using IC weight annealing: start={ic_weight_start}, end={ic_weight_final}, duration={annealing_end_epoch} epochs.")
        else:
            static_ic_weight = self.hp_train['loss_weights']['initial_condition']
            
        curriculum_enabled = self.hp_train['curriculum_schedule'].get('enabled', False)
        if curriculum_enabled:
            print(f"Using curriculum learning until epoch {self.hp_train['curriculum_schedule']['end_epoch']}.")

        for epoch in range(self.hp_train['epochs']):
            model_input, forcing_funcs, batch_ics = self._generate_batch(self.hp_train['batch_size'])
            
            self.optimizer.zero_grad(set_to_none=True)
            
            u_pred = self.model(model_input)
            loss_res = self._physics_residual_loss(u_pred, forcing_funcs, epoch)
            loss_ic = self._ic_loss(u_pred, batch_ics)
            
            if use_annealing:
                if epoch < annealing_end_epoch:
                    progress = epoch / annealing_end_epoch
                    current_ic_weight = ic_weight_final + 0.5 * (ic_weight_start - ic_weight_final) * (1 + np.cos(np.pi * progress))
                else:
                    current_ic_weight = ic_weight_final
            else:
                current_ic_weight = static_ic_weight
                
            total_loss = (self.hp_train['loss_weights']['ode_residual'] * loss_res +
                          current_ic_weight * loss_ic)

            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            self.scheduler.step()

            if (epoch + 1) % 1000 == 0:
                log_msg = (f'Epoch [{epoch+1}/{self.hp_train["epochs"]}], Loss: {total_loss.item():.4e}, '
                           f'ODE Loss: {loss_res.item():.4e}, IC Loss: {loss_ic.item():.4e}')
                if use_annealing:
                    log_msg += f', IC Weight: {current_ic_weight:.2f}'
                print(log_msg)
        
        elapsed = time.time() - start_time
        print(f"--- Training finished in {elapsed:.2f} seconds ---")

    def evaluate_and_plot(self, num_test_cases=4):
        self.model.eval()
        os.makedirs("results_pino", exist_ok=True)
        model_input, forcing_funcs, batch_ics = self._generate_batch(num_test_cases)
        with torch.no_grad():
            u_pino = self.model(model_input).cpu()
        
        t_np = self.t_grid.cpu().numpy().flatten()
        forcing_np = forcing_funcs.cpu().numpy()
        ics_np = batch_ics.cpu().numpy()

        fig, axes = plt.subplots(num_test_cases, self.num_vars, figsize=(14, 4 * num_test_cases), squeeze=False)
        all_errors = []

        for i in range(num_test_cases):
            sol_numerical_np = self.solve_numerically(t_np, ics_np[i], forcing_np[i, :, 0])
            sol_numerical = torch.from_numpy(sol_numerical_np)

            relative_l2_error = torch.norm(u_pino[i] - sol_numerical) / torch.norm(sol_numerical)
            all_errors.append(relative_l2_error.item())
            print(f"Test Case {i+1} | ICs: {dict(zip(self.state_vars, np.round(ics_np[i], 3)))} | Rel L2 Error: {relative_l2_error.item():.4e}")

            for j, var in enumerate(self.state_vars):
                ax = axes[i, j]
                ax.plot(t_np, sol_numerical_np[:, j], 'k-', label='Numerical', linewidth=2)
                ax.plot(t_np, u_pino[i, :, j], 'r--', label='PINO')
                ax.set_ylabel(var)
                ax.grid(True, linestyle='--', alpha=0.6)
                if i == 0:
                    ax.set_title(f'Solution for {var}')
                if i == num_test_cases - 1:
                    ax.set_xlabel('Time (t)')
                ax.legend()
        
        print(f"\nMean Relative L2 Error over {num_test_cases} cases: {np.mean(all_errors):.4e}")
        fig.suptitle('PINO Generalization on Unseen Forcing Functions and ICs', fontsize=16)
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.savefig("results_pino/pino_generalization_test.pdf")
        plt.close()
        print("\nEvaluation plot saved to results_pino/pino_generalization_test.pdf")

    def solve_numerically(self, t_eval, y0, forcing_func_values):
        forcing_interp = interp1d(t_eval, forcing_func_values, bounds_error=False, fill_value="extrapolate")
        
        def ode_system(t, y):
            scope = {'t': t, 'CA0_t': forcing_interp(t)}
            scope.update(self.problem['parameters'])
            scope['F_t'] = float(self.problem['time_varying_parameter']['F_t'])
            for i, var in enumerate(self.state_vars):
                scope[var] = y[i]
            dydt = [eval(self.problem['odes'][f"d{var}dt"], {}, scope) for var in self.state_vars]
            return dydt
            
        sol = solve_ivp(ode_system, self.t_domain, y0, t_eval=t_eval, method='DOP853', rtol=1e-8, atol=1e-10)
        return sol.y.T

def main():
    parser = argparse.ArgumentParser(description="Physics-Informed Neural Operator Solver")
    parser.add_argument(
        "config_file", type=str,
        help="Path to the JSON configuration file.",
        default="problem_config.json", nargs='?'
    )
    args = parser.parse_args()
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    
    problem_spec = config['problems'][0]
    
    solver_config = {
        'problem_definition': problem_spec['problem_definition'],
        'operator_input_specification': problem_spec['operator_input_specification'],
        'hyperparameters': config['hyperparameters']
    }
    
    solver = PINOSolver(solver_config)
    
    solver.train()
    solver.evaluate_and_plot()

if __name__ == "__main__":
    main()