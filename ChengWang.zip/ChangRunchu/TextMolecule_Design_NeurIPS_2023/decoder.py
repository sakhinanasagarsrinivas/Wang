import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple

class TransformerDecoderLayer(nn.Module):
    """Single layer of transformer decoder"""
    
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        d_ff: int = 2048,
        dropout: float = 0.1
    ):
        super().__init__()
        
        # Self attention
        self.self_attn = nn.MultiheadAttention(d_model, num_heads, dropout=dropout)
        self.norm1 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        
        # Cross attention
        self.cross_attn = nn.MultiheadAttention(d_model, num_heads, dropout=dropout)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout2 = nn.Dropout(dropout)
        
        # Feed forward
        self.ff = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model)
        )
        self.norm3 = nn.LayerNorm(d_model)
        self.dropout3 = nn.Dropout(dropout)
        
    def forward(
        self,
        x: torch.Tensor,
        memory: torch.Tensor,
        tgt_mask: Optional[torch.Tensor] = None,
        memory_mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Forward pass through decoder layer
        
        Args:
            x: Input tensor
            memory: Encoder output tensor
            tgt_mask: Optional mask for self attention
            memory_mask: Optional mask for cross attention
            
        Returns:
            Decoded tensor
        """
        # Self attention
        attn_out, _ = self.self_attn(x, x, x, attn_mask=tgt_mask)
        x = x + self.dropout1(attn_out)
        x = self.norm1(x)
        
        # Cross attention
        attn_out, _ = self.cross_attn(x, memory, memory, attn_mask=memory_mask)
        x = x + self.dropout2(attn_out)
        x = self.norm2(x)
        
        # Feed forward
        ff_out = self.ff(x)
        x = x + self.dropout3(ff_out)
        x = self.norm3(x)
        
        return x

class SMILESDecoder(nn.Module):
    """Transformer decoder for SMILES generation"""
    
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        num_layers: int = 6,
        num_heads: int = 8,
        d_ff: int = 2048,
        dropout: float = 0.1
    ):
        super().__init__()
        
        self.embedding = nn.Embedding(vocab_size, d_model)
        self.pos_encoding = PositionalEncoding(d_model, dropout)
        
        self.layers = nn.ModuleList([
            TransformerDecoderLayer(d_model, num_heads, d_ff, dropout)
            for _ in range(num_layers)
        ])
        
        self.output_projection = nn.Linear(d_model, vocab_size)
        
    def generate_square_subsequent_mask(self, sz: int) -> torch.Tensor:
        """Generate mask for autoregressive decoding"""
        mask = torch.triu(torch.ones(sz, sz), diagonal=1).bool()
        return mask
        
    def forward(
        self,
        tgt: torch.Tensor,
        memory: torch.Tensor,
        tgt_mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Forward pass through decoder
        
        Args:
            tgt: Target sequence
            memory: Encoder output
            tgt_mask: Optional target mask
            
        Returns:
            Decoded logits
        """
        x = self.embedding(tgt)
        x = self.pos_encoding(x)
        
        for layer in self.layers:
            x = layer(x, memory, tgt_mask)
            
        return self.output_projection(x)