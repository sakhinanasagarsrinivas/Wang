# models/text_encoder.py
import torch
import torch.nn as nn
from transformers import LlamaModel
from peft import prepare_model_for_kbit_training, LoraConfig, get_peft_model
import math

class DynamicLoRALayer(nn.Module):
    """Dynamic Low-Rank Adaptation layer with variable rank"""
    def __init__(self, in_features, out_features, rank_min, rank_max):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.rank_min = rank_min
        self.rank_max = rank_max
        
        # Initialize max rank matrices
        self.lora_A = nn.Parameter(torch.zeros(rank_max, in_features))
        self.lora_B = nn.Parameter(torch.zeros(out_features, rank_max))
        
        # Initialize with scaled random values
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)
        
    def forward(self, x, current_rank):
        # Use only the first current_rank vectors
        A = self.lora_A[:current_rank, :]
        B = self.lora_B[:, :current_rank]
        
        # Compute LoRA adjustment
        adjustment = (B @ A) @ x.transpose(-1, -2)
        return adjustment.transpose(-1, -2)

class DyQLoRAFA(nn.Module):
    """Dynamic Quantized LoRA with Fast Attention memory reduction"""
    def __init__(self, config):
        super().__init__()
        
        # Load base model in 8-bit
        self.base_model = LlamaModel.from_pretrained(
            'meta-llama/Llama-2-7b',
            load_in_8bit=True,
            device_map="auto"
        )
        
        # Prepare model for training
        self.base_model = prepare_model_for_kbit_training(self.base_model)
        
        # Add dynamic LoRA layers
        self.lora_layers = nn.ModuleList([
            DynamicLoRALayer(
                config.text_hidden_dim,
                config.text_hidden_dim,
                config.rank_min,
                config.rank_max
            )
            for _ in range(config.text_num_hidden_layers)
        ])
        
        # Freeze base model parameters
        for param in self.base_model.parameters():
            param.requires_grad = False
            
        self.config = config
        
    def forward(self, input_ids, attention_mask):
        # Get base model outputs
        base_outputs = self.base_model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=True
        )
        
        hidden_states = base_outputs.hidden_states
        
        # Randomly select current rank for dynamic LoRA
        current_rank = torch.randint(
            self.config.rank_min,
            self.config.rank_max + 1,
            (1,)
        ).item()
        
        # Apply LoRA adjustments
        for idx, layer in enumerate(self.lora_layers):
            hidden_states[idx] = hidden_states[idx] + layer(
                hidden_states[idx],
                current_rank
            )
        
        return hidden_states[-1]

# models/attention.py
import torch
import torch.nn as nn
import math

class GatedCrossAttention(nn.Module):
    """Gated Cross-Attention mechanism as described in the paper"""
    def __init__(self, config):
        super().__init__()
        self.num_heads = config.num_cross_attention_heads
        self.hidden_dim = config.hidden_dim
        self.head_dim = self.hidden_dim // self.num_heads
        self.scaling = self.head_dim ** -0.5
        
        # Multi-head projections
        self.q_proj = nn.Linear(config.text_hidden_dim, self.hidden_dim)
        self.k_proj = nn.Linear(config.vision_hidden_dim, self.hidden_dim)
        self.v_proj = nn.Linear(config.vision_hidden_dim, self.hidden_dim)
        
        # Gating mechanism
        self.gate = nn.Linear(config.text_hidden_dim, self.hidden_dim)
        self.gate_activation = nn.Sigmoid()
        
        # Output projection
        self.out_proj = nn.Linear(self.hidden_dim, config.text_hidden_dim)
        
        # Layer normalization
        self.layer_norm1 = nn.LayerNorm(config.text_hidden_dim)
        self.layer_norm2 = nn.LayerNorm(config.vision_hidden_dim)
        
        self.dropout = nn.Dropout(config.cross_attention_dropout)
        
    def forward(self, text_features, visual_features, attention_mask=None):
        batch_size = text_features.size(0)
        
        # Apply layer normalization
        text_features = self.layer_norm1(text_features)
        visual_features = self.layer_norm2(visual_features)
        
        # Project to query, key, value
        q = self.q_proj(text_features)
        k = self.k_proj(visual_features)
        v = self.v_proj(visual_features)
        
        # Reshape for multi-head attention
        q = q.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Compute scaled dot-product attention
        attn_weights = torch.matmul(q, k.transpose(-2, -1)) * self.scaling
        
        if attention_mask is not None:
            attn_weights = attn_weights.masked_fill(attention_mask.unsqueeze(1).unsqueeze(2) == 0, float('-inf'))
        
        attn_weights = torch.softmax(attn_weights, dim=-1)
        attn_weights = self.dropout(attn_weights)
        
        # Compute attention output
        attention_output = torch.matmul(attn_weights, v)
        
        # Compute gating values
        gate_values = self.gate(text_features)
        gate_values = self.gate_activation(gate_values)
        gate_values = gate_values.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Apply gating
        gated_output = attention_output * gate_values
        
        # Reshape and project output
        output = gated_output.transpose(1, 2).contiguous()
        output = output.view(batch_size, -1, self.hidden_dim)
        output = self.out_proj(output)
        
        return output

class SelfAttentionBlock(nn.Module):
    """Self-attention block with feed-forward layer"""
    def __init__(self, config):
        super().__init__()
        self.attention = nn.MultiheadAttention(
            config.hidden_dim,
            config.num_cross_attention_heads,
            dropout=config.dropout
        )
        
        # Feed-forward network
        self.feed_forward = nn.Sequential(
            nn.Linear(config.hidden_dim, config.hidden_dim * 4),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim * 4, config.hidden_dim),
            nn.Dropout(config.dropout)
        )
        
        # Layer normalization
        self.norm1 = nn.LayerNorm(config.hidden_dim)
        self.norm2 = nn.LayerNorm(config.hidden_dim)
        
    def forward(self, x, attention_mask=None):
        # Self attention with residual connection
        residual = x
        x = self.norm1(x)
        x, _ = self.attention(x, x, x, attn_mask=attention_mask)
        x = residual + x
        
        # Feed-forward with residual connection
        residual = x
        x = self.norm2(x)
        x = self.feed_forward(x)
        x = residual + x
        
        return x


