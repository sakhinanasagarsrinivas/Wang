from typing import Dict, List, Any, Optional
from pathlib import Path
import json
import yaml
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from .metrics import MetricsCalculator

class Evaluator:
    def __init__(self, config_path: str):
        """
        Initialize evaluator with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.metrics_calculator = MetricsCalculator(config_path)
        self.logger = self._setup_logger()
        
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
            
    def _setup_logger(self) -> logging.Logger:
        """Setup logging configuration."""
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            
        return logger
        
    def evaluate_model(
        self,
        model,
        test_data: List[Dict],
        output_dir: str,
        batch_size: int = 32,
        num_workers: int = 4
    ) -> Dict[str, Any]:
        """
        Evaluate model performance on test data.
        
        Args:
            model: Model to evaluate
            test_data: List of test samples
            output_dir: Directory to save results
            batch_size: Batch size for evaluation
            num_workers: Number of worker threads
            
        Returns:
            Dictionary containing evaluation results
        """
        self.logger.info("Starting model evaluation...")
        
        # Create output directory
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Process test data in batches
        results = []
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = []
            for i in range(0, len(test_data), batch_size):
                batch = test_data[i:i + batch_size]
                future = executor.submit(
                    self._process_batch,
                    model,
                    batch
                )
                futures.append(future)

            # Collect results with progress bar
            for future in tqdm(
                as_completed(futures),
                total=len(futures),
                desc="Processing batches"
            ):
                try:
                    batch_results = future.result()
                    results.extend(batch_results)
                except Exception as e:
                    self.logger.error(f"Error processing batch: {str(e)}")

        # Calculate aggregate metrics
        metrics = self._calculate_aggregate_metrics(results)
        
        # Save results
        self._save_results(metrics, results, output_path)
        
        self.logger.info("Evaluation completed successfully.")
        return metrics

    def _process_batch(
        self,
        model,
        batch: List[Dict]
    ) -> List[Dict]:
        """
        Process a batch of test samples.
        
        Args:
            model: Model to evaluate
            batch: List of test samples
            
        Returns:
            List of dictionaries containing results for each sample
        """
        batch_results = []
        
        for sample in batch:
            try:
                # Get model predictions
                predictions = self._get_model_predictions(model, sample)
                
                # Calculate metrics for this sample
                sample_metrics = self.metrics_calculator.calculate_diagram_metrics(
                    predictions,
                    sample['ground_truth']
                )
                
                batch_results.append({
                    'sample_id': sample['id'],
                    'predictions': predictions,
                    'ground_truth': sample['ground_truth'],
                    'metrics': sample_metrics
                })
                
            except Exception as e:
                self.logger.error(f"Error processing sample {sample.get('id', 'unknown')}: {str(e)}")
                continue
                
        return batch_results

    def _get_model_predictions(self, model, sample: Dict) -> Dict:
        """
        Get model predictions for a sample.
        
        Args:
            model: Model to evaluate
            sample: Test sample
            
        Returns:
            Dictionary containing model predictions
        """
        try:
            # Handle different types of inputs
            if 'image' in sample:
                predictions = model.process_image(sample['image'])
            elif 'text' in sample:
                predictions = model.process_text(sample['text'])
            elif 'diagram' in sample:
                predictions = model.process_diagram(sample['diagram'])
            else:
                raise ValueError("Unknown sample format")
                
            return predictions
            
        except Exception as e:
            self.logger.error(f"Error getting predictions: {str(e)}")
            return {}

    def _calculate_aggregate_metrics(self, results: List[Dict]) -> Dict[str, Any]:
        """
        Calculate aggregate metrics across all results.
        
        Args:
            results: List of results for all samples
            
        Returns:
            Dictionary containing aggregate metrics
        """
        aggregate_metrics = {
            'overall': {},
            'component_detection': {},
            'flow_analysis': {},
            'equipment_identification': {}
        }
        
        # Collect all metrics
        for result in results:
            metrics = result['metrics']
            for category in aggregate_metrics:
                if category in metrics:
                    for metric_name, value in metrics[category].items():
                        if metric_name not in aggregate_metrics[category]:
                            aggregate_metrics[category][metric_name] = []
                        aggregate_metrics[category][metric_name].append(value)
        
        # Calculate mean and std for each metric
        for category in aggregate_metrics:
            category_metrics = {}
            for metric_name, values in aggregate_metrics[category].items():
                if values:  # Check if we have any values
                    category_metrics[f"{metric_name}_mean"] = float(np.mean(values))
                    category_metrics[f"{metric_name}_std"] = float(np.std(values))
                    
            aggregate_metrics[category] = category_metrics
            
        return aggregate_metrics

    def _save_results(
        self,
        metrics: Dict[str, Any],
        results: List[Dict],
        output_path: Path
    ):
        """
        Save evaluation results to files.
        
        Args:
            metrics: Aggregate metrics
            results: Individual sample results
            output_path: Output directory path
        """
        # Save aggregate metrics
        metrics_path = output_path / 'aggregate_metrics.json'
        with open(metrics_path, 'w') as f:
            json.dump(metrics, f, indent=2)
            
        # Save detailed results
        results_path = output_path / 'detailed_results.json'
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2)
            
        # Generate plots
        self.metrics_calculator.save_results(
            metrics,
            output_path / 'visualizations',
            include_plots=True
        )
        
        # Save summary report
        self._generate_summary_report(metrics, output_path / 'evaluation_summary.txt')

    def _generate_summary_report(self, metrics: Dict[str, Any], output_path: Path):
        """
        Generate a human-readable summary report.
        
        Args:
            metrics: Aggregate metrics
            output_path: Path to save the report
        """
        with open(output_path, 'w') as f:
            f.write("Evaluation Summary Report\n")
            f.write("=======================\n\n")
            
            for category, category_metrics in metrics.items():
                f.write(f"{category.replace('_', ' ').title()}\n")
                f.write("-" * len(category) + "\n")
                
                for metric_name, value in category_metrics.items():
                    formatted_name = metric_name.replace('_', ' ').title()
                    formatted_value = f"{value:.4f}" if isinstance(value, float) else str(value)
                    f.write(f"{formatted_name}: {formatted_value}\n")
                    
                f.write("\n")

    def evaluate_ablations(
        self,
        model,
        test_data: List[Dict],
        ablation_configs: List[Dict],
        output_dir: str
    ) -> Dict[str, Any]:
        """
        Evaluate model with different ablation configurations.
        
        Args:
            model: Base model to evaluate
            test_data: Test dataset
            ablation_configs: List of ablation configurations
            output_dir: Output directory for results
            
        Returns:
            Dictionary containing ablation study results
        """
        ablation_results = {}
        
        for config in ablation_configs:
            config_name = config['name']
            self.logger.info(f"Evaluating ablation: {config_name}")
            
            # Apply configuration to model
            model.configure(config['settings'])
            
            # Evaluate
            metrics = self.evaluate_model(
                model,
                test_data,
                f"{output_dir}/ablations/{config_name}"
            )
            
            ablation_results[config_name] = metrics
            
        # Save comparative results
        self._save_ablation_results(ablation_results, output_dir)
        
        return ablation_results

    def _save_ablation_results(self, results: Dict[str, Any], output_dir: str):
        """
        Save ablation study results.
        
        Args:
            results: Dictionary of ablation results
            output_dir: Output directory
        """
        output_path = Path(output_dir) / 'ablations'
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save raw results
        with open(output_path / 'ablation_results.json', 'w') as f:
            json.dump(results, f, indent=2)
            
        # Generate comparative visualizations
        self._generate_ablation_plots(results, output_path)
        
        # Generate comparative report
        self._generate_ablation_report(results, output_path / 'ablation_report.txt')

    def _generate_ablation_plots(self, results: Dict[str, Any], output_path: Path):
        """
        Generate comparative plots for ablation study.
        
        Args:
            results: Ablation study results
            output_path: Output directory path
        """
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        # Set style
        plt.style.use('seaborn')
        
        # Plot comparative metrics
        metrics_to_plot = ['overall.mean_score', 'component_detection.f1_mean']
        
        for metric in metrics_to_plot:
            plt.figure(figsize=(10, 6))
            
            # Extract values for each configuration
            values = []
            labels = []
            for config_name, metrics in results.items():
                # Navigate nested dictionary using metric path
                value = metrics
                for key in metric.split('.'):
                    value = value.get(key, {})
                if isinstance(value, (int, float)):
                    values.append(value)
                    labels.append(config_name)
            
            # Create bar plot
            plt.bar(labels, values)
            plt.title(f'Comparison of {metric}')
            plt.xlabel('Configuration')
            plt.ylabel('Score')
            plt.xticks(rotation=45)
            plt.tight_layout()
            
            # Save plot
            metric_name = metric.replace('.', '_')
            plt.savefig(output_path / f'{metric_name}_comparison.png')
            plt.close()    