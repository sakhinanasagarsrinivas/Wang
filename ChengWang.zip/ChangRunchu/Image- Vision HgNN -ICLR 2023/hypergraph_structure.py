import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math

class HypergraphStructureLearning(nn.Module):
    """
    Hypergraph Structure Learning Module
    Implements the approach described in the paper for converting images to hypergraphs
    """
    def __init__(self, input_channels=3, patch_size=32, feature_dim=128, k_nearest=20):
        super().__init__()
        self.patch_size = patch_size
        self.feature_dim = feature_dim
        self.k_nearest = k_nearest
        
        # Advanced patch embedding network
        self.patch_embedding = nn.Sequential(
            nn.Conv2d(input_channels, feature_dim // 2, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(feature_dim // 2),
            nn.GELU(),
            nn.Conv2d(feature_dim // 2, feature_dim, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(feature_dim),
            nn.GELU()
        )
        
        # Positional encoding
        self.position_encoding = self._generate_positional_encoding()
    
    def _generate_positional_encoding(self):
        """
        Sinusoidal positional encoding as described in transformer literature
        """
        position = torch.arange(64).unsqueeze(1)  # Assuming 64 patches
        div_term = torch.exp(torch.arange(0, self.feature_dim, 2) * -(math.log(10000.0) / self.feature_dim))
        
        pos_encoding = torch.zeros(64, self.feature_dim)
        pos_encoding[:, 0::2] = torch.sin(position * div_term)
        pos_encoding[:, 1::2] = torch.cos(position * div_term)
        
        return pos_encoding
    
    def _extract_patches(self, x):
        """
        Extract and embed patches as described in the paper
        """
        b, c, h, w = x.shape
        patches = x.unfold(2, self.patch_size, self.patch_size) \
                  .unfold(3, self.patch_size, self.patch_size)
        patches = patches.permute(0, 2, 3, 1, 4, 5).contiguous()
        patches = patches.view(b, -1, c, self.patch_size, self.patch_size)
        
        # Apply patch embedding
        embedded_patches = self.patch_embedding(patches.view(-1, c, self.patch_size, self.patch_size))
        embedded_patches = embedded_patches.view(b, -1, self.feature_dim)
        
        return embedded_patches
    
    def _compute_hypergraph_structure(self, patches):
        """
        Compute hypergraph structure using semantic similarity
        """
        # Normalize patches
        normalized_patches = F.normalize(patches, p=2, dim=-1)
        
        # Compute similarity matrix
        similarity_matrix = torch.matmul(normalized_patches, normalized_patches.transpose(-1, -2))
        
        # Find top-K nearest neighbors
        _, hyperedge_indices = torch.topk(similarity_matrix, k=self.k_nearest, dim=-1)
        
        return hyperedge_indices
    
    def forward(self, x):
        """
        Forward pass of Hypergraph Structure Learning
        """
        # Extract and embed patches
        patches = self._extract_patches(x)
        
        # Add positional encoding
        patches = patches + self.position_encoding.to(patches.device)
        
        # Compute hypergraph structure
        hyperedge_indices = self._compute_hypergraph_structure(patches)
        
        return patches, hyperedge_indices