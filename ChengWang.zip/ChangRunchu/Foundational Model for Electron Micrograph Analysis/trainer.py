# trainer/trainer.py
class MAEMITrainer:
    """Trainer class for MAEMI model"""
    def __init__(self, model, config, train_loader, val_loader, optimizer, scheduler):
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.metrics = MetricsCalculator()
        
    def train_epoch(self):
        self.model.train()
        total_loss = 0
        
        for batch in tqdm(self.train_loader):
            loss = self.training_step(batch)
            total_loss += loss
            
        return total_loss / len(self.train_loader)
    
    def training_step(self, batch):
        self.optimizer.zero_grad()
        
        outputs = self.model(
            pixel_values=batch['pixel_values'].to(self.config.device),
            input_ids=batch['input_ids'].to(self.config.device),
            attention_mask=batch['attention_mask'].to(self.config.device),
            task=batch['task_type'][0]  # Assuming same task type in batch
        )
        
        loss = self.compute_loss(outputs, batch)
        loss.backward()
        self.optimizer.step()
        
        return loss.item()
    
    def validate(self):
        self.model.eval()
        total_loss = 0
        all_predictions = []
        all_targets = []
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader):
                loss, predictions, targets = self.validation_step(batch)
                total_loss += loss
                all_predictions.extend(predictions)
                all_targets.extend(targets)
        
        # Calculate metrics
        metrics = self.calculate_metrics(all_predictions, all_targets)
        
        return total_loss / len(self.val_loader), metrics
    
    def validation_step(self, batch):
        outputs = self.model(
            pixel_values=batch['pixel_values'].to(self.config.device),
            input_ids=batch['input_ids'].to(self.config.device),
            attention_mask=batch['attention_mask'].to(self.config.device),
            task=batch['task_type'][0]
        )
        
        loss = self.compute_loss(outputs, batch)
        predictions = self.get_predictions(outputs)
        targets = batch['input_ids']
        
        return loss.item(), predictions, targets
