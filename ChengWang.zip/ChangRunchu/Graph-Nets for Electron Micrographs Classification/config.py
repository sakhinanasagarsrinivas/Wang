import os
import torch
import logging

class Config:
    """Comprehensive configuration class for EMCNet project"""
    def __init__(self):
        # Data Paths
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.data_dir = os.path.join(self.base_dir, 'data')
        self.train_csv = os.path.join(self.data_dir, 'train.csv')
        self.root_dir = os.path.join(self.data_dir, 'images')
        self.results_dir = os.path.join(self.base_dir, 'results')
        
        # Create necessary directories
        os.makedirs(self.results_dir, exist_ok=True)
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Model Architecture Hyperparameters
        self.input_dim = 3  # RGB channels
        self.hidden_dim = 64
        self.num_classes = 10
        self.patch_size = 32
        
        # Training Hyperparameters
        self.batch_size = 24
        self.learning_rate = 1e-3
        self.weight_decay = 1e-5
        self.epochs = 100
        
        # Dataset Split Ratios
        self.train_ratio = 0.6
        self.val_ratio = 0.2
        self.test_ratio = 0.2
        
        # Device Configuration
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Logging Configuration
        self.log_dir = os.path.join(self.results_dir, 'logs')
        os.makedirs(self.log_dir, exist_ok=True)
        
        # Reproducibility
        self.random_seed = 42
        
        # Logging Setup
        self.setup_logging()
    
    def setup_logging(self):
        """Configure logging for the project"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(self.log_dir, 'training.log')),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def log_config(self):
        """Log configuration details"""
        self.logger.info("Configuration Details:")
        for key, value in vars(self).items():
            if not key.startswith('_') and not callable(value):
                self.logger.info(f"{key}: {value}")