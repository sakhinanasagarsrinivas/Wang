from typing import List, Dict
import fitz
import re
import yaml
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document

class TextProcessor:
    def __init__(self, config_path: str):
        """
        Initialize text processor with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.text_splitter = self._initialize_text_splitter()
        
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
        
    def _initialize_text_splitter(self) -> RecursiveCharacterTextSplitter:
        """Initialize text splitter with configuration."""
        return RecursiveCharacterTextSplitter(
            chunk_size=self.config['processing']['chunk_size'],
            chunk_overlap=self.config['processing']['chunk_overlap'],
            separators=["\n\n", "\n", " ", ""]
        )
        
    def extract_text_blocks(self, page: fitz.Page) -> List[Dict]:
        """
        Extract and process text blocks from a page.
        
        Args:
            page: PyMuPDF page object
            
        Returns:
            List of processed text blocks
        """
        blocks = page.get_text("blocks")
        processed_blocks = []
        
        for block in blocks:
            processed_block = self._process_text_block(block)
            if processed_block:
                processed_blocks.append(processed_block)
                
        return processed_blocks
    
    def _process_text_block(self, block: tuple) -> Dict:
        """
        Process a single text block.
        
        Args:
            block: PyMuPDF text block tuple
            
        Returns:
            Dictionary containing processed text block data
        """
        x0, y0, x1, y1, text, block_no, block_type = block
        
        # Skip empty blocks
        if not text.strip():
            return None
            
        return {
            'text': self._clean_text(text),
            'position': {
                'x0': x0,
                'y0': y0,
                'x1': x1,
                'y1': y1
            },
            'block_no': block_no,
            'block_type': block_type,
            'metadata': self._extract_text_metadata(text)
        }
        
    def _clean_text(self, text: str) -> str:
        """
        Clean and normalize text content.
        
        Args:
            text: Raw text string
            
        Returns:
            Cleaned text string
        """
        # Remove multiple spaces
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters while preserving important symbols
        text = re.sub(r'[^\w\s\-.,;:/()\[\]{}°C°F+\-*=%]', '', text)
        
        # Normalize whitespace
        text = text.strip()
        
        return text
        
    def _extract_text_metadata(self, text: str) -> Dict:
        """
        Extract metadata from text content.
        
        Args:
            text: Text string
            
        Returns:
            Dictionary containing text metadata
        """
        return {
            'length': len(text),
            'word_count': len(text.split()),
            'has_numbers': bool(re.search(r'\d', text)),
            'has_symbols': bool(re.search(r'[^\w\s]', text)),
            'content_type': self._determine_content_type(text)
        }
        
    def _determine_content_type(self, text: str) -> str:
        """
        Determine the type of content in the text.
        
        Args:
            text: Text string
            
        Returns:
            Content type string
        """
        # Check for common patterns in process diagrams
        if re.search(r'^\d+(\.\d+)?$', text):
            return 'number'
        elif re.search(r'°[CF]', text):
            return 'temperature'
        elif re.search(r'[A-Z]-\d+', text):
            return 'equipment_id'
        elif re.search(r'^\w+\s*->\s*\w+$', text):
            return 'flow_direction'
        return 'general_text'
    
    def create_text_chunks(self, text: str) -> List[Document]:
        """
        Split text into chunks for processing.
        
        Args:
            text: Input text string
            
        Returns:
            List of Document objects containing text chunks
        """
        return self.text_splitter.create_documents([text])
    
    def extract_technical_terms(self, text: str) -> List[str]:
        """
        Extract technical terms from text.
        
        Args:
            text: Input text string
            
        Returns:
            List of technical terms
        """
        # Common patterns in process diagrams
        patterns = [
            r'[A-Z]-\d+',  # Equipment IDs
            r'\d+(\.\d+)?\s*(°[CF]|bar|psi|kPa|mL|L|kg|g)',  # Measurements
            r'[A-Z][A-Za-z\s]{2,}(?=\s|$)',  # Technical terms (capitalized)
        ]
        
        terms = []
        for pattern in patterns:
            terms.extend(re.findall(pattern, text))
            
        return list(set(terms))  # Remove duplicates
    
    def format_for_embedding(self, text_blocks: List[Dict]) -> List[Document]:
        """
        Format text blocks for embedding generation.
        
        Args:
            text_blocks: List of processed text blocks
            
        Returns:
            List of Document objects ready for embedding
        """
        documents = []
        
        for block in text_blocks:
            metadata = {
                'position': block['position'],
                'block_no': block['block_no'],
                'content_type': block['metadata']['content_type']
            }
            
            doc = Document(
                page_content=block['text'],
                metadata=metadata
            )
            documents.append(doc)
            
        return documents