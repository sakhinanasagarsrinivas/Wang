import torch
import torch.nn as nn
from typing import Dict, List, Tuple, Optional, Union, Any
from unsloth import FastLanguageModel
from peft import LoraConfig, get_peft_model
from constants import ModelConfig, TaskConfig, PROMPT_PATTERNS

class PromptPool:
    """Implementation of prompt pool as described in Section 3.1"""
    def __init__(
        self,
        task_type: str,
        embedding_dim: int,
        device: torch.device
    ):
        self.task_type = task_type
        self.embedding_dim = embedding_dim
        self.device = device
        self.patterns = PROMPT_PATTERNS[task_type]
        
        # Initialize prompt embeddings for each pattern
        self.prompt_pool = self._initialize_prompts()
        
    def _initialize_prompts(self) -> Dict[str, Dict[str, torch.Tensor]]:
        pool = {}
        for pattern in self.patterns:
            # Each pattern has multiple prompts
            for i in range(5):  # Multiple prompts per pattern
                key = f"{pattern}_{i}"
                pool[key] = {
                    'key': self._initialize_embedding(),
                    'value': self._initialize_embedding()
                }
        return pool
    
    def _initialize_embedding(self) -> torch.Tensor:
        return torch.randn(self.embedding_dim).to(self.device)
    
    def retrieve_prompts(
        self, 
        query_embedding: torch.Tensor,
        top_k: int = 5
    ) -> List[torch.Tensor]:
        """Retrieve relevant prompts using cosine similarity"""
        similarities = []
        for key, embeddings in self.prompt_pool.items():
            similarity = torch.cosine_similarity(
                query_embedding.view(-1),
                embeddings['key'].view(-1),
                dim=0
            )
            similarities.append((key, similarity))
        
        # Get top-k similar prompts
        top_prompts = sorted(similarities, key=lambda x: x[1], reverse=True)[:top_k]
        return [self.prompt_pool[key]['value'] for key, _ in top_prompts]

class BaseAgent(nn.Module):
    """Base agent implementing common functionality"""
    def __init__(
        self,
        config: ModelConfig,
        task_config: TaskConfig,
        task_type: str,
        device: Optional[str] = None
    ):
        super().__init__()
        self.config = config
        self.task_config = task_config
        self.task_type = task_type
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize model with LoRA
        self.model, self.tokenizer = self._init_model()
        
        # Initialize task-specific prompt pool
        self.prompt_pool = PromptPool(
            task_type=task_type,
            embedding_dim=self.model.config.hidden_size,
            device=self.device
        )

    def _init_model(self) -> Tuple[nn.Module, Any]:
        """Initialize model with LoRA config"""
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_id=self.config.model_name,
            max_seq_length=self.config.max_seq_length,
            dtype=getattr(torch, self.config.dtype),
            load_in_4bit=True
        )
        
        # Configure LoRA
        lora_config = LoraConfig(
            r=self.config.lora_r,
            lora_alpha=self.config.lora_alpha,
            lora_dropout=self.config.lora_dropout,
            bias="none",
            task_type="CAUSAL_LM"
        )
        
        model = get_peft_model(model, lora_config)
        model.to(self.device)
        return model, tokenizer

    def _enhance_embeddings(
        self,
        input_embeds: torch.Tensor
    ) -> torch.Tensor:
        """Enhance input embeddings with retrieved prompts"""
        batch_size = input_embeds.shape[0]
        enhanced_embeds = []
        
        for i in range(batch_size):
            seq_embeds = input_embeds[i]
            prompts = self.prompt_pool.retrieve_prompts(seq_embeds.mean(dim=0))
            prompt_tensor = torch.stack(prompts)
            enhanced_seq = torch.cat([prompt_tensor, seq_embeds], dim=0)
            enhanced_embeds.append(enhanced_seq)
        
        return torch.stack(enhanced_embeds)

class ForecastingAgent(BaseAgent):
    """Forecasting agent implementation (Section 2.1)"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, task_type="forecasting", **kwargs)
        
        # As per paper: use MSE loss for forecasting
        self.loss_fn = nn.MSELoss()
        
    def forward(
        self, 
        x: torch.Tensor,
        target: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        # Get input embeddings
        input_embeds = self.model.get_input_embeddings()(x)
        
        # Enhance with prompts
        enhanced_embeds = self._enhance_embeddings(input_embeds)
        
        # Forward pass with sliding window as per paper
        outputs = self.model(
            inputs_embeds=enhanced_embeds,
            return_dict=True
        )
        
        results = {
            "predictions": outputs.logits[:, -self.task_config.forecast_horizon:, :]
        }
        
        if target is not None:
            results["loss"] = self.loss_fn(results["predictions"], target)
            
        return results

class ImputationAgent(BaseAgent):
    """Imputation agent implementation (Section 2.2)"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, task_type="imputation", **kwargs)
        self.loss_fn = nn.MSELoss()
        
    def forward(
        self,
        x: torch.Tensor,
        mask: torch.Tensor,
        target: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        # Implement as per paper Section 2.2
        input_embeds = self.model.get_input_embeddings()(x)
        enhanced_embeds = self._enhance_embeddings(input_embeds)
        
        outputs = self.model(inputs_embeds=enhanced_embeds, return_dict=True)
        predictions = outputs.logits
        
        results = {"predictions": predictions}
        
        if target is not None:
            # Only compute loss for masked values
            masked_preds = predictions * mask
            masked_targets = target * mask
            results["loss"] = self.loss_fn(masked_preds, masked_targets)
            
        return results

class AnomalyDetectionAgent(BaseAgent):
    """Anomaly detection agent implementation (Section 2.3)"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, task_type="anomaly_detection", **kwargs)
        self.loss_fn = nn.BCEWithLogitsLoss()
        
    def forward(
        self,
        x: torch.Tensor,
        target: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        # Implement as per paper Section 2.3
        input_embeds = self.model.get_input_embeddings()(x)
        enhanced_embeds = self._enhance_embeddings(input_embeds)
        
        outputs = self.model(inputs_embeds=enhanced_embeds, return_dict=True)
        predictions = outputs.logits
        
        # Compute anomaly scores
        scores = self._compute_anomaly_scores(predictions, x)
        
        results = {
            "predictions": predictions,
            "anomaly_scores": scores
        }
        
        if target is not None:
            results["loss"] = self.loss_fn(scores, target)
            
        return results
    
    def _compute_anomaly_scores(
        self,
        predictions: torch.Tensor,
        inputs: torch.Tensor
    ) -> torch.Tensor:
        """Compute normalized anomaly scores as per paper"""
        errors = torch.abs(predictions - inputs)
        scores = (errors - errors.mean(dim=1, keepdim=True)) / errors.std(dim=1, keepdim=True)
        return scores

class ClassificationAgent(BaseAgent):
    """Classification agent implementation (Section 2.4)"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, task_type="classification", **kwargs)
        self.loss_fn = nn.CrossEntropyLoss()
        
    def forward(
        self,
        x: torch.Tensor,
        target: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        # Implement as per paper Section 2.4
        input_embeds = self.model.get_input_embeddings()(x)
        enhanced_embeds = self._enhance_embeddings(input_embeds)
        
        outputs = self.model(inputs_embeds=enhanced_embeds, return_dict=True)
        logits = outputs.logits
        
        results = {
            "logits": logits,
            "predictions": torch.argmax(logits, dim=-1)
        }
        
        if target is not None:
            results["loss"] = self.loss_fn(logits.view(-1, self.task_config.num_clusters), 
                                         target.view(-1))
            
        return results

class MasterAgent:
    """Master agent that orchestrates sub-agents (Section 3)"""
    def __init__(
        self,
        model_config: ModelConfig,
        task_config: TaskConfig,
        device: Optional[str] = None
    ):
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize all sub-agents
        self.agents = {
            "forecasting": ForecastingAgent(
                config=model_config,
                task_config=task_config,
                device=self.device
            ),
            "imputation": ImputationAgent(
                config=model_config,
                task_config=task_config,
                device=self.device
            ),
            "anomaly_detection": AnomalyDetectionAgent(
                config=model_config,
                task_config=task_config,
                device=self.device
            ),
            "classification": ClassificationAgent(
                config=model_config,
                task_config=task_config,
                device=self.device
            )
        }
    
    def forward(self, task_type: str, **kwargs) -> Dict[str, torch.Tensor]:
        """Route task to appropriate sub-agent"""
        if task_type not in self.agents:
            raise ValueError(f"Unknown task type: {task_type}")
        return self.agents[task_type](**kwargs)
    
    def get_agent(self, task_type: str) -> BaseAgent:
        return self.agents[task_type]