# config.py
from dataclasses import dataclass
import torch

@dataclass
class MAEMIConfig:
    # Vision Encoder
    image_size: int = 224
    patch_size: int = 16
    num_channels: int = 3
    vision_hidden_dim: int = 768
    vision_intermediate_dim: int = 3072
    vision_num_attention_heads: int = 12
    vision_num_hidden_layers: int = 12
    
    # Text Encoder (Llama-2-7b base)
    text_hidden_dim: int = 4096
    text_intermediate_dim: int = 11008
    text_num_attention_heads: int = 32
    text_num_hidden_layers: int = 32
    vocab_size: int = 32000
    max_position_embeddings: int = 4096
    
    # DyQLoRA-FA
    rank_min: int = 4
    rank_max: int = 16
    lora_alpha: float = 32
    lora_dropout: float = 0.05
    
    # Cross Attention
    num_cross_attention_heads: int = 8
    cross_attention_dropout: float = 0.1
    
    # Model Structure
    num_layers: int = 12  # Number of alternating attention blocks
    hidden_dim: int = 768  # Common dimension for cross-attention
    dropout: float = 0.1
    
    # Training
    batch_size: int = 32
    learning_rate: float = 1e-3
    weight_decay: float = 0.01
    num_epochs: int = 50
    warmup_steps: int = 500
    
    # Tasks
    num_classes: int = 10  # For classification tasks
    max_seq_length: int = 512