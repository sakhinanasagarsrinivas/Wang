import torch
import torch.nn as nn
import numpy as np
import json
import argparse
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import time
import os

torch.manual_seed(42)
np.random.seed(42)

class FourierFeatureMapping(nn.Module):
    def __init__(self, input_dim, mapping_size, scale=10.0):
        super().__init__()
        self.register_buffer('B', torch.randn(input_dim, mapping_size) * scale)
        
    def forward(self, x):
        x_proj = x @ self.B
        return torch.cat([torch.sin(x_proj), torch.cos(x_proj)], dim=-1)

class AdaptiveActivation(nn.Module):
    def __init__(self, activation):
        super().__init__()
        self.activation = activation()
        self.scaling = nn.Parameter(torch.ones(1))
        
    def forward(self, x):
        return self.scaling * self.activation(x)

class ResidualBlock(nn.Module):
    def __init__(self, dim, activation_fn):
        super().__init__()
        self.linear1 = nn.Linear(dim, dim)
        self.linear2 = nn.Linear(dim, dim)
        self.activation = AdaptiveActivation(activation_fn)
        self.dropout = nn.Dropout(0.1)
        
    def forward(self, x):
        residual = x
        out = self.activation(self.linear1(x))
        out = self.dropout(out)
        out = self.linear2(out)
        return self.activation(out + residual)

class PINN(nn.Module):
    def __init__(self, num_inputs, num_outputs, hidden_layers, neurons_per_layer, activation_fn, t_domain_tensor,
                 use_fourier=False, fourier_size=64, fourier_scale=10.0):
        super(PINN, self).__init__()
        self.t_min = t_domain_tensor[0]
        self.t_max = t_domain_tensor[1]
        self.use_fourier = use_fourier
        
        if self.use_fourier:
            self.fourier_mapping = FourierFeatureMapping(num_inputs, fourier_size, fourier_scale)
            current_input_dim = fourier_size * 2
        else:
            current_input_dim = num_inputs

        self.input_layer = nn.Linear(current_input_dim, neurons_per_layer)
        self.input_activation = AdaptiveActivation(activation_fn)
        
        self.residual_blocks = nn.ModuleList([
            ResidualBlock(neurons_per_layer, activation_fn) 
            for _ in range(hidden_layers // 2)
        ])
        
        self.dense_layers = nn.ModuleList()
        for _ in range(hidden_layers - hidden_layers // 2):
            self.dense_layers.append(nn.Linear(neurons_per_layer, neurons_per_layer))
            self.dense_layers.append(AdaptiveActivation(activation_fn))
            self.dense_layers.append(nn.Dropout(0.05))
        
        self.output_layer = nn.Linear(neurons_per_layer, num_outputs)
        
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.constant_(m.bias, 0.0)

    def forward(self, t):
        t_scaled = 2.0 * (t - self.t_min) / (self.t_max - self.t_min) - 1.0
        
        if self.use_fourier:
            features = self.fourier_mapping(t_scaled)
        else:
            features = t_scaled

        x = self.input_activation(self.input_layer(features))
        
        for block in self.residual_blocks:
            x = block(x)
        
        for layer in self.dense_layers:
            x = layer(x)
        
        return self.output_layer(x)

class PINNSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._build_model()

    def _parse_config(self):
        self.problem_name = self.config['problem_id']
        self.state_vars = self.config['state_variables']
        self.odes = self.config['odes']
        self.t_domain = torch.tensor(self.config['time_domain'], device=self.device)

        self.fixed_params = {}
        self.trainable_params_info = {}
        parameters_config = self.config.get('parameters', {})
        for name, value in parameters_config.items():
            if isinstance(value, dict) and value.get('trainable', False):
                initial_guess = value.get('initial_guess')
                if initial_guess is None:
                    raise ValueError(f"Trainable parameter '{name}' must have an 'initial_guess'.")
                self.trainable_params_info[name] = initial_guess
            else:
                self.fixed_params[name] = value

        self.time_inputs = self.config.get('time_varying_inputs', {})
        self.ic_values = torch.tensor(
            [self.config['initial_conditions'][var] for var in self.state_vars],
            device=self.device
        ).float()
        
        hp = self.config['hyperparameters']
        self.hidden_layers = hp['hidden_layers']
        self.neurons_per_layer = hp['neurons_per_layer']
        self.lr = hp['learning_rate']
        self.epochs = hp['epochs']
        self.num_collocation = hp['num_collocation_points']
        self.loss_weights = hp['loss_weights']
        activation_map = {"tanh": nn.Tanh, "relu": nn.ReLU, "sigmoid": nn.Sigmoid}
        self.activation_fn = activation_map.get(hp['activation_function'], nn.Tanh)

        self.use_fourier = hp.get('use_fourier_features', False)
        self.fourier_size = hp.get('fourier_mapping_size', 64)
        self.fourier_scale = hp.get('fourier_scale', 5.0)

    def _build_model(self):
        num_inputs = 1
        num_outputs = len(self.state_vars)
        self.model = PINN(
            num_inputs, num_outputs, self.hidden_layers, 
            self.neurons_per_layer, self.activation_fn, self.t_domain,
            use_fourier=self.use_fourier,
            fourier_size=self.fourier_size,
            fourier_scale=self.fourier_scale
        ).to(self.device)

        self.trainable_params_module = nn.ParameterDict({
            name: nn.Parameter(torch.tensor([guess], device=self.device, dtype=torch.float32))
            for name, guess in self.trainable_params_info.items()
        }).to(self.device)

        if self.trainable_params_info:
            print("--- Trainable Parameters (Initial Guesses) ---")
            for name, guess in self.trainable_params_info.items():
                print(f"  {name}: {guess}")
            print("---------------------------------------------")

        all_params_to_train = list(self.model.parameters()) + list(self.trainable_params_module.parameters())
        
        self.optimizer = torch.optim.AdamW(
            all_params_to_train, 
            lr=self.lr, 
            weight_decay=1e-5,
            amsgrad=True
        )
        
        self.scheduler = torch.optim.lr_scheduler.ExponentialLR(
            self.optimizer,
            gamma=(0.01)**(1/self.epochs)
        )

    def _get_eval_scope(self, t, u=None):
        t_squeezed = t.squeeze(-1)
        scope = {'t': t_squeezed}
        if u is not None:
            for i, var in enumerate(self.state_vars):
                scope[var] = u[:, i]
        
        scope.update(self.fixed_params)
        scope.update(self.trainable_params_module)
        
        time_input_scope = {'t': t_squeezed, 'sin': torch.sin, 'cos': torch.cos, 'exp': torch.exp, 'pi': torch.pi}
        for name, expr in self.time_inputs.items():
            scope[name] = eval(expr, {}, time_input_scope)
        return scope

    def _compute_derivatives(self, u, t):
        derivatives = []
        for i in range(u.shape[1]):
            du_dt = torch.autograd.grad(
                outputs=u[:, i], 
                inputs=t,
                grad_outputs=torch.ones_like(u[:, i]),
                create_graph=True,
                retain_graph=True
            )[0].squeeze(-1)  
            derivatives.append(du_dt)
        return torch.stack(derivatives, dim=1)

    def _ode_residual_loss(self, t):
        t.requires_grad_(True)
        u = self.model(t)
        du_dt = self._compute_derivatives(u, t)
        
        scope = self._get_eval_scope(t, u)
        
        total_residual_loss = 0.0
        for i, var in enumerate(self.state_vars):
            ode_key = f"d{var}dt"
            if ode_key in self.odes:
                rhs = eval(self.odes[ode_key], {}, scope)
                residual = du_dt[:, i] - rhs
                total_residual_loss += torch.mean(residual**2)
        
        return total_residual_loss

    def _ic_loss(self):
        t_ic = self.t_domain[0].reshape(-1, 1)
        u_ic_pred = self.model(t_ic)
        return torch.mean((u_ic_pred.squeeze() - self.ic_values)**2)

    def _adaptive_sampling(self, epoch):
        if epoch < self.epochs // 4:
            num_uniform = self.num_collocation // 2
            num_random = self.num_collocation - num_uniform
            t_uniform = torch.linspace(self.t_domain[0], self.t_domain[1], num_uniform, device=self.device).view(-1, 1)
            t_random = self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(num_random, 1, device=self.device)
            return torch.cat([t_uniform, t_random])
        else:
            t_test = torch.linspace(self.t_domain[0], self.t_domain[1], 1000, device=self.device).view(-1, 1)
            t_test.requires_grad_(True)

            self.model.eval()

            u = self.model(t_test)
            du_dt = self._compute_derivatives(u, t_test)
            scope = self._get_eval_scope(t_test, u)
            
            per_point_squared_residuals = torch.zeros(t_test.shape[0], device=self.device)
            for i, var in enumerate(self.state_vars):
                ode_key = f"d{var}dt"
                if ode_key in self.odes:
                    rhs = eval(self.odes[ode_key], {}, scope)
                    residual = du_dt[:, i] - rhs
                    per_point_squared_residuals += residual**2
            
            error_metric = per_point_squared_residuals.detach()
            
            self.model.train()

            probabilities = error_metric + 1e-6
            probabilities /= torch.sum(probabilities)
            
            num_focused = int(self.num_collocation * 0.8)
            num_random = self.num_collocation - num_focused

            indices = torch.multinomial(probabilities.squeeze(), num_focused, replacement=True)
            t_focused = t_test[indices]
            
            t_random = self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(num_random, 1, device=self.device)
            
            collocation_points = torch.cat([t_focused, t_random])
            return collocation_points.view(-1, 1).to(self.device)

    def train(self):
        print(f"--- Starting training for {self.problem_name} ---")
        start_time = time.time()
        self.model.train()
        
        best_loss = float('inf')
        patience = 0
        max_patience = 10000
        
        for epoch in range(self.epochs):
            self.optimizer.zero_grad()
            
            collocation_t = self._adaptive_sampling(epoch)
            
            loss_res = self._ode_residual_loss(collocation_t)
            loss_ic = self._ic_loss()
            
            total_loss = (
                self.loss_weights['ode_residual'] * loss_res + 
                self.loss_weights['initial_condition'] * loss_ic
            )
            
            total_loss.backward()
            
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            
            self.optimizer.step()
            self.scheduler.step()
            
            if total_loss.item() < best_loss:
                best_loss = total_loss.item()
                patience = 0
            else:
                patience += 1
            
            if patience > max_patience:
                print(f"Early stopping at epoch {epoch}")
                break
            
            if (epoch + 1) % 5000 == 0:
                current_lr = self.optimizer.param_groups[0]['lr']
                print(f'Epoch [{epoch+1}/{self.epochs}], Loss: {total_loss.item():.4e}, '
                      f'ODE Loss: {loss_res.item():.4e}, IC Loss: {loss_ic.item():.4e}, '
                      f'LR: {current_lr:.4e}')
                
                if self.trainable_params_module:
                    param_str = ", ".join([f"{name}: {val.item():.4f}" for name, val in self.trainable_params_module.items()])
                    print(f'  Inferred Params: [{param_str}]')

        elapsed_time = time.time() - start_time
        print(f"--- Training finished in {elapsed_time:.2f} seconds ---")

    def solve_with_numerical_integrator(self, t_eval, learned_params=None):
        print("Solving with SciPy using discovered parameters as a baseline...")
        t_span = self.t_domain.cpu().numpy()
        y0 = self.ic_values.cpu().numpy()

        current_params = self.fixed_params.copy()
        if learned_params:
            current_params.update(learned_params)
        
        def ode_system(t, y):
            scope = {'t': t}
            for i, var in enumerate(self.state_vars):
                scope[var] = y[i]
            
            scope.update(current_params)

            time_input_scope = {'t': t, 'sin': np.sin, 'cos': np.cos, 'exp': np.exp, 'pi': np.pi}
            for name, expr in self.time_inputs.items():
                scope[name] = eval(expr, {}, time_input_scope)
            dydt = [eval(self.odes[f"d{var}dt"], {}, scope) for var in self.state_vars]
            return dydt
            
        sol = solve_ivp(ode_system, t_span, y0, dense_output=True, t_eval=t_eval, method='DOP853', rtol=1e-10, atol=1e-12)
        return sol.y.T

    def evaluate_and_plot_results(self):
        self.model.eval()
        os.makedirs("results", exist_ok=True)
        base_filename = f"results/{self.problem_name.replace(' ', '_').replace('(', '').replace(')', '').lower()}"

        final_learned_params = {name: val.item() for name, val in self.trainable_params_module.items()}
        if final_learned_params:
            print("\n--- Final Inferred Parameters ---")
            for name, val in final_learned_params.items():
                print(f"  {name}: {val:.6f}")
            print("---------------------------------")

        t_plot = torch.linspace(self.t_domain[0], self.t_domain[1], 500).view(-1, 1).to(self.device)
        with torch.no_grad():
            u_pinn = self.model(t_plot).cpu().numpy()
        
        t_plot_np = t_plot.cpu().numpy()
        
        u_numerical = self.solve_with_numerical_integrator(
            t_eval=t_plot_np.flatten(), 
            learned_params=final_learned_params
        )
        
        num_vars = len(self.state_vars)
        
        fig1, axes1 = plt.subplots(num_vars, 1, figsize=(10, 5 * num_vars), sharex=True)
        if num_vars == 1: axes1 = [axes1]
        for i, var in enumerate(self.state_vars):
            axes1[i].plot(t_plot_np, u_numerical[:, i], 'k-', label='Numerical Baseline (using PINN params)', linewidth=2)
            axes1[i].plot(t_plot_np, u_pinn[:, i], 'r--', label='PINN Solution')
            axes1[i].set_ylabel(var)
            axes1[i].legend()
            axes1[i].grid(True, linestyle='--', alpha=0.6)
        axes1[-1].set_xlabel('Time (t)')
        fig1.suptitle(f'Inverse PINN vs. Numerical Solver for "{self.problem_name}"', fontsize=16)
        solution_filename = f"{base_filename}_solution.pdf"
        plt.savefig(solution_filename, format='pdf', bbox_inches='tight')
        plt.close(fig1)
        print(f"Solution comparison plot saved to {solution_filename}")

        error = np.abs(u_pinn - u_numerical)
        fig2, axes2 = plt.subplots(num_vars, 1, figsize=(10, 5 * num_vars), sharex=True)
        if num_vars == 1: axes2 = [axes2]
        for i, var in enumerate(self.state_vars):
            axes2[i].plot(t_plot_np, error[:, i], 'b-')
            axes2[i].set_ylabel(f'Absolute Error in {var}')
            axes2[i].grid(True, linestyle='--', alpha=0.6)
            axes2[i].set_yscale('log')
        axes2[-1].set_xlabel('Time (t)')
        fig2.suptitle(f'Absolute Error of Inverse PINN Solution for "{self.problem_name}"', fontsize=16)
        error_filename = f"{base_filename}_error.pdf"
        plt.savefig(error_filename, format='pdf', bbox_inches='tight')
        plt.close(fig2)
        print(f"Error plot saved to {error_filename}")

def main():
    parser = argparse.ArgumentParser(description="Generic Forward and Inverse ODE-PINN Solver")
    parser.add_argument(
        "config_file", type=str,
        help="Path to the JSON configuration file.",
        default="problem_config.json", nargs='?'
    )
    args = parser.parse_args()
    try:
        with open(args.config_file, 'r') as f:
            full_config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
        
    if 'problems' not in full_config or not full_config['problems']:
        print("Error: The configuration file must contain a non-empty 'problems' list.")
        return
        
    problem_config = full_config['problems'][0]
    
    solver_config = problem_config.copy()
    solver_config['hyperparameters'] = full_config.get('hyperparameters', {})
        
    solver = PINNSolver(solver_config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()