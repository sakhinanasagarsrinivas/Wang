# models/text_encoder.py
import torch
import torch.nn as nn
from transformers import LlamaModel, LlamaConfig
from typing import Optional, Tuple

class TextEncoder(nn.Module):
    def __init__(self, 
                 model_name: str = "meta-llama/Llama-2-7b",
                 hidden_size: int = 768,
                 num_attention_heads: int = 12,
                 num_hidden_layers: int = 12,
                 intermediate_size: int = 3072,
                 max_position_embeddings: int = 2048):
        super().__init__()
        
        # Initialize Llama configuration
        self.config = LlamaConfig(
            hidden_size=hidden_size,
            num_attention_heads=num_attention_heads,
            num_hidden_layers=num_hidden_layers,
            intermediate_size=intermediate_size,
            max_position_embeddings=max_position_embeddings
        )
        
        # Initialize Llama model
        self.model = LlamaModel(self.config)
        
        # Additional projection layer
        self.projection = nn.Linear(hidden_size, hidden_size)
        
        # Layer normalization
        self.layer_norm = nn.LayerNorm(hidden_size)
        
    def forward(self, 
                input_ids: torch.Tensor,
                attention_mask: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of the text encoder.
        
        Args:
            input_ids: Tensor of shape (batch_size, sequence_length)
            attention_mask: Optional tensor of shape (batch_size, sequence_length)
            
        Returns:
            tuple: (sequence_output, pooled_output)
                - sequence_output: Tensor of shape (batch_size, sequence_length, hidden_size)
                - pooled_output: Tensor of shape (batch_size, hidden_size)
        """
        
        # Get Llama outputs
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            return_dict=True
        )
        
        sequence_output = outputs.last_hidden_state
        
        # Apply additional processing
        sequence_output = self.layer_norm(sequence_output)
        sequence_output = self.projection(sequence_output)
        
        # Get pooled output (use [CLS] token or average)
        pooled_output = torch.mean(sequence_output, dim=1)
        
        return sequence_output, pooled_output
    
    def freeze_base_model(self):
        """Freeze the base Llama model parameters."""
        for param in self.model.parameters():
            param.requires_grad = False
            
    def unfreeze_base_model(self):
        """Unfreeze the base Llama model parameters."""
        for param in self.model.parameters():
            param.requires_grad = True
            
    def get_embedding_dim(self) -> int:
        """Get the dimension of the output embeddings."""
        return self.config.hidden_size

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 5000):
        super().__init__()
        
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, 1, d_model)
        pe[:, 0, 0::2] = torch.sin(position * div_term)
        pe[:, 0, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor of shape (seq_len, batch_size, embedding_dim)
        """
        return x + self.pe[:x.size(0)]