
import os
import torch
import random
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

'''
MCAR (Missing Completely At Random): Randomly assigns missing values without any dependency on data properties.
MAR (Missing At Random): Missingness depends on observed data, modeled with probabilities.
MNAR (Missing Not At Random): Missingness depends on unobserved data values.
Temporal Missing: Introduces blocks of missing data along the temporal dimension to simulate time-dependent patterns.
Spatial Missing: Creates blocks of missing data across variables at specific time steps to simulate spatial dependencies.
Spatio-Temporal Missing: Combines both spatial and temporal patterns to simulate realistic dependencies.
Intermittent Failures: Generates sporadic, repeated missing values within specific ranges.
'''


def visualize_mask(mask_matrix, num_batches=36, save_path=None):
    """
    Visualize the mask matrix for multiple batches in a grid format, with an option to save as a PDF.

    Args:
        mask_matrix (torch.Tensor): A binary mask matrix of shape (batch_size, seq_len, num_variables).
        num_batches (int, optional): The number of batches to visualize. Defaults to 36.
        save_path (str, optional): Path to save the visualization as a PDF. If None, it won't save.
    """
    # Validate input dimensions
    if mask_matrix.ndim != 3:
        raise ValueError("mask_matrix must be a 3D tensor of shape (batch_size, seq_len, num_variables).")

    batch_size = mask_matrix.shape[0]

    # Limit the number of batches to visualize
    num_batches = min(num_batches, batch_size)

    # Determine grid size (rows and columns)
    grid_size = int(num_batches**0.5)
    if grid_size * grid_size < num_batches:
        grid_size += 1

    # Create a figure and axes
    fig, axes = plt.subplots(grid_size, grid_size, figsize=(grid_size * 3, grid_size * 3))
    axes = axes.flatten()  # Flatten axes array for easy iteration

    # Normalize the color scale for all subplots
    vmin, vmax = 0, 1  # Binary mask values (0: Missing, 1: Observed)
    im = None  # To store the image handle for the colorbar

    for i in range(grid_size * grid_size):
        if i < num_batches:
            # Extract the mask for the current batch
            selected_mask = (
                mask_matrix[i].numpy()
                if mask_matrix.device.type == 'cpu'
                else mask_matrix[i].cpu().numpy()
            )

            # Plot the mask for this batch
            im = axes[i].imshow(selected_mask, cmap="binary", aspect="auto", interpolation="none", vmin=vmin, vmax=vmax)
            axes[i].set_title(f"Batch {i}", fontsize=10)
            axes[i].set_xlabel("Variables", fontsize=10, weight='bold')  # Thicker x-axis label
            axes[i].set_ylabel("Time Steps", fontsize=10, weight='bold')  # Thicker y-axis label

            # Adjust ticks for readability
            seq_len, num_variables = selected_mask.shape
            axes[i].set_xticks(range(0, num_variables, max(1, num_variables // 5)))  # Fewer x-ticks
            axes[i].set_yticks(range(0, seq_len, max(1, seq_len // 5)))  # Fewer y-ticks
            axes[i].tick_params(axis='both', which='major', labelsize=8)
        else:
            axes[i].axis("off")  # Hide unused subplots

    # Adjust spacing and margins
    plt.subplots_adjust(
        wspace=0.4,  # Horizontal space
        hspace=0.6,  # Vertical space
        top=0.9,     # Space at the top
        bottom=0.1   # Space at the bottom
    )

    # Add a single colorbar for all subplots
    cbar_ax = fig.add_axes([0.92, 0.15, 0.02, 0.7])  # [left, bottom, width, height]
    fig.colorbar(im, cax=cbar_ax, label="Mask Value (1: Observed, 0: Missing)")

    # Save to PDF if a path is provided
    if save_path:
        # Ensure the directory exists
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, format="pdf", bbox_inches="tight")
        print(f"Visualization saved to {save_path}")

    plt.show()

def analyze_missing_data_correlation(data_matrix, mask, max_lag=3):
    """
    Analyze the spatial and temporal correlation of missing data points in a given data matrix.

    Args:
        data_matrix (torch.Tensor or numpy.ndarray): Input data matrix of shape (batch_size, seq_len, num_variables) with missing values.
        mask (torch.Tensor or numpy.ndarray): Binary mask indicating missing values (1 for observed, 0 for missing).
        max_lag (int): Maximum lag to consider for temporal correlation analysis.

    Returns:
        None: Displays the correlation matrix of missingness and prints temporal and spatial correlations.
    """
    # Convert torch.Tensor to numpy.ndarray if necessary
    if isinstance(data_matrix, torch.Tensor):
        data_matrix = data_matrix.numpy()
    if isinstance(mask, torch.Tensor):
        mask = mask.numpy()

    # Convert to DataFrame for easier correlation analysis
    # Reshape mask to (batch_size * seq_len, num_variables)
    mask_df = pd.DataFrame(mask.reshape(-1, data_matrix.shape[2]), columns=[f"Var_{i+1}" for i in range(data_matrix.shape[2])])

    # Convert boolean to integers for correlation computation (1 for observed, 0 for missing)
    mask_df = mask_df.astype(int)

    # Calculate the correlation matrix for missingness across variables (spatial correlation)
    missing_corr_matrix = mask_df.corr()

    # Plot the correlation matrix to visualize the relationships
    plt.figure(figsize=(10, 6))
    sns.heatmap(missing_corr_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
    plt.title('Correlation Matrix of Missingness Across Variables (Spatial Correlation)')
    plt.show()

    # Interpretation based on correlation matrix
    print("\nCorrelation Matrix of Missingness (Spatial Correlation):\n")
    print(missing_corr_matrix)

    # Check for temporal correlation by lagging the mask and computing correlation
    temporal_corr = []
    for var in range(data_matrix.shape[2]):
        for lag in range(1, max_lag + 1):  # Lag up to max_lag time steps
            lagged_mask = np.roll(mask[:, :, var], shift=lag, axis=1)  # Lag along the temporal axis
            valid_length = mask.shape[1] - lag
            lagged_corr = np.corrcoef(mask[:, :valid_length, var].ravel(), lagged_mask[:, :valid_length].ravel())[0, 1]
            temporal_corr.append((f"Var_{var+1}", lag, lagged_corr))

    # Display temporal correlations
    print("\nTemporal Correlation of Missingness:\n")
    for var, lag, corr in temporal_corr:
        print(f"{var} with lag {lag}: correlation = {corr:.2f}")

    # Plot temporal correlations for each variable
    plt.figure(figsize=(10, 6))
    for var in range(data_matrix.shape[2]):
        lags = [lag for v, lag, _ in temporal_corr if v == f"Var_{var+1}"]
        correlations = [corr for v, lag, corr in temporal_corr if v == f"Var_{var+1}"]
        plt.plot(lags, correlations, marker='o', label=f"Var_{var+1}")

    plt.xlabel('Lag')
    plt.ylabel('Correlation')
    plt.title('Temporal Correlation of Missingness for Each Variable')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Compare spatial and temporal correlations
    avg_spatial_corr = missing_corr_matrix.mean().mean()
    avg_temporal_corr = np.mean([corr for _, _, corr in temporal_corr if not np.isnan(corr)])

    print("\nAverage Spatial Correlation of Missingness: {:.2f}".format(avg_spatial_corr))
    print("Average Temporal Correlation of Missingness: {:.2f}".format(avg_temporal_corr))

    if avg_spatial_corr > avg_temporal_corr:
        print("\nThe missing data exhibits stronger spatial correlation than temporal correlation.")
    else:
        print("\nThe missing data exhibits stronger temporal correlation than spatial correlation.")


def generate_mask_mcar(data_matrix, missing_percentage, method='random'):
    """
    Generate a binary mask matrix for Missing Completely At Random (MCAR) values.

    Args:
        data_matrix (torch.Tensor): Input data matrix.
        missing_percentage (float): Percentage of missing values (0 to 100).
        method (str): Method for generating missing values.  'random' (default) for random sampling, 'proportional' for proportional sampling across dimensions.

    Returns:
        torch.Tensor: A binary mask matrix.

    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data with shape (batch_size, seq_len, num_variables)
    missing_percentage = 40  # 20% missing values
    mask_matrix = generate_mask_mcar(data_matrix, missing_percentage)
    print("Mask Matrix Shape:", mask_matrix.shape)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize   
    analyze_missing_data_correlation(data_matrix, mask_matrix, max_lag=3)    
    """
    if not (0 <= missing_percentage <= 100):
        raise ValueError("missing_percentage must be a float between 0 and 100 inclusive.")

    total_elements = data_matrix.numel()
    num_missing = int(round((missing_percentage / 100) * total_elements)) # Round to nearest integer


    if method == 'random':
        mask = torch.ones(total_elements, dtype=torch.bool, device=data_matrix.device)
        missing_indices = torch.randperm(total_elements, device=data_matrix.device)[:num_missing]
        mask[missing_indices] = 0
    elif method == 'proportional':
        #For proportional missingness across all dimensions
        batch_size, seq_len, num_variables = data_matrix.shape
        num_missing_per_dim = [int(round( (missing_percentage/100) * (batch_size*seq_len*num_variables)/3)) for _ in range(3)] #approximately equal
        num_missing_per_dim[2] += num_missing - sum(num_missing_per_dim)
        mask = torch.ones_like(data_matrix, dtype=torch.bool)

        for i in range(3):
            dim_size = data_matrix.shape[i]
            indices = torch.randperm(dim_size)[:num_missing_per_dim[i]]
            if i == 0:
                mask[indices] = False
            elif i ==1:
                mask[:,indices] = False
            else:
                mask[:,:,indices] = False

    else:
        raise ValueError("Invalid method specified. Choose 'random' or 'proportional'.")


    mask = mask.view_as(data_matrix)
    # actual_missing_percentage = (mask == 0).float().mean().item() * 100

    # print(f"Desired Missing Percentage: {missing_percentage:.2f}%")
    # print(f"Actual Missing Percentage in Mask: {actual_missing_percentage:.2f}%")

    return mask


def generate_mask_mar(data_matrix, missing_percentage):
    """
    Generates a MAR (Missing At Random) mask efficiently using vectorized operations.

    Args:
        data_matrix (torch.Tensor): A 3D tensor of shape (batch_size, seq_len, num_variables)
            representing the input data where missing values will be introduced.
        missing_percentage (float): The percentage of values to be masked (missing),
            specified as a float between 0 and 100.

    Returns:
        torch.Tensor: A binary mask tensor of the same shape as `data_matrix`, where
            `True` indicates a present value, and `False` indicates a missing value.

    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data with shape (batch_size, seq_len, num_variables)
    missing_percentage = 40  # 20% missing values
    mask_matrix = generate_mask_mar(data_matrix, missing_percentage)
    print("Mask Matrix Shape:", mask_matrix.shape)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize   
    analyze_missing_data_correlation(data_matrix, mask_matrix, max_lag=3)           
    """
    # Get the dimensions of the input data matrix
    batch_size, seq_len, num_variables = data_matrix.shape
    total_elements = batch_size * seq_len * num_variables

    # Calculate the number of elements to mask
    num_missing = int(total_elements * (missing_percentage / 100))

    # Flatten the data matrix while preserving the number of variables
    flat_data = data_matrix.reshape(-1)  # Reshaped to 1D array

    # Compute probabilities based on normalized values
    probabilities = torch.softmax(flat_data, dim=0)

    # Adjust num_missing if it exceeds the total size
    num_missing = min(num_missing, flat_data.numel())

    # Sample indices to mask using the probabilities
    indices_to_mask = torch.multinomial(probabilities, num_missing, replacement=False)

    # Create a mask initialized to True (all values initially present)
    mask = torch.ones(flat_data.shape[0], dtype=torch.bool)

    # Mark the sampled indices as False (missing)
    mask[indices_to_mask] = False

    # Reshape the mask back to the original data matrix shape
    mask = mask.reshape(batch_size, seq_len, num_variables)

    # Verify that approximately the correct percentage is masked
    # percentage_masked = (1 - mask.sum().item() / mask.numel()) * 100
    # print(f"Percentage of values masked: {percentage_masked:.2f}%")

    return mask


def generate_mask_mnar(data_matrix, missing_percentage):
    """
    Generates an MNAR (Missing Not At Random) mask, where missingness is dependent
    on unobserved values in the input data.

    Args:
        data_matrix (torch.Tensor): A 3D tensor of shape (batch_size, seq_len, num_variables)
            representing the input data where missing values will be introduced.
        missing_percentage (float): The percentage of values to be masked (missing),
            specified as a float between 0 and 100.

    Returns:
        torch.Tensor: A binary mask tensor of the same shape as `data_matrix`, where
            `True` indicates a present value, and `False` indicates a missing value.
    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data with shape (batch_size, seq_len, num_variables)
    missing_percentage = 40  # 20% missing values
    mask_matrix = generate_mask_mnar(data_matrix, missing_percentage)
    print("Mask Matrix Shape:", mask_matrix.shape)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize   
    analyze_missing_data_correlation(data_matrix, mask_matrix, max_lag=3)         
    """
    # Get the dimensions of the input data matrix
    batch_size, seq_len, num_variables = data_matrix.shape
    total_elements = batch_size * seq_len * num_variables

    # Calculate the number of elements to mask
    num_missing = int(total_elements * (missing_percentage / 100))

    # Flatten the data matrix for easier processing
    flat_data = data_matrix.reshape(-1)

    # Define probabilities based on unobserved values (e.g., higher values more likely to be missing)
    # Here we normalize the absolute values of the data to create probabilities
    probabilities = torch.abs(flat_data)
    probabilities = probabilities / probabilities.sum()  # Normalize to create a probability distribution

    # Adjust num_missing if it exceeds the total size
    num_missing = min(num_missing, flat_data.numel())

    # Sample indices to mask using the probabilities
    indices_to_mask = torch.multinomial(probabilities, num_missing, replacement=False)

    # Create a mask initialized to True (all values initially present)
    mask = torch.ones(flat_data.shape[0], dtype=torch.bool)

    # Mark the sampled indices as False (missing)
    mask[indices_to_mask] = False

    # Reshape the mask back to the original data matrix shape
    mask = mask.reshape(batch_size, seq_len, num_variables)

    # Verify that approximately the correct percentage is masked
    # percentage_masked = (1 - mask.sum().item() / mask.numel()) * 100
    # print(f"Percentage of values masked: {percentage_masked:.2f}%")

    return mask


def generate_mask_with_intermittent_failures(data_matrix, missing_percentage, block_min=1, block_max=3, sparsity_factor=0.1):
    """
    Optimized function to generate a mask matrix with intermittent failures.

    Args:
        data_matrix (torch.Tensor): Input data matrix of shape (batch_size, seq_len, num_variables).
        missing_percentage (float): Percentage of missing values (0 to 100).
        block_min (int): Minimum length of a missing temporal block.
        block_max (int): Maximum length of a missing temporal block.
        sparsity_factor (float): Fraction of variables in each batch that will have intermittent failures.

    Returns:
        torch.Tensor: A binary mask matrix.

    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data
    missing_percentage = 40  # 40% missing values    
    mask_matrix = generate_mask_with_intermittent_failures(data_matrix, missing_percentage)
    print("Mask Matrix Shape:", mask_matrix.shape)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize    
    analyze_missing_data_correlation(data_matrix, mask_matrix, max_lag=3)     
    """

    # Input validation (same as before)
    if data_matrix.ndim != 3:
        raise ValueError("data_matrix must be a 3D tensor.")
    if not (0 <= missing_percentage <= 100):
        raise ValueError("missing_percentage must be between 0 and 100.")
    if data_matrix.shape[1] < block_min:
        raise ValueError("seq_len must be greater than or equal to block_min.")

    batch_size, seq_len, num_variables = data_matrix.shape
    mask = torch.ones_like(data_matrix, dtype=torch.int)
    num_missing_target = int((missing_percentage / 100) * batch_size * seq_len * num_variables)

    # Better initial estimate of the number of blocks
    avg_block_length = (block_min + block_max) / 2
    initial_num_blocks = int(num_missing_target / avg_block_length)
    num_variables_per_batch = int(num_variables * sparsity_factor)

    #Vectorized block creation (approximate)
    batches = torch.randint(0, batch_size, (initial_num_blocks,))
    variables = torch.randint(0, num_variables, (initial_num_blocks,))
    starts = torch.randint(0, seq_len - block_min + 1, (initial_num_blocks,))
    lengths = torch.randint(block_min, block_max + 1, (initial_num_blocks,))

    #Apply mask in a vectorized way
    for i in range(initial_num_blocks):
      batch_idx = batches[i]
      var_idx = variables[i]
      start_idx = starts[i]
      end_idx = min(start_idx + lengths[i], seq_len)
      mask[batch_idx, start_idx:end_idx, var_idx] = 0

    # actual_missing_percentage = (mask == 0).float().mean().item() * 100
    # print(f"Percentage of Missing Values in Mask: {actual_missing_percentage:.2f}% (Target: {missing_percentage:.2f}%)")
    return mask


def generate_mask_with_temporal_blocks(data_matrix, missing_percentage, block_min=1, block_max=5):
    """

    Continuous Temporal Blocks: The function generates a binary mask where missing values (0s) are introduced in continuous segments along
    the time dimension (seq_len). Each block can vary in length, defined by block_min and block_max. Missing blocks are generated for each variable and batch independently.


    Generate a mask matrix with missing data in continuous temporal blocks for temporal dependencies.

    Args:
        data_matrix (torch.Tensor): Input data matrix of shape (batch_size, seq_len, num_variables).
        missing_percentage (float): Percentage of missing data points (0 to 100).
        block_min (int): Minimum length of a missing temporal block.
        block_max (int): Maximum length of a missing temporal block.

    Returns:
        torch.Tensor: A binary mask matrix of the same shape as data_matrix,
                      where 1 indicates observed values and 0 indicates missing values.

    How to Invoke: 

    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data with shape (batch_size, seq_len, num_variables)
    missing_percentage = 20  # 20% missing values
    mask_matrix = generate_mask_with_temporal_blocks(data_matrix, missing_percentage)
    print("Mask Matrix Shape:", mask_matrix.shape)
    # Analyze missing data correlation
    analyze_missing_data_correlation(data_matrix, mask_matrix)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize  
    """
    # Validate input dimensions
    if data_matrix.ndim != 3:
        raise ValueError("data_matrix must be a 3D tensor of shape (batch_size, seq_len, num_variables).")

    # Extract dimensions from the data matrix
    batch_size, seq_len, num_variables = data_matrix.shape

    # Validate missing_percentage
    if not (0 <= missing_percentage <= 100):
        raise ValueError("missing_percentage must be between 0 and 100.")

    # Handle edge case where seq_len < block_min
    if seq_len < block_min:
        raise ValueError("seq_len must be greater than or equal to block_min.")

    # Initialize the mask matrix with ones (all observed values)
    mask = torch.ones_like(data_matrix, dtype=torch.int)

    # Calculate the total number of missing values
    total_elements = batch_size * seq_len * num_variables
    num_missing = int((missing_percentage / 100) * total_elements)

    # Track the number of missing values applied
    missing_count = 0

    # Continue adding temporal missing blocks until the required number of missing values is reached
    while missing_count < num_missing:
        # Randomly select batch and variable to apply temporal missing block
        batch = torch.randint(0, batch_size, (1,)).item()
        var = torch.randint(0, num_variables, (1,)).item()
        
        # Randomly select the start index along the temporal (sequence) dimension
        start_idx = torch.randint(0, seq_len, (1,)).item()

        # Randomly select block length
        block_length = torch.randint(block_min, min(block_max + 1, seq_len - start_idx + 1), (1,)).item()

        # Ensure the block doesn't exceed the sequence length
        end_idx = min(start_idx + block_length, seq_len)

        # Calculate how many values we are about to mask
        num_to_mask = end_idx - start_idx

        # Check if adding this block would exceed the target missing count
        if missing_count + num_to_mask > num_missing:
            # Adjust block size to fit the remaining missing count
            num_to_mask = num_missing - missing_count
            end_idx = start_idx + num_to_mask

        # Apply the temporal missing block
        if mask[batch, start_idx:end_idx, var].sum() == num_to_mask:
            mask[batch, start_idx:end_idx, var] = 0
            missing_count += num_to_mask

    # # Calculate the actual percentage of missing values in the mask
    # actual_missing_percentage = (mask == 0).float().mean().item() * 100

    # # Print the calculated percentage of missing values
    # print(f"Percentage of Missing Values in Mask: {actual_missing_percentage:.2f}% (Target: {missing_percentage:.2f}%)")

    return mask


def generate_mask_with_spatial_blocks(data_matrix, missing_percentage, block_min=1, block_max=5):
    """
    Generate a mask matrix with missing data in continuous spatial blocks across variables for spatial dependencies.

    Args:
        data_matrix (torch.Tensor): Input data matrix of shape (batch_size, seq_len, num_variables).
        missing_percentage (float): Percentage of missing data points (0 to 100).
        block_min (int): Minimum length of a missing block (number of variables).
        block_max (int): Maximum length of a missing block (number of variables).

    Returns:
        torch.Tensor: A binary mask matrix of the same shape as data_matrix,
                      where 1 indicates observed values and 0 indicates missing values.

    How to Invoke: 

    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data with shape (batch_size, seq_len, num_variables)
    missing_percentage = 20  # 20% missing values
    mask_matrix = generate_mask_with_spatial_blocks(data_matrix, missing_percentage)
    print("Mask Matrix Shape:", mask_matrix.shape)
    # Analyze missing data correlation
    analyze_missing_data_correlation(data_matrix, mask_matrix)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize  
    """
    # Validate input dimensions
    if data_matrix.ndim != 3:
        raise ValueError("data_matrix must be a 3D tensor of shape (batch_size, seq_len, num_variables).")

    # Extract dimensions from the data matrix
    batch_size, seq_len, num_variables = data_matrix.shape

    # Validate missing_percentage
    if not (0 <= missing_percentage <= 100):
        raise ValueError("missing_percentage must be between 0 and 100.")

    # Handle edge case where num_variables < block_min
    if num_variables < block_min:
        raise ValueError("num_variables must be greater than or equal to block_min.")

    # Initialize the mask matrix with ones (all observed values)
    mask = torch.ones_like(data_matrix, dtype=torch.int)

    # Calculate the total number of missing values
    total_elements = batch_size * seq_len * num_variables
    num_missing = int((missing_percentage / 100) * total_elements)

    # Track the number of missing values applied
    missing_count = 0

    # Continue adding missing blocks until the required number of missing values is reached
    while missing_count < num_missing:
        # Randomly select batch and time step to apply spatial missing block
        batch = torch.randint(0, batch_size, (1,)).item()
        time_step = torch.randint(0, seq_len, (1,)).item()
        
        # Randomly select block length (number of variables to mask)
        block_length = torch.randint(block_min, min(block_max + 1, num_variables + 1), (1,)).item()

        # Randomly select the start variable index
        start_var = torch.randint(0, num_variables - block_length + 1, (1,)).item()

        # Apply the missing block across the selected variables at the given time step
        mask[batch, time_step, start_var:start_var + block_length] = 0
        missing_count += block_length

        # Ensure we don't exceed the target missing count
        if missing_count > num_missing:
            excess = missing_count - num_missing
            mask[batch, time_step, start_var + block_length - excess:start_var + block_length] = 1
            missing_count = num_missing

    # Calculate the actual percentage of missing values in the mask
    # actual_missing_percentage = (mask == 0).float().mean().item() * 100

    # Print the calculated percentage of missing values
    # print(f"Percentage of Missing Values in Mask: {actual_missing_percentage:.2f}% (Target: {missing_percentage:.2f}%)")

    return mask

def generate_mask_with_spatio_temporal_blocks(data_matrix, missing_percentage, block_min_time=2, block_max_time=5, block_min_var=1, block_max_var=3):
    """
    Generate a mask matrix with missing data in spatio-temporal blocks.

    Args:
        data_matrix (torch.Tensor): Input data matrix of shape (batch_size, seq_len, num_variables).
        missing_percentage (float): Percentage of missing data points (0 to 100).
        block_min_time (int): Minimum length of a missing block in the temporal dimension.
        block_max_time (int): Maximum length of a missing block in the temporal dimension.
        block_min_var (int): Minimum size of a missing block in the spatial dimension (across variables).
        block_max_var (int): Maximum size of a missing block in the spatial dimension (across variables).

    Returns:
        torch.Tensor: A binary mask matrix of the same shape as data_matrix,
                      where 1 indicates observed values and 0 indicates missing values.

    How to Invoke:

    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data with shape (batch_size, seq_len, num_variables)
    missing_percentage = 40  # % missing values
    mask_matrix = generate_mask_with_spatio_temporal_blocks(data_matrix, missing_percentage)
    print("Mask Matrix Shape:", mask_matrix.shape)
    # Analyze missing data correlation
    analyze_missing_data_correlation_spatial_temporal(data_matrix, mask_matrix)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize  
    """
    # Validate input dimensions
    if data_matrix.ndim != 3:
        raise ValueError("data_matrix must be a 3D tensor of shape (batch_size, seq_len, num_variables).")

    # Extract dimensions from the data matrix
    batch_size, seq_len, num_variables = data_matrix.shape

    # Validate missing_percentage
    if not (0 <= missing_percentage <= 100):
        raise ValueError("missing_percentage must be between 0 and 100.")

    # Handle edge cases
    if seq_len < block_min_time:
        raise ValueError("seq_len must be greater than or equal to block_min_time.")
    if num_variables < block_min_var:
        raise ValueError("num_variables must be greater than or equal to block_min_var.")

    # Initialize the mask matrix with ones (all observed values)
    mask = torch.ones_like(data_matrix, dtype=torch.int)

    # Calculate the total number of missing values
    total_elements = batch_size * seq_len * num_variables
    num_missing = int((missing_percentage / 100) * total_elements)

    # Calculate the per-batch target missing values, accounting for the remainder
    missing_values_per_batch = num_missing // batch_size
    extra_missing_values = num_missing % batch_size

    # For each batch, create spatio-temporal blocks
    for batch in range(batch_size):
        target_missing = missing_values_per_batch + (1 if batch < extra_missing_values else 0)
        missing_count = 0

        while missing_count < target_missing:
            # Randomly select the start of a missing block in time and variable dimensions
            start_time = torch.randint(0, seq_len, (1,)).item()
            start_var = torch.randint(0, num_variables, (1,)).item()

            # Randomly determine the block length in the temporal and spatial dimensions
            time_length = torch.randint(block_min_time, min(block_max_time + 1, seq_len), (1,)).item()
            var_length = torch.randint(block_min_var, min(block_max_var + 1, num_variables), (1,)).item()

            # Ensure the blocks don't exceed the sequence length or number of variables
            end_time = min(start_time + time_length, seq_len)
            end_var = min(start_var + var_length, num_variables)

            # Apply the spatio-temporal block
            mask[batch, start_time:end_time, start_var:end_var] = 0

            # Update the count of missing values
            missing_count += (end_time - start_time) * (end_var - start_var)

    # # Calculate the actual percentage of missing values in the mask
    # actual_missing_percentage = (mask == 0).float().mean().item() * 100

    # # Print the calculated percentage of missing values
    # print(f"Percentage of Missing Values in Mask: {actual_missing_percentage:.2f}% (Target: {missing_percentage:.2f}%)")

    return mask


def visualize_single_mask_overlap(ground_truth_mask, predicted_mask, save_path=None, chunk_size=100):
    """
    Visualize the overlap of ground truth and predicted missing masks, focusing on missing data.

    Args:
        ground_truth_mask (np.ndarray): Ground truth binary mask of shape (seq_len, num_variables).
        predicted_mask (np.ndarray): Predicted binary mask of shape (seq_len, num_variables).
        save_path (str, optional): Path to save the visualization as a PDF. If None, it won't save.
        chunk_size (int, optional): Number of time steps per plot. Defaults to 100.
    """
    # Validate input dimensions
    if ground_truth_mask.ndim != 2 or predicted_mask.ndim != 2:
        raise ValueError("Both ground_truth_mask and predicted_mask must be 2D arrays of shape (seq_len, num_variables).")

    if ground_truth_mask.shape != predicted_mask.shape:
        raise ValueError("ground_truth_mask and predicted_mask must have the same shape.")

    seq_len, num_variables = ground_truth_mask.shape

    # Determine the number of chunks needed
    num_chunks = (seq_len + chunk_size - 1) // chunk_size

    # Create an RGB image to visualize the overlap
    for i in range(num_chunks):
        start_idx = i * chunk_size
        end_idx = min((i + 1) * chunk_size, seq_len)

        gt_chunk = ground_truth_mask[start_idx:end_idx]
        pred_chunk = predicted_mask[start_idx:end_idx]

        # Create an RGB image for the current chunk
        overlap = np.ones((*gt_chunk.shape, 3))  # Default to white background (1, 1, 1)

        # Light blue for ground truth missing values
        overlap[gt_chunk == 0] = [0.7, 0.85, 1.0]  # Light blue

        # Light orange for predicted missing values
        overlap[pred_chunk == 0] = [1.0, 0.8, 0.6]  # Light orange

        # Plot the overlap
        plt.figure(figsize=(12, 8), dpi=150)
        plt.imshow(overlap, aspect="auto", interpolation="none")
        plt.title(f"Ground Truth vs Predicted Missing Mask (Time Steps {start_idx} to {end_idx - 1})", fontsize=14, weight='bold')
        plt.xlabel("Variables", fontsize=12, weight='bold')
        plt.ylabel("Time Steps", fontsize=12, weight='bold')

        # Adjust ticks for readability
        plt.xticks(range(0, num_variables, max(1, num_variables // 10)))
        plt.yticks(range(0, end_idx - start_idx, max(1, (end_idx - start_idx) // 10)))
        plt.grid(visible=False)

        # Add a legend
        legend_elements = [
            Patch(facecolor=(0.7, 0.85, 1.0), edgecolor='black', label='Ground Truth Missing'),
            Patch(facecolor=(1.0, 0.8, 0.6), edgecolor='black', label='Predicted Missing')
        ]
        plt.legend(handles=legend_elements, loc='upper right', fontsize=10)

        # Save to PDF if a path is provided
        if save_path:
            if os.path.isdir(save_path):
                save_path = os.path.join(save_path, f"mask_overlap_{i + 1}.pdf")
            else:
                base, ext = os.path.splitext(save_path)
                save_path = f"{base}_{i + 1}{ext}"

            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            plt.savefig(save_path, format="pdf", bbox_inches="tight")
            print(f"Visualization saved to {save_path}")

        # plt.show()


def plot_imputation_results(rawdata, imputed_data, ground_truth_mask, num_features, plots_storage_workspace):
    """
    Plots a comparison of time series data, including ground truth and predicted missing data,
    and saves the figures in high-quality PDFs.

    Parameters:
    - rawdata (numpy.ndarray): Raw time series data. Shape: (time_steps, num_features)
    - imputed_data (numpy.ndarray): Imputed time series data. Shape: (time_steps, num_features)
    - ground_truth_mask (numpy.ndarray): Ground truth mask for missing data. Shape: (time_steps, num_features)
    - num_features (int): Number of features to plot.
    - plots_storage_workspace (str): Directory to save the plots.
    """

    # Calculate the number of rows of subplots to generate
    num_rows = (num_features // 3) + (1 if num_features % 3 != 0 else 0)

    # Create the results directory if it doesn't exist
    results_folder = os.path.join(plots_storage_workspace, 'results')
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)

    for row in range(num_rows):
        start_feature = row * 3
        end_feature = min(start_feature + 3, num_features)
        n_categories = end_feature - start_feature

        # Create subplots for the current batch of features
        fig, axs = plt.subplots(n_categories, 1, figsize=(20, 4 * n_categories))

        if n_categories == 1:
            axs = np.array([axs])  # Ensure axs is iterable for consistent handling

        for i in range(n_categories):
            feature_idx = start_feature + i
            category = f'Feature {feature_idx + 1}'

            time_steps = np.arange(rawdata.shape[0])

            # Plot the raw data
            axs[i].plot(time_steps, rawdata[:, feature_idx], label='Original Data', color='blue')

            # Plot the imputed data
            # axs[i].plot(time_steps, imputed_data[:, feature_idx], label='Imputed Data', color='green', linestyle='dashed')

            # Ground truth missing data as circles
            missing_gt_indices = np.where(ground_truth_mask[:, feature_idx] == 0)[0]
            axs[i].scatter(missing_gt_indices, rawdata[missing_gt_indices, feature_idx],
                           color='red', marker='o', label='Ground Truth Missing', edgecolor='black', zorder=3)

            # Predicted missing data as crosses
            axs[i].scatter(missing_gt_indices, imputed_data[missing_gt_indices, feature_idx],
                           color='purple', marker='x', label='Predicted Missing', zorder=3)

            # Titles and labels
            axs[i].set_title(f'{category} - Time Series with Missing Data', fontsize=14, fontweight='bold')
            axs[i].set_xlabel('Time', fontsize=14, fontweight='bold')
            axs[i].set_ylabel('Values', fontsize=14, fontweight='bold')

            # Legends
            legend = axs[i].legend(fontsize=12, frameon=True, loc='best')
            for text in legend.get_texts():
                text.set_fontweight('bold')
            legend.get_frame().set_edgecolor('black')
            legend.get_frame().set_linewidth(2)

            # Ticks customization
            axs[i].tick_params(axis='x', labelrotation=45, labelsize=12, width=2)
            axs[i].tick_params(axis='y', labelsize=12, width=2)

            # Bold x-tick and y-tick labels
            for label in axs[i].get_xticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')
            for label in axs[i].get_yticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')

        # Adjust layout
        plt.tight_layout()
        plt.subplots_adjust(hspace=0.5, wspace=0.3, top=0.95, bottom=0.1)

        # Save the figure as a high-quality PDF in the results folder
        pdf_filename = os.path.join(results_folder, f'timeseries_comparison_features_{start_feature + 1}_to_{end_feature}.pdf')
        plt.savefig(pdf_filename, format='pdf', dpi=300)
        plt.close(fig)

def calculate_missingness(all_mask_2d):
    """
    Calculates the overall missingness percentage and missingness for each feature.
    
    Args:
        all_mask_2d (torch.Tensor or np.ndarray): 2D tensor/array where 1 indicates valid data and 0 indicates missing data.
    
    Returns:
        dict: A dictionary containing overall missingness percentage and per-feature missingness percentages.
    """
    if isinstance(all_mask_2d, np.ndarray):
        all_mask_2d = torch.from_numpy(all_mask_2d)
    
    # Total number of elements
    total_elements = all_mask_2d.numel()
    # Total number of missing elements
    total_missing = total_elements - all_mask_2d.sum().item()
    # Overall missingness percentage
    overall_missingness_percentage = (total_missing / total_elements) * 100

    # Missingness per feature (column)
    missing_per_feature = all_mask_2d.shape[0] - all_mask_2d.sum(dim=0)
    feature_missingness_percentage = (missing_per_feature / all_mask_2d.shape[0]) * 100

    # Create a dictionary to store results
    missingness_results = {
        'overall_missingness_percentage': overall_missingness_percentage,
        'feature_missingness_percentage': feature_missingness_percentage.tolist()
    }

    return missingness_results


def randomly_execute_mask_function(data_matrix, missing_percentage):
    """
    Randomly selects one of the mask generation functions and executes it, with higher likelihood
    for generate_mask_with_intermittent_failures.

    Args:
        data_matrix (torch.Tensor): Input data matrix of shape (batch_size, seq_len, num_variables).
        missing_percentage (float): Percentage of missing values (0 to 100).

    Returns:
        torch.Tensor: A binary mask matrix of the same shape as data_matrix,
                      where 1 indicates observed values and 0 indicates missing values.

    How it works:

    # Example usage
    data_matrix = torch.rand(128, 24, 6)  # Random time series data with shape (batch_size, seq_len, num_variables)
    missing_percentage = 10  # % missing values
    mask_matrix = randomly_execute_mask_function(data_matrix, missing_percentage)
    visualize_mask(mask_matrix, num_batches=16, save_path="./output/mask_visualization.pdf")  # Specify a batch to visualize  
  
    """
    # Input validation
    if data_matrix.ndim != 3:
        raise ValueError("data_matrix must be a 3D tensor of shape (batch_size, seq_len, num_variables).")
    if not (0 <= missing_percentage <= 100):
        raise ValueError("missing_percentage must be between 0 and 100.")

    # Define functions and their corresponding argument configurations
    functions_with_args = {  
        generate_mask_mcar: {"args": [data_matrix, missing_percentage], "kwargs": {}},
        generate_mask_mar: {"args": [data_matrix, missing_percentage], "kwargs": {}},
        generate_mask_mnar: {"args": [data_matrix, missing_percentage], "kwargs": {}},
        generate_mask_with_temporal_blocks: {"args": [data_matrix, missing_percentage], "kwargs": {"block_min": 1, "block_max": 5}},
        generate_mask_with_spatial_blocks: {"args": [data_matrix, missing_percentage], "kwargs": {"block_min": 1, "block_max": 5}},
        generate_mask_with_spatio_temporal_blocks: {"args": [data_matrix, missing_percentage], "kwargs": {"block_min_time": 2, "block_max_time": 5, "block_min_var": 1, "block_max_var": 3}},
        generate_mask_with_intermittent_failures: {"args": [data_matrix, missing_percentage], "kwargs": {"block_min": 1, "block_max": 3, "sparsity_factor": 0.1}},
    }

    # List of functions with weights for more control over selection probability
    functions = list(functions_with_args.keys())
    weights = [10000, 10000, 10000, 1, 1, 1, 1]  # More weight for generate_mask_with_intermittent_failures

    # Randomly select a function with given weights
    selected_function = random.choices(functions, weights=weights, k=1)[0]
    #print(f"Selected function: {selected_function.__name__}")

    # Execute the selected function
    func_args = functions_with_args[selected_function]["args"]
    func_kwargs = functions_with_args[selected_function]["kwargs"]

    mask_matrix = selected_function(*func_args, **func_kwargs)

    # Convert the result to CPU for compatibility, if needed
    return mask_matrix.cpu() if mask_matrix.device.type != 'cpu' else mask_matrix



























