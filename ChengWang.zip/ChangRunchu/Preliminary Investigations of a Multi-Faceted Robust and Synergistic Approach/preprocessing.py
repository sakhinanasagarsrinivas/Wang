import torch
import torchvision.transforms as transforms
from PIL import Image
import numpy as np
import cv2
import os
from typing import Tuple, List

class DataPreprocessor:
    def __init__(self, config):
        self.config = config
        self.transform = transforms.Compose([
            transforms.Resize((config.image_size, config.image_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            )
        ])
        
    def preprocess_image(self, image_path: str) -> torch.Tensor:
        """Preprocess a single image."""
        try:
            # Read image
            image = Image.open(image_path).convert('RGB')
            # Apply transformations
            image_tensor = self.transform(image)
            return image_tensor
        except Exception as e:
            print(f"Error preprocessing image {image_path}: {e}")
            return None

    def prepare_dataset(self, data_dir: str) -> Tuple[List[torch.Tensor], List[int], List[str]]:
        """Prepare entire dataset."""
        images = []
        labels = []
        categories = []
        
        # Get all categories
        class_dirs = sorted(os.listdir(data_dir))
        class_to_idx = {cls_name: idx for idx, cls_name in enumerate(class_dirs)}
        
        for class_name in class_dirs:
            class_path = os.path.join(data_dir, class_name)
            if not os.path.isdir(class_path):
                continue
                
            for img_name in os.listdir(class_path):
                img_path = os.path.join(class_path, img_name)
                if not img_path.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.tiff')):
                    continue
                    
                processed_image = self.preprocess_image(img_path)
                if processed_image is not None:
                    images.append(processed_image)
                    labels.append(class_to_idx[class_name])
                    categories.append(class_name)
        
        return images, labels, categories

    def augment_image(self, image: torch.Tensor) -> torch.Tensor:
        """Apply data augmentation."""
        augment_transform = transforms.Compose([
            transforms.RandomHorizontalFlip(),
            transforms.RandomVerticalFlip(),
            transforms.RandomRotation(30),
            transforms.ColorJitter(brightness=0.2, contrast=0.2)
        ])
        return augment_transform(image)

    def normalize_metadata(self, text: str) -> str:
        """Normalize text metadata."""
        # Remove special characters
        text = ''.join(c if c.isalnum() or c.isspace() else ' ' for c in text)
        # Convert to lowercase
        text = text.lower()
        # Remove extra whitespace
        text = ' '.join(text.split())
        return text

    @staticmethod
    def create_patches(image_tensor: torch.Tensor, patch_size: int) -> torch.Tensor:
        """Create patches from image tensor."""
        B, C, H, W = image_tensor.shape
        patches = image_tensor.unfold(2, patch_size, patch_size)\
                             .unfold(3, patch_size, patch_size)\
                             .reshape(B, C, -1, patch_size, patch_size)\
                             .permute(0, 2, 1, 3, 4)
        return patches.reshape(B, -1, C * patch_size * patch_size)

    def get_validation_transforms(self) -> transforms.Compose:
        """Get transforms for validation/testing."""
        return transforms.Compose([
            transforms.Resize((self.config.image_size, self.config.image_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            )
        ])

    def preprocess_batch(self, batch: List[str]) -> torch.Tensor:
        """Preprocess a batch of images."""
        processed_images = []
        for image_path in batch:
            processed = self.preprocess_image(image_path)
            if processed is not None:
                processed_images.append(processed)
        return torch.stack(processed_images) if processed_images else None