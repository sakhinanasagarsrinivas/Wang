from typing import Dict, List, Optional
from langchain.llms import HuggingFacePipeline
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import torch

from .base_agent import BaseAgent
from .sub_agent import SubAgent
from .critique_agent import CritiqueAgent

class MainAgent(BaseAgent):
    def __init__(self, config_path: str):
        """Initialize main agent with configuration."""
        super().__init__(config_path, "main_agent")
        self.sub_agents = {
            "pfd": SubAgent(config_path, "pfd"),
            "pid": SubAgent(config_path, "pid")
        }
        self.critique_agent = CritiqueAgent(config_path)
        self.task_planning_chain = self._create_task_planning_chain()
    
    def _initialize_llm(self) -> HuggingFacePipeline:
        """Initialize Gemma model for main agent."""
        model_name = self.model_config['model_name']
        
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16,
            device_map="auto"
        )
        
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            max_new_tokens=self.model_config['max_tokens'],
            temperature=self.model_config['temperature'],
            device_map="auto"
        )
        
        return HuggingFacePipeline(pipeline=pipe)
    
    def _create_task_planning_chain(self) -> LLMChain:
        """Create chain for task planning and decomposition."""
        template = """
        Given the following query about process diagrams:
        {query}
        
        Break down this query into subtasks and determine which type of diagram (PFD or P&ID) is most relevant.
        
        Provide your response in the following format:
        Diagram Type: [PFD/P&ID]
        Subtasks:
        1. [First subtask]
        2. [Second subtask]
        ...
        
        Your response:
        """
        
        prompt = PromptTemplate(
            template=template,
            input_variables=["query"]
        )
        
        return LLMChain(llm=self.llm, prompt=prompt)
    
    def process_query(self, query: str, context: Optional[Dict] = None) -> Dict:
        """
        Process a query through the multi-agent framework.
        
        Args:
            query: User query
            context: Optional context information
            
        Returns:
            Dictionary containing the final response and processing metadata
        """
        # 1. Plan task and determine relevant diagram type
        task_plan = self.task_planning_chain.run(query)
        diagram_type = self._extract_diagram_type(task_plan)
        
        # 2. Delegate to appropriate sub-agent
        sub_agent = self.sub_agents[diagram_type.lower()]
        initial_response = sub_agent.process_query(query, context)
        
        # 3. Get critique and feedback
        critique = self.critique_agent.evaluate_response(
            query=query,
            response=initial_response,
            context=context
        )
        
        # 4. If needed, refine response based on critique
        final_response = self._refine_response(
            initial_response=initial_response,
            critique=critique,
            sub_agent=sub_agent,
            query=query,
            context=context
        )
        
        return self._format_response({
            'final_response': final_response,
            'task_plan': task_plan,
            'critique': critique,
            'metadata': {
                'diagram_type': diagram_type,
                'iterations': 1 if final_response == initial_response else 2
            }
        })
    
    def _extract_diagram_type(self, task_plan: str) -> str:
        """Extract diagram type from task plan."""
        # Simple extraction - in practice, use more robust parsing
        if "PFD" in task_plan:
            return "PFD"
        return "PID"
    
    def _refine_response(
        self,
        initial_response: Dict,
        critique: Dict,
        sub_agent: SubAgent,
        query: str,
        context: Optional[Dict]
    ) -> Dict:
        """
        Refine response based on critique feedback.
        
        Args:
            initial_response: Original response from sub-agent
            critique: Feedback from critique agent
            sub_agent: Reference to sub-agent for potential reprocessing
            query: Original query
            context: Optional context information
            
        Returns:
            Refined response or original response if no refinement needed
        """
        if critique.get('needs_refinement', False):
            # Add critique feedback to context
            refined_context = context.copy() if context else {}
            refined_context['critique_feedback'] = critique['feedback']
            
            # Reprocess with updated context
            return sub_agent.process_query(query, refined_context)
        
        return initial_response