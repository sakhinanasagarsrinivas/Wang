import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import json
import argparse
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import time
import os

torch.manual_seed(42)
np.random.seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(42)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

class GaussianRandomField:
    def __init__(self, size, length_scale, device='cpu'):
        self.size = size
        self.device = device
        freqs = torch.fft.rfftfreq(size, d=1/size).to(device)
        self.power_spectrum = (1.0 / (2.0 * np.pi * length_scale**2)) * \
                              torch.exp(-0.5 * freqs**2 * length_scale**2)
        self.power_spectrum[0] = 0

    def sample(self, n_samples, mean=0.0, stddev=1.0):
        rand_coeffs = (torch.randn(n_samples, self.size // 2 + 1, dtype=torch.cfloat, device=self.device) *
                       np.sqrt(self.size))
        f_coeffs = rand_coeffs * torch.sqrt(self.power_spectrum)
        field = torch.fft.irfft(f_coeffs, n=self.size, norm='ortho')
        field_std = torch.std(field, dim=-1, keepdim=True)
        field = field / (field_std + 1e-8) * stddev
        field += mean
        return field.unsqueeze(-1)

class FactorizedSpectralConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, modes_z, modes_t):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes_z = modes_z
        self.modes_t = modes_t

        scale = 1 / (in_channels * out_channels)
        self.weights_z = nn.Parameter(scale * torch.rand(in_channels, out_channels, self.modes_z, dtype=torch.cfloat))
        self.weights_t = nn.Parameter(scale * torch.rand(in_channels, out_channels, self.modes_t, dtype=torch.cfloat))

    def forward(self, x):
        B, C, NZ, NT = x.shape

        x_ft_t = torch.fft.rfft(x, n=NT, dim=-1)
        out_ft_t = torch.zeros(B, self.out_channels, NZ, NT // 2 + 1, device=x.device, dtype=torch.cfloat)
        out_ft_t[..., :self.modes_t] = torch.einsum("bixy,ioy->boxy", x_ft_t[..., :self.modes_t], self.weights_t)
        x_t = torch.fft.irfft(out_ft_t, n=NT, dim=-1)

        x_ft_z = torch.fft.rfft(x, n=NZ, dim=-2)
        out_ft_z = torch.zeros(B, self.out_channels, NZ // 2 + 1, NT, device=x.device, dtype=torch.cfloat)
        out_ft_z[..., :self.modes_z, :] = torch.einsum("bixy,iox->boxy", x_ft_z[..., :self.modes_z, :], self.weights_z)
        x_z = torch.fft.irfft(out_ft_z, n=NZ, dim=-2)

        return x_t + x_z

class F_FNO_Block(nn.Module):
    def __init__(self, width, modes_z, modes_t):
        super().__init__()
        self.conv = FactorizedSpectralConv2d(width, width, modes_z, modes_t)
        self.w = nn.Conv2d(width, width, 1)
        self.norm = nn.InstanceNorm2d(width)

    def forward(self, x):
        residual = x
        x1 = self.conv(x)
        x2 = self.w(x)
        out = self.norm(x1 + x2)
        return F.gelu(out) + residual

class F_FNO(nn.Module):
    def __init__(self, width, num_blocks, modes_z, modes_t, in_channels=4, out_channels=1):
        super().__init__()
        self.modes_z = modes_z
        self.modes_t = modes_t
        self.width = width
        self.fc0 = nn.Linear(in_channels, self.width)
        self.blocks = nn.ModuleList([F_FNO_Block(self.width, self.modes_z, self.modes_t) for _ in range(num_blocks)])
        self.fc1 = nn.Linear(self.width, 128)
        self.fc2 = nn.Linear(128, out_channels)

    def forward(self, x):
        x = self.fc0(x)
        x = x.permute(0, 3, 1, 2)
        for block in self.blocks:
            x = block(x)
        x = x.permute(0, 2, 3, 1)
        x = F.gelu(self.fc1(x))
        x = self.fc2(x)
        return x

class F_FNO_PFR_Solver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._setup_grid_and_data_generator()
        self._build_model()
        self.val_input, self.val_ics, self.val_bcs = self._generate_batch(self.hp_train['batch_size'])
        self.best_val_loss = float('inf')
        self.epochs_no_improve = 0

    def _parse_config(self):
        problem_config = self.config['problems'][0]
        self.problem = problem_config['problem_definition']
        self.op_inputs = problem_config['operator_input_specification']
        self.hp_model = self.config['hyperparameters']['model_architecture']
        self.hp_train = self.config['hyperparameters']['training']
        self.state_vars = self.problem['state_variables']

    def _setup_grid_and_data_generator(self):
        self.z_domain = self.op_inputs['discretization']['spatial_domain']
        self.nz = self.op_inputs['discretization']['num_spatial_points']
        self.t_domain = self.op_inputs['discretization']['time_domain']
        self.nt = self.op_inputs['discretization']['num_time_points']
        self.z_grid = torch.linspace(self.z_domain[0], self.z_domain[1], self.nz, device=self.device)
        self.t_grid = torch.linspace(self.t_domain[0], self.t_domain[1], self.nt, device=self.device)
        self.dz = self.z_grid[1] - self.z_grid[0]
        self.dt = self.t_grid[1] - self.t_grid[0]
        ic_config = self.op_inputs['initial_conditions_distribution']['C_z0']
        self.grf_ic = GaussianRandomField(self.nz, ic_config['parameters']['length_scale'], device=self.device)
        self.ic_mean, self.ic_std = ic_config['parameters']['mean'], ic_config['parameters']['stddev']
        bc_config = self.op_inputs['function_inputs']['C_in_t']
        self.grf_bc = GaussianRandomField(self.nt, bc_config['parameters']['length_scale'], device=self.device)
        self.bc_mean, self.bc_std = bc_config['parameters']['mean'], bc_config['parameters']['stddev']

    def _build_model(self):
        self.model = F_FNO(
            width=self.hp_model['width'],
            num_blocks=self.hp_model['num_blocks'],
            modes_z=self.hp_model['modes_z'],
            modes_t=self.hp_model['modes_t'],
            in_channels=4,
            out_channels=len(self.state_vars)
        ).to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=self.hp_train['learning_rate'],
            weight_decay=self.hp_train['weight_decay']
        )
        self.scheduler = torch.optim.lr_scheduler.OneCycleLR(
            self.optimizer, max_lr=self.hp_train['learning_rate'],
            epochs=self.hp_train['epochs'],
            steps_per_epoch=1
        )

    def _generate_batch(self, batch_size):
        ics = self.grf_ic.sample(batch_size, self.ic_mean, self.ic_std)
        bcs = self.grf_bc.sample(batch_size, self.bc_mean, self.bc_std)
        ics_grid = ics.unsqueeze(2).expand(-1, -1, self.nt, -1)
        bcs_grid = bcs.unsqueeze(1).expand(-1, self.nz, -1, -1)
        z_norm = self.z_grid / self.z_domain[1]
        t_norm = self.t_grid / self.t_domain[1]
        z_grid, t_grid = torch.meshgrid(z_norm, t_norm, indexing='ij')
        coord_grid = torch.stack([z_grid, t_grid], dim=-1).unsqueeze(0).expand(batch_size, -1, -1, -1)
        model_input = torch.cat([ics_grid, bcs_grid, coord_grid], dim=-1)
        return model_input, ics, bcs

    def calculate_loss(self, model_input_grid, ics, bcs):
        C_pred = self.model(model_input_grid)
        C_pred_squeezed = C_pred.squeeze(-1)
        dC_dt = torch.gradient(C_pred_squeezed, spacing=self.dt, dim=2)[0]
        dC_dz = torch.gradient(C_pred_squeezed, spacing=self.dz, dim=1)[0]
        scope = self.problem['parameters'].copy()
        scope.update({'C': C_pred_squeezed, 'dCdz': dC_dz})
        pde_rhs = eval(self.problem['pde']['dCdt'], {}, scope)
        residual = dC_dt - pde_rhs
        loss_res = F.mse_loss(residual, torch.zeros_like(residual))
        loss_ic = F.mse_loss(C_pred[:, :, 0, :], ics)
        loss_bc = F.mse_loss(C_pred[:, 0, :, :], bcs)
        total_loss = (self.hp_train['loss_weights']['pde_residual'] * loss_res +
                      self.hp_train['loss_weights']['initial_condition'] * loss_ic +
                      self.hp_train['loss_weights']['boundary_condition'] * loss_bc)
        return total_loss, loss_res, loss_ic, loss_bc

    def train(self):
        print("--- Starting F-FNO Training ---")
        start_time = time.time()
        for epoch in range(self.hp_train['epochs']):
            self.model.train()
            model_input_grid, ics, bcs = self._generate_batch(self.hp_train['batch_size'])
            self.optimizer.zero_grad(set_to_none=True)
            total_loss, _, _, _ = self.calculate_loss(model_input_grid, ics, bcs)
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.hp_train['gradient_clip_norm'])
            self.optimizer.step()
            self.scheduler.step()
            if (epoch + 1) % self.hp_train['validation_frequency'] == 0:
                self.model.eval()
                with torch.no_grad():
                    val_loss, _, _, _ = self.calculate_loss(self.val_input, self.val_ics, self.val_bcs)
                lr = self.optimizer.param_groups[0]['lr']
                print(f'Epoch [{epoch+1}/{self.hp_train["epochs"]}], Train Loss: {total_loss.item():.4e}, Val Loss: {val_loss.item():.4e}, LR: {lr:.4e}')
                if self.hp_train['early_stopping']['enabled']:
                    if val_loss < self.best_val_loss - self.hp_train['early_stopping']['min_delta']:
                        self.best_val_loss = val_loss
                        self.epochs_no_improve = 0
                        torch.save(self.model.state_dict(), 'best_model_fno.pth')
                    else:
                        self.epochs_no_improve += self.hp_train['validation_frequency']
                    if self.epochs_no_improve >= self.hp_train['early_stopping']['patience']:
                        print(f"Early stopping triggered at epoch {epoch+1}. Best validation loss: {self.best_val_loss:.4e}")
                        break
        elapsed = time.time() - start_time
        print(f"--- Training finished in {elapsed:.2f} seconds ---")
        if self.hp_train['early_stopping']['enabled'] and os.path.exists('best_model_fno.pth'):
            print("Loading best model for evaluation.")
            self.model.load_state_dict(torch.load('best_model_fno.pth'))

    def evaluate_and_plot(self, num_test_cases=4):
        self.model.eval()
        os.makedirs("results_fno", exist_ok=True)
        model_input_grid, ics, bcs = self._generate_batch(num_test_cases)
        with torch.no_grad():
            C_fno = self.model(model_input_grid).cpu().numpy().squeeze(-1)
        ics_np, bcs_np = ics.cpu().numpy().squeeze(-1), bcs.cpu().numpy().squeeze(-1)
        fig, axes = plt.subplots(num_test_cases, 2, figsize=(12, 5 * num_test_cases), squeeze=False)
        all_errors = []
        for i in range(num_test_cases):
            sol_numerical = self.solve_numerically(ics_np[i], bcs_np[i])
            relative_l2_error = np.linalg.norm(C_fno[i] - sol_numerical) / np.linalg.norm(sol_numerical)
            all_errors.append(relative_l2_error)
            print(f"Test Case {i+1} | Rel L2 Error: {relative_l2_error:.4e}")
            vmax = max(np.max(sol_numerical), np.max(C_fno[i]))
            vmin = min(np.min(sol_numerical), np.min(C_fno[i]))
            im1 = axes[i, 0].imshow(C_fno[i].T, extent=[*self.z_domain, *self.t_domain], origin='lower', aspect='auto', cmap='viridis', vmin=vmin, vmax=vmax)
            axes[i, 0].set_title(f'F-FNO Prediction (Case {i+1})'); axes[i, 0].set_xlabel('Position (z)'); axes[i, 0].set_ylabel('Time (t)')
            im2 = axes[i, 1].imshow(sol_numerical.T, extent=[*self.z_domain, *self.t_domain], origin='lower', aspect='auto', cmap='viridis', vmin=vmin, vmax=vmax)
            axes[i, 1].set_title(f'Numerical Solution (Case {i+1})'); axes[i, 1].set_xlabel('Position (z)'); axes[i, 1].set_ylabel('Time (t)')
            fig.colorbar(im1, ax=axes[i, 0]); fig.colorbar(im2, ax=axes[i, 1])
        print(f"\nMean Relative L2 Error over {num_test_cases} cases: {np.mean(all_errors):.4e}")
        fig.suptitle('F-FNO Generalization on Unseen ICs and BCs', fontsize=16)
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.savefig("results_fno/fno_generalization_test.pdf")
        plt.close()
        print("\nEvaluation plot saved to results_fno/fno_generalization_test.pdf")

    def solve_numerically(self, C0, Cin_t):
        u, k = self.problem['parameters']['u'], self.problem['parameters']['k']
        z_np, t_np = self.z_grid.cpu().numpy(), self.t_grid.cpu().numpy()
        dz = z_np[1] - z_np[0]
        def pde_system(t, C):
            C_in = np.interp(t, t_np, Cin_t)
            dCdz = np.zeros_like(C)
            dCdz[1:] = (C[1:] - C[:-1]) / dz
            dCdz[0] = (C[0] - C_in) / dz
            return -u * dCdz - k * C
        sol = solve_ivp(pde_system, self.t_domain, C0, t_eval=t_np, method='DOP853', rtol=1e-6, atol=1e-8)
        return sol.y

def main():
    parser = argparse.ArgumentParser(description="Factorized Fourier Neural Operator Solver for PFRs")
    parser.add_argument("config_file", type=str, help="Path to the JSON configuration file.", default="problem_config.json", nargs='?')
    args = parser.parse_args()
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    solver = F_FNO_PFR_Solver(config)
    solver.train()
    solver.evaluate_and_plot(num_test_cases=config['hyperparameters']['evaluation']['test_cases'])

if __name__ == "__main__":
    main()