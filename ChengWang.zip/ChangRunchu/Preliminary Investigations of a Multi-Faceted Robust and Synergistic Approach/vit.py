import torch
import torch.nn as nn
import torch.nn.functional as F

class PatchEmbedding(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.patch_size = config.patch_size
        self.proj = nn.Conv2d(
            config.num_channels,
            config.embed_dim,
            kernel_size=config.patch_size,
            stride=config.patch_size
        )
        
        # Calculate number of patches
        self.num_patches = (config.image_size // config.patch_size) ** 2
        
        # Create positional embeddings
        self.pos_embed = nn.Parameter(
            torch.randn(1, self.num_patches + 1, config.embed_dim)
        )
        self.cls_token = nn.Parameter(torch.randn(1, 1, config.embed_dim))
        
    def forward(self, x):
        B = x.shape[0]
        # Project patches
        x = self.proj(x)
        x = x.flatten(2).transpose(1, 2)
        
        # Add classification token
        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        
        # Add positional embeddings
        x = x + self.pos_embed
        return x

class TransformerEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.layers = nn.ModuleList([
            TransformerBlock(config)
            for _ in range(config.num_layers)
        ])
        
    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

class TransformerBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.norm1 = nn.LayerNorm(config.embed_dim)
        self.attn = nn.MultiheadAttention(
            config.embed_dim,
            config.num_heads,
            dropout=config.dropout
        )
        self.norm2 = nn.LayerNorm(config.embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(config.embed_dim, int(config.embed_dim * config.mlp_ratio)),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(int(config.embed_dim * config.mlp_ratio), config.embed_dim),
            nn.Dropout(config.dropout)
        )
        
    def forward(self, x):
        # Multi-head attention
        x = x + self._attention_block(self.norm1(x))
        # MLP block
        x = x + self.mlp(self.norm2(x))
        return x
    
    def _attention_block(self, x):
        x = x.transpose(0, 1)  # (B, N, D) -> (N, B, D)
        x, _ = self.attn(x, x, x)
        x = x.transpose(0, 1)  # (N, B, D) -> (B, N, D)
        return x

class ViT(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.patch_embed = PatchEmbedding(config)
        self.transformer = TransformerEncoder(config)
        self.norm = nn.LayerNorm(config.embed_dim)
        
    def forward(self, x):
        # Create patch embeddings
        x = self.patch_embed(x)
        # Apply transformer
        x = self.transformer(x)
        # Get CLS token output
        x = self.norm(x)
        cls_token_output = x[:, 0]
        return cls_token_output