import torch
import torch.nn as nn
import math
from typing import Optional, Tuple

class MultiHeadAttention(nn.Module):
    """Multi-head attention mechanism"""
    
    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        
        # Linear layers for Q, K, V projections
        self.W_q = nn.Linear(d_model, d_model)
        self.W_k = nn.Linear(d_model, d_model)
        self.W_v = nn.Linear(d_model, d_model)
        
        # Output projection
        self.W_o = nn.Linear(d_model, d_model)
        
        self.dropout = nn.Dropout(dropout)
        
    def scaled_dot_product_attention(
        self,
        Q: torch.Tensor,
        K: torch.Tensor,
        V: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Compute scaled dot-product attention
        
        Args:
            Q: Query tensor
            K: Key tensor
            V: Value tensor
            mask: Optional attention mask
            
        Returns:
            Tuple of (attention output, attention weights)
        """
        d_k = Q.size(-1)
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(d_k)
        
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
            
        attention_weights = torch.softmax(scores, dim=-1)
        attention_weights = self.dropout(attention_weights)
        
        output = torch.matmul(attention_weights, V)
        
        return output, attention_weights
        
    def forward(
        self,
        Q: torch.Tensor,
        K: torch.Tensor,
        V: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        batch_size = Q.size(0)
        
        # Linear projections and reshape
        Q = self.W_q(Q).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        K = self.W_k(K).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        V = self.W_v(V).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        
        # Apply attention
        output, attention_weights = self.scaled_dot_product_attention(Q, K, V, mask)
        
        # Reshape and project output
        output = output.transpose(1, 2).contiguous().view(batch_size, -1, self.d_model)
        output = self.W_o(output)
        
        return output, attention_weights

class HierarchicalMultiHeadAttention(nn.Module):
    """Hierarchical multi-head attention for cross-modal integration"""
    
    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        
        self.first_layer_attention = MultiHeadAttention(d_model, num_heads, dropout)
        self.second_layer_attention = MultiHeadAttention(d_model, num_heads, dropout)
        
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        
    def forward(
        self,
        org_embeddings: torch.Tensor,
        exp_embeddings: torch.Tensor,
        pred_embeddings: torch.Tensor
    ) -> torch.Tensor:
        """
        Forward pass through hierarchical attention
        
        Args:
            org_embeddings: Original text embeddings
            exp_embeddings: Explanation embeddings
            pred_embeddings: Prediction embeddings
            
        Returns:
            Integrated cross-modal embeddings
        """
        # First layer: combine original and explanation embeddings
        unified_embeddings, _ = self.first_layer_attention(
            org_embeddings,
            exp_embeddings,
            exp_embeddings
        )
        unified_embeddings = self.norm1(unified_embeddings)
        
        # Second layer: integrate with prediction embeddings
        cross_modal_embeddings, _ = self.second_layer_attention(
            unified_embeddings,
            pred_embeddings,
            pred_embeddings
        )
        cross_modal_embeddings = self.norm2(cross_modal_embeddings)
        
        return cross_modal_embeddings