# train/trainer.py
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Dict, Optional, Tuple
import logging
from tqdm import tqdm
import time
from utils.helpers import AverageMeter, format_time, save_checkpoint, move_to_device
from utils.metrics import Metrics

class Trainer:
    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        criterion: nn.Module,
        scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None,
        device: str = 'cuda',
        max_grad_norm: float = 1.0,
        logger: Optional[logging.Logger] = None,
        save_dir: str = './checkpoints',
        save_freq: int = 1,
        eval_freq: int = 1
    ):
        self.model = model.to(device)
        self.optimizer = optimizer
        self.criterion = criterion
        self.scheduler = scheduler
        self.device = device
        self.max_grad_norm = max_grad_norm
        self.logger = logger or logging.getLogger(__name__)
        self.save_dir = save_dir
        self.save_freq = save_freq
        self.eval_freq = eval_freq
        self.metrics = Metrics()
        
        # Initialize best metric score for model saving
        self.best_metric = float('inf')
        
    def train_epoch(
        self,
        train_loader: DataLoader,
        epoch: int
    ) -> Dict[str, float]:
        """Train for one epoch."""
        self.model.train()
        
        # Initialize meters
        loss_meter = AverageMeter()
        time_meter = AverageMeter()
        
        start_time = time.time()
        pbar = tqdm(train_loader, desc=f"Epoch {epoch}")
        
        for batch_idx, batch in enumerate(pbar):
            batch_start = time.time()
            batch = move_to_device(batch, self.device)
            
            # Forward pass
            self.optimizer.zero_grad()
            outputs = self.model(**batch)
            loss = outputs.loss if hasattr(outputs, 'loss') else outputs[0]
            
            # Add auxiliary losses if present
            if hasattr(self.model, 'get_aux_loss'):
                aux_loss = self.model.get_aux_loss()
                loss += aux_loss
            
            # Backward pass
            loss.backward()
            
            # Clip gradients
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(),
                self.max_grad_norm
            )
            
            # Optimizer step
            self.optimizer.step()
            
            # Update scheduler if needed
            if self.scheduler is not None:
                self.scheduler.step()
                
            # Update meters
            loss_meter.update(loss.item())
            time_meter.update(time.time() - batch_start)
            
            # Update progress bar
            pbar.set_postfix({
                'loss': f"{loss_meter.avg:.4f}",
                'time/batch': f"{time_meter.avg:.2f}s"
            })
            
        epoch_time = time.time() - start_time
        
        # Log epoch stats
        self.logger.info(
            f"Epoch {epoch} - "
            f"Loss: {loss_meter.avg:.4f} - "
            f"Time: {format_time(epoch_time)}"
        )
        
        return {'loss': loss_meter.avg}
    
    def validate(
        self,
        val_loader: DataLoader
    ) -> Dict[str, float]:
        """Validate the model."""
        self.model.eval()
        
        # Initialize meters
        loss_meter = AverageMeter()
        metric_meters = {
            'bleu-2': AverageMeter(),
            'bleu-4': AverageMeter(),
            'rouge-1': AverageMeter(),
            'rouge-2': AverageMeter(),
            'rouge-l': AverageMeter(),
            'meteor': AverageMeter()
        }
        
        with torch.no_grad():
            for batch in tqdm(val_loader, desc="Validating"):
                batch = move_to_device(batch, self.device)
                
                # Forward pass
                outputs = self.model(**batch)
                loss = outputs.loss if hasattr(outputs, 'loss') else outputs[0]
                
                # Update loss meter
                loss_meter.update(loss.item())
                
                # Generate predictions
                if hasattr(outputs, 'logits'):
                    predictions = outputs.logits.argmax(dim=-1)
                else:
                    predictions = self.model.generate(
                        batch['input_ids'],
                        max_length=128,
                        num_beams=4,
                        early_stopping=True
                    )
                
                # Convert predictions and references to text
                pred_texts = self.tokenizer.batch_decode(predictions, skip_special_tokens=True)
                ref_texts = self.tokenizer.batch_decode(batch['labels'], skip_special_tokens=True)
                
                # Calculate metrics
                metrics = self.metrics.calculate_all_metrics(ref_texts, pred_texts)
                
                # Update metric meters
                for metric_name, value in metrics.items():
                    metric_meters[metric_name].update(value)
        
        # Prepare validation results
        val_results = {
            'val_loss': loss_meter.avg,
            'val_bleu2': metric_meters['bleu-2'].avg,
            'val_bleu4': metric_meters['bleu-4'].avg,
            'val_rouge1': metric_meters['rouge-1'].avg,
            'val_rouge2': metric_meters['rouge-2'].avg,
            'val_rougeL': metric_meters['rouge-l'].avg,
            'val_meteor': metric_meters['meteor'].avg
        }
        
        # Log validation results
        self.logger.info(
            "Validation Results - " +
            " - ".join([f"{k}: {v:.4f}" for k, v in val_results.items()])
        )
        
        return val_results
    
    def train(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
        num_epochs: int,
        tokenizer=None,
    ) -> Dict[str, list]:
        """Main training loop."""
        self.tokenizer = tokenizer
        history = {
            'train_loss': [],
            'val_loss': [],
            'val_bleu2': [],
            'val_bleu4': [],
            'val_rouge1': [],
            'val_rouge2': [],
            'val_rougeL': [],
            'val_meteor': []
        }
        
        best_val_loss = float('inf')
        
        for epoch in range(1, num_epochs + 1):
            # Train epoch
            train_metrics = self.train_epoch(train_loader, epoch)
            history['train_loss'].append(train_metrics['loss'])
            
            # Validate epoch
            if epoch % self.eval_freq == 0:
                val_metrics = self.validate(val_loader)
                
                # Update history
                for metric_name, value in val_metrics.items():
                    if metric_name in history:
                        history[metric_name].append(value)
                
                # Save best model
                if val_metrics['val_loss'] < best_val_loss:
                    best_val_loss = val_metrics['val_loss']
                    save_checkpoint(
                        self.model,
                        self.optimizer,
                        self.scheduler,
                        epoch,
                        val_metrics,
                        self.save_dir,
                        'best_model'
                    )
                    
            # Save regular checkpoint
            if epoch % self.save_freq == 0:
                save_checkpoint(
                    self.model,
                    self.optimizer,
                    self.scheduler,
                    epoch,
                    val_metrics if epoch % self.eval_freq == 0 else {},
                    self.save_dir,
                    f'checkpoint_epoch_{epoch}'
                )
        
        return history

    def evaluate(
        self,
        test_loader: DataLoader
    ) -> Dict[str, float]:
        """Evaluate model on test set."""
        test_metrics = self.validate(test_loader)
        
        # Log test results
        self.logger.info(
            "Test Results - " +
            " - ".join([f"{k}: {v:.4f}" for k, v in test_metrics.items()])
        )
        
        return test_metrics
    
    def predict(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        **kwargs
    ) -> torch.Tensor:
        """Generate predictions for given input."""
        self.model.eval()
        with torch.no_grad():
            input_ids = input_ids.to(self.device)
            if attention_mask is not None:
                attention_mask = attention_mask.to(self.device)
            
            outputs = self.model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                **kwargs
            )
            
        return outputs