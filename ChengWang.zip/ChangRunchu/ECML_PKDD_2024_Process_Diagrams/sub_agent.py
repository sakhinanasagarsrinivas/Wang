from typing import Dict, List, Optional, Tuple
from langchain.llms import HuggingFacePipeline
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import torch

from .base_agent import BaseAgent

class SubAgent(BaseAgent):
    def __init__(self, config_path: str, diagram_type: str):
        """
        Initialize sub-agent for specific diagram type.
        
        Args:
            config_path: Path to configuration file
            diagram_type: Type of diagram (pfd or pid)
        """
        super().__init__(config_path, "sub_agent")
        self.diagram_type = diagram_type
        self.candidate_chain = self._create_candidate_chain()
        self.summary_chain = self._create_summary_chain()
        self.validation_chain = self._create_validation_chain()
        self.ranking_chain = self._create_ranking_chain()
    
    def _initialize_llm(self) -> HuggingFacePipeline:
        """Initialize PaliGemma model for sub-agent."""
        model_name = self.model_config['model_name']
        
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16,
            device_map="auto"
        )
        
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            max_new_tokens=self.model_config['max_tokens'],
            temperature=self.model_config['temperature'],
            device_map="auto"
        )