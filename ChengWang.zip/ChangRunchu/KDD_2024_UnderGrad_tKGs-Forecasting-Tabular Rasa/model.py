"""
model.py - Neural network models for Temporal Knowledge Graph Forecasting
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import logging
from typing import Dict, List, Optional, Tuple, Union
from dataclasses import dataclass

from .core import ValidationError

logger = logging.getLogger(__name__)

@dataclass
class ModelConfig:
    """Configuration for sLA-tKGF model"""
    hidden_dim: int = 128
    num_layers: int = 3
    num_heads: int = 8
    dropout: float = 0.1
    learning_rate: float = 1e-3
    batch_size: int = 48
    num_epochs: int = 30
    
    def validate(self) -> bool:
        """Validate model configuration"""
        try:
            assert self.hidden_dim > 0
            assert self.num_layers > 0
            assert self.num_heads > 0
            assert 0 <= self.dropout < 1
            assert self.learning_rate > 0
            assert self.batch_size > 0
            assert self.num_epochs > 0
            return True
        except AssertionError as e:
            logger.error(f"Invalid model configuration: {str(e)}")
            return False

class MultiHeadAttention(nn.Module):
    """Multi-head attention module with rigorous checks"""
    
    def __init__(self, d_model: int, num_heads: int):
        super().__init__()
        
        # Validate inputs
        if d_model % num_heads != 0:
            raise ValidationError(
                f"d_model ({d_model}) must be divisible by num_heads ({num_heads})"
            )
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        
        # Initialize layers
        self.W_q = nn.Linear(d_model, d_model)
        self.W_k = nn.Linear(d_model, d_model)
        self.W_v = nn.Linear(d_model, d_model)
        self.W_o = nn.Linear(d_model, d_model)
        
        # Initialize weights
        self._reset_parameters()
        
    def _reset_parameters(self):
        """Initialize weights using Xavier uniform initialization"""
        nn.init.xavier_uniform_(self.W_q.weight)
        nn.init.xavier_uniform_(self.W_k.weight)
        nn.init.xavier_uniform_(self.W_v.weight)
        nn.init.xavier_uniform_(self.W_o.weight)
        
    def _validate_input_shapes(self, Q: torch.Tensor, K: torch.Tensor, V: torch.Tensor):
        """Validate input tensor shapes"""
        if not (len(Q.shape) == len(K.shape) == len(V.shape) == 3):
            raise ValidationError("Input tensors must be 3-dimensional")
        if not (Q.size(-1) == K.size(-1) == V.size(-1) == self.d_model):
            raise ValidationError(f"Input feature dimension must be {self.d_model}")
        if not (K.size(1) == V.size(1)):
            raise ValidationError("Key and Value must have same sequence length")
            
    def forward(
        self,
        Q: torch.Tensor,
        K: torch.Tensor,
        V: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        try:
            self._validate_input_shapes(Q, K, V)
            batch_size = Q.size(0)
            
            # Linear transformations and reshape
            Q = self.W_q(Q).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
            K = self.W_k(K).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
            V = self.W_v(V).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
            
            # Scaled dot-product attention
            scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_k)
            
            if mask is not None:
                scores = scores.masked_fill(mask == 0, float('-inf'))
                
            attention = F.softmax(scores, dim=-1)
            
            # Apply attention to V
            context = torch.matmul(attention, V)
            context = context.transpose(1, 2).contiguous().view(
                batch_size, -1, self.d_model
            )
            output = self.W_o(context)
            
            return output, attention
            
        except Exception as e:
            logger.error(f"Forward pass failed in MultiHeadAttention: {str(e)}")
            raise

class TemporalTransformerLayer(nn.Module):
    """Transformer layer with temporal attention"""
    
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        d_ff: int,
        dropout: float = 0.1
    ):
        super().__init__()
        
        # Validate inputs
        if d_ff < d_model:
            raise ValidationError(
                f"d_ff ({d_ff}) should be larger than d_model ({d_model})"
            )
        
        self.attention = MultiHeadAttention(d_model, num_heads)
        self.feed_forward = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model)
        )
        
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        
        # Initialize weights
        self._reset_parameters()
        
    def _reset_parameters(self):
        """Initialize weights of feed-forward layers"""
        for layer in self.feed_forward:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                if layer.bias is not None:
                    nn.init.zeros_(layer.bias)
                    
    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        try:
            # Self-attention with residual connection and layer norm
            attn_output, _ = self.attention(x, x, x, mask)
            x = self.norm1(x + self.dropout(attn_output))
            
            # Feed-forward with residual connection and layer norm
            ff_output = self.feed_forward(x)
            x = self.norm2(x + self.dropout(ff_output))
            
            return x
            
        except Exception as e:
            logger.error(f"Forward pass failed in TemporalTransformerLayer: {str(e)}")
            raise

class sLA_tKGF(nn.Module):
    """Small-scale Language Assistant for tKG Forecasting"""
    
    def __init__(
        self,
        config: ModelConfig,
        num_entities: int,
        num_relations: int
    ):
        super().__init__()
        
        # Validate inputs
        if not config.validate():
            raise ValidationError("Invalid model configuration")
            
        self.config = config
        self.num_entities = num_entities
        self.num_relations = num_relations
        
        # Initialize embeddings
        self.entity_embeddings = nn.Embedding(num_entities, config.hidden_dim)
        self.relation_embeddings = nn.Embedding(num_relations, config.hidden_dim)
        self.time_embeddings = nn.Linear(1, config.hidden_dim)
        
        # Initialize transformer layers
        self.historical_encoder = nn.ModuleList([
            TemporalTransformerLayer(
                config.hidden_dim,
                config.num_heads,
                config.hidden_dim * 4,
                config.dropout
            ) for _ in range(config.num_layers)
        ])
        
        # Initialize score predictor
        self.score_predictor = nn.Sequential(
            nn.Linear(config.hidden_dim * 3, config.hidden_dim),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim, num_entities)
        )
        
        # Initialize weights
        self._reset_parameters()
        
    def _reset_parameters(self):
        """Initialize model weights"""
        nn.init.xavier_uniform_(self.entity_embeddings.weight)
        nn.init.xavier_uniform_(self.relation_embeddings.weight)
        nn.init.xavier_uniform_(self.time_embeddings.weight)
        
        for layer in self.score_predictor:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                if layer.bias is not None:
                    nn.init.zeros_(layer.bias)
                    
    def _validate_batch(self, batch: Dict[str, torch.Tensor]):
        """Validate input batch"""
        required_keys = {'subject', 'relation', 'object', 'timestamp', 'historical_context'}
        if not all(k in batch for k in required_keys):
            raise ValidationError(f"Missing required keys in batch: {required_keys}")
            
    def encode_historical_context(
        self,
        historical_facts: torch.Tensor
    ) -> torch.Tensor:
        """Encode historical context using transformer layers"""
        try:
            batch_size, window_size = historical_facts.shape[:2]
            
            # Embed entities and relations
            s_emb = self.entity_embeddings(historical_facts[..., 0])
            r_emb = self.relation_embeddings(historical_facts[..., 1])
            o_emb = self.entity_embeddings(historical_facts[..., 2])
            
            # Combine embeddings
            fact_embeddings = torch.cat([s_emb, r_emb, o_emb], dim=-1)
            
            # Pass through transformer layers
            x = fact_embeddings
            for layer in self.historical_encoder:
                x = layer(x)
                
            return x.mean(dim=1)  # Pool across time dimension
            
        except Exception as e:
            logger.error(f"Failed to encode historical context: {str(e)}")
            raise
            
    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Forward pass of the model"""
        try:
            self._validate_batch(batch)
            
            # Encode input elements
            s_emb = self.entity_embeddings(batch['subject'])
            r_emb = self.relation_embeddings(batch['relation'])
            t_emb = self.time_embeddings(batch['timestamp'].unsqueeze(-1))
            
            # Encode historical context
            hist_emb = self.encode_historical_context(batch['historical_context'])
            
            # Combine embeddings
            combined = torch.cat([s_emb, r_emb, hist_emb], dim=-1)
            
            # Predict scores
            scores = self.score_predictor(combined)
            
            return scores
            
        except Exception as e:
            logger.error(f"Forward pass failed: {str(e)}")
            raise

class ModelTrainer:
    """Trainer class for sLA-tKGF model"""
    
    def __init__(
        self,
        model: sLA_tKGF,
        optimizer: torch.optim.Optimizer,
        device: torch.device,
        config: ModelConfig
    ):
        self.model = model
        self.optimizer = optimizer
        self.device = device
        self.config = config
        
        # Initialize best metrics
        self.best_mrr = 0.0
        self.best_hits = {k: 0.0 for k in [1, 3, 10]}
        
    def train_epoch(
        self,
        dataloader: torch.utils.data.DataLoader
    ) -> float:
        """Train for one epoch"""
        self.model.train()
        total_loss = 0.0
        
        for batch in dataloader:
            try:
                # Move batch to device
                batch = {k: v.to(self.device) for k, v in batch.items()}
                
                # Forward pass
                scores = self.model(batch)
                loss = F.cross_entropy(scores, batch['object'])
                
                # Backward pass
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                
                total_loss += loss.item()
                
            except Exception as e:
                logger.error(f"Error during training step: {str(e)}")
                continue
                
        return total_loss / len(dataloader)
        
    def evaluate(
        self,
        dataloader: torch.utils.data.DataLoader,
        k: List[int] = [1, 3, 10]
    ) -> Dict[str, float]:
        """Evaluate model performance"""
        self.model.eval()
        mrr = 0.0
        hits = {k_i: 0.0 for k_i in k}
        total = 0
        
        with torch.no_grad():
            for batch in dataloader:
                try:
                    # Move batch to device
                    batch = {k: v.to(self.device) for k, v in batch.items()}
                    
                    # Get predictions
                    scores = self.model(batch)
                    
                    # Calculate metrics
                    targets = batch['object'].view(-1, 1)
                    ranks = (scores >= scores.gather(1, targets)).sum(1)
                    
                    mrr += (1.0 / ranks).sum().item()
                    for k_i in k:
                        hits[k_i] += (ranks <= k_i).sum().item()
                    total += targets.size(0)
                    
                except Exception as e:
                    logger.error(f"Error during evaluation step: {str(e)}")
                    continue
                    
        # Compute final metrics
        metrics = {
            'MRR': mrr / total,
            **{f'Hits@{k_i}': hits[k_i] / total for k_i in k}
        }
        
        # Update best metrics
        if metrics['MRR'] > self.best_mrr:
            self.best_mrr = metrics['MRR']
            self.best_hits = {k: metrics[f'Hits@{k}'] for k in hits.keys()}
            
        return metrics