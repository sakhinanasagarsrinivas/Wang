# main.py
import os
import logging
import argparse
from typing import Dict, Any, Optional

# Import RAIT Framework Components
from rait_framework.datasets.mathcomp_dataset import MathCompDataset
from rait_framework.datasets.chemproc_dataset import ChemProcDataset
from rait_framework.models.rait_model import RAITModel
from rait_framework.tools.tool_registry import ToolRegistry, ToolInvoker
from rait_framework.evaluation.metrics import RAITMetrics
from rait_framework.retrievers.knowledge_retriever import KnowledgeRetriever

class RAITFrameworkRunner:
    """
    Comprehensive runner for the Retrieval-Augmented Instruction-Tuning (RAIT) Framework
    """
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize RAIT Framework with configurable components
        
        Args:
            config (Dict[str, Any], optional): Configuration dictionary
        """
        # Logging configuration
        self.logger = logging.getLogger(self.__class__.__name__)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # Default configuration
        self.config = self._prepare_config(config)
        
        # Initialize core components
        self._initialize_components()
    
    def _prepare_config(self, config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Prepare and validate configuration
        
        Args:
            config (Dict[str, Any], optional): User-provided configuration
        
        Returns:
            Dict[str, Any]: Validated configuration
        """
        default_config = {
            'model': {
                'name': 'google/codegemma-7b',
                'device': None
            },
            'dataset': {
                'type': 'mathcomp',
                'train_ratio': 0.7,
                'val_ratio': 0.15,
                'test_ratio': 0.15
            },
            'experiment': {
                'max_iterations': 3,
                'evaluation_mode': 'comprehensive'
            },
            'logging': {
                'level': 'INFO',
                'output_dir': './rait_results'
            }
        }
        
        # Update default config with user-provided config
        if config:
            from copy import deepcopy
            default_config = self._deep_merge(default_config, config)
        
        return default_config
    
    def _deep_merge(self, base: Dict[str, Any], update: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively merge configuration dictionaries
        
        Args:
            base (Dict[str, Any]): Base configuration
            update (Dict[str, Any]): Update configuration
        
        Returns:
            Dict[str, Any]: Merged configuration
        """
        merged = base.copy()
        for key, value in update.items():
            if isinstance(value, dict):
                merged[key] = self._deep_merge(merged.get(key, {}), value)
            else:
                merged[key] = value
        return merged
    
    def _initialize_components(self):
        """
        Initialize framework components based on configuration
        """
        # Tool Registry and Invoker
        self.tool_registry = ToolRegistry()
        self.tool_invoker = ToolInvoker(self.tool_registry)
        
        # Knowledge Retriever
        self.knowledge_retriever = KnowledgeRetriever()
        
        # Model Initialization
        self.model = RAITModel(
            model_name=self.config['model']['name'],
            device=self.config['model']['device']
        )
        
        # Dataset Loading
        self._load_dataset()
        
        # Metrics
        self.metrics = RAITMetrics()
    
    def _load_dataset(self):
        """
        Load dataset based on configuration
        """
        dataset_type = self.config['dataset']['type'].lower()
        
        dataset_classes = {
            'mathcomp': MathCompDataset,
            'chemproc': ChemProcDataset
        }
        
        try:
            dataset_class = dataset_classes.get(dataset_type)
            if not dataset_class:
                raise ValueError(f"Unsupported dataset type: {dataset_type}")
            
            # Load dataset
            self.dataset = dataset_class()
            
            # Split dataset
            self.dataset_splits = self.dataset.split_dataset(
                train_ratio=self.config['dataset']['train_ratio'],
                val_ratio=self.config['dataset']['val_ratio'],
                test_ratio=self.config['dataset']['test_ratio']
            )
        
        except Exception as e:
            self.logger.error(f"Dataset loading failed: {e}")
            raise
    
def register_custom_tools(self, tools: Dict[str, callable]):
    """
    Register custom tools for problem-solving
    
    Args:
        tools (Dict[str, callable]): Dictionary of tool names and functions
    """
    for name, tool_func in tools.items():
        self.tool_registry.register_tool(
            tool_func, 
            name=name, 
            description=tool_func.__doc__ or f"Custom tool for {name}",
            category=self._infer_tool_category(tool_func)
        )
        
        # Log tool registration
        self.logger.info(f"Registered custom tool: {name}")
    
def _infer_tool_category(self, tool_func: callable) -> str:
    """
    Infer tool category based on function characteristics
    
    Args:
        tool_func (callable): Tool function to categorize
    
    Returns:
        str: Inferred tool category
    """
    import inspect
    
    # Analyze function signature and docstring
    signature = inspect.signature(tool_func)
    docstring = tool_func.__doc__ or ""
    
    # Categorization heuristics
    categories = {
        'numerical': ['numpy', 'scipy', 'math', 'calculate', 'compute'],
        'visualization': ['plot', 'graph', 'matplotlib', 'seaborn'],
        'data_processing': ['pandas', 'process', 'transform', 'filter'],
        'machine_learning': ['sklearn', 'predict', 'train', 'model'],
        'optimization': ['optimize', 'minimize', 'maximize', 'optuna']
    }
    
    # Check docstring and function name
    for category, keywords in categories.items():
        if any(keyword in tool_func.__name__.lower() or 
               (docstring and keyword in docstring.lower()) 
               for keyword in keywords):
            return category
    
    # Check parameter types
    param_types = [
        param.annotation for param in signature.parameters.values()
        if param.annotation != inspect.Parameter.empty
    ]
    
    type_categories = {
        'numerical': [int, float, np.ndarray],
        'data_processing': [pd.DataFrame, list, dict],
        'machine_learning': ['Model', 'Estimator']
    }
    
    for category, type_checks in type_categories.items():
        if any(
            any(isinstance(t, type_check) or 
                (isinstance(type_check, str) and type_check in str(t.__name__))
                for t in param_types)
            for type_check in type_checks
        ):
            return category
    
    # Default category
    return 'general'

def run_experiments(self, experiment_type: str = 'full') -> Dict[str, Any]:
    """
    Run comprehensive experiments on the dataset
    
    Args:
        experiment_type (str): Type of experiment to run
    
    Returns:
        Dict[str, Any]: Experiment results
    """
    # Prepare output directory
    output_dir = self.config['logging']['output_dir']
    os.makedirs(output_dir, exist_ok=True)
    
    # Select dataset split
    train_dataset = self.dataset_splits['train']
    
    # Collect solutions and metadata
    solutions = []
    reference_solutions = []
    
    # Experiment iteration
    for sample in train_dataset:
        try:
            # Retrieve context
            context = self.knowledge_retriever.retrieve(
                sample['instruction'], 
                top_k=3
            )
            
            # Select relevant tools
            relevant_tools = self.tool_registry.find_tools_by_description(
                sample['instruction']
            )
            
            # Generate solution
            solution = {
                'instruction': sample['instruction'],
                'retrieved_context': context,
                'tools_used': list(relevant_tools.keys())
            }
            
            # Code generation
            generated_code = self.model.generate_code(
                instruction=sample['instruction'],
                context=context,
                tools=list(relevant_tools.keys())
            )
            
            solution['code'] = generated_code
            
            # Optional code execution (with error handling)
            try:
                # Create a safe execution environment
                exec_globals = {}
                exec_locals = {}
                exec(generated_code, exec_globals, exec_locals)
                solution['execution_result'] = exec_locals.get('result', None)
            except Exception as e:
                solution['error'] = str(e)
            
            solutions.append(solution)
            reference_solutions.append(sample.get('output', ''))
            
            # Log progress
            self.logger.info(f"Solved: {sample['instruction'][:50]}...")
        
        except Exception as e:
            self.logger.error(f"Failed to solve problem: {e}")
    
    # Generate comprehensive report
    results = self.metrics.generate_comprehensive_report(
        solutions, 
        reference_solutions
    )
    
    # Save detailed results
    results_path = os.path.join(output_dir, 'experiment_results.json')
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    return results

def export_results(self, 
                   results: Dict[str, Any], 
                   output_file: Optional[str] = None):
    """
    Export experiment results with multiple output formats
    
    Args:
        results (Dict[str, Any]): Experiment results
        output_file (str, optional): Output file path
    """
    # Use configured output directory if no specific file provided
    if not output_file:
        output_dir = self.config['logging']['output_dir']
        output_file = os.path.join(output_dir, 'rait_results')
    
    # Export formats
    export_formats = [
        ('json', json.dump),
        ('yaml', yaml.dump),
        ('jsonl', lambda data, f: f.writelines(json.dumps(item) + '\n' for item in data))
    ]
    
    for fmt, dump_func in export_formats:
        try:
            with open(f"{output_file}.{fmt}", 'w') as f:
                dump_func(results, f, indent=2)
            self.logger.info(f"Results exported to {output_file}.{fmt}")
        except Exception as e:
            self.logger.warning(f"Failed to export {fmt} format: {e}")

def main():
    """
    Main entry point for the RAIT Framework
    """
    # Configure argument parsing
    parser = argparse.ArgumentParser(description='RAIT Framework Experiment Runner')
    parser.add_argument('--dataset', 
                        choices=['mathcomp', 'chemproc'], 
                        default='mathcomp',
                        help='Dataset type for experiments')
    parser.add_argument('--model', 
                        default='google/codegemma-7b',
                        help='Pretrained model to use')
    parser.add_argument('--output', 
                        default='rait_results',
                        help='Base name for output files')
    parser.add_argument('--log-level', 
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], 
                        default='INFO',
                        help='Logging level')
    
    # Parse arguments
    args = parser.parse_args()
    
    # Configure logging
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Prepare configuration
    config = {
        'dataset': {'type': args.dataset},
        'model': {'name': args.model},
        'logging': {'output_dir': f'results/{args.output}'}
    }
    
    # Initialize and run framework
    framework = RAITFrameworkRunner(config)
    
   
    # Run experiments
    results = framework.run_experiments()
    
    # Export results
    framework.export_results(results)
    
    # Print key metrics
    print("\nExperiment Summary:")
    for key, value in results.items():
        print(f"{key}: {value}")

if __name__ == '__main__':
    main()