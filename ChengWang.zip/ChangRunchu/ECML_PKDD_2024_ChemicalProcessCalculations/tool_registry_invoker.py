# rait_framework/tools/tool_registry.py
from typing import Dict, Callable, Any, Optional, Type
import inspect
import logging
from functools import wraps

class ToolMetadata:
    """
    Comprehensive metadata for registered tools
    """
    def __init__(self, 
                 name: str, 
                 description: str, 
                 category: str, 
                 dependencies: Optional[list] = None,
                 input_types: Optional[Dict[str, Type]] = None):
        """
        Initialize tool metadata
        
        Args:
            name (str): Name of the tool
            description (str): Detailed description of the tool's functionality
            category (str): Categorization of the tool (e.g., 'numerical', 'visualization')
            dependencies (list, optional): Required dependencies for the tool
            input_types (Dict[str, Type], optional): Expected input parameter types
        """
        self.name = name
        self.description = description
        self.category = category
        self.dependencies = dependencies or []
        self.input_types = input_types or {}
        self.usage_count = 0
        self.last_used = None

class ToolRegistry:
    """
    Advanced tool registry with comprehensive management and retrieval capabilities
    """
    def __init__(self):
        """
        Initialize the tool registry with logging and advanced tracking
        """
        # Singleton pattern implementation
        self._registered_tools: Dict[str, Dict[str, Any]] = {}
        self._logger = logging.getLogger(self.__class__.__name__)
        logging.basicConfig(level=logging.INFO)
    
    def register_tool(self, 
                      tool_func: Callable, 
                      name: Optional[str] = None, 
                      description: Optional[str] = None,
                      category: str = 'general') -> str:
        """
        Register a tool with comprehensive metadata
        
        Args:
            tool_func (Callable): Function to be registered
            name (str, optional): Name of the tool
            description (str, optional): Detailed description
            category (str): Tool category
        
        Returns:
            str: Registered tool name
        """
        # Use function name if no name provided
        tool_name = name or tool_func.__name__
        
        # Extract function signature for input type inference
        signature = inspect.signature(tool_func)
        input_types = {
            param_name: param.annotation 
            for param_name, param in signature.parameters.items()
            if param.annotation != inspect.Parameter.empty
        }
        
        # Create metadata
        metadata = ToolMetadata(
            name=tool_name,
            description=description or tool_func.__doc__ or "No description provided",
            category=category,
            input_types=input_types
        )
        
        # Wrap the function with usage tracking
        @wraps(tool_func)
        def tracked_tool(*args, **kwargs):
            # Update usage statistics
            metadata.usage_count += 1
            metadata.last_used = logging.Formatter().formatTime(logging.LogRecord('', 0, '', 0, '', (), None))
            
            try:
                # Validate input types
                self._validate_input_types(signature, args, kwargs)
                return tool_func(*args, **kwargs)
            except Exception as e:
                self._logger.error(f"Error in tool {tool_name}: {e}")
                raise
        
        # Store tool with metadata
        self._registered_tools[tool_name] = {
            'function': tracked_tool,
            'metadata': metadata
        }
        
        self._logger.info(f"Registered tool: {tool_name}")
        return tool_name
    
    def _validate_input_types(self, 
                               signature: inspect.Signature, 
                               args: tuple, 
                               kwargs: Dict[str, Any]):
        """
        Validate input types for registered tools
        
        Args:
            signature (inspect.Signature): Function signature
            args (tuple): Positional arguments
            kwargs (Dict[str, Any]): Keyword arguments
        
        Raises:
            TypeError: If input types do not match expected types
        """
        bound_arguments = signature.bind(*args, **kwargs)
        bound_arguments.apply_defaults()
        
        for param_name, param_value in bound_arguments.arguments.items():
            # Check if type annotation exists
            expected_type = signature.parameters[param_name].annotation
            if expected_type != inspect.Parameter.empty:
                if not isinstance(param_value, expected_type):
                    raise TypeError(
                        f"Invalid type for parameter {param_name}. "
                        f"Expected {expected_type}, got {type(param_value)}"
                    )
    
    def get_tool(self, name: str) -> Callable:
        """
        Retrieve a registered tool
        
        Args:
            name (str): Name of the tool
        
        Returns:
            Callable: Registered tool function
        
        Raises:
            KeyError: If tool is not registered
        """
        if name not in self._registered_tools:
            raise KeyError(f"Tool {name} not registered")
        return self._registered_tools[name]['function']
    
    def list_tools(self, category: Optional[str] = None) -> Dict[str, ToolMetadata]:
        """
        List registered tools, optionally filtered by category
        
        Args:
            category (str, optional): Filter tools by category
        
        Returns:
            Dict[str, ToolMetadata]: Registered tools and their metadata
        """
        if category:
            return {
                name: tool_info['metadata'] 
                for name, tool_info in self._registered_tools.items()
                if tool_info['metadata'].category == category
            }
        return {
            name: tool_info['metadata'] 
            for name, tool_info in self._registered_tools.items()
        }
    
    def get_tool_metadata(self, name: str) -> ToolMetadata:
        """
        Get metadata for a specific tool
        
        Args:
            name (str): Name of the tool
        
        Returns:
            ToolMetadata: Tool metadata
        
        Raises:
            KeyError: If tool is not registered
        """
        if name not in self._registered_tools:
            raise KeyError(f"Tool {name} not registered")
        return self._registered_tools[name]['metadata']
    
    def find_tools_by_description(self, query: str) -> Dict[str, ToolMetadata]:
        """
        Find tools based on description similarity
        
        Args:
            query (str): Search query
        
        Returns:
            Dict[str, ToolMetadata]: Matching tools
        """
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
        
        # Prepare vectorizer
        vectorizer = TfidfVectorizer()
        
        # Collect descriptions
        descriptions = [
            tool_info['metadata'].description 
            for tool_info in self._registered_tools.values()
        ]
        names = list(self._registered_tools.keys())
        
        # Add query to descriptions
        descriptions.append(query)
        
        # Vectorize descriptions
        tfidf_matrix = vectorizer.fit_transform(descriptions)
        
        # Compute similarity
        similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])[0]
        
        # Find top matching tools
        threshold = 0.5  # Similarity threshold
        matching_tools = {
            names[idx]: self._registered_tools[names[idx]]['metadata']
            for idx in range(len(names))
            if similarities[idx] > threshold
        }
        
        return matching_tools

# Tool Invoker for advanced tool integration
class ToolInvoker:
    """
    Advanced tool invoker with intelligent parameter extraction and error handling
    """
    def __init__(self, tool_registry: Optional[ToolRegistry] = None):
        """
        Initialize tool invoker
        
        Args:
            tool_registry (ToolRegistry, optional): Tool registry to use
        """
        self.tool_registry = tool_registry or ToolRegistry()
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def invoke_tool(self, 
                    tool_name: str, 
                    query: str, 
                    **kwargs) -> Any:
        """
        Invoke a tool with intelligent parameter extraction
        
        Args:
            tool_name (str): Name of the tool to invoke
            query (str): Natural language query
            **kwargs: Additional parameters
        
        Returns:
            Any: Result of tool invocation
        """
        try:
            # Retrieve the tool
            tool = self.tool_registry.get_tool(tool_name)
            
            # Extract parameters intelligently
            extracted_params = self._extract_parameters(
                tool, query, **kwargs
            )
            
            # Invoke the tool
            result = tool(**extracted_params)
            
            # Log tool usage
            self.logger.info(f"Successfully invoked tool: {tool_name}")
            
            return result
        
        except Exception as e:
            self.logger.error(f"Error invoking tool {tool_name}: {e}")
            raise
    
    def _extract_parameters(self, 
                             tool: Callable, 
                             query: str, 
                             **additional_kwargs) -> Dict[str, Any]:
        """
        Intelligently extract parameters for tool invocation
        
        Args:
            tool (Callable): Tool function to be invoked
            query (str): Natural language query
            **additional_kwargs: Additional parameters
        
        Returns:
            Dict[str, Any]: Extracted parameters
        """
        # Get function signature
        sig = inspect.signature(tool)
        params = {}
        
        # First, use any provided additional kwargs
        params.update(additional_kwargs)
        
        # Use NLP techniques for parameter extraction
        for param_name, param in sig.parameters.items():
            if param_name not in params:
                try:
                    # Advanced parameter extraction
                    extracted_value = self._advanced_param_extraction(
                        query, param_name, param.annotation
                    )
                    if extracted_value is not None:
                        params[param_name] = extracted_value
                except Exception as e:
                    self.logger.warning(f"Could not extract parameter {param_name}: {e}")
        
        return params
    
    def _advanced_param_extraction(self, 
                                   query: str, 
                                   param_name: str, 
                                   expected_type: Type) -> Optional[Any]:
        """
        Advanced parameter extraction with type-aware processing
        
        Args:
            query (str): Natural language query
            param_name (str): Name of the parameter
            expected_type (Type): Expected parameter type
        
        Returns:
            Optional[Any]: Extracted parameter value
        """
        import re
        
        # Type-specific extraction strategies
        if expected_type == int:
            # Extract integers
            match = re.search(r'\b(\d+)\b', query)
            return int(match.group(1)) if match else None
        
        elif expected_type == float:
            # Extract floats
            match = re.search(r'\b(\d+\.?\d*)\b', query)
            return float(match.group(1)) if match else None
        
        elif expected_type == str:
            # Extract string-based parameters
            keywords = {
                'volume': ['volume', 'vol', 'V'],
                'flow_rate': ['flow rate', 'rate', 'q'],
                'concentration': ['concentration', 'conc', 'c']
            }
            
            for key, variations in keywords.items():
                if key in param_name.lower():
                    for variation in variations:
                        match = re.search(rf'{variation}\s*[:=]?\s*"?([^"\s]+)"?', query, re.IGNORECASE)
                        if match:
                            return match.group(1)
        
        # Fallback for other types or complex extractions
        return None