import torch
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from typing import Dict, Tuple, List, Optional
import logging

class MetricsCalculator:
    """Handles calculation of various evaluation metrics"""
    
    def __init__(self, target_scaler=None):
        """
        Initialize metrics calculator
        
        Args:
            target_scaler: Scaler used for target normalization
        """
        self.target_scaler = target_scaler
        self.logger = logging.getLogger(__name__)

    def _inverse_transform(self, y: np.ndarray) -> np.ndarray:
        """Inverse transform scaled targets"""
        if self.target_scaler is not None:
            return self.target_scaler.inverse_transform(y)
        return y

    def calculate_regression_metrics(
        self,
        y_true: torch.Tensor,
        y_pred: torch.Tensor,
        task_names: Optional[List[str]] = None
    ) -> Dict[str, float]:
        """
        Calculate regression metrics
        
        Args:
            y_true: True values
            y_pred: Predicted values
            task_names: Names of prediction tasks
            
        Returns:
            Dictionary of metrics
        """
        # Convert to numpy and inverse transform if needed
        y_true_np = self._inverse_transform(y_true.cpu().numpy())
        y_pred_np = self._inverse_transform(y_pred.cpu().numpy())
        
        if task_names is None:
            task_names = [f"task_{i}" for i in range(y_true_np.shape[1])]
        
        metrics = {}
        
        # Calculate metrics for each task
        for i, task in enumerate(task_names):
            task_metrics = {
                f"{task}_rmse": np.sqrt(mean_squared_error(y_true_np[:, i], y_pred_np[:, i])),
                f"{task}_mae": mean_absolute_error(y_true_np[:, i], y_pred_np[:, i]),
                f"{task}_r2": r2_score(y_true_np[:, i], y_pred_np[:, i])
            }
            metrics.update(task_metrics)
        
        # Calculate average metrics
        metrics.update({
            "avg_rmse": np.mean([metrics[f"{task}_rmse"] for task in task_names]),
            "avg_mae": np.mean([metrics[f"{task}_mae"] for task in task_names]),
            "avg_r2": np.mean([metrics[f"{task}_r2"] for task in task_names])
        })
        
        return metrics

    def calculate_uncertainty_metrics(
        self,
        y_true: torch.Tensor,
        y_pred: torch.Tensor,
        y_std: torch.Tensor,
        task_names: Optional[List[str]] = None
    ) -> Dict[str, float]:
        """
        Calculate uncertainty quantification metrics
        
        Args:
            y_true: True values
            y_pred: Predicted values
            y_std: Predicted standard deviations
            task_names: Names of prediction tasks
        """
        y_true_np = self._inverse_transform(y_true.cpu().numpy())
        y_pred_np = self._inverse_transform(y_pred.cpu().numpy())
        y_std_np = y_std.cpu().numpy()
        
        if task_names is None:
            task_names = [f"task_{i}" for i in range(y_true_np.shape[1])]
        
        metrics = {}
        
        for i, task in enumerate(task_names):
            # Calculate normalized error
            normalized_error = np.abs(y_true_np[:, i] - y_pred_np[:, i]) / y_std_np[:, i]
            
            # Calculate calibration metrics
            coverage_50 = np.mean(normalized_error <= 0.67449)  # 50% coverage
            coverage_90 = np.mean(normalized_error <= 1.64485)  # 90% coverage
            
            task_metrics = {
                f"{task}_coverage_50": coverage_50,
                f"{task}_coverage_90": coverage_90,
                f"{task}_mean_std": np.mean(y_std_np[:, i])
            }
            metrics.update(task_metrics)
        
        # Calculate average metrics
        metrics.update({
            "avg_coverage_50": np.mean([metrics[f"{task}_coverage_50"] for task in task_names]),
            "avg_coverage_90": np.mean([metrics[f"{task}_coverage_90"] for task in task_names]),
            "avg_std": np.mean([metrics[f"{task}_mean_std"] for task in task_names])
        })
        
        return metrics

    @staticmethod
    def calculate_early_stopping_metric(metrics: Dict[str, float]) -> float:
        """Calculate metric for early stopping"""
        return metrics["avg_rmse"]  # Can be modified based on requirements

class TrainingMetrics:
    """Tracks training metrics over time"""
    
    def __init__(self):
        self.train_losses = []
        self.val_losses = []
        self.train_metrics = []
        self.val_metrics = []
        self.best_val_loss = float('inf')
        self.best_epoch = 0
        self.patience_counter = 0

    def update(
        self,
        epoch: int,
        train_loss: float,
        val_loss: float,
        train_metrics: Dict[str, float],
        val_metrics: Dict[str, float],
        patience: int
    ) -> bool:
        """
        Update metrics and check for early stopping
        
        Returns:
            bool: Whether to stop training
        """
        self.train_losses.append(train_loss)
        self.val_losses.append(val_loss)
        self.train_metrics.append(train_metrics)
        self.val_metrics.append(val_metrics)
        
        # Check for improvement
        if val_loss < self.best_val_loss:
            self.best_val_loss = val_loss
            self.best_epoch = epoch
            self.patience_counter = 0
            return False
        else:
            self.patience_counter += 1
            return self.patience_counter >= patience

    def get_best_metrics(self) -> Tuple[float, Dict[str, float]]:
        """Get metrics from best epoch"""
        return self.val_losses[self.best_epoch], self.val_metrics[self.best_epoch]

    def plot_training_curves(self, save_path: Optional[str] = None):
        """Plot training curves"""
        import matplotlib.pyplot as plt
        
        # Plot losses
        plt.figure(figsize=(10, 5))
        plt.subplot(1, 2, 1)
        plt.plot(self.train_losses, label='Train')
        plt.plot(self.val_losses, label='Validation')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.title('Training and Validation Loss')
        plt.legend()
        
        # Plot metrics
        plt.subplot(1, 2, 2)
        for metric in self.train_metrics[0].keys():
            if metric.startswith('avg_'):
                train_values = [m[metric] for m in self.train_metrics]
                val_values = [m[metric] for m in self.val_metrics]
                plt.plot(train_values, label=f'Train {metric}')
                plt.plot(val_values, label=f'Val {metric}')
        
        plt.xlabel('Epoch')
        plt.ylabel('Metric Value')
        plt.title('Training and Validation Metrics')
        plt.legend()
        
        if save_path:
            plt.savefig(save_path)
        else:
            plt.show()