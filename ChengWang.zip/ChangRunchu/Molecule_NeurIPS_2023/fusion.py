import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional

class MultiHeadAttention(nn.Module):
    def __init__(
        self,
        hidden_dim: int,
        num_heads: int,
        dropout: float = 0.1
    ):
        """
        Multi-head attention module for cross-modal fusion
        """
        super().__init__()
        
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        assert self.head_dim * num_heads == hidden_dim, "hidden_dim must be divisible by num_heads"
        
        # Linear projections
        self.q_proj = nn.Linear(hidden_dim, hidden_dim)
        self.k_proj = nn.Linear(hidden_dim, hidden_dim)
        self.v_proj = nn.Linear(hidden_dim, hidden_dim)
        self.o_proj = nn.Linear(hidden_dim, hidden_dim)
        
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of multi-head attention
        
        Args:
            query: Query tensor [batch_size, seq_len_q, hidden_dim]
            key: Key tensor [batch_size, seq_len_k, hidden_dim]
            value: Value tensor [batch_size, seq_len_v, hidden_dim]
            mask: Optional attention mask
            
        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (output, attention_weights)
        """
        batch_size = query.size(0)
        
        # Linear projections and reshape
        q = self.q_proj(query).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(key).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(value).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Scaled dot-product attention
        scores = torch.matmul(q, k.transpose(-2, -1)) / torch.sqrt(torch.tensor(self.head_dim, dtype=torch.float32))
        
        # Apply mask if provided
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))
        
        # Apply softmax and dropout
        attention_weights = F.softmax(scores, dim=-1)
        attention_weights = self.dropout(attention_weights)
        
        # Apply attention to values
        output = torch.matmul(attention_weights, v)
        
        # Reshape and apply output projection
        output = output.transpose(1, 2).contiguous().view(batch_size, -1, self.hidden_dim)
        output = self.o_proj(output)
        
        return output, attention_weights

class CrossModalFusion(nn.Module):
    def __init__(
        self,
        hidden_dim: int,
        num_heads: int,
        num_layers: int = 2,
        dropout: float = 0.1
    ):
        """
        Cross-modal fusion module
        """
        super().__init__()
        
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        
        # Multi-head attention layers
        self.attention_layers = nn.ModuleList([
            MultiHeadAttention(hidden_dim, num_heads, dropout)
            for _ in range(num_layers)
        ])
        
        # Feed-forward layers
        self.ff_layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim * 4),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim * 4, hidden_dim)
            )
            for _ in range(num_layers)
        ])
        
        # Layer normalization
        self.layer_norms1 = nn.ModuleList([
            nn.LayerNorm(hidden_dim)
            for _ in range(num_layers)
        ])
        self.layer_norms2 = nn.ModuleList([
            nn.LayerNorm(hidden_dim)
            for _ in range(num_layers)
        ])
        
        # Final projection
        self.final_proj = nn.Linear(hidden_dim * 2, hidden_dim)

    def forward(
        self,
        graph_embed: torch.Tensor,
        text_embed: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of cross-modal fusion
        
        Args:
            graph_embed: Graph embeddings [batch_size, hidden_dim]
            text_embed: Text embeddings [batch_size, hidden_dim]
            
        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (fused_embedding, attention_weights)
        """
        # Add sequence dimension for attention
        graph_embed = graph_embed.unsqueeze(1)
        text_embed = text_embed.unsqueeze(1)
        
        attention_weights_list = []
        
        # Process through attention layers
        x = graph_embed
        for i in range(self.num_layers):
            # Multi-head attention
            attended, attention_weights = self.attention_layers[i](
                query=x,
                key=text_embed,
                value=text_embed
            )
            attention_weights_list.append(attention_weights)
            
            # Add & normalize
            x = self.layer_norms1[i](x + attended)
            
            # Feed-forward
            ff_output = self.ff_layers[i](x)
            x = self.layer_norms2[i](x + ff_output)
        
        # Concatenate and project
        fused = torch.cat([x.squeeze(1), text_embed.squeeze(1)], dim=-1)
        fused = self.final_proj(fused)
        
        # Average attention weights across layers
        avg_attention = torch.stack(attention_weights_list).mean(dim=0)
        
        return fused, avg_attention

class ModalityFusion(nn.Module):
    def __init__(
        self,
        hidden_dim: int,
        num_heads: int = 8,
        num_layers: int = 2,
        dropout: float = 0.1
    ):
        """
        Complete modality fusion module
        """
        super().__init__()
        
        # Cross-modal fusion modules
        self.graph_text_fusion = CrossModalFusion(
            hidden_dim=hidden_dim,
            num_heads=num_heads,
            num_layers=num_layers,
            dropout=dropout
        )
        
        self.zero_few_shot_fusion = CrossModalFusion(
            hidden_dim=hidden_dim,
            num_heads=num_heads,
            num_layers=num_layers,
            dropout=dropout
        )
        
        # Final fusion layer
        self.final_fusion = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim)
        )

    def forward(
        self,
        graph_embed: torch.Tensor,
        text_zero_shot: torch.Tensor,
        text_few_shot: torch.Tensor
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Forward pass of complete modality fusion
        
        Args:
            graph_embed: Graph embeddings [batch_size, hidden_dim]
            text_zero_shot: Zero-shot text embeddings [batch_size, hidden_dim]
            text_few_shot: Few-shot text embeddings [batch_size, hidden_dim]
            
        Returns:
            Tuple[torch.Tensor, Dict]: (fused_embedding, attention_weights_dict)
        """
        # Graph-text fusion
        graph_text_fused, graph_text_attention = self.graph_text_fusion(
            graph_embed=graph_embed,
            text_embed=text_zero_shot
        )
        
        # Zero-shot few-shot fusion
        shot_fused, shot_attention = self.zero_few_shot_fusion(
            graph_embed=text_zero_shot,
            text_embed=text_few_shot
        )
        
        # Final fusion
        final_fused = torch.cat([graph_text_fused, shot_fused], dim=-1)
        output = self.final_fusion(final_fused)
        
        # Collect attention weights
        attention_weights = {
            'graph_text': graph_text_attention,
            'shot_fusion': shot_attention
        }
        
        return output, attention_weights


class CrossModalEmbedding(nn.Module):
    def __init__(
        self,
        hidden_dim: int,
        num_modalities: int = 3,  # graph, zero-shot, few-shot
        num_heads: int = 8,
        dropout: float = 0.1
    ):
        """
        Cross-modal embedding module that combines all modalities
        """
        super().__init__()
        
        self.hidden_dim = hidden_dim
        self.num_modalities = num_modalities
        
        # Modality-specific projections
        self.modality_projections = nn.ModuleList([
            nn.Linear(hidden_dim, hidden_dim)
            for _ in range(num_modalities)
        ])
        
        # Cross-modal attention
        self.cross_attention = MultiHeadAttention(
            hidden_dim=hidden_dim,
            num_heads=num_heads,
            dropout=dropout
        )
        
        # Final projection
        self.final_projection = nn.Sequential(
            nn.Linear(hidden_dim * num_modalities, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim)
        )

    def forward(
        self,
        embeddings: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass combining all modalities
        
        Args:
            embeddings: List of embeddings from different modalities
                       [batch_size, hidden_dim]
            
        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (combined_embedding, attention_weights)
        """
        assert len(embeddings) == self.num_modalities, \
            f"Expected {self.num_modalities} modalities, got {len(embeddings)}"
        
        # Project each modality
        projected = [
            proj(embed) for proj, embed in zip(self.modality_projections, embeddings)
        ]
        
        # Stack for cross-attention
        stacked = torch.stack(projected, dim=1)  # [batch_size, num_modalities, hidden_dim]
        
        # Cross-modal attention
        attended, attention_weights = self.cross_attention(
            query=stacked,
            key=stacked,
            value=stacked
        )
        
        # Combine modalities
        combined = torch.cat([
            attended.mean(dim=1),  # Average attended features
            *embeddings  # Original embeddings
        ], dim=-1)
        
        # Final projection
        output = self.final_projection(combined)
        
        return output, attention_weights