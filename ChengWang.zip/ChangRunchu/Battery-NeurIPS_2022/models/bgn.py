
import torch
import torch.nn as nn
import torch.nn.functional as F

class BatteryGraphNets(nn.Module):
    """
    Base BGN model as described in Section 3.
    """
    def __init__(self, num_nodes, input_dim, hidden_dim, embed_dim, dropout=0.5):
        super(BatteryGraphNets, self).__init__()
        
        self.dgi = DynamicGraphInference(num_nodes, input_dim, hidden_dim, embed_dim)
        self.grapher = GrapherModule(input_dim, hidden_dim, dropout)
        
        # Graph readout (equation 3)
        self.readout = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1)
        )
        
    def forward(self, x_t):
        A_t = self.dgi(x_t)
        h_t = self.grapher(x_t, A_t)
        h_g = torch.mean(h_t * self.dgi.node_embeddings.unsqueeze(0), dim=1)
        y_t_p = self.readout(h_g)
        return y_t_p

class BatteryGraphNetsUE(nn.Module):
    """
    BGN with Uncertainty Estimation (BGN-UE) as described in Section 3.4.
    """
    def __init__(self, num_nodes, input_dim, hidden_dim, embed_dim, dropout=0.5):
        super(BatteryGraphNetsUE, self).__init__()
        
        self.dgi = DynamicGraphInference(num_nodes, input_dim, hidden_dim, embed_dim)
        self.grapher = GrapherModule(input_dim, hidden_dim, dropout)
        
        # Uncertainty estimation network fθ (equation 5)
        self.uncertainty_net = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 2)  # [μφ, log(σ²φ)]
        )
        
    def forward(self, x_t):
        A_t = self.dgi(x_t)
        h_t = self.grapher(x_t, A_t)
        h_g = torch.mean(h_t * self.dgi.node_embeddings.unsqueeze(0), dim=1)
        outputs = self.uncertainty_net(h_g)
        return outputs[..., 0], outputs[..., 1]  # mean, log_variance