import os
from dotenv import load_dotenv
import logging
from pathlib import Path
from typing import Dict, Any

from data.data_generator import DataGenerator
from data.data_processor import DataProcessor
from models.meta_agent import MetaAgent
from models.expert_models import CodeExpert, MathExpert, KnowledgeExpert
from models.action_generator import ActionGenerator
from models.graph_builder import GraphBuilder
from evaluation.evaluator import Evaluator

# Load environment variables
load_dotenv()

class PEOA:
    def __init__(self):
        # Initialize components
        self.data_generator = DataGenerator(
            api_key=os.getenv('OPENAI_API_KEY')
        )
        self.data_processor = DataProcessor(
            data_path='data/processed'
        )
        self.meta_agent = MetaAgent()
        self.action_generator = ActionGenerator()
        self.graph_builder = GraphBuilder(
            uri=os.getenv('NEO4J_URI'),
            user=os.getenv('NEO4J_USER'),
            password=os.getenv('NEO4J_PASSWORD')
        )
        
        # Initialize expert models
        self.expert_models = {
            'code_expert': CodeExpert(),
            'math_expert': MathExpert(),
            'knowledge_expert': KnowledgeExpert(
                os.getenv('NEO4J_URI')
            )
        }
        
        self.evaluator = Evaluator()
        
    def generate_dataset(self):
        """Generate and process dataset"""
        # Generate synthetic data
        raw_data = self.data_generator.generate_dataset(
            size=1000,
            domain='process_engineering',
            complexity='intermediate'
        )
        
        # Process data
        df = self.data_processor.preprocess(raw_data)
        
        # Split data
        train, val, test = self.data_processor.split_data(df)
        
        # Build knowledge graph
        self.graph_builder.create_knowledge_graph(train.to_dict('records'))
        
        return train, val, test
        
    def solve_problem(self, query: str) -> Dict[str, Any]:
        """Solve a given problem"""
        try:
            # Initialize solution history
            solution_history = []
            
            # Generate initial action
            action = self.action_generator.generate_action(query, solution_history)
            
            while action and len(solution_history) < 10:  # Limit steps to avoid infinite loops
                # Select expert model
                expert_model = self.expert_models.get(
                    action['tool_required'],
                    self.expert_models['knowledge_expert']
                )
                
                # Execute action
                result = expert_model.execute({
                    'action': action,
                    'query': query,
                    'history': solution_history
                })
                
                # Update history
                solution_history.append({
                    'action': action,
                    'result': result
                })
                
                # Generate next action
                action = self.action_generator.generate_action(
                    query,
                    solution_history
                )
                
            return {
                'status': 'success',
                'solution_history': solution_history,
                'final_result': solution_history[-1]['result'] if solution_history else None
            }
            
        except Exception as e:
            logging.error(f"Error solving problem: {str(e)}")
            return {
                'status': 'error',
                'message': str(e)
            }
            
    def evaluate(self, test_queries: List[str], 
                reference_solutions: List[Dict[str, Any]]) -> Dict[str, float]:
        """Evaluate the framework"""
        predictions = []
        for query in test_queries:
            prediction = self.solve_problem(query)
            predictions.append(prediction)
            
        return self.evaluator.evaluate(predictions, reference_solutions)

def main():
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('peoa.log'),
            logging.StreamHandler()
        ]
    )
    
    logger = logging.getLogger(__name__)
    logger.info("Initializing PEOA framework")
    
    try:
        # Initialize framework
        peoa = PEOA()
        
        # Generate and process dataset
        logger.info("Generating synthetic dataset")
        train, val, test = peoa.generate_dataset()
        
        # Save datasets
        data_dir = Path('data/processed')
        data_dir.mkdir(parents=True, exist_ok=True)
        
        train.to_json(data_dir / 'train.json', orient='records')
        val.to_json(data_dir / 'val.json', orient='records')
        test.to_json(data_dir / 'test.json', orient='records')
        
        # Run evaluation on validation set
        logger.info("Running evaluation on validation set")
        val_queries = val['question'].tolist()
        val_solutions = val.to_dict('records')
        
        eval_results = peoa.evaluate(val_queries, val_solutions)
        
        # Log evaluation results
        logger.info("Evaluation Results:")
        for metric, value in eval_results.items():
            logger.info(f"{metric}: {value:.4f}")
            
        # Interactive mode for problem solving
        while True:
            query = input("\nEnter your process engineering question (or 'quit' to exit): ")
            if query.lower() == 'quit':
                break
                
            logger.info(f"Processing query: {query}")
            solution = peoa.solve_problem(query)
            
            if solution['status'] == 'success':
                print("\nSolution History:")
                for step in solution['solution_history']:
                    print(f"\nStep: {step['action']['description']}")
                    print(f"Result: {step['result']}")
                print(f"\nFinal Result: {solution['final_result']}")
            else:
                print(f"\nError: {solution['message']}")
                
    except Exception as e:
        logger.error(f"Error in main execution: {str(e)}")
        raise

if __name__ == "__main__":
    main()