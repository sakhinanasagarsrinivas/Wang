# config.py

from dataclasses import dataclass, field
from typing import Dict, Optional
import torch
from pathlib import Path

@dataclass
class ModelConfig:
    """Model configuration parameters"""
    # Model Architecture
    embedding_dim: int = 128
    hidden_dim: int = 256
    num_layers: int = 2
    dropout: float = 0.1
    
    # Hypergraph Parameters
    k_neighbors: int = 15  # Number of neighbors for k-uniform hypergraph
    pooling_ratio: float = 0.5  # Ratio for hypergraph pooling
    use_node_embeddings: bool = True
    normalize_adjacency: bool = True
    
    # Training Parameters
    batch_size: int = 48
    num_epochs: int = 100
    learning_rate: float = 0.001
    weight_decay: float = 1e-5
    early_stopping_patience: int = 10
    
    # Loss Function Weights
    prediction_loss_weight: float = 1.0
    structure_reg_weight: float = 0.01
    attention_loss_weight: float = 0.1
    reconstruction_loss_weight: float = 0.1
    
    # Data Parameters
    window_size: int = 30  # Sliding window size
    train_ratio: float = 0.7
    val_ratio: float = 0.1
    
    # Device Configuration 
    device: torch.device = field(default_factory=lambda: torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    
    # Dataset Paths
    dataset_paths: Dict[str, str] = field(default_factory=lambda: {
        'SWAT': 'data/swat.csv',
        'WADI': 'data/wadi.csv',
        'SMAP': 'data/smap.csv',
        'MSL': 'data/msl.csv',
        'TEP': 'data/tep.csv',
        'HAI': 'data/hai.csv'
    })
    
    # Root Cause Analysis
    rca_k_hops: int = 2
    rca_attention_threshold: float = 0.1
    rca_top_k: int = 5
    
    # Prescriptive Control
    control_population_size: int = 50
    control_generations: int = 100
    control_bounds: tuple = (0, 1)
    control_mutation_rate: float = 0.2
    control_crossover_rate: float = 0.7

@dataclass
class TrainingConfig:
    """Training configuration parameters"""
    # Optimizer Parameters
    optimizer: str = 'adam'
    scheduler: str = 'reduce_lr_on_plateau'
    scheduler_patience: int = 5
    scheduler_factor: float = 0.5
    min_lr: float = 1e-6
    
    # Gradient Clipping
    clip_grad_norm: bool = True
    max_grad_norm: float = 1.0
    
    # Loss Function Parameters
    use_focal_loss: bool = False
    focal_alpha: float = 0.25
    focal_gamma: float = 2.0
    
    # Training Features
    use_mixed_precision: bool = True
    num_workers: int = 4
    pin_memory: bool = True
    
    # Logging and Checkpointing
    log_interval: int = 100
    eval_interval: int = 1000
    save_interval: int = 5000
    checkpoint_dir: str = 'checkpoints'
    log_dir: str = 'logs'
    
    # Validation
    val_interval: int = 1
    val_steps: Optional[int] = None
    
    def __post_init__(self):
        # Create directories if they don't exist
        Path(self.checkpoint_dir).mkdir(parents=True, exist_ok=True)
        Path(self.log_dir).mkdir(parents=True, exist_ok=True)

class ExperimentConfig:
    """Complete experiment configuration"""
    def __init__(
        self,
        model_config: Optional[ModelConfig] = None,
        training_config: Optional[TrainingConfig] = None,
        experiment_name: str = "default"
    ):
        self.model = model_config or ModelConfig()
        self.training = training_config or TrainingConfig()
        self.experiment_name = experiment_name
        
    @classmethod
    def from_dict(cls, config_dict: Dict):
        """Create config from dictionary"""
        model_config = ModelConfig(**config_dict.get('model', {}))
        training_config = TrainingConfig(**config_dict.get('training', {}))
        experiment_name = config_dict.get('experiment_name', 'default')
        return cls(model_config, training_config, experiment_name)
    
    def to_dict(self) -> Dict:
        """Convert config to dictionary"""
        return {
            'model': self.model.__dict__,
            'training': self.training.__dict__,
            'experiment_name': self.experiment_name
        }
        
    def save(self, path: str):
        """Save config to file"""
        import json
        with open(path, 'w') as f:
            json.dump(self.to_dict(), f, indent=4)
            
    @classmethod
    def load(cls, path: str):
        """Load config from file"""
        import json
        with open(path, 'r') as f:
            config_dict = json.load(f)
        return cls.from_dict(config_dict)
    
    def get_experiment_dir(self) -> Path:
        """Get experiment directory"""
        base_dir = Path(self.training.checkpoint_dir) / self.experiment_name
        base_dir.mkdir(parents=True, exist_ok=True)
        return base_dir
    
    def __str__(self):
        """String representation of config"""
        return f"ExperimentConfig(name={self.experiment_name})"