# models/vision_encoder.py
import torch
import torch.nn as nn
import math
from torch.nn import functional as F

class PatchEmbedding(nn.Module):
    """Converts image into patches and embeds them."""
    def __init__(self, config):
        super().__init__()
        self.image_size = config.image_size
        self.patch_size = config.patch_size
        self.num_patches = (self.image_size // self.patch_size) ** 2
        
        self.projection = nn.Conv2d(
            config.num_channels, 
            config.vision_hidden_dim,
            kernel_size=self.patch_size, 
            stride=self.patch_size
        )
        
    def forward(self, pixel_values):
        batch_size = pixel_values.shape[0]
        x = self.projection(pixel_values)
        x = x.flatten(2).transpose(1, 2)
        return x

class VisionEncoder(nn.Module):
    """Vision Encoder using Vision Transformer architecture"""
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Patch embedding
        self.patch_embed = PatchEmbedding(config)
        
        # CLS token and position embedding
        self.cls_token = nn.Parameter(torch.zeros(1, 1, config.vision_hidden_dim))
        self.pos_embed = nn.Parameter(
            torch.zeros(1, self.patch_embed.num_patches + 1, config.vision_hidden_dim)
        )
        
        # Transformer layers
        self.layers = nn.ModuleList([
            VisionTransformerLayer(config)
            for _ in range(config.vision_num_hidden_layers)
        ])
        
        self.layer_norm = nn.LayerNorm(config.vision_hidden_dim)
        
        # Initialize weights
        self.initialize_weights()
        
    def initialize_weights(self):
        nn.init.normal_(self.cls_token, std=0.02)
        nn.init.normal_(self.pos_embed, std=0.02)
        
    def forward(self, pixel_values):
        batch_size = pixel_values.shape[0]
        
        # Create patch embeddings
        x = self.patch_embed(pixel_values)
        
        # Add CLS token
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        
        # Add position embeddings
        x = x + self.pos_embed
        
        # Apply transformer layers
        for layer in self.layers:
            x = layer(x)
            
        x = self.layer_norm(x)
        return x

class VisionTransformerLayer(nn.Module):
    """Single layer of Vision Transformer"""
    def __init__(self, config):
        super().__init__()
        self.attention = MultiHeadAttention(
            config.vision_hidden_dim,
            config.vision_num_attention_heads,
            dropout=config.dropout
        )
        self.mlp = MLP(
            config.vision_hidden_dim,
            config.vision_intermediate_dim,
            dropout=config.dropout
        )
        self.layernorm1 = nn.LayerNorm(config.vision_hidden_dim)
        self.layernorm2 = nn.LayerNorm(config.vision_hidden_dim)
        
    def forward(self, x):
        # Self attention
        residual = x
        x = self.layernorm1(x)
        x = self.attention(x)
        x = residual + x
        
        # MLP
        residual = x
        x = self.layernorm2(x)
        x = self.mlp(x)
        x = residual + x
        
        return x

class MultiHeadAttention(nn.Module):
    """Multi-head attention mechanism"""
    def __init__(self, hidden_dim, num_heads, dropout=0.1):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.scaling = self.head_dim ** -0.5
        
        self.qkv = nn.Linear(hidden_dim, hidden_dim * 3)
        self.proj = nn.Linear(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x, mask=None):
        batch_size, seq_len, hidden_dim = x.shape
        
        # Create Q, K, V
        qkv = self.qkv(x).reshape(batch_size, seq_len, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # (3, batch, heads, seq_len, head_dim)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        # Compute attention scores
        attn = (q @ k.transpose(-2, -1)) * self.scaling
        
        if mask is not None:
            attn = attn.masked_fill(mask == 0, float('-inf'))
            
        attn = F.softmax(attn, dim=-1)
        attn = self.dropout(attn)
        
        # Compute output
        x = (attn @ v).transpose(1, 2).reshape(batch_size, seq_len, hidden_dim)
        x = self.proj(x)
        x = self.dropout(x)
        
        return x

class MLP(nn.Module):
    """MLP with GELU activation"""
    def __init__(self, hidden_dim, intermediate_dim, dropout=0.1):
        super().__init__()
        self.fc1 = nn.Linear(hidden_dim, intermediate_dim)
        self.fc2 = nn.Linear(intermediate_dim, hidden_dim)
        self.gelu = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x):
        x = self.fc1(x)
        x = self.gelu(x)
        x = self.dropout(x)
        x = self.fc2(x)
        x = self.dropout(x)
        return x