import torch
import numpy as np
from sklearn.metrics import (
    accuracy_score, 
    precision_recall_fscore_support,
    confusion_matrix,
    classification_report,
    roc_auc_score
)

def compute_classification_metrics(y_true, y_pred, y_prob=None):
    """
    Comprehensive classification metrics computation
    
    Args:
    - y_true: Ground truth labels
    - y_pred: Predicted labels
    - y_prob: Predicted probabilities (optional)
    
    Returns:
    - Dictionary of classification metrics
    """
    # Basic metrics
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'confusion_matrix': confusion_matrix(y_true, y_pred)
    }
    
    # Precision, Recall, F1-Score
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, average='weighted'
    )
    metrics.update({
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'support': support
    })
    
    # Detailed classification report
    metrics['classification_report'] = classification_report(
        y_true, y_pred
    )
    
    # ROC AUC if probabilities are provided
    if y_prob is not None:
        try:
            metrics['roc_auc'] = roc_auc_score(
                y_true, y_prob, multi_class='ovr'
            )
        except:
            pass
    
    return metrics

def compute_per_class_metrics(y_true, y_pred):
    """
    Compute metrics for each class separately
    
    Args:
    - y_true: Ground truth labels
    - y_pred: Predicted labels
    
    Returns:
    - Dictionary of per-class metrics
    """
    classes = np.unique(y_true)
    per_class_metrics = {}
    
    for cls in classes:
        # Mask for current class
        mask = y_true == cls
        
        # Compute metrics for this class
        per_class_metrics[cls] = {
            'precision': precision_recall_fscore_support(
                y_true[mask], y_pred[mask], average='binary'
            )[0],
            'recall': precision_recall_fscore_support(
                y_true[mask], y_pred[mask], average='binary'
            )[1],
            'f1_score': precision_recall_fscore_support(
                y_true[mask], y_pred[mask], average='binary'
            )[2]
        }
    
    return per_class_metrics