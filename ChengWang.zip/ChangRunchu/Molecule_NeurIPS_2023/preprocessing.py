import torch
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem import Descriptors
from typing import List, Tuple, Dict, Optional
import pandas as pd
from sklearn.preprocessing import StandardScaler
from pathlib import Path
import logging
from tqdm import tqdm

class MoleculePreprocessor:
    """Handles preprocessing of molecular data"""
    
    def __init__(self, max_atoms: int = 50, add_hs: bool = True):
        """
        Initialize preprocessor
        
        Args:
            max_atoms: Maximum number of atoms to consider
            add_hs: Whether to add hydrogen atoms explicitly
        """
        self.max_atoms = max_atoms
        self.add_hs = add_hs
        self.atom_features = {
            'atomic_num': list(range(1, 119)),
            'degree': [0, 1, 2, 3, 4, 5, 6],
            'formal_charge': [-3, -2, -1, 0, 1, 2, 3],
            'chiral_tag': [0, 1, 2, 3],
            'hybridization': [
                Chem.rdchem.HybridizationType.SP,
                Chem.rdchem.HybridizationType.SP2,
                Chem.rdchem.HybridizationType.SP3,
                Chem.rdchem.HybridizationType.SP3D,
                Chem.rdchem.HybridizationType.SP3D2
            ],
            'num_hs': [0, 1, 2, 3, 4],
            'implicit_valence': [0, 1, 2, 3, 4, 5, 6],
            'aromatic': [0, 1]
        }
        
        self.bond_features = {
            'bond_type': [
                Chem.rdchem.BondType.SINGLE,
                Chem.rdchem.BondType.DOUBLE,
                Chem.rdchem.BondType.TRIPLE,
                Chem.rdchem.BondType.AROMATIC
            ],
            'conjugated': [0, 1],
            'in_ring': [0, 1],
            'stereo': list(range(6))
        }
        
        # Initialize scalers
        self.feature_scaler = StandardScaler()
        self.target_scaler = StandardScaler()
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def _get_atom_features(self, atom: Chem.Atom) -> List[float]:
        """Extract atom features"""
        features = []
        
        # One-hot encode atomic number
        atomic_num = [float(atom.GetAtomicNum() == i) for i in self.atom_features['atomic_num']]
        features.extend(atomic_num)
        
        # Add other atom features
        features.extend([
            float(atom.GetDegree()),
            float(atom.GetFormalCharge()),
            float(atom.GetChiralTag()),
            float(atom.GetHybridization()),
            float(atom.GetNumExplicitHs()),
            float(atom.GetImplicitValence()),
            float(atom.GetIsAromatic())
        ])
        
        return features

    def _get_bond_features(self, bond: Chem.Bond) -> List[float]:
        """Extract bond features"""
        features = []
        
        # One-hot encode bond type
        bond_type = [float(bond.GetBondType() == t) for t in self.bond_features['bond_type']]
        features.extend(bond_type)
        
        # Add other bond features
        features.extend([
            float(bond.GetIsConjugated()),
            float(bond.IsInRing()),
            float(bond.GetStereo())
        ])
        
        return features

    def _compute_molecular_descriptors(self, mol: Chem.Mol) -> List[float]:
        """Compute RDKit molecular descriptors"""
        descriptors = []
        
        # Add various molecular descriptors
        descriptors.extend([
            Descriptors.ExactMolWt(mol),
            Descriptors.NumRotatableBonds(mol),
            Descriptors.NumHAcceptors(mol),
            Descriptors.NumHDonors(mol),
            Descriptors.TPSA(mol),
            Descriptors.MolLogP(mol),
            Descriptors.NumAromaticRings(mol),
            Descriptors.FractionCSP3(mol),
            Descriptors.NumAliphaticRings(mol),
            Descriptors.BertzCT(mol)
        ])
        
        return descriptors

    def _pad_array(self, array: np.ndarray, target_size: int, axis: int = 0) -> np.ndarray:
        """Pad array to target size"""
        pad_size = target_size - array.shape[axis]
        if pad_size <= 0:
            return array
            
        pad_width = [(0, 0)] * array.ndim
        pad_width[axis] = (0, pad_size)
        return np.pad(array, pad_width, mode='constant')

    def preprocess_molecule(self, smiles: str) -> Dict[str, torch.Tensor]:
        """
        Preprocess a single molecule from SMILES
        
        Returns:
            Dict containing:
                - node_features: Node feature tensor
                - edge_index: Edge index tensor
                - edge_features: Edge feature tensor
                - global_features: Global molecular descriptors
        """
        try:
            # Convert SMILES to RDKit molecule
            mol = Chem.MolFromSmiles(smiles)
            if self.add_hs:
                mol = Chem.AddHs(mol)
                
            if mol is None:
                raise ValueError(f"Could not parse SMILES: {smiles}")
            
            # Get atom features
            atom_features = []
            for atom in mol.GetAtoms():
                atom_features.append(self._get_atom_features(atom))
            atom_features = np.array(atom_features)
            
            # Get bond features and indices
            bond_features = []
            edge_indices = []
            
            for bond in mol.GetBonds():
                i = bond.GetBeginAtomIdx()
                j = bond.GetEndAtomIdx()
                
                # Add both directions
                edge_indices.extend([[i, j], [j, i]])
                
                f = self._get_bond_features(bond)
                bond_features.extend([f, f])
            
            if len(bond_features) > 0:
                edge_index = torch.tensor(edge_indices).t().contiguous()
                edge_features = torch.tensor(bond_features)
            else:
                edge_index = torch.zeros((2, 0), dtype=torch.long)
                edge_features = torch.zeros((0, len(self._get_bond_features(mol.GetBondWithIdx(0)))))
            
            # Get global features
            global_features = torch.tensor(self._compute_molecular_descriptors(mol))
            
            # Pad if necessary
            atom_features = self._pad_array(atom_features, self.max_atoms)
            
            return {
                'node_features': torch.tensor(atom_features),
                'edge_index': edge_index,
                'edge_features': edge_features,
                'global_features': global_features
            }
            
        except Exception as e:
            self.logger.error(f"Error processing SMILES {smiles}: {str(e)}")
            return None

    def process_dataset(
        self,
        data: pd.DataFrame,
        smiles_col: str,
        target_cols: List[str],
        save_path: Optional[str] = None
    ) -> Tuple[List[Dict[str, torch.Tensor]], torch.Tensor]:
        """
        Process entire dataset
        
        Args:
            data: DataFrame containing SMILES and targets
            smiles_col: Name of SMILES column
            target_cols: List of target column names
            save_path: Optional path to save processed data
            
        Returns:
            Tuple of (processed_data, targets)
        """
        processed_data = []
        valid_indices = []
        
        # Process molecules
        for idx, row in tqdm(data.iterrows(), total=len(data)):
            mol_data = self.preprocess_molecule(row[smiles_col])
            if mol_data is not None:
                processed_data.append(mol_data)
                valid_indices.append(idx)
        
        # Process targets
        targets = torch.tensor(data.loc[valid_indices, target_cols].values)
        
        # Scale features and targets
        if len(processed_data) > 0:
            # Scale node features
            node_features = torch.stack([d['node_features'] for d in processed_data])
            node_features_reshaped = node_features.reshape(-1, node_features.shape[-1])
            self.feature_scaler.fit(node_features_reshaped)
            node_features_scaled = torch.tensor(
                self.feature_scaler.transform(node_features_reshaped)
            ).reshape(node_features.shape)
            
            # Update node features in processed data
            for i, d in enumerate(processed_data):
                d['node_features'] = node_features_scaled[i]
            
            # Scale targets
            self.target_scaler.fit(targets)
            targets = torch.tensor(self.target_scaler.transform(targets))
        
        # Save processed data if path provided
        if save_path is not None:
            save_path = Path(save_path)
            save_path.mkdir(parents=True, exist_ok=True)
            
            torch.save({
                'processed_data': processed_data,
                'targets': targets,
                'feature_scaler': self.feature_scaler,
                'target_scaler': self.target_scaler
            }, save_path / 'processed_data.pt')
        
        return processed_data, targets

class BatchSampler:
    """Handles batch sampling for training"""
    
    def __init__(
        self,
        data: List[Dict[str, torch.Tensor]],
        targets: torch.Tensor,
        batch_size: int,
        shuffle: bool = True
    ):
        """
        Initialize batch sampler
        
        Args:
            data: List of processed molecule data
            targets: Target tensor
            batch_size: Batch size
            shuffle: Whether to shuffle data
        """
        self.data = data
        self.targets = targets
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.num_samples = len(data)
        
    def __iter__(self):
        if self.shuffle:
            indices = torch.randperm(self.num_samples)
        else:
            indices = torch.arange(self.num_samples)
            
        for i in range(0, self.num_samples, self.batch_size):
            batch_indices = indices[i:i + self.batch_size]
            
            # Collect batch data
            batch_data = [self.data[idx] for idx in batch_indices]
            batch_targets = self.targets[batch_indices]
            
            yield self.collate_batch(batch_data, batch_targets)
            
    def collate_batch(
        self,
        batch_data: List[Dict[str, torch.Tensor]],
        batch_targets: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """Collate batch into dictionary of tensors"""
        # Stack node features
        node_features = torch.stack([d['node_features'] for d in batch_data])
        
        # Process edge indices and features
        batch_size = len(batch_data)
        edge_indices = []
        edge_features = []
        batch_idx = []
        
        for i, data in enumerate(batch_data):
            num_nodes = data['node_features'].size(0)
            edge_indices.append(data['edge_index'] + i * num_nodes)
            edge_features.append(data['edge_features'])
            batch_idx.extend([i] * num_nodes)
        
        edge_index = torch.cat(edge_indices, dim=1)
        edge_features = torch.cat(edge_features, dim=0)
        batch_idx = torch.tensor(batch_idx)
        
        # Stack global features
        global_features = torch.stack([d['global_features'] for d in batch_data])
        
        return {
            'node_features': node_features,
            'edge_index': edge_index,
            'edge_features': edge_features,
            'global_features': global_features,
            'batch_idx': batch_idx,
            'targets': batch_targets
        }

    def __len__(self):
        return (self.num_samples + self.batch_size - 1) // self.batch_size