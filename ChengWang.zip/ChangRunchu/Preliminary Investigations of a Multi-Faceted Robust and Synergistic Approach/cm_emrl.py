import torch
import torch.nn as nn
import torch.nn.functional as F

from vit import ViT
from llm_module import LLMModule
from lmm_module import LMMModule
from unified_attention import HierarchicalUnifiedAttention

class CMEMRL(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Initialize components
        self.vit = ViT(config)
        self.llm_module = LLMModule(config)
        self.lmm_module = LMMModule(config)
        self.unified_attention = HierarchicalUnifiedAttention(config)
        
        # Final classification layer
        self.classifier = nn.Linear(config.embed_dim, config.num_classes)
        
    def forward(self, images, categories):
        """
        Forward pass of the CM-EMRL model.
        
        Args:
            images: Batch of input images (B, C, H, W)
            categories: List of category names for the batch
            
        Returns:
            logits: Classification logits (B, num_classes)
            embeddings: Dictionary containing intermediate embeddings
        """
        # Get image embeddings from ViT
        image_embeddings = self.vit(images)
        
        # Get text embeddings from LLM module
        text_embeddings = self.llm_module(categories)
        
        # Get prediction embeddings from LMM module
        pred_embeddings = self.lmm_module(images)
        
        # Combine embeddings using hierarchical unified attention
        cross_modal_embeddings = self.unified_attention(
            image_embeddings,
            text_embeddings,
            pred_embeddings
        )
        
        # Get classification logits
        logits = self.classifier(cross_modal_embeddings)
        
        # Store intermediate embeddings for analysis
        embeddings = {
            'image': image_embeddings,
            'text': text_embeddings,
            'pred': pred_embeddings,
            'cross_modal': cross_modal_embeddings
        }
        
        return logits, embeddings
    
    def compute_loss(self, logits, labels):
        """Compute the classification loss."""
        return F.cross_entropy(logits, labels)
    
    def get_predictions(self, logits):
        """Get predicted classes from logits."""
        return torch.argmax(logits, dim=1)

    def training_step(self, batch):
        """Perform a single training step."""
        images = batch['image'].to(self.config.device)
        labels = batch['label'].to(self.config.device)
        categories = batch['category']
        
        # Forward pass
        logits, _ = self(images, categories)
        
        # Compute loss
        loss = self.compute_loss(logits, labels)
        
        return loss
    
    def validation_step(self, batch):
        """Perform a single validation step."""
        images = batch['image'].to(self.config.device)
        labels = batch['label'].to(self.config.device)
        categories = batch['category']
        
        with torch.no_grad():
            # Forward pass
            logits, embeddings = self(images, categories)
            
            # Compute loss and predictions
            loss = self.compute_loss(logits, labels)
            preds = self.get_predictions(logits)
            
        return {
            'val_loss': loss,
            'preds': preds,
            'labels': labels,
            'embeddings': embeddings
        }
    
    def save_checkpoint(self, path, optimizer, epoch, best_metric):
        """Save model checkpoint."""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'best_metric': best_metric,
            'config': self.config
        }
        torch.save(checkpoint, path)
        
    def load_checkpoint(self, path, optimizer=None):
        """Load model checkpoint."""
        checkpoint = torch.load(path, map_location=self.config.device)
        self.load_state_dict(checkpoint['model_state_dict'])
        
        if optimizer is not None:
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            
        return checkpoint['epoch'], checkpoint['best_metric']
    
    def extract_features(self, images, categories):
        """Extract features from different components."""
        with torch.no_grad():
            image_embeddings = self.vit(images)
            text_embeddings = self.llm_module(categories)
            pred_embeddings = self.lmm_module(images)
            
            return {
                'image_features': image_embeddings,
                'text_features': text_embeddings,
                'pred_features': pred_embeddings
            }
    
    @torch.no_grad()
    def get_attention_maps(self, images, categories):
        """Get attention maps for visualization."""
        # Forward pass
        _, embeddings = self(images, categories)
        
        # Get attention weights from unified attention
        attention_maps = self.unified_attention.get_attention_weights(
            embeddings['image'],
            embeddings['text'],
            embeddings['pred']
        )
        
        return attention_maps
    
    def freeze_backbone(self):
        """Freeze ViT backbone for fine-tuning."""
        for param in self.vit.parameters():
            param.requires_grad = False
            
    def unfreeze_backbone(self):
        """Unfreeze ViT backbone."""
        for param in self.vit.parameters():
            param.requires_grad = True
    
    def get_embedding_similarity(self, embed1, embed2):
        """Compute cosine similarity between embeddings."""
        return F.cosine_similarity(embed1, embed2)