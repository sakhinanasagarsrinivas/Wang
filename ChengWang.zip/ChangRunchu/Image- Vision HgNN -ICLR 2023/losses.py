import torch
import torch.nn.functional as F

def focal_loss(inputs, targets, alpha=0.25, gamma=2.0):
    """
    Focal Loss to handle class imbalance in SEM dataset
    
    Args:
    - inputs: Model predictions (logits)
    - targets: True labels
    - alpha: Weighting factor for class balance
    - gamma: Focusing parameter
    
    Returns:
    - Computed focal loss
    """
    ce_loss = F.cross_entropy(inputs, targets, reduction='none')
    pt = torch.exp(-ce_loss)
    focal_loss = (alpha * (1-pt)**gamma * ce_loss).mean()
    return focal_loss

def label_smoothing_loss(inputs, targets, smoothing=0.1):
    """
    Label Smoothing Cross Entropy Loss
    
    Args:
    - inputs: Model predictions (logits)
    - targets: True labels
    - smoothing: Amount of label smoothing
    
    Returns:
    - Computed label smoothing loss
    """
    log_prob = F.log_softmax(inputs, dim=-1)
    loss = (1 - smoothing) * F.nll_loss(log_prob, targets) + \
           smoothing * (-log_prob.mean(dim=-1)).mean()
    return loss

def weighted_cross_entropy(inputs, targets, class_weights=None):
    """
    Weighted Cross Entropy Loss for handling imbalanced datasets
    
    Args:
    - inputs: Model predictions (logits)
    - targets: True labels
    - class_weights: Tensor of weights for each class
    
    Returns:
    - Computed weighted cross entropy loss
    """
    if class_weights is None:
        # Compute class weights based on inverse frequency
        class_counts = torch.bincount(targets)
        class_weights = 1.0 / class_counts.float()
        class_weights /= class_weights.sum()
    
    return F.cross_entropy(inputs, targets, weight=class_weights)