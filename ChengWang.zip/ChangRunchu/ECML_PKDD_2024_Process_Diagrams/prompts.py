from typing import Dict, List, Optional
from pathlib import Path
import yaml
from langchain.prompts import PromptTemplate
from langchain.prompts.chat import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate

class PromptManager:
    def __init__(self, config_path: str):
        """
        Initialize prompt manager with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.prompts = self._load_prompt_templates()
        
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
            
    def _load_prompt_templates(self) -> Dict:
        """Load and initialize prompt templates."""
        return {
            # Main Agent Prompts
            'task_planning': PromptTemplate(
                template="""Given the following query about process diagrams:
                {query}
                
                Break down this query into subtasks and determine which type of diagram (PFD or P&ID) is most relevant.
                
                Subtasks:
                1. [First subtask]
                2. [Second subtask]
                ...""",
                input_variables=['query']
            ),
            
            # Sub-Agent Prompts
            'generate_candidates': PromptTemplate(
                template="""Based on the following information:
                Query: {query}
                Context: {context}
                
                Generate multiple potential answers. Consider:
                1. Technical accuracy
                2. Relevance to query
                3. Completeness
                
                Provide your answers in this format:
                A) [First answer]
                B) [Second answer]
                ...""",
                input_variables=['query', 'context']
            ),
            
            'conditional_summary': PromptTemplate(
                template="""Given:
                Question: {question}
                Answer Candidate: {answer}
                Context: {context}
                
                Generate a detailed summary that validates this answer, focusing on:
                1. Supporting evidence
                2. Technical justification
                3. Logical reasoning""",
                input_variables=['question', 'answer', 'context']
            ),
            
            # Critique Agent Prompts
            'evaluate_response': ChatPromptTemplate.from_messages([
                SystemMessagePromptTemplate.from_template(
                    "You are a critique agent for process engineering diagrams. "
                    "Evaluate responses for accuracy, completeness, and relevance."
                ),
                HumanMessagePromptTemplate.from_template(
                    """Query: {query}
                    Response: {response}
                    Context: {context}
                    
                    Evaluate considering:
                    1. Technical accuracy
                    2. Completeness
                    3. Relevance
                    4. Clarity
                    
                    Provide structured feedback and suggestions."""
                )
            ]),
            
            # OCR and Text Processing Prompts
            'extract_technical_info': PromptTemplate(
                template="""From the following OCR text:
                {text}
                
                Extract and classify technical information:
                1. Equipment IDs
                2. Process parameters
                3. Flow directions
                4. Units and measurements""",
                input_variables=['text']
            ),
            
            # Image Analysis Prompts
            'analyze_diagram': PromptTemplate(
                template="""Analyze the following diagram components:
                Components: {components}
                Text: {text}
                
                Provide a structured analysis of:
                1. Equipment layout
                2. Process flow
                3. Control systems
                4. Key parameters""",
                input_variables=['components', 'text']
            )
        }
        
    def get_prompt(self, prompt_type: str) -> Optional[PromptTemplate]:
        """
        Get prompt template by type.
        
        Args:
            prompt_type: Type of prompt to retrieve
            
        Returns:
            PromptTemplate or None if not found
        """
        return self.prompts.get(prompt_type)
        
    def format_prompt(self, prompt_type: str, **kwargs) -> Optional[str]:
        """
        Format prompt with provided variables.
        
        Args:
            prompt_type: Type of prompt to format
            **kwargs: Variables for prompt formatting
            
        Returns:
            Formatted prompt string or None if prompt type not found
        """
        prompt = self.get_prompt(prompt_type)
        if prompt:
            return prompt.format(**kwargs)
        return None
        
    def add_prompt(self, prompt_type: str, template: str, input_variables: List[str]):
        """
        Add new prompt template.
        
        Args:
            prompt_type: Type of prompt
            template: Prompt template string
            input_variables: List of input variables
        """
        self.prompts[prompt_type] = PromptTemplate(
            template=template,
            input_variables=input_variables
        )
        
    def update_prompt(self, prompt_type: str, template: str, input_variables: List[str]):
        """
        Update existing prompt template.
        
        Args:
            prompt_type: Type of prompt to update
            template: New prompt template string
            input_variables: List of input variables
        """
        if prompt_type in self.prompts:
            self.prompts[prompt_type] = PromptTemplate(
                template=template,
                input_variables=input_variables
            )
            
    def save_prompts(self, output_path: str):
        """
        Save prompt templates to file.
        
        Args:
            output_path: Path to save prompts
        """
        prompts_data = {
            name: {
                'template': prompt.template,
                'input_variables': prompt.input_variables
            }
            for name, prompt in self.prompts.items()
        }
        
        with open(output_path, 'w') as f:
            yaml.dump(prompts_data, f)
            
    def load_prompts_from_file(self, input_path: str):
        """
        Load prompt templates from file.
        
        Args:
            input_path: Path to load prompts from
        """
        with open(input_path, 'r') as f:
            prompts_data = yaml.safe_load(f)
            
        for name, data in prompts_data.items():
            self.prompts[name] = PromptTemplate(
                template=data['template'],
                input_variables=data['input_variables']
            )
            
    def get_chat_prompt(self, prompt_type: str) -> Optional[ChatPromptTemplate]:
        """
        Get chat prompt template by type.
        
        Args:
            prompt_type: Type of chat prompt to retrieve
            
        Returns:
            ChatPromptTemplate or None if not found
        """
        prompt = self.prompts.get(prompt_type)
        if isinstance(prompt, ChatPromptTemplate):
            return prompt
        return None