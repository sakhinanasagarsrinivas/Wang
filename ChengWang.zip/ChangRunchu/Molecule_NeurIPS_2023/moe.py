import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Dict

class Expert(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        num_layers: int = 2,
        dropout: float = 0.1
    ):
        """
        Single expert network
        
        Args:
            input_dim: Input dimension
            hidden_dim: Hidden dimension
            output_dim: Output dimension
            num_layers: Number of hidden layers
            dropout: Dropout probability
        """
        super().__init__()
        
        layers = []
        current_dim = input_dim
        
        # Hidden layers
        for _ in range(num_layers - 1):
            layers.extend([
                nn.Linear(current_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
            current_dim = hidden_dim
        
        # Output layer
        layers.append(nn.Linear(current_dim, output_dim))
        
        self.network = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through the expert"""
        return self.network(x)


class GatingNetwork(nn.Module):
    def __init__(
        self,
        input_dim: int,
        num_experts: int,
        hidden_dim: int = None,
        dropout: float = 0.1
    ):
        """
        Gating network for selecting experts
        
        Args:
            input_dim: Input dimension
            num_experts: Number of experts
            hidden_dim: Hidden dimension (optional)
            dropout: Dropout probability
        """
        super().__init__()
        
        if hidden_dim is None:
            hidden_dim = input_dim // 2
        
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_experts)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass to compute gating weights
        
        Returns:
            torch.Tensor: Gating weights [batch_size, num_experts]
        """
        logits = self.network(x)
        return F.softmax(logits, dim=-1)


class MixtureOfExperts(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        num_experts: int = 3,
        expert_layers: int = 2,
        dropout: float = 0.1,
        k: int = 2  # Number of experts to use per sample
    ):
        """
        Mixture of Experts module
        
        Args:
            input_dim: Input dimension
            hidden_dim: Hidden dimension for experts
            output_dim: Output dimension
            num_experts: Number of expert networks
            expert_layers: Number of layers in each expert
            dropout: Dropout probability
            k: Number of experts to use per sample
        """
        super().__init__()
        
        self.num_experts = num_experts
        self.k = min(k, num_experts)
        
        # Create experts
        self.experts = nn.ModuleList([
            Expert(
                input_dim=input_dim,
                hidden_dim=hidden_dim,
                output_dim=output_dim,
                num_layers=expert_layers,
                dropout=dropout
            )
            for _ in range(num_experts)
        ])
        
        # Create gating network
        self.gating = GatingNetwork(
            input_dim=input_dim,
            num_experts=num_experts,
            hidden_dim=hidden_dim,
            dropout=dropout
        )
        
        # Noise for load balancing
        self.noise_scalar = 1e-2

    def _compute_expert_losses(
        self,
        gates: torch.Tensor,
        expert_mask: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Compute auxiliary losses for expert load balancing
        
        Args:
            gates: Gating weights [batch_size, num_experts]
            expert_mask: Binary mask of selected experts [batch_size, num_experts]
            
        Returns:
            Dict[str, torch.Tensor]: Dictionary of losses
        """
        # Load balancing loss
        expert_usage = expert_mask.sum(0)  # [num_experts]
        expert_usage_normalized = expert_usage / expert_usage.sum()
        target_usage = torch.ones_like(expert_usage) / self.num_experts
        load_balancing_loss = F.mse_loss(expert_usage_normalized, target_usage)
        
        # Importance loss (encourages sparse gating)
        importance_loss = gates.pow(2).mean()
        
        return {
            'load_balancing_loss': load_balancing_loss,
            'importance_loss': importance_loss
        }

    def forward(
        self,
        x: torch.Tensor,
        return_gates: bool = False
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Forward pass through Mixture of Experts
        
        Args:
            x: Input tensor [batch_size, input_dim]
            return_gates: Whether to return gating weights
            
        Returns:
            Tuple[torch.Tensor, Dict]: (output, auxiliary_outputs)
        """
        batch_size = x.size(0)
        
        # Compute gating weights
        gates = self.gating(x)
        
        if self.training:
            # Add noise during training for exploration
            noise_gates = gates + torch.randn_like(gates) * self.noise_scalar
        else:
            noise_gates = gates
        
        # Select top-k experts
        top_k_gates, top_k_indices = torch.topk(noise_gates, k=self.k, dim=-1)
        top_k_gates = top_k_gates / top_k_gates.sum(dim=-1, keepdim=True)
        
        # Create mask for selected experts
        expert_mask = torch.zeros_like(gates)
        expert_mask.scatter_(1, top_k_indices, 1)
        
        # Compute outputs from each expert
        expert_outputs = []
        for i, expert in enumerate(self.experts):
            # Only compute for batches that use this expert
            expert_mask_i = expert_mask[:, i]
            if expert_mask_i.any():
                # Get relevant inputs
                expert_input = x[expert_mask_i]
                # Get expert output
                expert_output = expert(expert_input)
                # Store output
                expert_outputs.append((expert_output, i, expert_mask_i))
        
        # Combine expert outputs
        combined_output = torch.zeros(batch_size, self.experts[0].network[-1].out_features,
                                    device=x.device)
        
        for expert_output, expert_idx, mask in expert_outputs:
            # Get corresponding gating weights
            expert_gates = gates[mask, expert_idx].unsqueeze(1)
            # Add weighted expert output
            combined_output[mask] += expert_output * expert_gates
        
        # Compute auxiliary losses
        auxiliary_outputs = self._compute_expert_losses(gates, expert_mask)
        
        if return_gates:
            auxiliary_outputs['gates'] = gates
            auxiliary_outputs['expert_mask'] = expert_mask
        
        return combined_output, auxiliary_outputs


class MOEOutput(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        num_tasks: int,
        num_experts: int = 3,
        dropout: float = 0.1
    ):
        """
        MOE-based output layer for multi-task prediction
        
        Args:
            input_dim: Input dimension
            hidden_dim: Hidden dimension
            num_tasks: Number of prediction tasks
            num_experts: Number of experts
            dropout: Dropout probability
        """
        super().__init__()
        
        self.moe = MixtureOfExperts(
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            output_dim=num_tasks,
            num_experts=num_experts,
            dropout=dropout
        )
        
        # Task-specific layers
        self.task_projections = nn.ModuleList([
            nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, 1)
            )
            for _ in range(num_tasks)
        ])

    def forward(
        self,
        x: torch.Tensor
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Forward pass
        
        Args:
            x: Input tensor [batch_size, input_dim]
            
        Returns:
            Tuple[torch.Tensor, Dict]: (predictions, auxiliary_outputs)
        """
        # Get MoE outputs
        moe_output, auxiliary_outputs = self.moe(x, return_gates=True)
        
        # Get task-specific predictions
        task_predictions = []
        for task_projection in self.task_projections:
            task_pred = task_projection(x)
            task_predictions.append(task_pred)
        
        # Combine predictions
        predictions = torch.cat(task_predictions, dim=-1)
        
        # Combine with MoE output
        final_predictions = (predictions + moe_output) / 2
        
        return final_predictions, auxiliary_outputs