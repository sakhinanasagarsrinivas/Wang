# rait_framework/datasets/synthetic_data_generator.py
import os
import csv
import json
import asyncio
from typing import List, Dict, Any, Optional
import random
import logging

from openai import AsyncOpenAI
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class SyntheticDataGenerator:
    """
    Advanced synthetic data generator with iterative self-reflection 
    for Retrieval-Augmented Instruction-Tuning (RAIT)
    """
    def __init__(self, 
                 api_key: Optional[str] = None, 
                 model: str = "gpt-4o",
                 retrieval_model: str = "all-MiniLM-L6-v2"):
        """
        Initialize synthetic data generator with advanced self-reflection capabilities
        
        Args:
            api_key (str, optional): OpenAI API key
            model (str): GPT model to use for generation
            retrieval_model (str): Sentence transformer model for semantic retrieval
        """
        # Logging setup
        self.logger = logging.getLogger(self.__class__.__name__)
        logging.basicConfig(level=logging.INFO)
        
        # API and model configuration
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        if not self.api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY env var or pass directly.")
        
        self.client = AsyncOpenAI(api_key=self.api_key)
        self.model = model
        
        # Iterative refinement parameters
        self.max_refinement_iterations = 3
        self.rejection_criteria = {
            'technical_accuracy': 0.7,
            'complexity_match': 0.7,
            'computational_feasibility': 0.7
        }
        
        # Advanced retrieval components
        self.retrieval_model = SentenceTransformer(retrieval_model)
        
        # Open-source tool mappings
        self.tool_mappings = {
            'mathematical_computation': [
                'NumPy', 
                'SciPy', 
                'SymPy', 
                'Matplotlib', 
                'scikit-learn', 
                'JAX', 
                'Optuna'
            ],
            'chemical_engineering': [
                'ChemPy', 
                'CoolProp', 
                'Cantera', 
                'Pyomo',
                'OpenFOAM-dev', 
                'Pandas',
                'thermo'
            ]
        }
        
        # Knowledge base for domain-specific augmentation
        self._load_domain_knowledge()
    
    def _load_domain_knowledge(self):
        """
        Load and prepare domain-specific knowledge bases
        """
        self.domain_knowledge = {
            'mathematical_computation': [
                "Advanced numerical methods for differential equations",
                "Computational linear algebra techniques",
                "Optimization algorithms and computational complexity theory",
                "Stochastic process modeling",
                "Numerical integration and differentiation strategies"
            ],
            'chemical_engineering': [
                "Advanced mass and energy balance principles",
                "Thermodynamic equilibrium and phase behavior modeling",
                "Reaction kinetics and reactor design fundamentals",
                "Transport phenomena and fluid dynamics",
                "Process simulation and optimization techniques"
            ]
        }
        
        # Embed domain knowledge for semantic retrieval
        self.domain_embeddings = {
            domain: self.retrieval_model.encode(knowledge)
            for domain, knowledge in self.domain_knowledge.items()
        }
    
    async def generate_synthetic_qa_pairs(self, 
                                           domain: str, 
                                           num_samples: int = 100, 
                                           complexity_levels: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        Generate synthetic QA pairs with comprehensive self-reflection
        
        Args:
            domain (str): Problem domain
            num_samples (int): Number of QA pairs to generate
            complexity_levels (List[str], optional): Complexity levels to generate
        
        Returns:
            List[Dict[str, Any]]: Generated and validated QA pairs
        """
        complexity_levels = complexity_levels or ['easy', 'medium', 'hard']
        synthetic_pairs = []
        
        async def generate_and_validate_qa_pair(complexity: str) -> Optional[Dict[str, Any]]:
            """
            Generate and iteratively refine a single QA pair
            
            Args:
                complexity (str): Complexity level
            
            Returns:
                Optional[Dict[str, Any]]: Validated QA pair or None
            """
            for iteration in range(self.max_refinement_iterations):
                try:
                    # Initial generation
                    initial_pair = await self._generate_initial_qa_pair(domain, complexity)
                    
                    # Self-reflection and validation
                    validation_result = await self._validate_qa_pair(initial_pair, domain, complexity)
                    
                    # Check if pair meets validation criteria
                    if all(score >= threshold 
                           for score, threshold in zip(
                               validation_result.values(), 
                               self.rejection_criteria.values()
                           )):
                        return initial_pair
                    
                    # If not validated, log and continue to next iteration
                    self.logger.info(f"Iteration {iteration + 1}: QA pair did not meet validation criteria.")
                
                except Exception as e:
                    self.logger.error(f"Error in QA pair generation: {e}")
            
            # If all iterations fail, return None
            self.logger.warning(f"Failed to generate valid QA pair for {domain} at {complexity} complexity")
            return None
        
        # Generate QA pairs with parallel processing
        tasks = [
            generate_and_validate_qa_pair(random.choice(complexity_levels)) 
            for _ in range(num_samples)
        ]
        
        # Await all tasks and filter out None results
        synthetic_pairs = [
            pair for pair in await asyncio.gather(*tasks) 
            if pair is not None
        ]
        
        return synthetic_pairs
    
    async def _generate_initial_qa_pair(self, 
                                        domain: str, 
                                        complexity: str) -> Dict[str, Any]:
        """
        Generate an initial QA pair with contextual augmentation
        
        Args:
            domain (str): Problem domain
            complexity (str): Problem complexity
        
        Returns:
            Dict[str, Any]: Generated QA pair
        """
        # Retrieve relevant context
        context_snippets = random.sample(self.domain_knowledge[domain], 3)
        
        # Construct generation prompt
        prompt = self._construct_problem_generation_prompt(
            domain, complexity, context_snippets
        )
        
        # Generate problem using GPT
        response = await self._call_gpt(prompt)
        
        # Parse response
        initial_pair = self._parse_gpt_response(response)
        
        # Enhance with tools and computational approach
        enhanced_pair = await self._enhance_qa_pair(
            initial_pair, domain, complexity
        )
        
        return enhanced_pair
    
    async def _validate_qa_pair(self, 
                                 qa_pair: Dict[str, Any], 
                                 domain: str, 
                                 complexity: str) -> Dict[str, float]:
        """
        Comprehensive validation of QA pair through self-reflection
        
        Args:
            qa_pair (Dict[str, Any]): QA pair to validate
            domain (str): Problem domain
            complexity (str): Problem complexity
        
        Returns:
            Dict[str, float]: Validation scores
        """
        # Construct validation prompt
        validation_prompt = f"""
        Critically evaluate the following problem pair for a {domain} domain problem 
        with {complexity} complexity:

        Problem Pair:
        {json.dumps(qa_pair, indent=2)}

        Provide a detailed assessment focusing on:
        1. Technical Accuracy: Assess the scientific and computational precision
        2. Complexity Alignment: Verify the problem matches the specified complexity level
        3. Computational Feasibility: Evaluate the practicality of solving the problem
        4. Learning Potential: Analyze the problem's educational and skill-development value

        Return a JSON with scores (0-1) for each criterion and detailed reasoning.
        """
        
        # Get validation response
        validation_response = await self._call_gpt(validation_prompt)
        
        # Parse validation scores
        try:
            validation_results = json.loads(validation_response)
            
            # Extract numerical scores
            scores = {
                'technical_accuracy': float(validation_results.get('technical_accuracy', 0)),
                'complexity_match': float(validation_results.get('complexity_match', 0)),
                'computational_feasibility': float(validation_results.get('computational_feasibility', 0))
            }
            
            return scores
        
        except (json.JSONDecodeError, ValueError) as e:
            self.logger.error(f"Validation scoring failed: {e}")
            # Return default low scores if parsing fails
            return {
                'technical_accuracy': 0.3,
                'complexity_match': 0.3,
                'computational_feasibility': 0.3
            }
    
    async def _enhance_qa_pair(self, 
                                qa_pair: Dict[str, Any], 
                                domain: str, 
                                complexity: str) -> Dict[str, Any]:
        """
        Enhance QA pair with computational tools and approaches
        
        Args:
            qa_pair (Dict[str, Any]): Initial QA pair
            domain (str): Problem domain
            complexity (str): Problem complexity
        
        Returns:
            Dict[str, Any]: Enhanced QA pair
        """
        # Select tools based on complexity
        complexity_tool_count = {
            'easy': 1, 
            'medium': 2, 
            'hard': 3
        }
        
        # Randomly select tools
        selected_tools = random.sample(
            self.tool_mappings.get(domain, []), 
            complexity_tool_count.get(complexity, 1)
        )
        
        # Enhance QA pair with computational details
        enhanced_pair = {
            **qa_pair,
            'domain': domain,
            'complexity': complexity,
            'tools_required': ','.join(selected_tools),
            'computational_approach': f"Solution approach utilizing {', '.join(selected_tools)} libraries",
            'learning_objectives': self._generate_learning_objectives(domain, complexity)
        }
        
        return enhanced_pair
    
    def _generate_learning_objectives(self, domain: str, complexity: str) -> List[str]:
        """
        Generate learning objectives based on domain and complexity
        
        Args:
            domain (str): Problem domain
            complexity (str): Problem complexity
        
        Returns:
            List[str]: Learning objectives
        """
        learning_objectives_map = {
            'mathematical_computation': {
                'easy': [
                    "Understand basic numerical computation techniques",
                    "Practice implementing simple mathematical algorithms"
                ],
                'medium': [
                    "Apply advanced numerical methods",
                    "Develop skills in computational problem-solving",
                    "Explore algorithm optimization techniques"
                ],
                'hard': [
                    "Master complex computational strategies",
                    "Develop advanced algorithmic thinking",
                    "Analyze computational complexity and efficiency"
                ]
            },
            'chemical_engineering': {
                'easy': [
                    "Understand fundamental chemical engineering principles",
                    "Practice basic computational modeling"
                ],
                'medium': [
                    "Apply advanced thermodynamic and kinetic modeling",
                    "Develop process simulation skills",
                    "Explore computational approaches in chemical engineering"
                ],
                'hard': [
                    "Master complex process design and optimization",
                    "Develop advanced computational modeling techniques",
                    "Analyze intricate chemical engineering systems"
                ]
            }
        }
        
        return learning_objectives_map.get(domain, {}).get(complexity, [])
    
    async def _call_gpt(self, prompt: str) -> str:
        """
        Asynchronous call to GPT with enhanced error handling
        
        Args:
            prompt (str): Prompt to send to GPT
        
        Returns:
            str: GPT response
        """
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert problem generator for scientific and computational domains, focusing on technical precision and educational value."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.7
            )
            return response.choices[0].message.content
        
        except Exception as e:
            self.logger.error(f"GPT API Error: {e}")
            raise
    
    def _construct_problem_generation_prompt(self, 
                                             domain: str, 
                                             complexity: str, 
                                             context_snippets: List[str]) -> str:
        """
        Construct a sophisticated problem generation prompt
        
        Args:
            domain (str): Problem domain
            complexity (str): Problem complexity
            context_snippets (List[str]): Retrieved context snippets
        
        Returns:
            str: Constructed prompt
        """
        complexity_map = {
            'easy': "Simple problems requiring basic computational skills.",
            'medium': "Moderately complex problems involving multiple computational steps.",
            'hard': "Advanced problems requiring sophisticated analytical and computational techniques."
        }
        
        context_str = "\n".join(f"- {snippet}" for snippet in context_snippets)
        
        return f"""
        Generate a high-quality, technically precise problem in the {domain} domain with {complexity} complexity.

        Contextual Knowledge:
        {context_str}

        Problem Generation Requirements:
        1. Create a technically rigorous problem statement
        2. Ensure mathematical and computational complexity appropriate to the specified level
        3. Include clear initial conditions and constraints
        4. Design a problem that requires non-trivial computational approach
        5. Incorporate domain-specific theoretical foundations

        Complexity Level: {complexity_map.get(complexity, '')}

        Output Format (Strict JSON):
        {{
            "instruction": "Detailed problem description",
            "input_parameters": "Specific initial conditions and variables",
            "theoretical_background": "Relevant scientific principles",
            "solution_approach": "High-level computational strategy",
            "expected_output": "Description of solution or result"
        }}
        """
    
    def save_synthetic_dataset(self, 
                                synthetic_pairs: List[Dict[str, Any]], 
                                output_path: str, 
                                format: str = 'csv'):
        """
        Save synthetic dataset with enhanced metadata
        
        Args:
            synthetic_pairs (List[Dict[str, Any]]): Generated synthetic pairs
            output_path (str): Output file path
            format (str): Output file format
        """
        if not synthetic_pairs:
            self.logger.warning("No synthetic pairs to save.")
            return
        
        # Ensure consistent keys across all pairs
        keys = set().union(*[pair.keys() for pair in synthetic_pairs])
        
        if format == 'csv':
            with open(output_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=list(keys))
                writer.writeheader()
                writer.writerows(synthetic_pairs)
        
        elif format == 'json':
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(synthetic_pairs, f, indent=2)
        
        else:
            raise ValueError("Unsupported format. Use 'csv' or 'json'.")
        
        self.logger.info(f"Saved {len(synthetic_pairs)} synthetic pairs to {output_path}")

async def generate_datasets():
    """
    Comprehensive dataset generation pipeline with enhanced logging
    """
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger('DatasetGeneration')
    
    generator = SyntheticDataGenerator()
    
    # Generation configurations
    dataset_configs = [
        {
            'domain': 'mathematical_computation',
            'num_samples': 7500,
            'output_path': 'mathcomp_synthetic_dataset.csv'
        },
        {
            'domain': 'chemical_engineering',
            'num_samples': 5000,
            'output_path': 'chemproc_synthetic_dataset.csv'
        }
    ]
    
    for config in dataset_configs:
        logger.info(f"Generating {config['domain']} dataset...")
        
        try:
            # Measure generation time
            start_time = asyncio.get_event_loop().time()
            
            synthetic_pairs = await generator.generate_synthetic_qa_pairs(
                domain=config['domain'],
                num_samples=config['num_samples']
            )
            
            end_time = asyncio.get_event_loop().time()
            
            # Save dataset
            generator.save_synthetic_dataset(
                synthetic_pairs, 
                config['output_path']
            )
            
            # Log generation statistics
            logger.info(f"Completed generation for {config['domain']}")
            logger.info(f"Total pairs generated: {len(synthetic_pairs)}")
            logger.info(f"Generation time: {end_time - start_time:.2f} seconds")
        
        except Exception as e:
            logger.error(f"Dataset generation failed for {config['domain']}: {e}")

if __name__ == '__main__':
    asyncio.run(generate_datasets())