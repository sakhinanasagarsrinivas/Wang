import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import ChebConv, global_add_pool
from typing import Tuple

class ChebyshevGNN(nn.Module):
    def __init__(self,
                 in_channels: int,
                 hidden_channels: int,
                 num_layers: int,
                 K: int = 3,
                 dropout: float = 0.1):
        """
        Initialize the Chebyshev GNN model
        
        Args:
            in_channels: Number of input channels
            hidden_channels: Number of hidden channels
            num_layers: Number of GNN layers
            K: Order of Chebyshev polynomial
            dropout: Dropout probability
        """
        super().__init__()
        
        self.dropout = dropout
        self.num_layers = num_layers
        
        # Initial projection
        self.init_proj = nn.Linear(in_channels, hidden_channels)
        
        # Chebyshev convolution layers
        self.convs = nn.ModuleList([
            ChebConv(hidden_channels, hidden_channels, K)
            for _ in range(num_layers)
        ])
        
        # Batch normalization layers
        self.bns = nn.ModuleList([
            nn.BatchNorm1d(hidden_channels)
            for _ in range(num_layers)
        ])
        
        # Final projection
        self.final_proj = nn.Linear(hidden_channels, hidden_channels)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor, 
                batch: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of the model
        
        Args:
            x: Node features [num_nodes, in_channels]
            edge_index: Edge indices [2, num_edges]
            batch: Batch indices [num_nodes]
            
        Returns:
            tuple: (graph_embedding, node_embeddings)
        """
        # Initial projection
        x = self.init_proj(x)
        
        # Store initial node embeddings
        node_embeddings = x
        
        # Apply Chebyshev convolutions
        for i in range(self.num_layers):
            # Convolution
            x = self.convs[i](x, edge_index)
            
            # Batch normalization
            x = self.bns[i](x)
            
            # Activation and dropout
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
            
            # Update node embeddings with residual connection
            node_embeddings = node_embeddings + x
        
        # Final projection
        node_embeddings = self.final_proj(node_embeddings)
        
        # Global pooling to get graph embedding
        graph_embedding = global_add_pool(node_embeddings, batch)
        
        return graph_embedding, node_embeddings

    def get_attention_weights(self, x: torch.Tensor, 
                            edge_index: torch.Tensor) -> torch.Tensor:
        """
        Get attention weights for edges
        
        Args:
            x: Node features [num_nodes, in_channels]
            edge_index: Edge indices [2, num_edges]
            
        Returns:
            torch.Tensor: Attention weights for edges
        """
        attention_weights = []
        
        x = self.init_proj(x)
        
        for i in range(self.num_layers):
            # Get attention weights from ChebConv layer
            _, attention = self.convs[i](x, edge_index, return_attention_weights=True)
            attention_weights.append(attention)
            
            # Update node features
            x = self.convs[i](x, edge_index)
            x = self.bns[i](x)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        
        # Average attention weights across layers
        mean_attention = torch.stack(attention_weights).mean(dim=0)
        
        return mean_attention