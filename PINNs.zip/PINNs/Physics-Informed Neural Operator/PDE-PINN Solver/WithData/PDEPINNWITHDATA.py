import torch
import torch.nn as nn
import numpy as np
import json
import argparse
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import time
import os

torch.manual_seed(42)
np.random.seed(42)

class PINN(nn.Module):
    def __init__(self, num_inputs, num_outputs, hidden_layers, neurons_per_layer, activation_fn):
        super(PINN, self).__init__()
        
        self.num_inputs = num_inputs
        self.num_outputs = num_outputs
        
        layers = []
        layers.append(nn.Linear(num_inputs, neurons_per_layer))
        layers.append(activation_fn())
        
        for _ in range(hidden_layers - 1):
            layers.append(nn.Linear(neurons_per_layer, neurons_per_layer))
            layers.append(activation_fn())
            
        layers.append(nn.Linear(neurons_per_layer, num_outputs))
        
        self.net = nn.Sequential(*layers)
        
        self._initialize_weights()
        
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.constant_(m.bias, 0.0)

    def forward(self, xt):
        return self.net(xt)

class PINNSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.internal_data_points = None
        self._parse_config()
        self._setup_normalization()
        self._build_model()

    def _parse_config(self):
        self.problem_name = self.config['problem_name']
        self.state_vars = self.config['state_variables']
        self.pde = self.config['pde']
        self.spatial_domain_def = self.config['spatial_domain']
        self.spatial_dims = list(self.spatial_domain_def.keys())
        self.num_spatial_dims = len(self.spatial_dims)
        self.t_domain = torch.tensor(self.config['time_domain'], device=self.device)
        self.params = self.config.get('parameters', {})
        self.ic_def = self.config['initial_conditions']
        self.bc_def = self.config['boundary_conditions']

        if 'data' in self.config and self.config['data']:
            all_points = []
            for sensor_name, points in self.config['data'].items():
                if sensor_name.startswith("_"):
                    continue
                if points:
                    all_points.extend(points)
            if all_points:
                self.internal_data_points = torch.tensor(all_points, dtype=torch.float32).to(self.device)
                print(f"Loaded {len(self.internal_data_points)} internal data points from config.")

        hp = self.config['hyperparameters']
        self.hidden_layers = hp['hidden_layers']
        self.neurons_per_layer = hp['neurons_per_layer']
        self.lr = hp['learning_rate']
        self.epochs = hp['epochs']
        self.num_collocation = hp['num_collocation_points']
        self.num_ic = hp['num_ic_points']
        self.num_bc = hp['num_bc_points']
        self.loss_weights = hp['loss_weights']
        activation_map = {"tanh": nn.Tanh, "relu": nn.ReLU, "sigmoid": nn.Sigmoid}
        self.activation_fn = activation_map.get(hp['activation_function'], nn.Tanh)

    def _setup_normalization(self):
        x_range = self.spatial_domain_def['x']
        t_range = self.t_domain.cpu().numpy()
        
        self.x_mean = (x_range[0] + x_range[1]) / 2
        self.x_std = (x_range[1] - x_range[0]) / 2
        self.t_mean = (t_range[0] + t_range[1]) / 2
        self.t_std = (t_range[1] - t_range[0]) / 2

    def _normalize_input(self, xt):
        x_norm = (xt[:, 0] - self.x_mean) / self.x_std
        t_norm = (xt[:, 1] - self.t_mean) / self.t_std
        return torch.stack([x_norm, t_norm], dim=1)

    def _denormalize_input(self, xt_norm):
        x = xt_norm[:, 0] * self.x_std + self.x_mean
        t = xt_norm[:, 1] * self.t_std + self.t_mean
        return torch.stack([x, t], dim=1)

    def _build_model(self):
        num_inputs = self.num_spatial_dims + 1
        num_outputs = len(self.state_vars)
        self.model = PINN(
            num_inputs, num_outputs, self.hidden_layers,
            self.neurons_per_layer, self.activation_fn
        ).to(self.device)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer, mode='min', factor=0.8, patience=1000, verbose=True
        )

    def _get_eval_scope(self, scope_vars):
        scope = scope_vars.copy()
        scope.update(self.params)
        scope.update({'exp': torch.exp, 'sin': torch.sin, 'cos': torch.cos, 'pi': torch.pi})
        return scope

    def _pde_residual_loss(self, xt_collocation):
        xt_norm = self._normalize_input(xt_collocation)
        xt_norm.requires_grad_(True)
        
        u = self.model(xt_norm)
        
        grad_outputs = torch.ones_like(u)
        grad_u = torch.autograd.grad(u, xt_norm, grad_outputs=grad_outputs, create_graph=True)[0]
        
        dudx_norm = grad_u[:, 0]
        dudt_norm = grad_u[:, 1]
        
        dudx = dudx_norm / self.x_std
        dudt = dudt_norm / self.t_std
        
        grad_dudx_norm = torch.autograd.grad(dudx_norm, xt_norm, grad_outputs=torch.ones_like(dudx_norm), create_graph=True)[0]
        dudx2 = grad_dudx_norm[:, 0] / (self.x_std ** 2)
        
        scope_vars = {
            'u': u.squeeze(), 
            'dudt': dudt, 
            'dudx': dudx, 
            'dudx2': dudx2,
            'x': xt_collocation[:, 0], 
            't': xt_collocation[:, 1]
        }
        scope = self._get_eval_scope(scope_vars)
        pde_residual = eval(self.pde, {}, scope)
        return torch.mean(pde_residual**2)

    def _ic_loss(self):
        x_range = self.spatial_domain_def['x']
        x_ic = x_range[0] + (x_range[1] - x_range[0]) * torch.rand(self.num_ic, 1, device=self.device)
        t_ic = torch.zeros_like(x_ic, device=self.device)
        xt_ic = torch.cat([x_ic, t_ic], dim=1)
        
        xt_ic_norm = self._normalize_input(xt_ic)
        u_pred = self.model(xt_ic_norm)
        
        scope_vars = {'x': x_ic.squeeze()}
        scope = self._get_eval_scope(scope_vars)
        u_true = eval(self.ic_def['u'], {}, scope).reshape(-1, 1)
        return torch.mean((u_pred - u_true)**2)

    def _bc_loss(self):
        total_bc_loss = 0.0
        x_min, x_max = self.spatial_domain_def['x']
        t_bc = self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(self.num_bc, 1, device=self.device)
        
        for bc in self.bc_def:
            if bc['location'] == 'x_min':
                x_bc = torch.full_like(t_bc, x_min)
            elif bc['location'] == 'x_max':
                x_bc = torch.full_like(t_bc, x_max)
            
            xt_bc = torch.cat([x_bc, t_bc], dim=1)
            scope_vars = {'t': t_bc.squeeze()}
            scope = self._get_eval_scope(scope_vars)
            true_val = eval(str(bc['value']), {}, scope).reshape(-1, 1)
            
            if bc['type'] == 'Dirichlet':
                xt_bc_norm = self._normalize_input(xt_bc)
                u_pred = self.model(xt_bc_norm)
                loss = torch.mean((u_pred - true_val)**2)
            elif bc['type'] == 'Neumann':
                xt_bc_norm = self._normalize_input(xt_bc)
                xt_bc_norm.requires_grad_(True)
                u_pred = self.model(xt_bc_norm)
                grad_u = torch.autograd.grad(u_pred, xt_bc_norm, grad_outputs=torch.ones_like(u_pred), create_graph=True)[0]
                dudx_pred = (grad_u[:, 0] / self.x_std).reshape(-1, 1)
                loss = torch.mean((dudx_pred - true_val)**2)
            
            total_bc_loss += loss
        return total_bc_loss
    
    def _data_loss(self):
        if self.internal_data_points is None:
            return torch.tensor(0.0, device=self.device)
        
        t_data = self.internal_data_points[:, 0]
        x_data = self.internal_data_points[:, 1]
        u_true = self.internal_data_points[:, 2]
        
        xt_data = torch.stack([x_data, t_data], dim=1)
        xt_data_norm = self._normalize_input(xt_data)
        
        u_pred = self.model(xt_data_norm).squeeze()
        return torch.mean((u_pred - u_true)**2)

    def _generate_collocation_points(self, epoch):
        x_range = self.spatial_domain_def['x']
        
        if epoch < self.epochs // 4:
            x_collocation = x_range[0] + (x_range[1] - x_range[0]) * torch.rand(self.num_collocation, 1, device=self.device)
            t_collocation = self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(self.num_collocation, 1, device=self.device)
        else:
            num_uniform = self.num_collocation // 2
            num_random = self.num_collocation - num_uniform
            
            x_uniform = torch.linspace(x_range[0], x_range[1], int(np.sqrt(num_uniform)), device=self.device)
            t_uniform = torch.linspace(self.t_domain[0], self.t_domain[1], int(np.sqrt(num_uniform)), device=self.device)
            X_uniform, T_uniform = torch.meshgrid(x_uniform, t_uniform, indexing='ij')
            
            x_coll_uniform = X_uniform.flatten()[:num_uniform].unsqueeze(1)
            t_coll_uniform = T_uniform.flatten()[:num_uniform].unsqueeze(1)
            
            x_coll_random = x_range[0] + (x_range[1] - x_range[0]) * torch.rand(num_random, 1, device=self.device)
            t_coll_random = self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(num_random, 1, device=self.device)
            
            x_collocation = torch.cat([x_coll_uniform, x_coll_random], dim=0)
            t_collocation = torch.cat([t_coll_uniform, t_coll_random], dim=0)
        
        return torch.cat([x_collocation, t_collocation], dim=1)

    def train(self):
        print(f"--- Starting training for {self.problem_name} ---")
        start_time = time.time()
        self.model.train()
        
        best_loss = float('inf')
        patience_counter = 0
        max_patience = 5000
        
        for epoch in range(self.epochs):
            self.optimizer.zero_grad()
            
            xt_collocation = self._generate_collocation_points(epoch)
            
            loss_pde = self._pde_residual_loss(xt_collocation)
            loss_ic = self._ic_loss()
            loss_bc = self._bc_loss()
            loss_data = self._data_loss()
            
            total_loss = (self.loss_weights['pde_residual'] * loss_pde +
                          self.loss_weights['initial_condition'] * loss_ic +
                          self.loss_weights['boundary_condition'] * loss_bc +
                          self.loss_weights.get('data', 0.0) * loss_data)
            
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            if epoch % 100 == 0:
                self.scheduler.step(total_loss)
            
            if total_loss.item() < best_loss:
                best_loss = total_loss.item()
                patience_counter = 0
            else:
                patience_counter += 1
            
            if patience_counter > max_patience:
                print(f"Early stopping at epoch {epoch}")
                break

            if (epoch + 1) % 5000 == 0:
                log_msg = (f'Epoch [{epoch+1}/{self.epochs}], Loss: {total_loss.item():.4e}, '
                           f'PDE: {loss_pde.item():.4e}, IC: {loss_ic.item():.4e}, BC: {loss_bc.item():.4e}')
                if self.internal_data_points is not None:
                    log_msg += f', Data: {loss_data.item():.4e}'
                print(log_msg)
        
        elapsed_time = time.time() - start_time
        print(f"--- Training finished in {elapsed_time:.2f} seconds ---")

    def evaluate_and_plot_results(self):
        self.model.eval()
        os.makedirs("results", exist_ok=True)
        base_filename = f"results/{self.problem_name.replace(' ', '_').lower()}"
        
        x_range = self.spatial_domain_def['x']
        t_range = self.t_domain.cpu().numpy()
        
        x = torch.linspace(x_range[0], x_range[1], 201, device=self.device)
        t = torch.linspace(t_range[0], t_range[1], 101, device=self.device)
        X, T = torch.meshgrid(x, t, indexing='ij')
        
        xt_grid = torch.stack([X.flatten(), T.flatten()], dim=1)
        xt_grid_norm = self._normalize_input(xt_grid)
        
        with torch.no_grad():
            u_pinn = self.model(xt_grid_norm).cpu().numpy().reshape(X.shape)
        
        fig, ax = plt.subplots(1, 1, figsize=(10, 8))
        
        c = ax.pcolormesh(T.cpu(), X.cpu(), u_pinn, cmap='viridis', shading='gouraud')
        fig.colorbar(c, ax=ax)
        
        if self.internal_data_points is not None:
            data_np = self.internal_data_points.cpu().numpy()
            ax.scatter(data_np[:, 0], data_np[:, 1], s=100, c='red', ec='white', lw=2, zorder=3, label='Internal Sensor Data')
            ax.legend()

        ax.set_title('Enhanced PINN Solution with Internal Sensor Data', fontsize=14)
        ax.set_xlabel('Time (t)', fontsize=12)
        ax.set_ylabel('Space (x)', fontsize=12)
        plt.tight_layout()
        
        solution_filename = f"{base_filename}_enhanced_solution.pdf"
        plt.savefig(solution_filename, format='pdf', bbox_inches='tight', dpi=300)
        plt.close(fig)
        print(f"Enhanced solution plot with data points saved to {solution_filename}")

def main():
    parser = argparse.ArgumentParser(description="Enhanced PDE-PINN Solver")
    parser.add_argument(
        "config_file", type=str,
        help="Path to the JSON configuration file.",
        default="problem_config.json", nargs='?'
    )
    args = parser.parse_args()
    
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    
    solver = PINNSolver(config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()