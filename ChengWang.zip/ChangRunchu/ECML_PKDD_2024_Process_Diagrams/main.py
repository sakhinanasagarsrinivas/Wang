import argparse
from pathlib import Path
import yaml
import logging
from typing import Dict
import torch

from models.main_agent import MainAgent
from preprocessing.document_processor import DocumentProcessor
from evaluation.evaluator import Evaluator

def setup_logging(log_path: str) -> logging.Logger:
    """Setup logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def load_config(config_path: str) -> Dict:
    """Load configuration from YAML file."""
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def process_documents(config: Dict, logger: logging.Logger):
    """Process raw documents."""
    processor = DocumentProcessor(config_path=args.config)
    
    # Process PFDs
    pfd_dir = Path(config['paths']['raw_data']['pfds'])
    for pdf_path in pfd_dir.glob('*.pdf'):
        try:
            processed_data = processor.process_document(str(pdf_path))
            processor.save_processed_data(
                processed_data,
                config['paths']['processed_data']
            )
            logger.info(f"Processed PFD: {pdf_path.name}")
        except Exception as e:
            logger.error(f"Error processing {pdf_path.name}: {str(e)}")
            
    # Process P&IDs
    pid_dir = Path(config['paths']['raw_data']['pids'])
    for pdf_path in pid_dir.glob('*.pdf'):
        try:
            processed_data = processor.process_document(str(pdf_path))
            processor.save_processed_data(
                processed_data,
                config['paths']['processed_data']
            )
            logger.info(f"Processed P&ID: {pdf_path.name}")
        except Exception as e:
            logger.error(f"Error processing {pdf_path.name}: {str(e)}")

def evaluate_model(config: Dict, logger: logging.Logger):
    """Evaluate model performance."""
    evaluator = Evaluator(config_path=args.config)
    model = MainAgent(config_path=args.config)
    
    # Load test data
    test_data = load_test_data(config['paths']['processed_data'])
    logger.info(f"Loaded {len(test_data)} test samples")
    
    # Run evaluation
    metrics = evaluator.evaluate_model(
        model=model,
        test_data=test_data,
        output_dir=config['paths']['model_checkpoints'],
        batch_size=config['training']['batch_size']
    )
    
    logger.info("Evaluation complete")
    return metrics

def load_test_data(data_path: str) -> List[Dict]:
    """Load test dataset."""
    test_data = []
    data_path = Path(data_path)
    
    # Load processed documents
    for doc_dir in data_path.iterdir():
        if doc_dir.is_dir():
            # Load metadata
            with open(doc_dir / 'metadata.yaml', 'r') as f:
                metadata = yaml.safe_load(f)
                
            # Load ground truth data if available
            ground_truth_path = doc_dir / 'ground_truth.json'
            if ground_truth_path.exists():
                with open(ground_truth_path, 'r') as f:
                    ground_truth = json.load(f)
                    
                test_data.append({
                    'id': metadata['document_id'],
                    'metadata': metadata,
                    'ground_truth': ground_truth
                })
    
    return test_data

def run_ablation_study(config: Dict, logger: logging.Logger):
    """Run ablation studies."""
    evaluator = Evaluator(config_path=args.config)
    model = MainAgent(config_path=args.config)
    test_data = load_test_data(config['paths']['processed_data'])
    
    # Define ablation configurations
    ablation_configs = [
        {
            'name': 'no_instruction_tuning',
            'settings': {'use_instruction_tuning': False}
        },
        {
            'name': 'no_preference_tuning',
            'settings': {'use_preference_tuning': False}
        },
        {
            'name': 'no_iterative_correction',
            'settings': {'use_iterative_correction': False}
        },
        {
            'name': 'no_conditional_summary',
            'settings': {'use_conditional_summary': False}
        }
    ]
    
    # Run ablation study
    results = evaluator.evaluate_ablations(
        model=model,
        test_data=test_data,
        ablation_configs=ablation_configs,
        output_dir=str(Path(config['paths']['model_checkpoints']) / 'ablation_study')
    )
    
    logger.info("Ablation study complete")
    return results

def main(args):
    """Main execution function."""
    # Setup logging
    logger = setup_logging(args.log_file)
    logger.info("Starting process engineering diagram analysis system")
    
    # Load configuration
    config = load_config(args.config)
    
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Using device: {device}")
    
    try:
        if args.process_documents:
            logger.info("Starting document processing")
            process_documents(config, logger)
            
        if args.evaluate:
            logger.info("Starting model evaluation")
            metrics = evaluate_model(config, logger)
            logger.info(f"Evaluation metrics: {metrics}")
            
        if args.ablation_study:
            logger.info("Starting ablation study")
            ablation_results = run_ablation_study(config, logger)
            logger.info("Ablation study completed")
            
    except Exception as e:
        logger.error(f"Error in main execution: {str(e)}", exc_info=True)
        raise
        
    logger.info("Process completed successfully")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Process Engineering Diagram Analysis System'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        required=True,
        help='Path to configuration file'
    )
    
    parser.add_argument(
        '--log_file',
        type=str,
        default='execution.log',
        help='Path to log file'
    )
    
    parser.add_argument(
        '--process_documents',
        action='store_true',
        help='Process raw documents'
    )
    
    parser.add_argument(
        '--evaluate',
        action='store_true',
        help='Evaluate model performance'
    )
    
    parser.add_argument(
        '--ablation_study',
        action='store_true',
        help='Run ablation study'
    )
    
    parser.add_argument(
        '--output_dir',
        type=str,
        default='outputs',
        help='Output directory for results'
    )
    
    parser.add_argument(
        '--batch_size',
        type=int,
        default=32,
        help='Batch size for processing'
    )
    
    parser.add_argument(
        '--num_workers',
        type=int,
        default=4,
        help='Number of worker threads'
    )
    
    args = parser.parse_args()
    
    # Create output directory if it doesn't exist
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    
    main(args)