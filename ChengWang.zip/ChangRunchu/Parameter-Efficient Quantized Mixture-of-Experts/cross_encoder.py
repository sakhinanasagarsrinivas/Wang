# models/cross_encoder.py
import torch
import torch.nn as nn
from typing import Optional, Tuple

class CrossAttention(nn.Module):
    def __init__(self, dim: int, num_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, 
                query: torch.Tensor,
                key: torch.Tensor,
                value: torch.Tensor,
                mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        B, Nq, C = query.shape
        Nk = key.shape[1]
        
        # Project and reshape
        q = self.q_proj(query).reshape(B, Nq, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(key).reshape(B, Nk, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(value).reshape(B, Nk, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Compute attention scores
        attn = (q @ k.transpose(-2, -1)) * self.scale
        
        if mask is not None:
            attn = attn.masked_fill(mask == 0, float('-inf'))
        
        attn = attn.softmax(dim=-1)
        attn = self.dropout(attn)
        
        # Apply attention to values
        out = (attn @ v).transpose(1, 2).reshape(B, Nq, C)
        out = self.out_proj(out)
        
        return out

class CrossEncoderBlock(nn.Module):
    def __init__(self, 
                 dim: int,
                 num_heads: int = 8,
                 mlp_ratio: float = 4.0,
                 dropout: float = 0.1):
        super().__init__()
        
        # Cross-attention layers
        self.norm1_q = nn.LayerNorm(dim)
        self.norm1_kv = nn.LayerNorm(dim)
        self.cross_attn = CrossAttention(dim, num_heads, dropout)
        
        # Self-attention layers
        self.norm2 = nn.LayerNorm(dim)
        self.self_attn = CrossAttention(dim, num_heads, dropout)
        
        # MLP layers
        self.norm3 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, int(dim * mlp_ratio)),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(int(dim * mlp_ratio), dim),
            nn.Dropout(dropout)
        )
        
    def forward(self,
                query: torch.Tensor,
                key: torch.Tensor,
                value: torch.Tensor,
                mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        # Cross-attention
        q = self.norm1_q(query)
        kv = self.norm1_kv(key)
        x = query + self.cross_attn(q, kv, kv, mask)
        
        # Self-attention
        x = x + self.self_attn(self.norm2(x), self.norm2(x), self.norm2(x))
        
        # MLP
        x = x + self.mlp(self.norm3(x))
        
        return x

class CrossModalEncoder(nn.Module):
    def __init__(self,
                 dim: int = 768,
                 num_layers: int = 6,
                 num_heads: int = 8,
                 mlp_ratio: float = 4.0,
                 dropout: float = 0.1,
                 use_modality_tokens: bool = True):
        super().__init__()
        
        # Modality-specific tokens
        self.use_modality_tokens = use_modality_tokens
        if use_modality_tokens:
            self.vision_token = nn.Parameter(torch.zeros(1, 1, dim))
            self.text_token = nn.Parameter(torch.zeros(1, 1, dim))
            nn.init.normal_(self.vision_token, std=0.02)
            nn.init.normal_(self.text_token, std=0.02)
        
        # Cross-encoder layers
        self.layers = nn.ModuleList([
            CrossEncoderBlock(
                dim=dim,
                num_heads=num_heads,
                mlp_ratio=mlp_ratio,
                dropout=dropout
            )
            for _ in range(num_layers)
        ])
        
        # Output normalization
        self.norm = nn.LayerNorm(dim)
        
        # Fusion layer
        self.fusion = nn.Sequential(
            nn.Linear(dim * 2, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim)
        )
        
    def add_modality_tokens(self, 
                           vision_features: torch.Tensor, 
                           text_features: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Add modality-specific tokens to the features."""
        B = vision_features.shape[0]
        
        if self.use_modality_tokens:
            vision_token = self.vision_token.expand(B, -1, -1)
            text_token = self.text_token.expand(B, -1, -1)
            
            vision_features = torch.cat([vision_token, vision_features], dim=1)
            text_features = torch.cat([text_token, text_features], dim=1)
            
        return vision_features, text_features
    
    def create_attention_mask(self,
                            vision_mask: Optional[torch.Tensor] = None,
                            text_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """Create cross-attention mask."""
        B = vision_mask.shape[0] if vision_mask is not None else text_mask.shape[0]
        
        if vision_mask is None:
            vision_mask = torch.ones(B, vision_features.shape[1], device=text_mask.device)
        if text_mask is None:
            text_mask = torch.ones(B, text_features.shape[1], device=vision_mask.device)
            
        if self.use_modality_tokens:
            # Add mask values for modality tokens
            vision_token_mask = torch.ones(B, 1, device=vision_mask.device)
            text_token_mask = torch.ones(B, 1, device=text_mask.device)
            
            vision_mask = torch.cat([vision_token_mask, vision_mask], dim=1)
            text_mask = torch.cat([text_token_mask, text_mask], dim=1)
            
        # Create cross-attention mask
        mask = torch.einsum('bm,bn->bmn', vision_mask, text_mask)
        
        return mask
    
    def forward(self,
                vision_features: torch.Tensor,
                text_features: torch.Tensor,
                vision_mask: Optional[torch.Tensor] = None,
                text_mask: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of the cross-modal encoder.
        
        Args:
            vision_features: Tensor of shape (batch_size, num_patches, dim)
            text_features: Tensor of shape (batch_size, seq_len, dim)
            vision_mask: Optional tensor of shape (batch_size, num_patches)
            text_mask: Optional tensor of shape (batch_size, seq_len)
            
        Returns:
            tuple: (fused_features, cross_attention_weights)
                - fused_features: Tensor of shape (batch_size, dim)
                - cross_attention_weights: Optional attention weights for visualization
        """
        
        # Add modality tokens
        vision_features, text_features = self.add_modality_tokens(vision_features, text_features)
        
        # Create attention mask
        attention_mask = self.create_attention_mask(vision_mask, text_mask)
        
        # Process through cross-encoder layers
        cross_attention_weights = []
        
        # Vision -> Text
        for layer in self.layers:
            vision_features = layer(vision_features, text_features, text_features, attention_mask)
            if isinstance(layer.cross_attn, CrossAttention):
                cross_attention_weights.append(layer.cross_attn.attn.detach())
        
        # Text -> Vision
        for layer in self.layers:
            text_features = layer(text_features, vision_features, vision_features, attention_mask.transpose(-2, -1))
            
        # Apply final normalization
        vision_features = self.norm(vision_features)
        text_features = self.norm(text_features)
        
        # Extract modality tokens if used
        if self.use_modality_tokens:
            vision_features = vision_features[:, 0]  # Use vision modality token
            text_features = text_features[:, 0]     # Use text modality token
        else:
            # Use mean pooling
            vision_features = vision_features.mean(dim=1)
            text_features = text_features.mean(dim=1)
            
        # Fuse modalities
        fused_features = self.fusion(torch.cat([vision_features, text_features], dim=-1))
        
        return fused_features, torch.stack(cross_attention_weights) if cross_attention_weights else None
    
    def get_attention_maps(self) -> List[torch.Tensor]:
        """Get attention maps from all layers for visualization."""
        attention_maps = []
        for layer in self.layers:
            if hasattr(layer.cross_attn, 'attn'):
                attention_maps.append(layer.cross_attn.attn.detach())
        return attention_maps