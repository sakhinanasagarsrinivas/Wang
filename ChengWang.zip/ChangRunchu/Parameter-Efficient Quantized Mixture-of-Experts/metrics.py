# utils/metrics.py
from typing import List, Dict, Optional, Union
import torch
import numpy as np
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.translate.meteor_score import meteor_score
from rouge_score import rouge_scorer

class Metrics:
    def __init__(self):
        self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
        self.smooth = SmoothingFunction()
    
    def calculate_bleu(self, reference: str, hypothesis: str) -> Dict[str, float]:
        """Calculate BLEU scores."""
        reference_tokens = reference.split()
        hypothesis_tokens = hypothesis.split()
        
        bleu_2 = sentence_bleu([reference_tokens], hypothesis_tokens, 
                             weights=(0.5, 0.5),
                             smoothing_function=self.smooth.method1)
        bleu_4 = sentence_bleu([reference_tokens], hypothesis_tokens,
                             weights=(0.25, 0.25, 0.25, 0.25),
                             smoothing_function=self.smooth.method1)
        
        return {
            'bleu-2': bleu_2,
            'bleu-4': bleu_4
        }
    
    def calculate_rouge(self, reference: str, hypothesis: str) -> Dict[str, float]:
        """Calculate ROUGE scores."""
        scores = self.rouge_scorer.score(reference, hypothesis)
        return {
            'rouge-1': scores['rouge1'].fmeasure,
            'rouge-2': scores['rouge2'].fmeasure,
            'rouge-l': scores['rougeL'].fmeasure
        }
    
    def calculate_meteor(self, reference: str, hypothesis: str) -> float:
        """Calculate METEOR score."""
        return meteor_score([reference.split()], hypothesis.split())
    
    def calculate_all_metrics(self, references: List[str], hypotheses: List[str]) -> Dict[str, float]:
        """Calculate all metrics for a batch of predictions."""
        metrics = {
            'bleu-2': [],
            'bleu-4': [],
            'rouge-1': [],
            'rouge-2': [],
            'rouge-l': [],
            'meteor': []
        }
        
        for ref, hyp in zip(references, hypotheses):
            bleu_scores = self.calculate_bleu(ref, hyp)
            rouge_scores = self.calculate_rouge(ref, hyp)
            meteor = self.calculate_meteor(ref, hyp)
            
            metrics['bleu-2'].append(bleu_scores['bleu-2'])
            metrics['bleu-4'].append(bleu_scores['bleu-4'])
            metrics['rouge-1'].append(rouge_scores['rouge-1'])
            metrics['rouge-2'].append(rouge_scores['rouge-2'])
            metrics['rouge-l'].append(rouge_scores['rouge-l'])
            metrics['meteor'].append(meteor)
        
        # Calculate mean scores
        return {k: np.mean(v) for k, v in metrics.items()}

class ClassificationMetrics:
    @staticmethod
    def accuracy(preds: torch.Tensor, labels: torch.Tensor) -> float:
        """Calculate accuracy score."""
        return (preds.argmax(dim=-1) == labels).float().mean().item()
    
    @staticmethod
    def precision_recall_f1(preds: torch.Tensor, labels: torch.Tensor, 
                          average: str = 'macro') -> Dict[str, float]:
        """Calculate precision, recall, and F1 scores."""
        preds = preds.argmax(dim=-1).cpu().numpy()
        labels = labels.cpu().numpy()
        
        from sklearn.metrics import precision_recall_fscore_support
        precision, recall, f1, _ = precision_recall_fscore_support(
            labels, preds, average=average
        )
        
        return {
            'precision': precision,
            'recall': recall,
            'f1': f1
        }
    
    @staticmethod
    def confusion_matrix(preds: torch.Tensor, labels: torch.Tensor, 
                        num_classes: int) -> torch.Tensor:
        """Calculate confusion matrix."""
        preds = preds.argmax(dim=-1)
        confusion = torch.zeros(num_classes, num_classes)
        
        for p, l in zip(preds, labels):
            confusion[l][p] += 1
            
        return confusion

def compute_perplexity(loss: torch.Tensor) -> float:
    """Compute perplexity from loss."""
    return torch.exp(loss).item()