import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer
import openai

class LLMModule(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.tokenizer = AutoTokenizer.from_pretrained(config.deberta_model)
        self.language_model = AutoModel.from_pretrained(config.deberta_model)
        self.attention_pool = nn.Linear(self.language_model.config.hidden_size, 1)
        
        # Set up GPT-4 API
        openai.api_key = config.gpt4_api_key
        
    def generate_description(self, category):
        """Generate technical description using GPT-4."""
        prompt = self._create_cot_prompt(category)
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a materials science expert."},
                    {"role": "user", "content": prompt}
                ]
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating description: {e}")
            return ""
        
    def _create_cot_prompt(self, category):
        """Create Chain-of-Thought prompt for GPT-4."""
        return f"""
        Please provide a detailed technical description of {category} nanomaterials.
        Consider the following aspects:
        1. Structure and morphology
        2. Synthesis methods
        3. Physical and chemical properties
        4. Applications
        5. Characterization techniques
        
        Explain each aspect in detail, focusing on the scientific and technical aspects.
        """
        
    def process_text(self, text):
        """Process text through DeBERTa and get embeddings."""
        # Tokenize and encode text
        inputs = self.tokenizer(
            text,
            max_length=self.config.max_text_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        ).to(self.config.device)
        
        # Get model outputs
        outputs = self.language_model(**inputs)
        hidden_states = outputs.last_hidden_state
        
        # Apply attention pooling
        attention_weights = F.softmax(self.attention_pool(hidden_states), dim=1)
        text_embedding = torch.sum(attention_weights * hidden_states, dim=1)
        
        return text_embedding
    
    def forward(self, categories):
        """Forward pass for a batch of categories."""
        text_embeddings = []
        
        for category in categories:
            # Generate description using GPT-4
            description = self.generate_description(category)
            # Process through DeBERTa
            embedding = self.process_text(description)
            text_embeddings.append(embedding)
            
        return torch.stack(text_embeddings)