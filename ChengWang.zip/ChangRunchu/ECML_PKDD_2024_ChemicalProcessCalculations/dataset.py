# rait_framework/datasets/base_dataset.py
import math
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Callable
from pathlib import Path

import pandas as pd
from datasets import Dataset, DatasetDict

class BaseRAITDataset(ABC):
    """
    Abstract base class for RAIT framework datasets with advanced splitting and filtering capabilities
    """
    def __init__(self, 
                 data_path: Optional[str] = None, 
                 domain: Optional[str] = None,
                 random_seed: int = 42):
        """
        Initialize base dataset with advanced configuration
        
        Args:
            data_path (str, optional): Path to custom dataset
            domain (str, optional): Dataset domain
            random_seed (int): Seed for reproducible splits
        """
        # Logging configuration
        self.logger = logging.getLogger(self.__class__.__name__)
        logging.basicConfig(level=logging.INFO)
        
        # Dataset properties
        self.data: List[Dict[str, Any]] = []
        self.domain = domain
        self.random_seed = random_seed
        
        # Load dataset
        if data_path:
            self.load_custom_dataset(data_path)
        else:
            self._ensure_dataset_exists()
    
    @abstractmethod
    def _generate_synthetic_dataset(self):
        """
        Abstract method to generate synthetic dataset
        Must be implemented by subclasses
        """
        pass
    
    def _ensure_dataset_exists(self):
        """
        Ensure dataset exists, generate if not present
        """
        default_path = self._get_default_dataset_path()
        
        if not default_path.exists():
            self.logger.info(f"Synthetic dataset not found. Generating...")
            self._generate_synthetic_dataset()
        
        self.load_custom_dataset(str(default_path))
    
    @abstractmethod
    def _get_default_dataset_path(self) -> Path:
        """
        Abstract method to get default dataset path
        Must be implemented by subclasses
        
        Returns:
            Path: Path to default dataset
        """
        pass
    
    def load_custom_dataset(self, data_path: str):
        """
        Load dataset from CSV or JSON file with enhanced validation
        
        Args:
            data_path (str): Path to dataset file
        """
        try:
            if data_path.endswith('.csv'):
                df = pd.read_csv(data_path)
            elif data_path.endswith('.json'):
                df = pd.read_json(data_path)
            else:
                raise ValueError("Unsupported file format. Use CSV or JSON.")
            
            # Validate dataset structure
            self._validate_dataset_structure(df)
            
            # Convert to list of dictionaries
            self.data = df.to_dict('records')
            
            self.logger.info(f"Loaded dataset from {data_path} with {len(self.data)} samples")
        
        except Exception as e:
            self.logger.error(f"Error loading dataset: {e}")
            raise
    
    def _validate_dataset_structure(self, df: pd.DataFrame):
        """
        Validate dataset structure
        
        Args:
            df (pd.DataFrame): DataFrame to validate
        
        Raises:
            ValueError: If dataset does not meet required structure
        """
        required_columns = [
            'instruction', 
            'input', 
            'output', 
            'domain', 
            'complexity'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
    
    def to_huggingface_dataset(self) -> Dataset:
        """
        Convert dataset to Hugging Face Dataset
        
        Returns:
            Dataset: Hugging Face compatible dataset
        """
        return Dataset.from_list(self.data)
    
    def split_dataset(self, 
                      train_ratio: float = 0.7, 
                      val_ratio: float = 0.15, 
                      test_ratio: float = 0.15,
                      stratify_by: Optional[str] = None) -> Dict[str, Dataset]:
        """
        Split dataset into train, validation, and test sets with advanced options
        
        Args:
            train_ratio (float): Ratio of training data
            val_ratio (float): Ratio of validation data
            test_ratio (float): Ratio of test data
            stratify_by (str, optional): Column to use for stratified splitting
        
        Returns:
            Dict[str, Dataset]: Dictionary of split datasets
        
        Raises:
            ValueError: If ratios do not sum to 1
        """
        # Validate split ratios
        if not math.isclose(train_ratio + val_ratio + test_ratio, 1.0):
            raise ValueError("Dataset split ratios must sum to 1.0")
        
        # Convert to pandas for advanced splitting
        df = pd.DataFrame(self.data)
        
        # Stratified splitting if requested
        if stratify_by and stratify_by in df.columns:
            from sklearn.model_selection import train_test_split
            
            # Initial train+val and test split
            train_val_df, test_df = train_test_split(
                df, 
                test_size=test_ratio, 
                stratify=df[stratify_by],
                random_state=self.random_seed
            )
            
            # Split train+val into train and validation
            train_df, val_df = train_test_split(
                train_val_df, 
                test_size=val_ratio / (train_ratio + val_ratio),
                stratify=train_val_df[stratify_by],
                random_state=self.random_seed
            )
        else:
            # Simple sequential splitting
            total_samples = len(self.data)
            train_end = int(total_samples * train_ratio)
            val_end = train_end + int(total_samples * val_ratio)
            
            # Convert to DataFrames
            train_df = df.iloc[:train_end]
            val_df = df.iloc[train_end:val_end]
            test_df = df.iloc[val_end:]
        
        # Convert back to Hugging Face Datasets
        return {
            'train': Dataset.from_pandas(train_df),
            'validation': Dataset.from_pandas(val_df),
            'test': Dataset.from_pandas(test_df)
        }
    
    def filter_dataset(self, 
                       filter_func: Optional[Callable] = None, 
                       domain: Optional[str] = None, 
                       complexity: Optional[str] = None) -> 'BaseRAITDataset':
        """
        Advanced dataset filtering with multiple criteria
        
        Args:
            filter_func (callable, optional): Custom filter function
            domain (str, optional): Filter by specific domain
            complexity (str, optional): Filter by complexity level
        
        Returns:
            BaseRAITDataset: Filtered dataset
        """
        filtered_data = self.data.copy()
        
        # Domain filtering
        if domain:
            filtered_data = [
                item for item in filtered_data 
                if item.get('domain', '').lower() == domain.lower()
            ]
        
        # Complexity filtering
        if complexity:
            filtered_data = [
                item for item in filtered_data
                if item.get('complexity', '').lower() == complexity.lower()
            ]
        
        # Custom filter function
        if filter_func:
            filtered_data = [
                item for item in filtered_data
                if filter_func(item)
            ]
        
        # Create a new instance with filtered data
        filtered_dataset = self.__class__()
        filtered_dataset.data = filtered_data
        
        return filtered_dataset

# Specific dataset implementations
class MathCompDataset(BaseRAITDataset):
    """
    Dataset for Mathematical Computation Problems
    """
    def __init__(self, data_path: Optional[str] = None):
        """
        Initialize Mathematical Computation Dataset
        
        Args:
            data_path (str, optional): Path to custom dataset
        """
        super().__init__(data_path, domain='mathematical_computation')
    
    def _get_default_dataset_path(self) -> Path:
        """
        Get default path for MathComp synthetic dataset
        
        Returns:
            Path: Path to default dataset
        """
        return Path(__file__).parent / 'mathcomp_synthetic_dataset.csv'
    
    def _generate_synthetic_dataset(self):
        """
        Generate synthetic dataset for mathematical computation
        """
        from .synthetic_data_generator import SyntheticDataGenerator
        
        # Create generator
        generator = SyntheticDataGenerator()
        
        # Async generation function
        async def generate():
            # Generate synthetic pairs for mathematical computation
            synthetic_pairs = await generator.generate_synthetic_qa_pairs(
                domain='mathematical_computation', 
                num_samples=7500,
                complexity_levels=['easy', 'medium', 'hard']
            )
            
            # Save generated dataset
            generator.save_synthetic_dataset(
                synthetic_pairs, 
                self._get_default_dataset_path()
            )
        
        # Run async generation
        import asyncio
        asyncio.run(generate())

class ChemProcDataset(BaseRAITDataset):
    """
    Dataset for Chemical Process Engineering Problems
    """
    def __init__(self, data_path: Optional[str] = None):
        """
        Initialize Chemical Process Engineering Dataset
        
        Args:
            data_path (str, optional): Path to custom dataset
        """
        super().__init__(data_path, domain='chemical_engineering')
    
    def _get_default_dataset_path(self) -> Path:
        """
        Get default path for ChemProc synthetic dataset
        
        Returns:
            Path: Path to default dataset
        """
        return Path(__file__).parent / 'chemproc_synthetic_dataset.csv'
    
    def _generate_synthetic_dataset(self):
        """
        Generate synthetic dataset for chemical process engineering
        """
        from .synthetic_data_generator import SyntheticDataGenerator
        
        # Create generator
        generator = SyntheticDataGenerator()
        
        # Async generation function
        async def generate():
            # Generate synthetic pairs for chemical engineering
            synthetic_pairs = await generator.generate_synthetic_qa_pairs(
                domain='chemical_engineering', 
                num_samples=5000,
                complexity_levels=['easy', 'medium', 'hard']
            )
            
            # Save generated dataset
            generator.save_synthetic_dataset(
                synthetic_pairs, 
                self._get_default_dataset_path()
            )
        
        # Run async generation
        import asyncio
        asyncio.run(generate())