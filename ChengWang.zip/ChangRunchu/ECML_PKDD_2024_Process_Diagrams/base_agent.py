from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from langchain.llms import BaseLLM
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.schema import Document
import yaml

class BaseAgent(ABC):
    def __init__(self, config_path: str, agent_type: str):
        """
        Initialize base agent with configuration.
        
        Args:
            config_path: Path to configuration file
            agent_type: Type of agent (main_agent, sub_agent, or critique_agent)
        """
        self.config = self._load_config(config_path)
        self.agent_type = agent_type
        self.model_config = self.config['models'][agent_type]
        self.vector_store = self._initialize_vector_store()
        self.llm = self._initialize_llm()
    
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def _initialize_vector_store(self) -> Chroma:
        """Initialize vector store for document retrieval."""
        embeddings = HuggingFaceEmbeddings(
            model_name=self.config['vector_store']['embedding_model']
        )
        
        return Chroma(
            collection_name=self.config['vector_store']['collection_name'],
            embedding_function=embeddings,
            persist_directory=self.config['paths']['processed_data']
        )
    
    @abstractmethod
    def _initialize_llm(self) -> BaseLLM:
        """Initialize language model specific to agent type."""
        pass
    
    @abstractmethod
    def process_query(self, query: str, context: Optional[Dict] = None) -> Dict:
        """Process a query with optional context."""
        pass
    
    def retrieve_relevant_documents(self, query: str, k: int = 5) -> List[Document]:
        """
        Retrieve relevant documents from vector store.
        
        Args:
            query: Query string
            k: Number of documents to retrieve
            
        Returns:
            List of relevant documents
        """
        return self.vector_store.similarity_search(query, k=k)
    
    def update_memory(self, query: str, response: Dict):
        """
        Update agent's memory with query-response pair.
        
        Args:
            query: Original query
            response: Generated response
        """
        # Implementation depends on specific memory requirements
        pass
    
    def _format_response(self, response_data: Any) -> Dict:
        """
        Format response data into standardized structure.
        
        Args:
            response_data: Raw response data
            
        Returns:
            Formatted response dictionary
        """
        return {
            'agent_type': self.agent_type,
            'response': response_data,
            'metadata': {
                'model': self.model_config['model_name'],
                'timestamp': self._get_timestamp()
            }
        }
    
    def _get_timestamp(self) -> str:
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now().isoformat()