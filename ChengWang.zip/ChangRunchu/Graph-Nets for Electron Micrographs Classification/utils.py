import os
import json
import torch
import numpy as np
import matplotlib.pyplot as plt
import logging
from sklearn.metrics import (
    accuracy_score, 
    precision_recall_fscore_support, 
    confusion_matrix, 
    classification_report
)

class ResultLogger:
    """
    Comprehensive result logging and visualization utility
    Tracks training metrics and saves results
    """
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Initialize metrics history
        self.history = {
            'train_loss': [], 
            'val_loss': [],
            'train_accuracy': [], 
            'val_accuracy': []
        }
    
    def log_epoch(self, epoch, train_metrics, val_metrics):
        """
        Log metrics for a single training epoch
        
        Args:
            epoch (int): Current training epoch
            train_metrics (dict): Training metrics
            val_metrics (dict): Validation metrics
        """
        self.history['train_loss'].append(train_metrics['loss'])
        self.history['val_loss'].append(val_metrics['loss'])
        self.history['train_accuracy'].append(train_metrics['accuracy'])
        self.history['val_accuracy'].append(val_metrics['accuracy'])
        
        self.logger.info(
            f"Epoch {epoch}: "
            f"Train Loss {train_metrics['loss']:.4f}, "
            f"Train Acc {train_metrics['accuracy']:.2f}% | "
            f"Val Loss {val_metrics['loss']:.4f}, "
            f"Val Acc {val_metrics['accuracy']:.2f}%"
        )
    
    def plot_training_curves(self):
        """
        Generate and save training curves plot
        Visualizes loss and accuracy progression
        """
        plt.figure(figsize=(12, 4))
        
        # Loss subplot
        plt.subplot(1, 2, 1)
        plt.plot(self.history['train_loss'], label='Train Loss')
        plt.plot(self.history['val_loss'], label='Val Loss')
        plt.title('Loss Curves')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.legend()
        
        # Accuracy subplot
        plt.subplot(1, 2, 2)
        plt.plot(self.history['train_accuracy'], label='Train Accuracy')
        plt.plot(self.history['val_accuracy'], label='Val Accuracy')
        plt.title('Accuracy Curves')
        plt.xlabel('Epochs')
        plt.ylabel('Accuracy (%)')
        plt.legend()
        
        plt.tight_layout()
        plot_path = os.path.join(self.config.results_dir, 'training_curves.png')
        plt.savefig(plot_path)
        self.logger.info(f"Training curves saved to {plot_path}")
    
    def save_metrics(self, metrics):
        """
        Save final metrics to a JSON file
        
        Args:
            metrics (dict): Final evaluation metrics
        """
        metrics_path = os.path.join(self.config.results_dir, 'final_metrics.json')
        with open(metrics_path, 'w') as f:
            json.dump(metrics, f, indent=4)
        
        self.logger.info(f"Final metrics saved to {metrics_path}")

def compute_metrics(y_true, y_pred):
    """
    Compute comprehensive classification metrics
    
    Args:
        y_true (array-like): True labels
        y_pred (array-like): Predicted labels
    
    Returns:
        dict: Comprehensive classification metrics
    """
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_recall_fscore_support(y_true, y_pred, average='weighted')[0],
        'recall': precision_recall_fscore_support(y_true, y_pred, average='weighted')[1],
        'f1_score': precision_recall_fscore_support(y_true, y_pred, average='weighted')[2],
        'confusion_matrix': confusion_matrix(y_true, y_pred).tolist()
    }
    
    # Detailed classification report
    metrics['classification_report'] = classification_report(y_true, y_pred)
    
    return metrics

def train_epoch(model, dataloader, criterion, optimizer, device, logger=None):
    """
    Train the model for one epoch
    
    Args:
        model (nn.Module): Neural network model
        dataloader (DataLoader): Training data loader
        criterion (nn.Module): Loss function
        optimizer (torch.optim.Optimizer): Optimization algorithm
        device (torch.device): Device to run training
        logger (logging.Logger, optional): Logger for tracking training
    
    Returns:
        dict: Training metrics for the epoch
    """
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    
    for batch in dataloader:
        # Move batch to device
        batch = {k: v.to(device) for k, v in batch.items()}
        labels = batch['label']
        
        # Zero gradients
        optimizer.zero_grad()
        
        # Forward pass
        outputs = model(batch)
        loss = criterion(outputs, labels)
        
        # Backward pass and optimization
        loss.backward()
        optimizer.step()
        
        # Metrics tracking
        total_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
    
    # Compute epoch metrics
    epoch_metrics = {
        'loss': total_loss / len(dataloader),
        'accuracy': 100 * correct / total
    }
    
    if logger:
        logger.info(
            f"Training Metrics: "
            f"Loss {epoch_metrics['loss']:.4f}, "
            f"Accuracy {epoch_metrics['accuracy']:.2f}%"
        )
    
    return epoch_metrics

def validate(model, dataloader, criterion, device, logger=None):
    """
    Validate the model on a given dataset
    
    Args:
        model (nn.Module): Neural network model
        dataloader (DataLoader): Validation data loader
        criterion (nn.Module): Loss function
        device (torch.device): Device to run validation
        logger (logging.Logger, optional): Logger for tracking validation
    
    Returns:
        dict: Validation metrics
    """
    model.eval()
    total_loss = 0
    correct = 0
    total = 0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for batch in dataloader:
            # Move batch to device
            batch = {k: v.to(device) for k, v in batch.items()}
            labels = batch['label']
            
            # Forward pass
            outputs = model(batch)
            loss = criterion(outputs, labels)
            
            # Metrics tracking
            total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            # Collect predictions and labels
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    # Compute validation metrics
    metrics = {
        'loss': total_loss / len(dataloader),
        'accuracy': 100 * correct / total,
        'predictions': all_preds,
        'ground_truth': all_labels
    }
    
    if logger:
        logger.info(
            f"Validation Metrics: "
            f"Loss {metrics['loss']:.4f}, "
            f"Accuracy {metrics['accuracy']:.2f}%"
        )
    
    return metrics