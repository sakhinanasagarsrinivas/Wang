import os
import cv2
import json
import torch
import numpy as np
from torch.utils.data import Dataset
from typing import List, Dict, Optional
from .preprocessing import ImagePreprocessor, TextPreprocessor

class SEMDataset(Dataset):
    """Dataset class for SEM images."""
    
    def __init__(
        self,
        data_dir: str,
        split: str = "train",
        transform: Optional[ImagePreprocessor] = None,
        text_processor: Optional[TextPreprocessor] = None
    ):
        self.data_dir = data_dir
        self.split = split
        self.transform = transform or ImagePreprocessor()
        self.text_processor = text_processor or TextPreprocessor()
        
        # Load dataset annotations
        self.annotations = self._load_annotations()
        
    def _load_annotations(self) -> List[Dict]:
        """Load dataset annotations from JSON file."""
        ann_file = os.path.join(self.data_dir, f"{self.split}_annotations.json")
        with open(ann_file, "r") as f:
            annotations = json.load(f)
        return annotations
    
    def __len__(self) -> int:
        return len(self.annotations)
    
    def __getitem__(self, idx: int) -> Dict:
        """Get a single item from dataset."""
        ann = self.annotations[idx]
        
        # Load image
        img_path = os.path.join(self.data_dir, ann["image_path"])
        image = cv2.imread(img_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Process image
        if self.transform:
            image = self.transform.preprocess_image(image)
            
        # Process text
        question = ann["question"]
        answer = ann["answer"]
        
        if self.text_processor:
            q_input_ids, q_attention_mask = self.text_processor.preprocess_text(question)
            a_input_ids, a_attention_mask = self.text_processor.preprocess_text(answer)
        
        return {
            "image": image,
            "question_input_ids": q_input_ids,
            "question_attention_mask": q_attention_mask,
            "answer_input_ids": a_input_ids,
            "answer_attention_mask": a_attention_mask,
            "metadata": {
                "image_id": ann["image_id"],
                "category": ann["category"]
            }
        }

class DatasetFactory:
    """Factory class to create different types of datasets."""
    
    @staticmethod
    def create_dataset(
        dataset_name: str,
        data_dir: str,
        split: str = "train",
        transform: Optional[ImagePreprocessor] = None,
        text_processor: Optional[TextPreprocessor] = None
    ) -> Dataset:
        """Create dataset based on name."""
        if dataset_name.lower() == "sem":
            return SEMDataset(data_dir, split, transform, text_processor)
        elif dataset_name.lower() == "neu-sdd":
            return NEUSDDDataset(data_dir, split, transform, text_processor)
        elif dataset_name.lower() == "cmi":
            return CMIDataset(data_dir, split, transform, text_processor)
        elif dataset_name.lower() == "kth-tips":
            return KTHTIPSDataset(data_dir, split, transform, text_processor)
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")

# Additional dataset classes can be implemented similarly
class NEUSDDDataset(SEMDataset):
    """Dataset class for NEU-SDD dataset."""
    pass

class CMIDataset(SEMDataset):
    """Dataset class for CMI dataset."""
    pass

class KTHTIPSDataset(SEMDataset):
    """Dataset class for KTH-TIPS dataset."""
    pass