# main.py
import argparse
import torch
import logging
from pathlib import Path
from torch.utils.data import DataLoader

from config.config import Config
from models.vision_encoder import VisionEncoder
from models.text_encoder import TextEncoder
from models.cross_encoder import CrossModalEncoder
from models.decoder import Decoder
from models.dya_mopes import DyAMoQPEs, DyAMoQPEsConfig
from models.dya_mopes_manager import DyAMoQPEsManager
from data.datasets import DatasetFactory
from train.trainer import Trainer
from train.optimizer import create_optimizer_and_scheduler
from evaluate.evaluator import Evaluator
from utils.helpers import set_seed, setup_logging

def parse_args():
    parser = argparse.ArgumentParser(description='Train and evaluate sLAVA model')
    
    # General settings
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--device', type=str, default='cuda', help='Device to use')
    parser.add_argument('--num_workers', type=int, default=4, help='Number of data loading workers')
    
    # Data settings
    parser.add_argument('--data_dir', type=str, required=True, help='Data directory')
    parser.add_argument('--dataset', type=str, default='sem', help='Dataset name')
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size')
    
    # Model settings
    parser.add_argument('--vision_dim', type=int, default=768, help='Vision encoder dimension')
    parser.add_argument('--text_dim', type=int, default=768, help='Text encoder dimension')
    parser.add_argument('--num_heads', type=int, default=12, help='Number of attention heads')
    parser.add_argument('--num_layers', type=int, default=12, help='Number of layers')
    
    # Training settings
    parser.add_argument('--num_epochs', type=int, default=50, help='Number of epochs')
    parser.add_argument('--learning_rate', type=float, default=1e-4, help='Learning rate')
    parser.add_argument('--weight_decay', type=float, default=0.01, help='Weight decay')
    parser.add_argument('--warmup_steps', type=int, default=1000, help='Number of warmup steps')
    parser.add_argument('--save_dir', type=str, default='checkpoints', help='Directory to save checkpoints')
    parser.add_argument('--save_freq', type=int, default=1, help='Checkpoint save frequency')
    parser.add_argument('--eval_freq', type=int, default=1, help='Evaluation frequency')
    
    # DyA-MoQPEs settings
    parser.add_argument('--num_experts', type=int, default=8, help='Number of experts')
    parser.add_argument('--rank_min', type=int, default=4, help='Minimum rank')
    parser.add_argument('--rank_max', type=int, default=16, help='Maximum rank')
    
    return parser.parse_args()

def main():
    # Parse arguments
    args = parse_args()
    
    # Setup
    set_seed(args.seed)
    logger = setup_logging(args.save_dir, 'slava')
    logger.info(f'Arguments: {args}')
    
    # Create datasets and dataloaders
    dataset_factory = DatasetFactory()
    train_dataset = dataset_factory.create_dataset(args.dataset, args.data_dir, 'train')
    val_dataset = dataset_factory.create_dataset(args.dataset, args.data_dir, 'val')
    test_dataset = dataset_factory.create_dataset(args.dataset, args.data_dir, 'test')
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )
    
    # Create model components
    vision_encoder = VisionEncoder(
        hidden_size=args.vision_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers
    )
    
    text_encoder = TextEncoder(
        hidden_size=args.text_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers
    )
    
    cross_encoder = CrossModalEncoder(
        dim=args.vision_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers
    )
    
    decoder = Decoder(
        vocab_size=train_dataset.get_vocab_size(),
        hidden_size=args.vision_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers
    )
    
    # Create DyA-MoQPEs configuration and manager
    dya_mopes_config = DyAMoQPEsConfig(
        num_experts=args.num_experts,
        rank_min=args.rank_min,
        rank_max=args.rank_max
    )
    
    dya_mopes_manager = DyAMoQPEsManager(
        vision_encoder,
        dya_mopes_config
    )
    
    # Apply DyA-MoQPEs to linear layers
    dya_mopes_manager.apply_to_model(['qkv', 'fc'])
    
    # Create optimizer and scheduler
    optimizer_config = {
        'learning_rate': args.learning_rate,
        'weight_decay': args.weight_decay
    }
    
    scheduler_config = {
        'num_warmup_steps': args.warmup_steps,
        'num_training_steps': len(train_loader) * args.num_epochs
    }
    
    optimizer, scheduler = create_optimizer_and_scheduler(
        model=vision_encoder,
        optimizer_config=optimizer_config,
        scheduler_config=scheduler_config
    )
    
    # Create trainer and evaluator
    trainer = Trainer(
        model=vision_encoder,
        optimizer=optimizer,
        scheduler=scheduler,
        device=args.device,
        save_dir=args.save_dir,
        save_freq=args.save_freq,
        eval_freq=args.eval_freq,
        logger=logger
    )
    
    evaluator = Evaluator(
        model=vision_encoder,
        device=args.device,
        logger=logger
    )
    
    # Training loop
    logger.info("Starting training...")
    history = trainer.train(train_loader, val_loader, args.num_epochs)
    
    # Final evaluation
    logger.info("Evaluating on test set...")
    test_results = evaluator.evaluate(test_loader)
    
    # Save final results
    logger.info("Training completed.")
    logger.info(f"Test results: {test_results}")

if __name__ == "__main__":
    main()