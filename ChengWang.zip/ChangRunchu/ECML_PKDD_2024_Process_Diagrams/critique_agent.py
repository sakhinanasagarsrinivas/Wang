from typing import Dict, Optional, List
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain
from langchain.schema import HumanMessage, SystemMessage
from langchain.evaluation import load_evaluator
from .base_agent import BaseAgent

class CritiqueAgent(BaseAgent):
    def __init__(self, config_path: str):
        """Initialize critique agent with GPT-4 Turbo configuration."""
        super().__init__(config_path, "critique_agent")
        self.evaluation_metrics = self.config['evaluation']['metrics']
        self.evaluators = self._initialize_evaluators()
        self.feedback_chain = self._create_feedback_chain()

    def _initialize_llm(self) -> ChatOpenAI:
        """Initialize GPT-4 Turbo for critique agent."""
        return ChatOpenAI(
            model_name=self.model_config['model_name'],
            temperature=self.model_config['temperature'],
            max_tokens=self.model_config['max_tokens']
        )

    def _initialize_evaluators(self) -> Dict:
        """Initialize evaluation metrics."""
        evaluators = {}
        for metric in self.evaluation_metrics:
            try:
                evaluators[metric] = load_evaluator(metric)
            except ValueError:
                print(f"Warning: Evaluator {metric} not available")
        return evaluators

    def _create_feedback_chain(self) -> LLMChain:
        """Create chain for generating detailed feedback."""
        template = ChatPromptTemplate.from_messages([
            SystemMessage(content="""You are a critique agent specializing in analyzing responses about process engineering diagrams (PFDs and P&IDs). 
            Your role is to evaluate responses for accuracy, completeness, and relevance. Provide specific, actionable feedback for improvement."""),
            HumanMessage(content="""Query: {query}
            Response: {response}
            Context: {context}
            
            Evaluate this response considering:
            1. Technical accuracy
            2. Completeness of information
            3. Relevance to the query
            4. Clarity and coherence
            
            Provide your evaluation and specific suggestions for improvement.""")
        ])

        return LLMChain(llm=self.llm, prompt=template)

    def evaluate_response(self, query: str, response: Dict, context: Optional[Dict] = None) -> Dict:
        """
        Evaluate a response and provide detailed feedback.
        
        Args:
            query: Original user query
            response: Response to evaluate
            context: Optional context information
            
        Returns:
            Dictionary containing evaluation results and feedback
        """
        # Compute quantitative metrics
        metric_scores = self._compute_metrics(query, response, context)
        
        # Generate qualitative feedback
        feedback = self.feedback_chain.run(
            query=query,
            response=response['response'],
            context=str(context) if context else "No additional context provided"
        )
        
        # Determine if refinement is needed
        needs_refinement = self._check_refinement_needed(metric_scores, feedback)
        
        return self._format_response({
            'metric_scores': metric_scores,
            'feedback': feedback,
            'needs_refinement': needs_refinement,
            'improvement_suggestions': self._extract_suggestions(feedback)
        })

    def _compute_metrics(self, query: str, response: Dict, context: Optional[Dict]) -> Dict:
        """Compute evaluation metrics for the response."""
        metric_scores = {}
        
        for metric_name, evaluator in self.evaluators.items():
            try:
                # Handle different metric types appropriately
                if metric_name in ['bleu', 'rouge', 'meteor']:
                    # Text generation metrics
                    score = evaluator.evaluate_strings(
                        prediction=str(response['response']),
                        reference=str(context.get('reference', '')) if context else ''
                    )
                elif metric_name in ['precision', 'recall', 'f1']:
                    # Classification metrics
                    score = evaluator.evaluate_strings(
                        prediction=str(response.get('classification', '')),
                        reference=str(context.get('true_class', '')) if context else ''
                    )
                else:
                    # Generic evaluation
                    score = evaluator.evaluate(
                        prediction=str(response['response']),
                        reference=query
                    )
                metric_scores[metric_name] = score
            except Exception as e:
                print(f"Error computing {metric_name}: {str(e)}")
                metric_scores[metric_name] = None
        
        return metric_scores

    def _check_refinement_needed(self, metric_scores: Dict, feedback: str) -> bool:
        """
        Determine if response needs refinement based on metrics and feedback.
        
        Args:
            metric_scores: Dictionary of computed metric scores
            feedback: Qualitative feedback string
            
        Returns:
            Boolean indicating if refinement is needed
        """
        # Define threshold for various metrics
        metric_thresholds = {
            'bleu': 0.7,
            'rouge': 0.7,
            'meteor': 0.7,
            'precision': 0.8,
            'recall': 0.8,
            'f1': 0.8
        }

        # Check if any metric is below threshold
        metrics_below_threshold = any(
            score < metric_thresholds.get(metric, 0.8)
            for metric, score in metric_scores.items()
            if score is not None
        )

        # Check if feedback contains critical issues
        critical_keywords = ['incorrect', 'incomplete', 'unclear', 'missing', 'error']
        has_critical_feedback = any(keyword in feedback.lower() for keyword in critical_keywords)

        return metrics_below_threshold or has_critical_feedback

    def _extract_suggestions(self, feedback: str) -> List[str]:
        """Extract specific improvement suggestions from feedback."""
        # Use the LLM to extract structured suggestions
        suggestion_prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content="Extract specific, actionable suggestions from the feedback."),
            HumanMessage(content=feedback)
        ])
        
        suggestion_chain = LLMChain(llm=self.llm, prompt=suggestion_prompt)
        suggestions_text = suggestion_chain.run(feedback=feedback)
        
        # Split into individual suggestions
        suggestions = [
            suggestion.strip()
            for suggestion in suggestions_text.split('\n')
            if suggestion.strip()
        ]
        
        return suggestions

    def process_query(self, query: str, context: Optional[Dict] = None) -> Dict:
        """
        Process a query directly (not typically used as critique agent mainly evaluates).
        
        Args:
            query: Query string
            context: Optional context information
            
        Returns:
            Evaluation results
        """
        # This method is mainly for compatibility with base class
        # Critique agent typically uses evaluate_response instead
        if context and 'response' in context:
            return self.evaluate_response(query, context['response'], context)
        return self._format_response({
            'error': 'Critique agent requires a response to evaluate'
        })