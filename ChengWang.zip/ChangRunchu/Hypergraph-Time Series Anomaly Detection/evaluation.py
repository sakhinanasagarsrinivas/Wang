# evaluation.py

import torch
import numpy as np
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import json
import logging
from sklearn.metrics import (
    precision_score, recall_score, f1_score, 
    confusion_matrix, average_precision_score,
    roc_auc_score
)
import matplotlib.pyplot as plt
import seaborn as sns
from .utils import AnomalyAnalytics, RootCauseAnalysis

logger = logging.getLogger(__name__)

class ModelEvaluator:
    """Class for model evaluation and result analysis"""
    
    def __init__(self, model, config, data_processor=None):
        self.model = model
        self.config = config
        self.data_processor = data_processor
        self.analytics = AnomalyAnalytics()
        self.rca = RootCauseAnalysis(model, config)
        
    @torch.no_grad()
    def evaluate_model(
        self, 
        test_loader,
        threshold: Optional[float] = None,
        save_dir: Optional[str] = None
    ) -> Dict:
        """
        Comprehensive model evaluation
        
        Args:
            test_loader: DataLoader with test data
            threshold: Anomaly threshold (if None, use validation)
            save_dir: Directory to save results
            
        Returns:
            Dictionary with evaluation metrics and results
        """
        self.model.eval()
        
        # Initialize results storage
        predictions = []
        targets = []
        anomaly_scores = []
        hidden_states = []
        timestamps = []
        
        # Collect predictions
        for batch_idx, (x, y) in enumerate(test_loader):
            x = x.to(self.config.model.device)
            y = y.to(self.config.model.device)
            
            # Get predictions and states
            pred, scores, states = self.model(x, return_embeddings=True)
            
            # Store results
            predictions.extend(pred.cpu().numpy())
            targets.extend(y.cpu().numpy())
            anomaly_scores.extend(scores.cpu().numpy())
            hidden_states.extend(states.cpu().numpy())
            timestamps.extend([batch_idx * len(x) + i for i in range(len(x))])
            
        # Convert to arrays
        predictions = np.array(predictions)
        targets = np.array(targets)
        anomaly_scores = np.array(anomaly_scores)
        hidden_states = np.array(hidden_states)
        timestamps = np.array(timestamps)
        
        # Compute threshold if not provided
        if threshold is None:
            threshold = self._compute_threshold(anomaly_scores, targets)
            
        # Compute metrics
        metrics = self._compute_metrics(predictions, targets, anomaly_scores, threshold)
        
        # Analyze anomalies
        anomaly_analysis = self._analyze_anomalies(
            predictions, targets, anomaly_scores, threshold, hidden_states
        )
        
        # Generate visualizations
        if save_dir:
            save_dir = Path(save_dir)
            save_dir.mkdir(parents=True, exist_ok=True)
            self._generate_visualizations(
                predictions, targets, anomaly_scores,
                threshold, timestamps, save_dir
            )
            
        results = {
            'metrics': metrics,
            'anomaly_analysis': anomaly_analysis,
            'threshold': threshold
        }
        
        # Save results
        if save_dir:
            with open(save_dir / 'results.json', 'w') as f:
                json.dump(results, f, indent=4)
                
        return results
    
# evaluation.py (continued)

    def _compute_threshold(
        self,
        anomaly_scores: np.ndarray,
        targets: np.ndarray,
        method: str = 'f1'
    ) -> float:
        """Compute optimal threshold"""
        if method == 'f1':
            thresholds = np.linspace(0, 1, 100)
            best_f1 = 0
            best_threshold = 0.5
            
            for thresh in thresholds:
                pred_labels = (anomaly_scores > thresh).astype(int)
                true_labels = (targets > 0).astype(int)
                f1 = f1_score(true_labels, pred_labels)
                
                if f1 > best_f1:
                    best_f1 = f1
                    best_threshold = thresh
                    
            return best_threshold
        elif method == 'precision_recall':
            # Find threshold that balances precision and recall
            thresholds = np.linspace(0, 1, 100)
            best_diff = float('inf')
            best_threshold = 0.5
            
            for thresh in thresholds:
                pred_labels = (anomaly_scores > thresh).astype(int)
                true_labels = (targets > 0).astype(int)
                precision = precision_score(true_labels, pred_labels)
                recall = recall_score(true_labels, pred_labels)
                
                diff = abs(precision - recall)
                if diff < best_diff:
                    best_diff = diff
                    best_threshold = thresh
                    
            return best_threshold
        elif method == 'gaussian':
            # Use Gaussian distribution of normal samples
            normal_scores = anomaly_scores[targets == 0]
            mean = np.mean(normal_scores)
            std = np.std(normal_scores)
            return mean + 3 * std  # 3-sigma rule
        else:
            # Default percentile-based threshold
            return np.percentile(anomaly_scores, 95)
    
    def _compute_metrics(
        self,
        predictions: np.ndarray,
        targets: np.ndarray,
        anomaly_scores: np.ndarray,
        threshold: float
    ) -> Dict:
        """Compute comprehensive evaluation metrics"""
        # Binary predictions
        pred_labels = (anomaly_scores > threshold).astype(int)
        true_labels = (targets > 0).astype(int)
        
        # Basic metrics
        metrics = {
            'precision': precision_score(true_labels, pred_labels),
            'recall': recall_score(true_labels, pred_labels),
            'f1': f1_score(true_labels, pred_labels),
            'auroc': roc_auc_score(true_labels, anomaly_scores),
            'auprc': average_precision_score(true_labels, anomaly_scores),
            'mse': np.mean((predictions - targets) ** 2),
            'mae': np.mean(np.abs(predictions - targets))
        }
        
        # Confusion matrix
        cm = confusion_matrix(true_labels, pred_labels)
        metrics.update({
            'true_negatives': cm[0, 0],
            'false_positives': cm[0, 1],
            'false_negatives': cm[1, 0],
            'true_positives': cm[1, 1]
        })
        
        # Additional metrics
        metrics.update({
            'fpr': metrics['false_positives'] / (metrics['false_positives'] + metrics['true_negatives']),
            'fnr': metrics['false_negatives'] / (metrics['false_negatives'] + metrics['true_positives']),
            'accuracy': (metrics['true_positives'] + metrics['true_negatives']) / np.sum(cm)
        })
        
        return metrics
    
    def _analyze_anomalies(
        self,
        predictions: np.ndarray,
        targets: np.ndarray,
        anomaly_scores: np.ndarray,
        threshold: float,
        hidden_states: np.ndarray
    ) -> Dict:
        """Analyze detected anomalies"""
        # Find anomaly points
        anomaly_indices = np.where(anomaly_scores > threshold)[0]
        
        analysis = {
            'num_anomalies': len(anomaly_indices),
            'anomaly_segments': self._find_anomaly_segments(anomaly_indices),
            'intensity': anomaly_scores[anomaly_indices].mean(),
            'duration_stats': self._compute_duration_stats(anomaly_indices)
        }
        
        # Root cause analysis for major anomalies
        rca_results = []
        for idx in anomaly_indices:
            if anomaly_scores[idx] > np.percentile(anomaly_scores, 90):  # Top 10% anomalies
                rca_result = self.rca.analyze(
                    anomaly_idx=idx,
                    data=torch.tensor(hidden_states)
                )
                rca_results.append({
                    'index': idx,
                    'score': anomaly_scores[idx],
                    'causes': rca_result['causes'][:3]  # Top 3 causes
                })
                
        analysis['root_causes'] = rca_results
        
        return analysis
    
    def _find_anomaly_segments(self, anomaly_indices: np.ndarray) -> List[Tuple[int, int]]:
        """Find continuous anomaly segments"""
        if len(anomaly_indices) == 0:
            return []
            
        segments = []
        start = anomaly_indices[0]
        prev = start
        
        for idx in anomaly_indices[1:]:
            if idx - prev > 1:
                segments.append((start, prev))
                start = idx
            prev = idx
            
        segments.append((start, prev))
        return segments
    
    def _compute_duration_stats(self, anomaly_indices: np.ndarray) -> Dict:
        """Compute statistics about anomaly durations"""
        segments = self._find_anomaly_segments(anomaly_indices)
        durations = [end - start + 1 for start, end in segments]
        
        return {
            'min_duration': min(durations) if durations else 0,
            'max_duration': max(durations) if durations else 0,
            'mean_duration': np.mean(durations) if durations else 0,
            'median_duration': np.median(durations) if durations else 0
        }
    
    def _generate_visualizations(
        self,
        predictions: np.ndarray,
        targets: np.ndarray,
        anomaly_scores: np.ndarray,
        threshold: float,
        timestamps: np.ndarray,
        save_dir: Path
    ):
        """Generate evaluation visualizations"""
        # 1. Anomaly scores plot
        self.analytics.plot_anomaly_scores(
            timestamps,
            anomaly_scores,
            threshold,
            save_path=str(save_dir / 'anomaly_scores.png')
        )
        
        # 2. Confusion matrix
        pred_labels = (anomaly_scores > threshold).astype(int)
        true_labels = (targets > 0).astype(int)
        cm = confusion_matrix(true_labels, pred_labels)
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.savefig(save_dir / 'confusion_matrix.png')
        plt.close()
        
        # 3. Prediction vs Actual
        plt.figure(figsize=(12, 6))
        plt.plot(timestamps, targets, 'b-', label='Actual')
        plt.plot(timestamps, predictions, 'r--', label='Predicted')
        plt.fill_between(timestamps, 
                        targets, 
                        predictions,
                        where=(anomaly_scores > threshold),
                        color='red',
                        alpha=0.3,
                        label='Anomalies')
        plt.xlabel('Time')
        plt.ylabel('Value')
        plt.title('Predictions vs Actual Values')
        plt.legend()
        plt.savefig(save_dir / 'predictions.png')
        plt.close()
        
        # 4. Anomaly duration distribution
        if len(self._find_anomaly_segments(np.where(anomaly_scores > threshold)[0])) > 0:
            durations = [end - start + 1 for start, end in 
                        self._find_anomaly_segments(np.where(anomaly_scores > threshold)[0])]
            plt.figure(figsize=(8, 6))
            plt.hist(durations, bins=20)
            plt.xlabel('Duration')
            plt.ylabel('Count')
            plt.title('Anomaly Duration Distribution')
            plt.savefig(save_dir / 'duration_dist.png')
            plt.close()