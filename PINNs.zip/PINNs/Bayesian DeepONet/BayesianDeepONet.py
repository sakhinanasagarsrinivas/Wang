import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import json
import argparse
import os
import math
from tqdm import tqdm

torch.manual_seed(42)
np.random.seed(42)

def solve_diffusion_pde(D, h, X_env, z_points, t_points, z_domain, t_domain, X0):
    L = z_domain[1] - z_domain[0]
    dz = L / (z_points - 1)
    
    A = np.zeros((z_points, z_points))
    for i in range(1, z_points - 1):
        A[i, i-1] = 1
        A[i, i] = -2
        A[i, i+1] = 1

    A[0, 0] = -2 - 2 * dz * h
    A[0, 1] = 2
    
    A[-1, -2] = 2
    A[-1, -1] = -2 - 2 * dz * h
    
    A = (D / dz**2) * A
    
    b = np.zeros(z_points)
    b[0] = 2 * dz * h * X_env * (D / dz**2)
    b[-1] = 2 * dz * h * X_env * (D / dz**2)
    
    def ode_system(t, y):
        return A @ y + b

    y0 = np.full(z_points, X0)
    t_eval = np.linspace(t_domain[0], t_domain[1], t_points)
    
    sol = solve_ivp(ode_system, t_domain, y0, t_eval=t_eval, method='BDF', rtol=1e-5, atol=1e-6)
    
    return sol.y.T

class MoistureDataset(Dataset):
    def __init__(self, data_path, config):
        super().__init__()
        self.config = config
        self.data_path = data_path
        
        if os.path.exists(self.data_path):
            print(f"Loading dataset from {self.data_path}...")
            self.data = torch.load(self.data_path)
        else:
            print("Generating new dataset...")
            self.data = self._generate_data()
            torch.save(self.data, self.data_path)
            
        solutions = self.data['solutions']
        self.global_mean = solutions.mean()
        self.global_std = solutions.std()
        
        cfg_disc = self.config['operator_input_specification']['discretization']
        z_points, t_points = cfg_disc['z_points'], cfg_disc['t_points']
        
        z_domain = self.config['problem_definition']['domain']['z']
        t_domain = self.config['problem_definition']['domain']['t']

        z_grid = torch.linspace(z_domain[0], z_domain[1], z_points)
        t_grid = torch.linspace(t_domain[0], t_domain[1], t_points)
        grid_t, grid_z = torch.meshgrid(t_grid, z_grid, indexing='ij')
        self.coords = torch.stack([grid_z, grid_t], dim=-1).view(-1, 2)

    def _generate_data(self):
        cfg_data = self.config['data_generation']
        cfg_params = self.config['operator_input_specification']
        cfg_prob = self.config['problem_definition']
        
        num_samples = cfg_data['num_train_samples'] + cfg_data['num_test_samples']
        
        solutions, conditions = [], []

        for _ in tqdm(range(num_samples), desc="Generating PDE Solutions"):
            D = np.random.uniform(*cfg_params['uncertain_parameters_distribution']['D']['range'])
            h = np.random.uniform(*cfg_params['uncertain_parameters_distribution']['h']['range'])
            X_env = np.random.uniform(*cfg_params['uncertain_parameters_distribution']['X_env']['range'])
            
            sol = solve_diffusion_pde(
                D, h, X_env,
                cfg_params['discretization']['z_points'],
                cfg_params['discretization']['t_points'],
                cfg_prob['domain']['z'],
                cfg_prob['domain']['t'],
                cfg_prob['initial_condition']['X0']
            )

            if np.isnan(sol).any() or np.isinf(sol).any():
                print(f"\nWarning: Unstable solution detected despite fix for D={D:.3f}, h={h:.2f}, X_env={X_env:.2f}. Regenerating sample.")
                continue

            solutions.append(torch.from_numpy(sol).float())
            conditions.append(torch.tensor([D, h, X_env]).float())
            
        return {'solutions': torch.stack(solutions), 'conditions': torch.stack(conditions)}

    def __len__(self):
        return len(self.data['solutions'])

    def __getitem__(self, idx):
        solution = self.data['solutions'][idx]
        condition = self.data['conditions'][idx]
        
        solution_normalized = (solution - self.global_mean) / self.global_std
        targets = solution_normalized.view(-1, 1)

        D_range = self.config['operator_input_specification']['uncertain_parameters_distribution']['D']['range']
        h_range = self.config['operator_input_specification']['uncertain_parameters_distribution']['h']['range']
        X_env_range = self.config['operator_input_specification']['uncertain_parameters_distribution']['X_env']['range']
        
        D_norm = 2 * (condition[0] - D_range[0]) / (D_range[1] - D_range[0]) - 1
        h_norm = 2 * (condition[1] - h_range[0]) / (h_range[1] - h_range[0]) - 1
        X_env_norm = 2 * (condition[2] - X_env_range[0]) / (X_env_range[1] - X_env_range[0]) - 1
        condition_normalized = torch.tensor([D_norm, h_norm, X_env_norm]).float()
        
        return condition_normalized, self.coords, targets

class BayesianLinear(nn.Module):
    def __init__(self, in_features, out_features, prior_sigma=0.1):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.prior_sigma = prior_sigma
        self.prior_log_sigma = math.log(prior_sigma)
        
        self.weight_mu = nn.Parameter(torch.Tensor(out_features, in_features))
        self.weight_rho = nn.Parameter(torch.Tensor(out_features, in_features))
        self.bias_mu = nn.Parameter(torch.Tensor(out_features))
        self.bias_rho = nn.Parameter(torch.Tensor(out_features))
        
        self._reset_parameters()

    def _reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight_mu.size(1))
        self.weight_mu.data.uniform_(-stdv, stdv)
        self.weight_rho.data.fill_(-3.0)
        if self.bias_mu is not None:
            self.bias_mu.data.uniform_(-stdv, stdv)
            self.bias_rho.data.fill_(-3.0)

    def forward(self, x):
        if self.training:
            weight_sigma = F.softplus(self.weight_rho) + 1e-6
            bias_sigma = F.softplus(self.bias_rho) + 1e-6
            
            weight_eps = torch.randn_like(weight_sigma)
            bias_eps = torch.randn_like(bias_sigma)

            weight = self.weight_mu + weight_sigma * weight_eps
            bias = self.bias_mu + bias_sigma * bias_eps
        else:
            weight = self.weight_mu
            bias = self.bias_mu

        return F.linear(x, weight, bias)
    
    def kl_divergence(self):
        weight_sigma = F.softplus(self.weight_rho) + 1e-6
        bias_sigma = F.softplus(self.bias_rho) + 1e-6
        
        weight_log_sigma = torch.log(weight_sigma)
        bias_log_sigma = torch.log(bias_sigma)
        
        kl_weight = 0.5 * torch.sum(
            self.prior_log_sigma - weight_log_sigma +
            (weight_sigma**2 + self.weight_mu**2) / (self.prior_sigma**2) - 1
        )
        
        kl_bias = 0.5 * torch.sum(
            self.prior_log_sigma - bias_log_sigma +
            (bias_sigma**2 + self.bias_mu**2) / (self.prior_sigma**2) - 1
        )
        
        return kl_weight + kl_bias

class BayesianMLP(nn.Module):
    def __init__(self, input_dim, hidden_dims, output_dim, dropout=0.1):
        super().__init__()
        layers = []
        dims = [input_dim] + hidden_dims + [output_dim]
        
        for i in range(len(dims) - 1):
            layers.append(BayesianLinear(dims[i], dims[i+1]))
            if i < len(dims) - 2:
                layers.append(nn.LayerNorm(dims[i+1]))
                layers.append(nn.GELU())
                layers.append(nn.Dropout(dropout))
        
        self.net = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.net(x)
        
    def kl_divergence(self):
        kl = 0
        for module in self.modules():
            if isinstance(module, BayesianLinear):
                kl += module.kl_divergence()
        return kl

class BayesianDeepONet(nn.Module):
    def __init__(self, branch_input_dim, trunk_input_dim, branch_hidden_dims, trunk_hidden_dims, latent_dim):
        super().__init__()
        self.branch_net = BayesianMLP(branch_input_dim, branch_hidden_dims, latent_dim)
        self.trunk_net = BayesianMLP(trunk_input_dim, trunk_hidden_dims, latent_dim)
        
        self.output_layer = BayesianLinear(latent_dim, 1)
        self.b = nn.Parameter(torch.zeros(1))

    def forward(self, u, y):
        branch_out = self.branch_net(u)
        trunk_out = self.trunk_net(y)
        
        combined = branch_out * trunk_out
        output = self.output_layer(combined) + self.b
        
        return output

    def kl_divergence(self):
        return (self.branch_net.kl_divergence() + 
                self.trunk_net.kl_divergence() + 
                self.output_layer.kl_divergence())

class ProbabilisticSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._setup_dataloaders()
        self._build_model()

    def _setup_dataloaders(self):
        full_dataset = MoistureDataset(self.config['data_generation']['data_path'], self.config)
        self.dataset = full_dataset
        train_size = self.config['data_generation']['num_train_samples']
        test_size = self.config['data_generation']['num_test_samples']
        if len(full_dataset) < train_size + test_size:
            raise ValueError("Not enough data generated to create train/test splits.")
        self.train_dataset, self.test_dataset = torch.utils.data.random_split(
            full_dataset, [train_size, test_size]
        )
        self.train_loader = DataLoader(
            self.train_dataset, 
            batch_size=self.config['hyperparameters']['training']['batch_size'], 
            shuffle=True, num_workers=2, pin_memory=True
        )

    def _build_model(self):
        hp_arch = self.config['hyperparameters']['bayesian_deeponet']
        self.model = BayesianDeepONet(
            branch_input_dim=3,
            trunk_input_dim=2,
            branch_hidden_dims=hp_arch['branch_hidden_dims'],
            trunk_hidden_dims=hp_arch['trunk_hidden_dims'],
            latent_dim=hp_arch['latent_dim']
        ).to(self.device)
        
        hp_train = self.config['hyperparameters']['training']
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), 
            lr=hp_train['learning_rate'],
            weight_decay=hp_train['weight_decay']
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=hp_train['epochs'], eta_min=hp_train['learning_rate']*0.1
        )

    def train(self):
        print("--- Starting Bayesian DeepONet Training ---")
        hp_train = self.config['hyperparameters']['training']
        epochs = hp_train['epochs']
        best_loss = float('inf')

        kl_weight_max = hp_train['kl_weight']
        warmup_epochs = hp_train.get('kl_warmup_epochs', 0)
        print(f"KL Annealing: Max weight {kl_weight_max} with a {warmup_epochs}-epoch warm-up.")

        for epoch in range(epochs):
            self.model.train()
            pbar = tqdm(self.train_loader, desc=f"Epoch {epoch+1}/{epochs}")
            total_loss = 0
            
            if warmup_epochs > 0:
                kl_beta = kl_weight_max * min(1.0, (epoch + 1) / warmup_epochs)
            else:
                kl_beta = kl_weight_max

            for conditions, coords, targets in pbar:
                self.optimizer.zero_grad()
                
                conditions = conditions.to(self.device)
                coords = coords.to(self.device)
                targets = targets.to(self.device)
                
                batch_size, num_points = coords.shape[0], coords.shape[1]
                
                branch_in = conditions.unsqueeze(1).repeat(1, num_points, 1).view(-1, 3)
                trunk_in = coords.view(-1, 2)
                
                y_pred = self.model(branch_in, trunk_in)
                y_true = targets.view(-1, 1)

                mse_loss = F.mse_loss(y_pred, y_true)
                kl_loss = self.model.kl_divergence()
                
                loss = mse_loss + kl_beta * kl_loss / len(self.train_dataset)
                
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                
                total_loss += loss.item()
                pbar.set_postfix(mse=f"{mse_loss.item():.4f}", kl_div=f"{kl_loss.item():.2e}", 
                               kl_w=f"{kl_beta:.5f}", total_loss=f"{loss.item():.4f}")
            
            avg_loss = total_loss / len(self.train_loader)
            self.scheduler.step()
            
            if avg_loss < best_loss:
                best_loss = avg_loss
                torch.save(self.model.state_dict(), "best_bdeeponet_model.pt")
            
            print(f"Epoch {epoch+1}: Avg Loss = {avg_loss:.6f}, Best Loss = {best_loss:.6f}")

        print("--- Training Finished ---")
        if os.path.exists("best_bdeeponet_model.pt"):
            self.model.load_state_dict(torch.load("best_bdeeponet_model.pt"))
        torch.save(self.model.state_dict(), "bdeeponet_model.pt")
        print("Model saved to bdeeponet_model.pt")

    @torch.no_grad()
    def predict_dist(self, conditions, coords, num_samples):
        self.model.train()
        predictions = []
        pbar = tqdm(range(num_samples), desc="MC Sampling for Prediction", leave=False)
        for _ in pbar:
            branch_in = conditions.unsqueeze(1).repeat(1, coords.shape[0], 1).view(-1, 3)
            trunk_in = coords
            pred = self.model(branch_in, trunk_in)
            predictions.append(pred)
        
        predictions = torch.stack(predictions)
        mean = predictions.mean(dim=0)
        std = predictions.std(dim=0)
        return mean, std

    def evaluate_and_plot(self):
        print("\n--- Evaluating Bayesian DeepONet ---")
        hp_eval = self.config['hyperparameters']['evaluation']
        hp_disc = self.config['operator_input_specification']['discretization']
        cfg_prob = self.config['problem_definition']
        model_path = "bdeeponet_model.pt"

        if not os.path.exists(model_path):
            print(f"Model file '{model_path}' not found. Please train first.")
            return
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))

        os.makedirs("results_bdeeponet", exist_ok=True)
        z_grid = np.linspace(cfg_prob['domain']['z'][0], cfg_prob['domain']['z'][1], hp_disc['z_points'])
        t_grid = np.linspace(cfg_prob['domain']['t'][0], cfg_prob['domain']['t'][1], hp_disc['t_points'])
        
        global_mean = self.dataset.global_mean.item()
        global_std = self.dataset.global_std.item()
        
        for i in range(hp_eval['num_test_cases']):
            test_conditions_norm, test_coords, _ = self.test_dataset[i]
            
            cond = self.dataset.data['conditions'][self.test_dataset.indices[i]]
            D, h, X_env = cond[0].item(), cond[1].item(), cond[2].item()
            print(f"\nTest Case {i+1}: D={D:.3f}, h={h:.2f}, X_env={X_env:.2f}")

            mean_pred_norm, std_pred_norm = self.predict_dist(
                test_conditions_norm.to(self.device), 
                test_coords.to(self.device), 
                hp_eval['num_mc_samples']
            )

            mean_pred_field_norm = mean_pred_norm.view(hp_disc['t_points'], hp_disc['z_points']).cpu().numpy()
            std_pred_field_norm = std_pred_norm.view(hp_disc['t_points'], hp_disc['z_points']).cpu().numpy()
            
            mean_pred_field = mean_pred_field_norm * global_std + global_mean
            std_pred_field = std_pred_field_norm * global_std

            true_solution = solve_diffusion_pde(D, h, X_env, hp_disc['z_points'], hp_disc['t_points'], cfg_prob['domain']['z'], cfg_prob['domain']['t'], cfg_prob['initial_condition']['X0'])
            
            fig, axes = plt.subplots(1, 3, figsize=(22, 6))
            extent = [z_grid[0], z_grid[-1], t_grid[0], t_grid[-1]]

            avg_moisture_true = np.mean(true_solution, axis=1)
            avg_moisture_pred = np.mean(mean_pred_field, axis=1)
            avg_moisture_std = np.sqrt(np.mean(std_pred_field**2, axis=1))

            axes[0].plot(t_grid, avg_moisture_true, 'k-', label='Ground Truth', lw=2.5)
            axes[0].plot(t_grid, avg_moisture_pred, 'b--', label='B-DeepONet Mean', lw=2)
            axes[0].fill_between(t_grid, avg_moisture_pred - 2 * avg_moisture_std, avg_moisture_pred + 2 * avg_moisture_std,
                                 color='b', alpha=0.2, label='±2σ Credible Interval')
            axes[0].set_title("Avg. Moisture vs. Time (Drying Curve)")
            axes[0].set_xlabel("Time (t)"), axes[0].set_ylabel("Avg. Moisture X(t)")
            axes[0].legend(), axes[0].grid(True, ls='--')

            vmin, vmax = min(true_solution.min(), mean_pred_field.min()), max(true_solution.max(), mean_pred_field.max())
            im1 = axes[1].imshow(true_solution, aspect='auto', origin='lower', extent=extent, vmin=vmin, vmax=vmax)
            axes[1].set_title("Ground Truth Solution Field"), axes[1].set_xlabel("Depth (z)"), axes[1].set_ylabel("Time (t)")
            plt.colorbar(im1, ax=axes[1], label="Moisture X")

            im2 = axes[2].imshow(mean_pred_field, aspect='auto', origin='lower', extent=extent, vmin=vmin, vmax=vmax)
            axes[2].set_title("Mean Predicted Solution Field"), axes[2].set_xlabel("Depth (z)"), axes[2].set_ylabel("Time (t)")
            plt.colorbar(im2, ax=axes[2], label="Moisture X")
            
            fig.suptitle(f"Bayesian DeepONet Evaluation - Case {i+1}", fontsize=16)
            plt.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.savefig(f"results_bdeeponet/evaluation_case_{i+1}.pdf")
            plt.close(fig)

            fig_unc, ax_unc = plt.subplots(1, 1, figsize=(8, 6))
            im_unc = ax_unc.imshow(std_pred_field, aspect='auto', origin='lower', extent=extent)
            ax_unc.set_title(f"Uncertainty Map (Posterior Predictive Std. Dev.) - Case {i+1}")
            ax_unc.set_xlabel("Depth (z)"), ax_unc.set_ylabel("Time (t)")
            plt.colorbar(im_unc, ax=ax_unc, label="Std. Dev.")
            plt.savefig(f"results_bdeeponet/evaluation_uncertainty_{i+1}.pdf")
            plt.close(fig_unc)

        print("\nEvaluation plots saved to 'results_bdeeponet/' directory.")

def main():
    parser = argparse.ArgumentParser(description="Bayesian DeepONet for Moisture Diffusion")
    parser.add_argument("config_file", type=str, default="problem_config.json", nargs='?')
    parser.add_argument("--skip-train", action='store_true', help="Skip training and go directly to evaluation.")
    args = parser.parse_args()

    with open(args.config_file, 'r') as f: 
        full_config = json.load(f)
    
    config = full_config['problems'][0]
    config['hyperparameters'] = full_config['hyperparameters']
    
    solver = ProbabilisticSolver(config)
    if not args.skip_train: 
        solver.train()
    solver.evaluate_and_plot()

if __name__ == "__main__":
    main()