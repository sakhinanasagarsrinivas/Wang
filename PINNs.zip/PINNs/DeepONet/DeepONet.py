import torch
import torch.nn as nn
import numpy as np
import json
import argparse
import time
import os
from collections import OrderedDict
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

torch.manual_seed(42)
np.random.seed(42)
plt.style.use('seaborn-v0_8-whitegrid')

class AdaptiveActivation(nn.Module):
    def __init__(self, activation_class):
        super().__init__()
        self.activation = activation_class()
        self.scaling = nn.Parameter(torch.ones(1))
    def forward(self, x):
        return self.scaling * self.activation(x)

class FourierFeatureMapping(nn.Module):
    def __init__(self, input_dim, mapping_size, scale=10.0):
        super().__init__()
        self.register_buffer('B', torch.randn(input_dim, mapping_size) * scale)
    def forward(self, x):
        x_proj = x @ self.B
        return torch.cat([torch.sin(x_proj), torch.cos(x_proj)], dim=-1)

class Network(nn.Module):
    def __init__(self, layers, activation_fn, dropout_rate=0.0):
        super().__init__()
        net_layers = []
        for i in range(len(layers) - 1):
            net_layers.append((f"linear_{i}", nn.Linear(layers[i], layers[i+1])))
            if i < len(layers) - 2:
                net_layers.append((f"activation_{i}", AdaptiveActivation(activation_fn)))
                if dropout_rate > 0:
                    net_layers.append((f"dropout_{i}", nn.Dropout(dropout_rate)))
        self.net = nn.Sequential(OrderedDict(net_layers))
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        return self.net(x)

class BranchNet(Network):
    def __init__(self, layers, activation_fn):
        super().__init__(layers, activation_fn)

class TrunkNet(nn.Module):
    def __init__(self, layers, activation_fn, t_domain_tensor, use_fourier=False, fourier_size=64, fourier_scale=10.0):
        super().__init__()
        self.t_min, self.t_max = t_domain_tensor
        self.use_fourier = use_fourier
        
        trunk_input_dim = 1
        if self.use_fourier:
            self.fourier_mapping = FourierFeatureMapping(1, fourier_size, fourier_scale)
            trunk_input_dim = fourier_size * 2
        
        self.net = Network([trunk_input_dim] + layers, activation_fn)

    def forward(self, t):
        t_scaled = 2.0 * (t - self.t_min) / (self.t_max - self.t_min) - 1.0
        if self.use_fourier:
            trunk_features = self.fourier_mapping(t_scaled)
        else:
            trunk_features = t_scaled
        return self.net(trunk_features)

class DeepONet(nn.Module):
    def __init__(self, branch_layers, trunk_layers, num_outputs, activation_fn, t_domain_tensor, use_fourier, fourier_size, fourier_scale):
        super().__init__()
        self.num_outputs = num_outputs
        self.latent_dim = branch_layers[-1]
        
        self.branch_net = BranchNet(branch_layers, activation_fn)
        self.trunk_nets = nn.ModuleList([
            TrunkNet(trunk_layers, activation_fn, t_domain_tensor, use_fourier, fourier_size, fourier_scale)
            for _ in range(num_outputs)
        ])
        self.bias = nn.Parameter(torch.randn(1, num_outputs))

    def forward(self, u_sensors, t):
        branch_out = self.branch_net(u_sensors)
        trunk_outputs = torch.stack([trunk(t) for trunk in self.trunk_nets], dim=1)
        solution = torch.einsum('bl,tol->bto', branch_out, trunk_outputs) + self.bias
        return solution

class DeepONetSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._build_model()

    def _parse_config(self):
        problem_config = self.config['problems'][0]
        hp = self.config['hyperparameters']

        self.problem_name = problem_config['problem_id']
        self.state_vars = problem_config['state_variables']
        self.num_state_vars = len(self.state_vars)
        self.odes = problem_config['odes']
        self.t_domain = torch.tensor(problem_config['time_domain'], device=self.device)
        self.params = problem_config.get('parameters', {})
        self.time_inputs_template = problem_config.get('time_varying_inputs', {})
        self.param_space = problem_config['function_parameter_space']

        d_hp = hp['deeponet']
        self.lr, self.epochs, self.batch_size = hp['learning_rate'], hp['epochs'], hp['batch_size']
        self.num_collocation = hp['num_collocation_points']
        self.loss_weights = hp['loss_weights']
        
        activation_map = {"tanh": nn.Tanh, "relu": nn.ReLU, "gelu": nn.GELU, "silu": nn.SiLU}
        self.activation_fn = activation_map.get(hp['activation_function'], nn.Tanh)
        
        self.sensor_points = torch.linspace(self.t_domain[0], self.t_domain[1], d_hp['num_sensors'], device=self.device).view(-1, 1)

        self.branch_layers = [d_hp['num_sensors']] + [d_hp['branch_neurons_per_layer']] * d_hp['branch_hidden_layers'] + [d_hp['latent_dim']]
        self.trunk_layers = [d_hp['trunk_neurons_per_layer']] * d_hp['trunk_hidden_layers'] + [d_hp['latent_dim']]
        self.use_fourier, self.fourier_size, self.fourier_scale = hp['use_fourier_features'], hp['fourier_mapping_size'], hp['fourier_scale']

    def _build_model(self):
        self.model = DeepONet(
            self.branch_layers, self.trunk_layers, self.num_state_vars, self.activation_fn, 
            self.t_domain, self.use_fourier, self.fourier_size, self.fourier_scale
        ).to(self.device)
        
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-5)
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=self.epochs, eta_min=1e-6)

    def _sample_input_functions(self, batch_size):
        sampled_params = {p: (r[0] + (r[1] - r[0]) * torch.rand(batch_size, 1, device=self.device))
                          for p, r in self.param_space.items()}
        
        eval_scope = {'t': self.sensor_points.squeeze(), 'torch': torch, **sampled_params}
        template = self.time_inputs_template['CA0_t'].format(**{k: k for k in sampled_params})
        branch_input = eval(template, {}, eval_scope)
        
        return {k: v.squeeze(1) for k, v in sampled_params.items()}, branch_input

    def _get_ode_rhs(self, t, u, sampled_params):
        scope = {'t': t.squeeze(), **self.params}
        for i, var in enumerate(self.state_vars):
            scope[var] = u[..., i]

        eval_scope = {'t': t.squeeze(), 'torch': torch}
        for k, v in sampled_params.items():
            eval_scope[k] = v.unsqueeze(1)
        
        for name, expr_template in self.time_inputs_template.items():
            formatted_expr = expr_template.format(**{k: k for k in sampled_params})
            scope[name] = eval(formatted_expr, {}, eval_scope)

        rhs = torch.stack([eval(self.odes[f"d{var}dt"], {}, scope) for var in self.state_vars], dim=-1)
        return rhs

    def calculate_loss(self, collocation_t, sampled_params, branch_input):
        branch_out = self.model.branch_net(branch_input)

        def get_trunk_output_at_t(t_scalar):
            return torch.stack([trunk(t_scalar.view(1, 1)).squeeze(0) for trunk in self.model.trunk_nets], dim=0)

        jac_func = torch.func.jacrev(get_trunk_output_at_t)
        vmapped_jac_func = torch.func.vmap(jac_func)
        
        d_trunk_dt = vmapped_jac_func(collocation_t.squeeze()).squeeze(-1)
        trunk_out = torch.stack([trunk(collocation_t) for trunk in self.model.trunk_nets], dim=1)

        u_pred = torch.einsum('bl,tol->bto', branch_out, trunk_out) + self.model.bias
        du_dt_pred = torch.einsum('bl,tol->bto', branch_out, d_trunk_dt)
        
        rhs = self._get_ode_rhs(collocation_t, u_pred, sampled_params)
        loss_res = torch.mean((du_dt_pred - rhs)**2)
        
        t_ic = self.t_domain[0].view(1, 1)
        u_ic_pred = self.model(branch_input, t_ic).squeeze(1)
        ic_targets = torch.stack([sampled_params[f"{var}_ic"] for var in self.state_vars], dim=1)
        loss_ic = torch.mean((u_ic_pred - ic_targets)**2)
        
        return loss_res, loss_ic

    def train(self):
        print(f"--- Starting training for {self.problem_name} ---")
        start_time = time.time()
        self.model.train()
        
        for epoch in range(self.epochs):
            self.optimizer.zero_grad()
            
            sampled_params, branch_input = self._sample_input_functions(self.batch_size)
            collocation_t = self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(self.num_collocation, 1, device=self.device)
            
            loss_res, loss_ic = self.calculate_loss(collocation_t, sampled_params, branch_input)
            total_loss = self.loss_weights['ode_residual'] * loss_res + self.loss_weights['initial_condition'] * loss_ic
            
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            self.scheduler.step()
            
            if (epoch + 1) % 5000 == 0 or epoch == 0:
                current_lr = self.scheduler.get_last_lr()[0]
                print(f'Epoch [{epoch+1}/{self.epochs}], Loss: {total_loss.item():.4e}, '
                      f'ODE: {loss_res.item():.4e}, IC: {loss_ic.item():.4e}, LR: {current_lr:.4e}')
        
        elapsed_time = time.time() - start_time
        print(f"--- Training finished in {elapsed_time:.2f} seconds ---")

    def solve_single_instance_numerically(self, t_eval, instance_params):
        y0 = [instance_params[f"{var}_ic"] for var in self.state_vars]
        
        def ode_system(t, y):
            scope = {'t': t, **self.params}
            for i, var in enumerate(self.state_vars): scope[var] = y[i]
            
            eval_scope = {'t': t, 'sin': np.sin, 'cos': np.cos, **instance_params}
            
            for name, expr_template in self.time_inputs_template.items():
                formatted_expr = expr_template.format(**{k:k for k in instance_params})
                numpy_expr = formatted_expr.replace("torch.sin", "sin").replace("torch.cos", "cos")
                scope[name] = eval(numpy_expr, {}, eval_scope)

            return [eval(self.odes[f"d{var}dt"], {}, scope) for var in self.state_vars]
            
        sol = solve_ivp(ode_system, self.t_domain.cpu().numpy(), y0, dense_output=True, t_eval=t_eval, method='DOP853', rtol=1e-8, atol=1e-10)
        return sol.y.T

    def evaluate_and_plot_results(self):
        self.model.eval()
        results_dir = "results"
        os.makedirs(results_dir, exist_ok=True)
        base_filename = os.path.join(results_dir, self.problem_name.replace(' ', '_').lower())

        test_cases = [
            {'mean': 1.0, 'amp': 0.75, 'freq': 0.4, 'phase': 1.5, 'CA1_ic': 0.15, 'CA2_ic': 0.08},
            {'mean': 0.9, 'amp': 0.3, 'freq': 0.15, 'phase': 4.0, 'CA1_ic': 0.05, 'CA2_ic': 0.01},
            {'mean': 1.1, 'amp': 0.5, 'freq': 0.25, 'phase': 0.0, 'CA1_ic': 0.0, 'CA2_ic': 0.0},
        ]
        
        t_plot_np = np.linspace(self.t_domain[0].cpu().numpy(), self.t_domain[1].cpu().numpy(), 500)
        t_plot_torch = torch.from_numpy(t_plot_np).float().view(-1, 1).to(self.device)

        for i, case_params in enumerate(test_cases):
            print(f"\n--- Evaluating Test Case {i+1}: {case_params} ---")

            eval_scope = {'t': self.sensor_points.squeeze(), 'torch': torch, **case_params}
            template = self.time_inputs_template['CA0_t'].format(**{k:k for k in case_params})
            branch_input_test = eval(template, {}, eval_scope).unsqueeze(0)
            
            with torch.no_grad():
                u_deeponet = self.model(branch_input_test, t_plot_torch).squeeze(0).cpu().numpy()

            u_numerical = self.solve_single_instance_numerically(t_plot_np, case_params)

            fig, axes = plt.subplots(self.num_state_vars, 2, figsize=(16, 5 * self.num_state_vars), sharex=True)
            if self.num_state_vars == 1: axes = np.array([axes])

            for j, var in enumerate(self.state_vars):
                axes[j, 0].plot(t_plot_np, u_numerical[:, j], 'k-', label='Numerical', linewidth=2.5, alpha=0.8)
                axes[j, 0].plot(t_plot_np, u_deeponet[:, j], 'r--', label='DeepONet', markersize=3)
                axes[j, 0].set_ylabel(var)
                axes[j, 0].legend()
                axes[j, 0].set_title(f'Solution for {var}')

                error = np.abs(u_numerical[:, j] - u_deeponet[:, j])
                axes[j, 1].plot(t_plot_np, error)
                axes[j, 1].set_yscale('log')
                axes[j, 1].set_ylabel(f'Absolute Error')
                axes[j, 1].set_title(f'Error for {var}')
                axes[j, 1].grid(True, which="both", ls="--")

            axes[-1, 0].set_xlabel('Time (t)')
            axes[-1, 1].set_xlabel('Time (t)')
            
            fig.suptitle(f'DeepONet Generalization - Test Case {i+1}', fontsize=16)
            plt.tight_layout(rect=[0, 0.03, 1, 0.95])
            plot_filename = f"{base_filename}_test_case_{i+1}.pdf"
            plt.savefig(plot_filename)
            plt.close(fig)
            print(f"Test case plot saved to {plot_filename}")

def main():
    parser = argparse.ArgumentParser(description="Physics-Informed DeepONet Solver for ODEs")
    parser.add_argument("config_file", type=str, nargs='?', default="problem_config.json", help="Path to the JSON configuration file.")
    args = parser.parse_args()
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    solver = DeepONetSolver(config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()