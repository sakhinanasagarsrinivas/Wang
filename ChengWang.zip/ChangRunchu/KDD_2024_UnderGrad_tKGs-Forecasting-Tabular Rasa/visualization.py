"""
visualization.py - Plotting utilities for tKG Forecasting results with CSV input
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ResultsVisualizer:
    """Visualization tools for tKG forecasting results"""
    
    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Set style
        plt.style.use('seaborn')
        sns.set_palette("husl")

    def load_results(self, csv_path: Path) -> pd.DataFrame:
        """Load results from CSV file"""
        try:
            df = pd.read_csv(csv_path)
            logger.info(f"Successfully loaded results from {csv_path}")
            return df
        except Exception as e:
            logger.error(f"Failed to load results from {csv_path}: {str(e)}")
            raise

    def plot_model_comparison(self, csv_path: Path, title: str, filename: str):
        """
        Plot model comparison from CSV.
        Expected CSV format:
        Model,Dataset,Metric,Value
        """
        try:
            df = self.load_results(csv_path)
            
            metrics = df['Metric'].unique()
            plt.figure(figsize=(15, 8))
            
            for i, metric in enumerate(metrics, 1):
                plt.subplot(1, len(metrics), i)
                
                metric_data = df[df['Metric'] == metric]
                
                sns.barplot(
                    data=metric_data,
                    x='Dataset',
                    y='Value',
                    hue='Model'
                )
                
                plt.title(f'{metric} Across Datasets')
                plt.xticks(rotation=45)
                if i == 1:
                    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
                else:
                    plt.legend([])
            
            plt.suptitle(title)
            plt.tight_layout()
            plt.savefig(self.output_dir / filename, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logger.error(f"Failed to create model comparison plot: {str(e)}")
            raise

    def plot_ablation_study(self, csv_path: Path, title: str, filename: str):
        """
        Plot ablation study from CSV.
        Expected CSV format:
        Component,Dataset,Metric,Value
        """
        try:
            df = self.load_results(csv_path)
            
            plt.figure(figsize=(12, 6))
            
            sns.barplot(
                data=df,
                x='Dataset',
                y='Value',
                hue='Component',
                palette='Set2'
            )
            
            plt.title(title)
            plt.xlabel('Dataset')
            plt.ylabel(df['Metric'].iloc[0])
            plt.legend(title='Model Variant')
            plt.xticks(rotation=45)
            
            plt.tight_layout()
            plt.savefig(self.output_dir / filename, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logger.error(f"Failed to create ablation study plot: {str(e)}")
            raise

    def plot_longterm_forecasting(self, csv_path: Path, title: str, filename: str):
        """
        Plot long-term forecasting results from CSV.
        Expected CSV format:
        Delta_T,Dataset,Metric,Value
        """
        try:
            df = self.load_results(csv_path)
            
            metrics = df['Metric'].unique()
            plt.figure(figsize=(15, 6))
            
            for i, metric in enumerate(metrics, 1):
                plt.subplot(1, len(metrics), i)
                
                metric_data = df[df['Metric'] == metric]
                
                sns.lineplot(
                    data=metric_data,
                    x='Delta_T',
                    y='Value',
                    hue='Dataset',
                    marker='o'
                )
                
                plt.title(f'{metric} vs. Forecast Horizon')
                plt.xlabel('ΔT (days)')
                if i == 1:
                    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
                else:
                    plt.legend([])
                    
                plt.grid(True, alpha=0.3)
            
            plt.suptitle(title)
            plt.tight_layout()
            plt.savefig(self.output_dir / filename, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logger.error(f"Failed to create long-term forecasting plot: {str(e)}")
            raise

    def plot_training_history(self, csv_path: Path, title: str, filename: str):
        """
        Plot training metrics evolution from CSV.
        Expected CSV format:
        Epoch,train_loss,val_loss,val_mrr
        """
        try:
            df = self.load_results(csv_path)
            
            plt.figure(figsize=(12, 8))
            
            # Plot training loss
            plt.subplot(2, 1, 1)
            plt.plot(df['Epoch'], df['train_loss'], 'b-', label='Training Loss')
            if 'val_loss' in df.columns:
                plt.plot(df['Epoch'], df['val_loss'], 'r-', label='Validation Loss')
            plt.title('Training and Validation Loss')
            plt.xlabel('Epoch')
            plt.ylabel('Loss')
            plt.legend()
            plt.grid(True, alpha=0.3)
            
            # Plot MRR evolution
            plt.subplot(2, 1, 2)
            if 'val_mrr' in df.columns:
                plt.plot(df['Epoch'], df['val_mrr'], 'g-', label='Validation MRR')
            plt.title('Validation MRR Evolution')
            plt.xlabel('Epoch')
            plt.ylabel('MRR')
            plt.legend()
            plt.grid(True, alpha=0.3)
            
            plt.suptitle(title)
            plt.tight_layout()
            plt.savefig(self.output_dir / filename, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logger.error(f"Failed to create training evolution plot: {str(e)}")
            raise

def main():
    # Initialize paths
    results_dir = Path('results')
    figures_dir = Path('outputs/figures')
    
    # Create directories if they don't exist
    results_dir.mkdir(exist_ok=True)
    figures_dir.mkdir(exist_ok=True, parents=True)
    
    # Initialize visualizer
    vis = ResultsVisualizer(figures_dir)
    
    # Create plots from CSV files
    if (results_dir / 'model_comparison.csv').exists():
        vis.plot_model_comparison(
            csv_path=results_dir / 'model_comparison.csv',
            title='Model Performance Comparison',
            filename='model_comparison.png'
        )
    
    if (results_dir / 'ablation_study.csv').exists():
        vis.plot_ablation_study(
            csv_path=results_dir / 'ablation_study.csv',
            title='Ablation Study Results',
            filename='ablation_study.png'
        )
    
    if (results_dir / 'longterm_forecasting.csv').exists():
        vis.plot_longterm_forecasting(
            csv_path=results_dir / 'longterm_forecasting.csv',
            title='Long-term Forecasting Performance',
            filename='longterm_forecasting.png'
        )
    
    if (results_dir / 'training_history.csv').exists():
        vis.plot_training_history(
            csv_path=results_dir / 'training_history.csv',
            title='Training Progress',
            filename='training_evolution.png'
        )

if __name__ == "__main__":
    main()