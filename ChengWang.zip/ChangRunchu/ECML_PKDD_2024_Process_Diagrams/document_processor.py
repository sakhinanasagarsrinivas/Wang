from typing import List, Dict, Tuple, Optional
import fitz  # PyMuPDF
import os
from pathlib import Path
import yaml
from PIL import Image
import io
import hashlib

from .text_processor import TextProcessor
from .image_processor import ImageProcessor

class DocumentProcessor:
    def __init__(self, config_path: str):
        """
        Initialize document processor with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.text_processor = TextProcessor(config_path)
        self.image_processor = ImageProcessor(config_path)
        
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
        
    def process_document(self, file_path: str) -> Dict:
        """
        Process a PDF document containing PFD or P&ID diagrams.
        
        Args:
            file_path: Path to the PDF file
            
        Returns:
            Dictionary containing processed text and images
        """
        # Verify file exists and is PDF
        if not os.path.exists(file_path) or not file_path.lower().endswith('.pdf'):
            raise ValueError("Invalid file path or not a PDF file")
            
        doc = fitz.open(file_path)
        processed_data = {
            'document_id': self._generate_doc_id(file_path),
            'file_name': Path(file_path).name,
            'total_pages': len(doc),
            'pages': []
        }
        
        for page_num in range(len(doc)):
            page_data = self._process_page(doc[page_num])
            processed_data['pages'].append(page_data)
            
        doc.close()
        return processed_data
    
    def _process_page(self, page: fitz.Page) -> Dict:
        """
        Process a single page from the document.
        
        Args:
            page: PyMuPDF page object
            
        Returns:
            Dictionary containing processed page data
        """
        # Extract text blocks
        text_blocks = self.text_processor.extract_text_blocks(page)
        
        # Extract images
        images = self._extract_images(page)
        processed_images = [
            self.image_processor.process_image(img)
            for img in images
        ]
        
        # Process page metadata
        metadata = self._extract_page_metadata(page)
        
        return {
            'page_number': page.number + 1,
            'text_blocks': text_blocks,
            'images': processed_images,
            'metadata': metadata
        }
    
    def _extract_images(self, page: fitz.Page) -> List[Image.Image]:
        """
        Extract images from a page.
        
        Args:
            page: PyMuPDF page object
            
        Returns:
            List of PIL Image objects
        """
        images = []
        image_list = page.get_images(full=True)
        
        for img_index, img_info in enumerate(image_list):
            try:
                base_image = self._extract_single_image(page.parent, img_info)
                if base_image:
                    images.append(base_image)
            except Exception as e:
                print(f"Error extracting image {img_index}: {str(e)}")
                
        return images
    
    def _extract_single_image(self, doc: fitz.Document, img_info: Tuple) -> Optional[Image.Image]:
        """
        Extract a single image from the document.
        
        Args:
            doc: PyMuPDF document object
            img_info: Tuple containing image information
            
        Returns:
            PIL Image object or None if extraction fails
        """
        xref = img_info[0]
        base_image = doc.extract_image(xref)
        
        if base_image:
            image_bytes = base_image["image"]
            try:
                return Image.open(io.BytesIO(image_bytes))
            except Exception as e:
                print(f"Error converting image bytes: {str(e)}")
        return None
    
    def _extract_page_metadata(self, page: fitz.Page) -> Dict:
        """
        Extract metadata from a page.
        
        Args:
            page: PyMuPDF page object
            
        Returns:
            Dictionary containing page metadata
        """
        return {
            'width': page.rect.width,
            'height': page.rect.height,
            'rotation': page.rotation,
            'mediabox': list(page.mediabox),
            'cropbox': list(page.cropbox)
        }
    
    def _generate_doc_id(self, file_path: str) -> str:
        """
        Generate a unique document ID based on file content.
        
        Args:
            file_path: Path to the document
            
        Returns:
            Unique document identifier
        """
        hasher = hashlib.sha256()
        with open(file_path, 'rb') as f:
            buf = f.read(65536)  # Read in 64kb chunks
            while len(buf) > 0:
                hasher.update(buf)
                buf = f.read(65536)
        return hasher.hexdigest()[:16]

    def save_processed_data(self, processed_data: Dict, output_dir: str):
        """
        Save processed document data to output directory.
        
        Args:
            processed_data: Processed document data
            output_dir: Output directory path
        """
        doc_id = processed_data['document_id']
        output_path = Path(output_dir) / doc_id
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save metadata and text content
        metadata_path = output_path / 'metadata.yaml'
        with open(metadata_path, 'w') as f:
            yaml.dump(
                {k: v for k, v in processed_data.items() if k != 'pages'},
                f
            )
        
        # Save individual page data
        for page_data in processed_data['pages']:
            page_dir = output_path / f"page_{page_data['page_number']}"
            page_dir.mkdir(exist_ok=True)
            
            # Save text blocks
            text_path = page_dir / 'text_blocks.yaml'
            with open(text_path, 'w') as f:
                yaml.dump(page_data['text_blocks'], f)
            
            # Save processed images
            for idx, img_data in enumerate(page_data['images']):
                img_path = page_dir / f'image_{idx}.png'
                self.image_processor.save_image(img_data['image'], str(img_path))
                
            # Save page metadata
            page_metadata_path = page_dir / 'metadata.yaml'
            with open(page_metadata_path, 'w') as f:
                yaml.dump(page_data['metadata'], f)