import numpy as np
from typing import Dict, Union, List
from sklearn.metrics import (
    mean_squared_error, 
    mean_absolute_error,
    precision_score, 
    recall_score, 
    f1_score,
    accuracy_score
)

def calculate_forecasting_metrics(
    predictions: np.ndarray,
    targets: np.ndarray,
    mask: Optional[np.ndarray] = None
) -> Dict[str, float]:
    """
    Calculate forecasting metrics as per paper Section 2.1
    MAE, RMSE, MAPE for 12-sequence-to-12-sequence forecasting tasks
    """
    if mask is not None:
        predictions = predictions[mask]
        targets = targets[mask]
        
    metrics = {}
    metrics["mae"] = mean_absolute_error(targets, predictions)
    metrics["rmse"] = np.sqrt(mean_squared_error(targets, predictions))
    
    # MAPE calculation with handling zero values
    non_zero_mask = targets != 0
    if non_zero_mask.any():
        mape = np.mean(np.abs((targets[non_zero_mask] - predictions[non_zero_mask]) / 
                              targets[non_zero_mask])) * 100
        metrics["mape"] = mape
    
    return metrics

def calculate_anomaly_metrics(
    predictions: np.ndarray,
    targets: np.ndarray,
    moving_average_window: int,
    dataset_name: str
) -> Dict[str, float]:
    """
    Calculate anomaly detection metrics as per paper Section 2.3
    Uses moving average calculation and handles different dataset requirements
    """
    # Calculate anomaly scores using moving average as per paper
    scores = np.abs(predictions - targets)
    smoothed_scores = np.convolve(scores, 
                                 np.ones(moving_average_window)/moving_average_window,
                                 mode='valid')
    
    # Calculate threshold based on validation set statistics
    threshold = np.percentile(smoothed_scores, 95)  # As per paper
    anomalies = smoothed_scores > threshold
    
    metrics = {
        "precision": precision_score(targets, anomalies) * 100,
        "recall": recall_score(targets, anomalies) * 100,
        "f1": f1_score(targets, anomalies) * 100
    }
    
    # Special handling for TEP dataset - calculate FDR
    if dataset_name == "TEP":
        fault_detection_rate = calculate_fault_detection_rate(predictions, targets)
        metrics["fdr"] = fault_detection_rate
    
    return metrics

def calculate_imputation_metrics(
    predictions: np.ndarray,
    targets: np.ndarray,
    mask: np.ndarray
) -> Dict[str, float]:
    """
    Calculate imputation metrics as per paper Section 2.2
    Only evaluates imputed values using the mask
    """
    # Only evaluate metrics for masked (imputed) values
    imputed_preds = predictions[mask == 1]
    imputed_targets = targets[mask == 1]
    
    metrics = {
        "mae": mean_absolute_error(imputed_targets, imputed_preds),
        "rmse": np.sqrt(mean_squared_error(imputed_targets, imputed_preds)),
        "mre": np.mean(np.abs(imputed_targets - imputed_preds) / 
                      (imputed_targets + 1e-10))  # Avoid division by zero
    }
    
    return metrics

def calculate_classification_metrics(
    predictions: np.ndarray,
    targets: np.ndarray,
    num_classes: int
) -> Dict[str, float]:
    """
    Calculate classification metrics as per paper Section 2.4
    Handles both binary and multi-class scenarios
    """
    metrics = {
        "accuracy": accuracy_score(targets, predictions),
        "precision_macro": precision_score(targets, predictions, 
                                         average='macro', 
                                         zero_division=0) * 100,
        "recall_macro": recall_score(targets, predictions, 
                                   average='macro', 
                                   zero_division=0) * 100,
        "f1_macro": f1_score(targets, predictions, 
                            average='macro', 
                            zero_division=0) * 100
    }
    
    # Per-class metrics
    for i in range(num_classes):
        class_mask = targets == i
        if class_mask.any():
            metrics[f"precision_class_{i}"] = precision_score(
                targets == i, 
                predictions == i, 
                zero_division=0
            ) * 100
            metrics[f"recall_class_{i}"] = recall_score(
                targets == i, 
                predictions == i, 
                zero_division=0
            ) * 100
            metrics[f"f1_class_{i}"] = f1_score(
                targets == i, 
                predictions == i, 
                zero_division=0
            ) * 100
    
    return metrics

def calculate_fault_detection_rate(
    predictions: np.ndarray,
    targets: np.ndarray,
    num_faults: int = 20  # TEP dataset has 20 fault types
) -> float:
    """
    Calculate Fault Detection Rate for TEP dataset
    as described in paper's experiments
    """
    fdr = 0
    for fault in range(1, num_faults + 1):
        fault_mask = targets == fault
        if fault_mask.any():
            detected = (predictions[fault_mask] == fault).any()
            fdr += detected
    
    return (fdr / num_faults) * 100

def calculate_metrics(
    predictions: np.ndarray,
    targets: np.ndarray,
    task_type: str,
    **kwargs
) -> Dict[str, float]:
    """Main function to calculate metrics for all tasks"""
    if task_type == "forecasting":
        return calculate_forecasting_metrics(predictions, targets, 
                                          mask=kwargs.get('mask'))
    elif task_type == "anomaly_detection":
        return calculate_anomaly_metrics(predictions, targets,
                                       kwargs['moving_average_window'],
                                       kwargs['dataset_name'])
    elif task_type == "imputation":
        return calculate_imputation_metrics(predictions, targets,
                                          mask=kwargs['mask'])
    elif task_type == "classification":
        return calculate_classification_metrics(predictions, targets,
                                             kwargs['num_classes'])
    else:
        raise ValueError(f"Unknown task type: {task_type}")