from typing import Dict, List, Any, Optional
import numpy as np
from sklearn.metrics import confusion_matrix
import pandas as pd
from pathlib import Path
import json
import logging
from utils.evaluation import EvaluationMetrics

class MetricsCalculator:
    def __init__(self, config_path: str):
        """
        Initialize metrics calculator with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.base_metrics = EvaluationMetrics(config_path)
        self.logger = self._setup_logger()
        
    def _setup_logger(self) -> logging.Logger:
        """Setup logging configuration."""
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            
        return logger
        
    def calculate_diagram_metrics(
        self,
        predictions: Dict[str, Any],
        ground_truth: Dict[str, Any]
    ) -> Dict[str, Dict[str, float]]:
        """
        Calculate metrics specific to diagram analysis.
        
        Args:
            predictions: Dictionary of model predictions
            ground_truth: Dictionary of ground truth values
            
        Returns:
            Dictionary containing diagram-specific metrics
        """
        metrics = {}
        
        # Component detection metrics
        if 'components' in predictions and 'components' in ground_truth:
            metrics['component_detection'] = self._calculate_component_metrics(
                predictions['components'],
                ground_truth['components']
            )
            
        # Flow analysis metrics
        if 'flows' in predictions and 'flows' in ground_truth:
            metrics['flow_analysis'] = self._calculate_flow_metrics(
                predictions['flows'],
                ground_truth['flows']
            )
            
        # Equipment identification metrics
        if 'equipment' in predictions and 'equipment' in ground_truth:
            metrics['equipment_identification'] = self._calculate_equipment_metrics(
                predictions['equipment'],
                ground_truth['equipment']
            )
            
        # Overall metrics
        metrics['overall'] = self._calculate_overall_metrics(predictions, ground_truth)
        
        return metrics
        
    def _calculate_component_metrics(
        self,
        pred_components: List[Dict],
        true_components: List[Dict]
    ) -> Dict[str, float]:
        """Calculate metrics for component detection."""
        # Match predicted and ground truth components
        matches = self._match_components(pred_components, true_components)
        
        # Calculate basic metrics
        tp = len(matches)
        fp = len(pred_components) - tp
        fn = len(true_components) - tp
        
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        # Calculate positional accuracy
        position_errors = [
            self._calculate_position_error(
                pred_components[m[0]],
                true_components[m[1]]
            )
            for m in matches
        ]
        
        return {
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'mean_position_error': np.mean(position_errors) if position_errors else 0
        }
        
    def _calculate_flow_metrics(
        self,
        pred_flows: List[Dict],
        true_flows: List[Dict]
    ) -> Dict[str, float]:
        """Calculate metrics for flow analysis."""
        # Match predicted and ground truth flows
        correct_flows = sum(
            1 for pf in pred_flows
            for tf in true_flows
            if self._compare_flows(pf, tf)
        )
        
        accuracy = correct_flows / len(true_flows) if true_flows else 0
        
        # Calculate direction accuracy
        direction_matches = sum(
            1 for pf in pred_flows
            for tf in true_flows
            if self._compare_flow_directions(pf, tf)
        )
        
        direction_accuracy = direction_matches / len(true_flows) if true_flows else 0
        
        return {
            'flow_accuracy': accuracy,
            'direction_accuracy': direction_accuracy
        }
        
    def _calculate_equipment_metrics(
        self,
        pred_equipment: List[Dict],
        true_equipment: List[Dict]
    ) -> Dict[str, float]:
        """Calculate metrics for equipment identification."""
        # Calculate classification metrics
        y_true = [eq['type'] for eq in true_equipment]
        y_pred = [eq['type'] for eq in pred_equipment]
        
        classification_metrics = self.base_metrics.calculate_precision_recall_f1(
            y_true, y_pred
        )
        
        # Calculate position accuracy
        position_metrics = self._calculate_position_metrics(
            pred_equipment,
            true_equipment
        )
        
        return {
            **classification_metrics,
            **position_metrics
        }
        
    def _calculate_overall_metrics(
        self,
        predictions: Dict[str, Any],
        ground_truth: Dict[str, Any]
    ) -> Dict[str, float]:
        """Calculate overall system performance metrics."""
        # Calculate text generation metrics
        if 'description' in predictions and 'description' in ground_truth:
            text_metrics = self.base_metrics.calculate_all_metrics(
                {'text': predictions['description']},
                {'text': ground_truth['description']}
            )
        else:
            text_metrics = {}
            
        # Calculate average metrics across all tasks
        metric_values = []
        for metric_group in text_metrics.values():
            metric_values.extend(metric_group.values())
            
        return {
            'mean_score': np.mean(metric_values) if metric_values else 0,
            'std_score': np.std(metric_values) if metric_values else 0
        }
        
    def _match_components(
        self,
        pred_components: List[Dict],
        true_components: List[Dict],
        iou_threshold: float = 0.5
    ) -> List[Tuple[int, int]]:
        """Match predicted components to ground truth components."""
        matches = []
        used_true = set()
        
        for i, pred in enumerate(pred_components):
            best_iou = iou_threshold
            best_match = None
            
            for j, true in enumerate(true_components):
                if j in used_true:
                    continue
                    
                iou = self.base_metrics.calculate_iou(
                    pred['bbox'],
                    true['bbox']
                )
                
                if iou > best_iou:
                    best_iou = iou
                    best_match = j
                    
            if best_match is not None:
                matches.append((i, best_match))
                used_true.add(best_match)
                
        return matches
        
    def _calculate_position_error(
        self,
        pred_component: Dict,
        true_component: Dict
    ) -> float:
        """Calculate positional error between predicted and true component."""
        pred_center = np.mean(pred_component['bbox'].reshape(-1, 2), axis=0)
        true_center = np.mean(true_component['bbox'].reshape(-1, 2), axis=0)
        
        return np.linalg.norm(pred_center - true_center)
        
    def _compare_flows(self, pred_flow: Dict, true_flow: Dict) -> bool:
        """Compare predicted and ground truth flows."""
        return (
            pred_flow['source'] == true_flow['source'] and
            pred_flow['target'] == true_flow['target']
        )
        
    def _compare_flow_directions(self, pred_flow: Dict, true_flow: Dict) -> bool:
        """Compare flow directions."""
        return pred_flow['direction'] == true_flow['direction']
        
    def _calculate_position_metrics(
        self,
        pred_equipment: List[Dict],
        true_equipment: List[Dict]
    ) -> Dict[str, float]:
        """Calculate position-related metrics for equipment."""
        position_errors = []
        
        matches = self._match_components(pred_equipment, true_equipment)
        for pred_idx, true_idx in matches:
            error = self._calculate_position_error(
                pred_equipment[pred_idx],
                true_equipment[true_idx]
            )
            position_errors.append(error)
            
        return {
            'mean_position_error': np.mean(position_errors) if position_errors else 0,
            'max_position_error': max(position_errors) if position_errors else 0
        }
        
    def save_results(
        self,
        metrics: Dict[str, Any],
        output_path: str,
        include_plots: bool = True
    ):
        """
        Save evaluation results and optionally generate plots.
        
        Args:
            metrics: Dictionary of calculated metrics
            output_path: Path to save results
            include_plots: Whether to generate and save plots
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save metrics to JSON
        with open(output_path / 'metrics.json', 'w') as f:
            json.dump(metrics, f, indent=2)
            
        # Create results summary
        summary = pd.DataFrame(self._flatten_metrics(metrics))
        summary.to_csv(output_path / 'summary.csv')
        
        if include_plots:
            self._generate_plots(metrics, output_path)
            
    def _flatten_metrics(self, metrics: Dict, parent_key: str = '') -> Dict:
        """Flatten nested metrics dictionary."""
        items = []
        for k, v in metrics.items():
            new_key = f"{parent_key}.{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_metrics(v, new_key).items())
            else:
                items.append((new_key, v))
        return dict(items)
        
    def _generate_plots(self, metrics: Dict[str, Any], output_path: Path):
        """Generate visualization plots for metrics."""
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        # Set style
        plt.style.use('seaborn')
        
        # Plot component detection metrics
        if 'component_detection' in metrics:
            self._plot_detection_metrics(
                metrics['component_detection'],
                output_path / 'component_detection.png'
            )
            
        # Plot flow analysis metrics
        if 'flow_analysis' in metrics:
            self._plot_flow_metrics(
                metrics['flow_analysis'],
                output_path / 'flow_analysis.png'
            )
            
        # Plot equipment identification metrics
        if 'equipment_identification' in metrics:
            self._plot_equipment_metrics(
                metrics['equipment_identification'],
                output_path / 'equipment_identification.png'
            )
            
    def _plot_detection_metrics(self, metrics: Dict[str, float], output_path: str):
        """Plot component detection metrics."""
        import matplotlib.pyplot as plt
        
        plt.figure(figsize=(10, 6))
        plt.bar(metrics.keys(), metrics.values())
        plt.title('Component Detection Metrics')
        plt.xlabel('Metric')
        plt.ylabel('Score')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()