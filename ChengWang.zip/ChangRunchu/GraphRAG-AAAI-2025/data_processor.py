import pandas as pd
import numpy as np
from typing import Tuple, List, Dict
from sklearn.model_selection import train_test_split
from pathlib import Path

class DataProcessor:
    def __init__(self, data_path: str):
        self.data_path = Path(data_path)
        
    def load_data(self) -> pd.DataFrame:
        """Load the generated dataset"""
        if self.data_path.suffix == '.json':
            return pd.read_json(self.data_path)
        elif self.data_path.suffix == '.csv':
            return pd.read_csv(self.data_path)
        else:
            raise ValueError("Unsupported file format")
            
    def preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        """Preprocess the dataset"""
        # Clean text
        df['question'] = df['question'].str.strip()
        df['solution'] = df['solution'].str.strip()
        
        # Remove duplicates
        df = df.drop_duplicates(subset=['question'])
        
        # Add metadata
        df['complexity'] = df['solution'].apply(self._calculate_complexity)
        df['domain'] = df['question'].apply(self._identify_domain)
        
        return df
        
    def split_data(self, df: pd.DataFrame, 
                   train_size: float = 0.7,
                   val_size: float = 0.15,
                   test_size: float = 0.15) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Split data into train, validation and test sets"""
        # First split: separate test set
        train_val, test = train_test_split(df, test_size=test_size, random_state=42)
        
        # Second split: separate train and validation from remaining data
        relative_val_size = val_size / (train_size + val_size)
        train, val = train_test_split(train_val, test_size=relative_val_size, random_state=42)
        
        return train, val, test
        
    def _calculate_complexity(self, solution: str) -> str:
        """Calculate complexity of a solution"""
        # Simple heuristic based on solution length and number of steps
        length = len(solution.split())
        steps = len(solution.split('\n'))
        
        if length < 100 and steps < 3:
            return 'basic'
        elif length < 300 and steps < 7:
            return 'intermediate'
        else:
            return 'advanced'
            
    def _identify_domain(self, question: str) -> str:
        """Identify the domain of the question"""
        # Simple keyword-based classification
        keywords = {
            'thermodynamics': ['heat', 'temperature', 'pressure', 'entropy'],
            'fluid_mechanics': ['flow', 'velocity', 'viscosity', 'pressure'],
            'mass_transfer': ['concentration', 'diffusion', 'mass', 'transfer'],
            'reaction_kinetics': ['reaction', 'rate', 'catalyst', 'equilibrium']
        }
        
        question = question.lower()
        for domain, kwords in keywords.items():
            if any(kw in question for kw in kwords):
                return domain
        return 'general'
