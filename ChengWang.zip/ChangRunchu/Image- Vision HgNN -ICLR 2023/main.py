import torch
from torch.utils.data import DataLoader, random_split
import wandb

from config.config import VisionHGNNConfig
from data.dataset import SEMDataset
from models.vision_hgnn import VisionHGNN
from training.trainer import Trainer

def main():
    # Initialize configuration
    config = VisionHGNNConfig()
    
    # Initialize wandb for experiment tracking
    wandb.init(
        project="Vision-HGNN",
        config={k: v for k, v in vars(config).items() if not k.startswith('__')}
    )
    
    # Device configuration
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Dataset preparation with train/val/test split
    full_dataset = SEMDataset(config.dataset_path)
    
    # Split dataset
    train_size = int(0.7 * len(full_dataset))
    val_size = int(0.15 * len(full_dataset))
    test_size = len(full_dataset) - train_size - val_size
    
    train_dataset, val_dataset, test_dataset = random_split(
        full_dataset, 
        [train_size, val_size, test_size]
    )
    
    # Data Loaders
    train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.batch_size)
    test_loader = DataLoader(test_dataset, batch_size=config.batch_size)
    
    # Model initialization
    model = VisionHGNN(config).to(device)
    
    # Trainer with full dataset splits
    trainer = Trainer(
        config=config,
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader
    )
    
    # Training with hyperparameter tuning and final evaluation
    final_test_metrics = trainer.train()
    
    # Print final test metrics
    print("Final Test Metrics:")
    for key, value in final_test_metrics.items():
        print(f"{key}: {value}")
    
    # Finish wandb run
    wandb.finish()

if __name__ == '__main__':
    main()