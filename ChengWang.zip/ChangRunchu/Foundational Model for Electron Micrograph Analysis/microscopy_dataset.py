# data_generation/microscopy_dataset.py
import torch
from PIL import Image
import openai
import json
from pathlib import Path
from tqdm import tqdm
import argparse
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoImageProcessor

class MicroscopyDataGenerator:
    """
    Generate instruction-following dataset for electron microscopy images 
    as described in Section 2.1 of the paper
    """
    def __init__(self, config):
        self.api_key = config.api_key
        openai.api_key = self.api_key
        self.prompts = self._load_microscopy_prompts()
        
    def _load_microscopy_prompts(self):
        """Load prompts specific to microscopy analysis"""
        return {
            "base_analysis": """Analyze this electron microscopy image and provide:
                1. Nanomaterial category identification
                2. Morphological features
                3. Size distribution analysis
                4. Surface characteristics
                5. Spatial arrangement""",
            
            "intra_class": """Analyze the high intra-class dissimilarity in this image:
                1. Variations within same category
                2. Distinctive features
                3. Structural differences""",
            
            "inter_class": """Compare similarities between different nanomaterial categories:
                1. Common features
                2. Shared characteristics
                3. Distinguishing aspects""",
            
            "spatial": """Analyze spatial heterogeneity:
                1. Size distribution patterns
                2. Spatial arrangements
                3. Clustering analysis"""
        }
    
    def generate_instruction_data(self, image_path, analysis_type):
        """Generate electron microscopy analysis instructions using GPT-4V"""
        try:
            # Read image and encode
            with open(image_path, "rb") as img_file:
                image_data = img_file.read()
            
            response = openai.ChatCompletion.create(
                model="gpt-4-vision-preview",
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in electron microscopy analysis."
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": self.prompts[analysis_type]},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64.b64encode(image_data).decode()}"
                                }
                            }
                        ]
                    }
                ]
            )
            
            return {
                "instruction": response.choices[0].message.content,
                "analysis_type": analysis_type,
                "image_path": str(image_path)
            }
            
        except Exception as e:
            print(f"Error generating instruction for {image_path}: {e}")
            return None

class SemDatasetProcessor:
    """
    Process SEM dataset as described in Section 2.1
    Handles the 21,000+ electron micrographs across 10 nanomaterial categories
    """
    def __init__(self, data_path, output_path):
        self.data_path = Path(data_path)
        self.output_path = Path(output_path)
        self.categories = [
            'biological', 'fibers', 'films', 'mems', 'nanowires',
            'particles', 'patterned', 'porous', 'powder', 'tips'
        ]
        
    def process_dataset(self):
        """Process and organize SEM dataset"""
        dataset = []
        
        for category in self.categories:
            category_path = self.data_path / category
            if not category_path.exists():
                continue
            
            # Process images in category
            for img_path in tqdm(list(category_path.glob('*.jpg'))):
                try:
                    # Load and validate image
                    img = Image.open(img_path)
                    
                    # Extract metadata
                    metadata = self._extract_metadata(img)
                    
                    dataset.append({
                        'path': str(img_path),
                        'category': category,
                        'metadata': metadata
                    })
                    
                except Exception as e:
                    print(f"Error processing {img_path}: {e}")
                    continue
        
        return dataset
    
    def _extract_metadata(self, img):
        """Extract relevant metadata from SEM image"""
        return {
            'size': img.size,
            'scale': self._extract_scale_bar(img),
            'magnification': self._extract_magnification(img)
        }

class InstructionDataset(torch.utils.data.Dataset):
    """
    Dataset class for instruction-tuned electron microscopy analysis
    as described in Section 2.2
    """
    def __init__(self, data_path, tokenizer, image_processor, max_length=512):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.image_processor = image_processor
        self.max_length = max_length
        
    def _load_data(self, data_path):
        with open(data_path, 'r') as f:
            return json.load(f)
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        # Load and process image
        image = Image.open(item['image_path'])
        pixel_values = self.image_processor(image)
        
        # Process instruction
        encoding = self.tokenizer(
            item['instruction'],
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'pixel_values': pixel_values,
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
            'category': item['category'],
            'analysis_type': item['analysis_type']
        }


def main(args):
    # Initialize data generator
    data_generator = MicroscopyDataGenerator(args)
    
    # Process SEM dataset
    dataset_processor = SemDatasetProcessor(args.data_path, args.output_path)
    sem_dataset = dataset_processor.process_dataset()
    
    # Generate instruction data for each analysis type
    analysis_types = ['base_analysis', 'intra_class', 'inter_class', 'spatial']
    instruction_data = []
    
    for item in tqdm(sem_dataset):
        for analysis_type in analysis_types:
            instruction = data_generator.generate_instruction_data(
                item['path'],
                analysis_type
            )
            if instruction:
                instruction_data.append({
                    **instruction,
                    'category': item['category']
                })
    
    # Save instruction dataset
    output_file = Path(args.output_path) / 'instruction_dataset.json'
    with open(output_file, 'w') as f:
        json.dump(instruction_data, f, indent=2)
    
    # Initialize tokenizer and image processor
    tokenizer = AutoTokenizer.from_pretrained('meta-llama/Llama-2-7b')
    image_processor = AutoImageProcessor.from_pretrained('google/vit-base-patch16-224')
    
    # Create dataset
    dataset = InstructionDataset(
        output_file,
        tokenizer,
        image_processor
    )
    
    print(f"Generated {len(dataset)} instruction-following examples")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, required=True,
                      help='Path to SEM dataset')
    parser.add_argument('--output_path', type=str, required=True,
                      help='Path to save processed data')
    parser.add_argument('--api_key', type=str, required=True,
                      help='OpenAI API key')
    
    args = parser.parse_args()
    main(args)