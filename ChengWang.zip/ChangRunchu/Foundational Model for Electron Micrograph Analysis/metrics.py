# evaluation/metrics.py
import torch
import numpy as np
from torchmetrics.text import BLEUScore, ROUGEScore, METEORScore
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

class MetricsCalculator:
    """Calculate various metrics for evaluation"""
    def __init__(self):
        self.bleu = BLEUScore(n_gram=4)
        self.rouge = ROUGEScore()
        self.meteor = METEORScore()
        
    def calculate_generation_metrics(self, predictions, targets):
        """Calculate metrics for generation tasks"""
        return {
            'bleu': self.bleu(predictions, targets).item(),
            'rouge': self.rouge(predictions, targets),
            'meteor': self.meteor(predictions, targets).item()
        }
    
    def calculate_classification_metrics(self, predictions, targets):
        """Calculate metrics for classification tasks"""
        accuracy = accuracy_score(targets, predictions)
        precision, recall, f1, _ = precision_recall_fscore_support(
            targets, predictions, average='weighted'
        )
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1
        }