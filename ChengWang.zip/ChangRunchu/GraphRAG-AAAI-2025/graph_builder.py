from neo4j import GraphDatabase
from typing import Dict, Any, List
import logging

class GraphBuilder:
    def __init__(self, uri: str, user: str, password: str):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        
    def close(self):
        self.driver.close()
        
    def create_knowledge_graph(self, data: List[Dict[str, Any]]):
        """Create knowledge graph from processed data"""
        try:
            with self.driver.session() as session:
                for item in data:
                    self._create_nodes_and_relationships(session, item)
                    
        except Exception as e:
            logging.error(f"Error creating knowledge graph: {str(e)}")
            
    def _create_nodes_and_relationships(self, session, item: Dict[str, Any]):
        """Create nodes and relationships for a single item"""
        # Create query node
        query = f"""
        CREATE (q:Query {{
            text: $question,
            domain: $domain,
            complexity: $complexity
        }})
        """
        session.run(query, question=item['question'], 
                   domain=item['domain'],
                   complexity=item['complexity'])
                   
        # Create solution node and relationship
        query = f"""
        MATCH (q:Query {{text: $question}})
        CREATE (s:Solution {{
            text: $solution,
            steps: $steps
        }})
        CREATE (q)-[:HAS_SOLUTION]->(s)
        """
        session.run(query, question=item['question'],
                   solution=item['solution'],
                   steps=item.get('steps', []))
                   
        # Create concept nodes and relationships
        for concept in self._extract_concepts(item):
            query = f"""
            MATCH (q:Query {{text: $question}})
            MERGE (c:Concept {{name: $concept}})
            CREATE (q)-[:INVOLVES]->(c)
            """
            session.run(query, question=item['question'],
                       concept=concept)
                       
    def _extract_concepts(self, item: Dict[str, Any]) -> List[str]:
        """Extract key concepts from an item"""
        # This is a simplified version. In practice, you might want to use
        # NLP techniques or a pre-defined ontology
        concepts = []
        if 'concepts' in item:
            concepts.extend(item['concepts'])
        if 'keywords' in item:
            concepts.extend(item['keywords'])
        return list(set(concepts))
        
    def query_knowledge_graph(self, query: str) -> List[Dict[str, Any]]:
        """Query the knowledge graph"""
        try:
            with self.driver.session() as session:
                result = session.run(query)
                return [record.data() for record in result]
                
        except Exception as e:
            logging.error(f"Error querying knowledge graph: {str(e)}")
            return []