# rait_framework/models/rait_model.py
import torch
import logging
import json
import os
from typing import List, Dict, Any, Optional

from transformers import (
    AutoModelForCausalLM, 
    AutoTokenizer, 
    PreTrainedModel, 
    PreTrainedTokenizer
)
from sentence_transformers import SentenceTransformer

from ..tools.tool_registry import ToolRegistry, ToolInvoker
from ..retrievers.knowledge_retriever import KnowledgeRetriever

from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

class KnowledgeRetriever:
    """
    Advanced knowledge retrieval system for semantic search
    """
    def __init__(self, 
                 embedding_model: str = "all-MiniLM-L6-v2",
                 knowledge_base_path: Optional[str] = None):
        """
        Initialize knowledge retriever
        
        Args:
            embedding_model (str): Sentence transformer model for embeddings
            knowledge_base_path (str, optional): Path to knowledge base JSON
        """
        # Logging setup
        self.logger = logging.getLogger(self.__class__.__name__)
        logging.basicConfig(level=logging.INFO)
        
        # Embedding model
        self.embedding_model = SentenceTransformer(embedding_model)
        
        # Load knowledge base
        self.knowledge_base = self._load_knowledge_base(knowledge_base_path)
    
    def _load_knowledge_base(self, path: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Load knowledge base from JSON file
        
        Args:
            path (str, optional): Path to knowledge base file
        
        Returns:
            List[Dict[str, Any]]: Loaded knowledge base
        """
        # Default knowledge base if no path provided
        default_knowledge = [
            {
                "domain": "mathematical_computation",
                "sources": [
                    "Numerical methods for solving differential equations",
                    "Linear algebra computational techniques",
                    "Optimization algorithms",
                    "Computational complexity theory"
                ]
            },
            {
                "domain": "chemical_engineering",
                "sources": [
                    "Mass and energy balance principles",
                    "Thermodynamic equilibrium modeling",
                    "Reaction kinetics fundamentals",
                    "Process simulation techniques"
                ]
            }
        ]
        
        if path and os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                self.logger.warning(f"Error loading knowledge base: {e}")
        
        return default_knowledge
    
    def retrieve(self, 
                 query: str, 
                 domain: Optional[str] = None, 
                 top_k: int = 3) -> List[str]:
        """
        Retrieve semantically relevant knowledge
        
        Args:
            query (str): Search query
            domain (str, optional): Specific domain to search
            top_k (int): Number of top results to return
        
        Returns:
            List[str]: Retrieved knowledge snippets
        """
        try:
            # Filter knowledge base by domain if specified
            knowledge_sources = self.knowledge_base
            if domain:
                knowledge_sources = [
                    kb for kb in knowledge_sources 
                    if kb.get('domain', '').lower() == domain.lower()
                ]
            
            # Flatten sources
            all_sources = [
                source 
                for kb in knowledge_sources 
                for source in kb.get('sources', [])
            ]
            
            # Embed query and sources
            query_embedding = self.embedding_model.encode([query])
            source_embeddings = self.embedding_model.encode(all_sources)
            
            # Compute cosine similarities
            similarities = cosine_similarity(query_embedding, source_embeddings)[0]
            
            # Get top-k most similar sources
            top_indices = similarities.argsort()[-top_k:][::-1]
            retrieved_sources = [all_sources[idx] for idx in top_indices]
            
            return retrieved_sources
        
        except Exception as e:
            self.logger.error(f"Knowledge retrieval error: {e}")
            return []
    
    def add_knowledge(self, 
                      domain: str, 
                      sources: List[str], 
                      save_path: Optional[str] = None):
        """
        Add new knowledge to the knowledge base
        
        Args:
            domain (str): Knowledge domain
            sources (List[str]): New knowledge sources
            save_path (str, optional): Path to save updated knowledge base
        """
        try:
            # Check if domain exists
            domain_entry = next(
                (kb for kb in self.knowledge_base if kb['domain'] == domain), 
                None
            )
            
            if domain_entry:
                # Update existing domain
                domain_entry['sources'].extend(sources)
            else:
                # Add new domain
                self.knowledge_base.append({
                    "domain": domain,
                    "sources": sources
                })
            
            # Save if path provided
            if save_path:
                with open(save_path, 'w') as f:
                    json.dump(self.knowledge_base, f, indent=2)
            
            self.logger.info(f"Added {len(sources)} sources to {domain} domain")
        
        except Exception as e:
            self.logger.error(f"Error adding knowledge: {e}")
            
class RAITModel:
    """
    Retrieval-Augmented Instruction-Tuning (RAIT) Model
    Implements advanced code generation with retrieval and tool augmentation
    """
    def __init__(self, 
                 model_name: str = "google/codegemma-7b",
                 device: Optional[str] = None,
                 retrieval_model: str = "all-MiniLM-L6-v2"):
        """
        Initialize RAIT model with advanced components
        
        Args:
            model_name (str): Hugging Face model name for code generation
            device (str, optional): Compute device (cuda/cpu)
            retrieval_model (str): Sentence transformer for semantic retrieval
        """
        # Logging configuration
        self.logger = logging.getLogger(self.__class__.__name__)
        logging.basicConfig(level=logging.INFO)
        
        # Device configuration
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        
        # Model and tokenizer loading
        try:
            self.tokenizer = self._load_tokenizer(model_name)
            self.model = self._load_model(model_name)
        except Exception as e:
            self.logger.error(f"Model loading error: {e}")
            raise
        
        # Retrieval and tool components
        self.knowledge_retriever = KnowledgeRetriever(
            embedding_model=retrieval_model
        )
        self.tool_registry = ToolRegistry()
        self.tool_invoker = ToolInvoker(self.tool_registry)
        
        # Generation configuration
        self.generation_config = {
            'max_new_tokens': 500,
            'num_return_sequences': 1,
            'do_sample': True,
            'temperature': 0.7,
            'top_p': 0.9,
            'repetition_penalty': 1.2
        }
    
    def _load_tokenizer(self, model_name: str) -> PreTrainedTokenizer:
        """
        Load tokenizer with error handling
        
        Args:
            model_name (str): Model name
        
        Returns:
            PreTrainedTokenizer: Loaded tokenizer
        """
        try:
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            
            # Configure special tokens if needed
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            
            return tokenizer
        except Exception as e:
            self.logger.error(f"Tokenizer loading error: {e}")
            raise
    
    def _load_model(self, model_name: str) -> PreTrainedModel:
        """
        Load model with device placement and precision optimization
        
        Args:
            model_name (str): Model name
        
        Returns:
            PreTrainedModel: Loaded and configured model
        """
        try:
            # Load model with optimized precision
            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                low_cpu_mem_usage=True
            )
            
            # Move to appropriate device
            model = model.to(self.device)
            
            return model
        except Exception as e:
            self.logger.error(f"Model loading error: {e}")
            raise
    
    def generate_code(self, 
                      instruction: str, 
                      context: Optional[List[str]] = None,
                      tools: Optional[List[str]] = None) -> str:
        """
        Generate code with retrieval-augmented generation
        
        Args:
            instruction (str): Problem description or instruction
            context (List[str], optional): Additional context or retrieved information
            tools (List[str], optional): Specific tools to be used
        
        Returns:
            str: Generated code
        """
        try:
            # Retrieve relevant context if not provided
            if not context:
                context = self._retrieve_context(instruction)
            
            # Identify and prepare relevant tools
            if not tools:
                tools = self._select_relevant_tools(instruction)
            
            # Prepare input for code generation
            input_text = self._prepare_input(
                instruction, 
                context, 
                tools
            )
            
            # Tokenize input
            inputs = self.tokenizer(
                input_text, 
                return_tensors="pt", 
                padding=True
            ).to(self.device)
            
            # Generate code
            outputs = self.model.generate(
                **inputs,
                **self.generation_config
            )
            
            # Decode generated code
            generated_code = self.tokenizer.decode(
                outputs[0], 
                skip_special_tokens=True
            )
            
            # Extract and clean code block
            cleaned_code = self._extract_code_block(generated_code)
            
            return cleaned_code
        
        except Exception as e:
            self.logger.error(f"Code generation error: {e}")
            raise
    
    def _retrieve_context(self, instruction: str, top_k: int = 3) -> List[str]:
        """
        Retrieve contextually relevant information
        
        Args:
            instruction (str): Problem description
            top_k (int): Number of context snippets to retrieve
        
        Returns:
            List[str]: Retrieved context snippets
        """
        return self.knowledge_retriever.retrieve(
            query=instruction, 
            top_k=top_k
        )
    
    def _select_relevant_tools(self, instruction: str, top_k: int = 3) -> List[str]:
        """
        Select relevant tools based on problem description
        
        Args:
            instruction (str): Problem description
            top_k (int): Number of tools to select
        
        Returns:
            List[str]: Selected tool names
        """
        return list(
            self.tool_registry.find_tools_by_description(instruction).keys()
        )[:top_k]
    
    def _prepare_input(self, 
                       instruction: str, 
                       context: List[str], 
                       tools: List[str]) -> str:
        """
        Prepare comprehensive input for code generation
        
        Args:
            instruction (str): Problem description
            context (List[str]): Retrieved context
            tools (List[str]): Selected tools
        
        Returns:
            str: Prepared input text
        """
        input_parts = []
        
        # Add context
        if context:
            input_parts.append("Contextual Information:")
            input_parts.extend(context)
            input_parts.append("\n")
        
        # Add selected tools
        if tools:
            input_parts.append("Relevant Tools:")
            input_parts.extend(tools)
            input_parts.append("\n")
        
        # Add main instruction
        input_parts.append("Instruction:")
        input_parts.append(instruction)
        input_parts.append("\nGenerate Python code to solve the problem:")
        
        return "\n".join(input_parts)
    
    def _extract_code_block(self, generated_text: str) -> str:
        """
        Extract code block from generated text
        
        Args:
            generated_text (str): Full generated text
        
        Returns:
            str: Extracted Python code block
        """
        import re
        
        # Extraction strategies
        extraction_patterns = [
            # Python code blocks in triple backticks
            r'```python\n(.*?)```',
            
            # Code blocks starting with function or import
            r'((?:def|import|class).*?(?:\n\n|$))',
            
            # Entire code-like text
            r'((?:import|def|class|#).*)',
        ]
        
        for pattern in extraction_patterns:
            code_match = re.search(pattern, generated_text, re.DOTALL | re.MULTILINE)
            if code_match:
                return code_match.group(1).strip()
        
        # Fallback to full text if no code block found
        return generated_text.strip()
    
    def refine_code(self, 
                    original_code: str, 
                    error_message: str, 
                    instruction: str) -> str:
        """
        Refine generated code based on error feedback
        
        Args:
            original_code (str): Initially generated code
            error_message (str): Error encountered during execution
            instruction (str): Original problem description
        
        Returns:
            str: Refined code
        """
        # Prepare refinement input
        refinement_input = f"""
        Original Code:
        {original_code}
        
        Error Encountered:
        {error_message}
        
        Original Instruction:
        {instruction}
        
        Refine the code to address the error and solve the problem.
        Provide a corrected and improved implementation.
        """
        
        # Generate refined code
        refined_code = self.generate_code(
            instruction=refinement_input,
            context=[error_message]
        )
        
        return refined_code