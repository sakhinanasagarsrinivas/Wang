import torch
from torch.utils.data import Dataset, DataLoader
import pandas as pd
from rdkit import Chem
from typing import List, Tuple, Dict
import numpy as np

class MoleculeDataset(Dataset):
    """Dataset class for molecule text-to-SMILES data"""
    
    def __init__(self, texts: List[str], smiles: List[str], transform=None):
        """
        Args:
            texts (List[str]): List of molecule descriptions
            smiles (List[str]): List of SMILES representations
            transform: Optional transform to be applied on a sample
        """
        self.texts = texts
        self.smiles = smiles
        self.transform = transform
        
        # Validate SMILES
        self.valid_indices = self._validate_smiles()
        
    def _validate_smiles(self) -> List[int]:
        """Validate SMILES strings using RDKit"""
        valid_indices = []
        for idx, smi in enumerate(self.smiles):
            mol = Chem.MolFromSmiles(smi)
            if mol is not None:
                valid_indices.append(idx)
        return valid_indices
    
    def __len__(self) -> int:
        return len(self.valid_indices)
    
    def __getitem__(self, idx: int) -> Dict[str, str]:
        """Get a sample from the dataset"""
        valid_idx = self.valid_indices[idx]
        sample = {
            'text': self.texts[valid_idx],
            'smiles': self.smiles[valid_idx]
        }
        
        if self.transform:
            sample = self.transform(sample)
            
        return sample

def create_dataloaders(
    texts: List[str],
    smiles: List[str],
    batch_size: int,
    train_split: float,
    val_split: float,
    seed: int = 42
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Create train, validation, and test dataloaders
    
    Args:
        texts: List of molecule descriptions
        smiles: List of SMILES strings
        batch_size: Batch size for dataloaders
        train_split: Proportion of data for training
        val_split: Proportion of data for validation
        seed: Random seed for reproducibility
        
    Returns:
        Tuple of (train_loader, val_loader, test_loader)
    """
    # Set random seed
    np.random.seed(seed)
    
    # Create dataset
    dataset = MoleculeDataset(texts, smiles)
    
    # Calculate split sizes
    total_size = len(dataset)
    train_size = int(train_split * total_size)
    val_size = int(val_split * total_size)
    test_size = total_size - train_size - val_size
    
    # Split dataset
    train_dataset, val_dataset, test_dataset = torch.utils.data.random_split(
        dataset, 
        [train_size, val_size, test_size]
    )
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=4
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=4
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=4
    )
    
    return train_loader, val_loader, test_loader