import torch
import numpy as np
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix

def calculate_metrics(predictions, labels, num_classes):
    """Calculate comprehensive metrics for model evaluation."""
    # Convert tensors to numpy arrays if needed
    if isinstance(predictions, torch.Tensor):
        predictions = predictions.cpu().numpy()
    if isinstance(labels, torch.Tensor):
        labels = labels.cpu().numpy()
    
    # Calculate precision, recall, and F1 score
    precision, recall, f1, _ = precision_recall_fscore_support(
        labels, predictions, average=None, 
        labels=range(num_classes)
    )
    
    # Calculate macro averages
    macro_precision = np.mean(precision)
    macro_recall = np.mean(recall)
    macro_f1 = np.mean(f1)
    
    # Calculate confusion matrix
    conf_matrix = confusion_matrix(labels, predictions, labels=range(num_classes))
    
    # Calculate accuracy
    accuracy = np.sum(predictions == labels) / len(labels)
    
    # Calculate Top-K accuracy for K=1,2,3,5
    top_k_accuracy = {}
    if isinstance(predictions, np.ndarray) and len(predictions.shape) > 1:
        for k in [1, 2, 3, 5]:
            top_k_correct = 0
            for i, label in enumerate(labels):
                if label in predictions[i].argsort()[-k:]:
                    top_k_correct += 1
            top_k_accuracy[f'top_{k}'] = top_k_correct / len(labels)
    
    # Compile metrics dictionary
    metrics = {
        'accuracy': accuracy,
        'macro_precision': macro_precision,
        'macro_recall': macro_recall,
        'macro_f1': macro_f1,
        'class_precision': precision,
        'class_recall': recall,
        'class_f1': f1,
        'confusion_matrix': conf_matrix,
        'top_k_accuracy': top_k_accuracy
    }
    
    return metrics

def print_metrics(metrics, class_names=None):
    """Print metrics in a formatted way."""
    print("\nModel Performance Metrics:")
    print("-" * 50)
    
    print(f"Overall Accuracy: {metrics['accuracy']:.4f}")
    print(f"Macro Precision: {metrics['macro_precision']:.4f}")
    print(f"Macro Recall: {metrics['macro_recall']:.4f}")
    print(f"Macro F1: {metrics['macro_f1']:.4f}")
    
    print("\nTop-K Accuracy:")
    for k, acc in metrics['top_k_accuracy'].items():
        print(f"{k.upper()}: {acc:.4f}")
    
    if class_names:
        print("\nPer-Class Metrics:")
        print(f"{'Class':<20} {'Precision':>10} {'Recall':>10} {'F1':>10}")
        print("-" * 50)
        for i, class_name in enumerate(class_names):
            print(f"{class_name:<20} {metrics['class_precision'][i]:>10.4f} "
                  f"{metrics['class_recall'][i]:>10.4f} "
                  f"{metrics['class_f1'][i]:>10.4f}")
    
    print("\nConfusion Matrix:")
    print(metrics['confusion_matrix'])