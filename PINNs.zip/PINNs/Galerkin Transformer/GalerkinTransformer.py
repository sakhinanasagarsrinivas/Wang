import torch
import torch.nn as nn
import numpy as np
import json
import argparse
import time
import os
import math
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from numpy.polynomial.legendre import legval

torch.manual_seed(42)
np.random.seed(42)
plt.style.use('seaborn-v0_8-whitegrid')

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 5000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

class GalerkinTransformer(nn.Module):
    def __init__(self, input_dim, output_dim, d_model, nhead, num_encoder_layers, dim_feedforward, dropout, activation_fn):
        super().__init__()
        self.d_model = d_model
        self.input_projection = nn.Linear(input_dim, d_model)
        self.pos_encoder = PositionalEncoding(d_model, dropout)
        encoder_layer = nn.TransformerEncoderLayer(d_model, nhead, dim_feedforward, dropout, activation=activation_fn, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_encoder_layers)
        self.output_projection = nn.Linear(d_model, output_dim)
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, src):
        src_proj = self.input_projection(src) * math.sqrt(self.d_model)
        src_pos = self.pos_encoder(src_proj)
        memory = self.transformer_encoder(src_pos)
        output = self.output_projection(memory)
        return output

class GalerkinTransformerSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._build_model()
        self._precompute_test_functions()

    def _parse_config(self):
        problem_config = self.config['problems'][0]
        hp = self.config['hyperparameters']
        tr_hp = hp['transformer']

        self.problem_name = problem_config['problem_id']
        self.state_vars = problem_config['state_variables']
        self.num_state_vars = len(self.state_vars)
        self.odes = problem_config['odes']
        self.t_domain = problem_config['time_domain']
        self.params = problem_config.get('parameters', {})
        self.time_inputs_template = problem_config.get('time_varying_inputs', {})
        self.param_space = problem_config['function_parameter_space']

        self.lr, self.epochs, self.batch_size = hp['learning_rate'], hp['epochs'], hp['batch_size']
        self.num_time_steps = hp['num_time_steps']
        self.num_test_functions = hp['num_test_functions']
        self.loss_weights = hp['loss_weights']

        self.t_grid = torch.linspace(self.t_domain[0], self.t_domain[1], self.num_time_steps, device=self.device).view(1, -1, 1)
        self.dt = (self.t_domain[1] - self.t_domain[0]) / (self.num_time_steps - 1)

        activation_map = {"tanh": "tanh", "relu": "relu", "gelu": "gelu"}
        self.activation_fn = activation_map.get(hp['activation_function'], "gelu")

        self.d_model = tr_hp['d_model']
        self.nhead = tr_hp['nhead']
        self.num_encoder_layers = tr_hp['num_encoder_layers']
        self.dim_feedforward = tr_hp['dim_feedforward']
        self.dropout = tr_hp['dropout']
        
        self.input_dim = 1 + self.num_state_vars

    def _build_model(self):
        self.model = GalerkinTransformer(
            input_dim=self.input_dim, output_dim=self.num_state_vars, d_model=self.d_model, nhead=self.nhead,
            num_encoder_layers=self.num_encoder_layers, dim_feedforward=self.dim_feedforward,
            dropout=self.dropout, activation_fn=self.activation_fn
        ).to(self.device)

        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=self.epochs, eta_min=1e-7)

    def _precompute_test_functions(self):
        t_interior = self.t_grid[:, 1:-1, :].squeeze()
        t_scaled = 2.0 * (t_interior - self.t_domain[0]) / (self.t_domain[1] - self.t_domain[0]) - 1.0
        t_scaled_cpu = t_scaled.cpu().numpy()
        
        test_funcs = []
        for k in range(self.num_test_functions):
            coeffs = [0] * k + [1]
            w_k = legval(t_scaled_cpu, coeffs)
            test_funcs.append(torch.from_numpy(w_k).float())
        
        self.test_function_basis = torch.stack(test_funcs, dim=0).to(self.device)

    def _sample_input_functions(self, batch_size):
        sampled_params = {p: (r[0] + (r[1] - r[0]) * torch.rand(batch_size, 1, device=self.device))
                          for p, r in self.param_space.items()}

        eval_scope = {'t': self.t_grid.squeeze(-1), 'torch': torch, **sampled_params}
        template = self.time_inputs_template['CA0_t'].format(**{k: k for k in sampled_params})
        ca0_t = eval(template, {}, eval_scope).unsqueeze(-1)

        ic_tensors = [sampled_params[f"{var}_ic"] for var in self.state_vars]
        ics = torch.cat(ic_tensors, dim=-1).unsqueeze(1).expand(-1, self.num_time_steps, -1)
        
        model_input = torch.cat([ca0_t, ics], dim=-1)

        return {k: v.squeeze(-1) for k, v in sampled_params.items()}, model_input

    def _evaluate_time_varying_inputs(self, t, sampled_params):
        """Evaluate time-varying inputs at given time points"""
        eval_scope = {'t': t.squeeze(-1) if hasattr(t, 'squeeze') else t, 'torch': torch}
        for k, v in sampled_params.items():
            if hasattr(v, 'view'):
                eval_scope[k] = v.view(-1, 1)
            else:
                eval_scope[k] = v
        
        time_varying_values = {}
        for input_name, template in self.time_inputs_template.items():
            formatted_template = template.format(**{k: k for k in sampled_params})
            time_varying_values[input_name] = eval(formatted_template, {}, eval_scope)
        
        return time_varying_values

    def _get_ode_rhs(self, t, u, sampled_params):
        scope = {**self.params}
        
        for i, var in enumerate(self.state_vars):
            scope[var] = u[..., i]
        
        time_varying_values = self._evaluate_time_varying_inputs(t, sampled_params)
        scope.update(time_varying_values)

        rhs_list = []
        for var in self.state_vars:
            ode_expr = self.odes[f"d{var}dt"]
            rhs_value = eval(ode_expr, {}, scope)
            rhs_list.append(rhs_value)
        
        return torch.stack(rhs_list, dim=-1)

    def calculate_loss(self, sampled_params, model_input):
        u_pred = self.model(model_input)

        du_dt_pred = (u_pred[:, 2:, :] - u_pred[:, :-2, :]) / (2 * self.dt)
        
        u_pred_interior = u_pred[:, 1:-1, :]
        t_interior = self.t_grid[:, 1:-1, :]
        
        rhs = self._get_ode_rhs(t_interior, u_pred_interior, sampled_params)
        
        residuals = du_dt_pred - rhs
        
        basis_reshaped = self.test_function_basis.unsqueeze(0).unsqueeze(-1)
        integrand = basis_reshaped * residuals.unsqueeze(1)
        
        integrals = torch.trapezoid(integrand, x=t_interior.squeeze(), dim=2)
        loss_res = torch.mean(integrals**2)

        u_ic_pred = u_pred[:, 0, :]
        ic_targets = torch.stack([sampled_params[f"{var}_ic"] for var in self.state_vars], dim=1)
        loss_ic = torch.mean((u_ic_pred - ic_targets)**2)
        
        return loss_res, loss_ic

    def train(self):
        print(f"--- Starting training for {self.problem_name} ---")
        start_time = time.time()
        self.model.train()
        
        for epoch in range(self.epochs):
            self.optimizer.zero_grad()
            
            sampled_params, model_input = self._sample_input_functions(self.batch_size)
            
            loss_res, loss_ic = self.calculate_loss(sampled_params, model_input)
            total_loss = self.loss_weights['ode_residual'] * loss_res + self.loss_weights['initial_condition'] * loss_ic
            
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            self.scheduler.step()
            
            if (epoch + 1) % 5000 == 0 or epoch == 0:
                current_lr = self.scheduler.get_last_lr()[0]
                print(f'Epoch [{epoch+1}/{self.epochs}], Loss: {total_loss.item():.4e}, '
                      f'ODE: {loss_res.item():.4e}, IC: {loss_ic.item():.4e}, LR: {current_lr:.4e}')
        
        elapsed_time = time.time() - start_time
        print(f"--- Training finished in {elapsed_time:.2f} seconds ---")

    def solve_single_instance_numerically(self, t_eval, instance_params):
        y0 = [instance_params[f"{var}_ic"] for var in self.state_vars]
        
        def ode_system(t, y):
            scope = {'t': t, **self.params}
            for i, var in enumerate(self.state_vars): 
                scope[var] = y[i]
            
            eval_scope = {'t': t, 'sin': np.sin, 'cos': np.cos, **instance_params}
            
            for input_name, template in self.time_inputs_template.items():
                formatted_template = template.format(**{k: k for k in instance_params})
                numpy_expr = formatted_template.replace("torch.sin", "sin").replace("torch.cos", "cos")
                scope[input_name] = eval(numpy_expr, {}, eval_scope)

            return [eval(self.odes[f"d{var}dt"], {}, scope) for var in self.state_vars]
            
        sol = solve_ivp(ode_system, (self.t_domain[0], self.t_domain[1]), y0, 
                       dense_output=True, t_eval=t_eval, method='DOP853', 
                       rtol=1e-8, atol=1e-10)
        return sol.y.T

    def evaluate_and_plot_results(self):
        self.model.eval()
        results_dir = "results"
        os.makedirs(results_dir, exist_ok=True)
        base_filename = os.path.join(results_dir, self.problem_name.replace(' ', '_').lower())

        test_cases = [
            {'mean': 1.0, 'amp': 0.75, 'freq': 0.4, 'phase': 1.5, 'CA1_ic': 0.15, 'CA2_ic': 0.08},
            {'mean': 0.9, 'amp': 0.3, 'freq': 0.15, 'phase': 4.0, 'CA1_ic': 0.05, 'CA2_ic': 0.01},
            {'mean': 1.1, 'amp': 0.5, 'freq': 0.25, 'phase': 0.0, 'CA1_ic': 0.0, 'CA2_ic': 0.0},
        ]
        
        t_plot_np = self.t_grid.squeeze().cpu().numpy()

        for i, case_params in enumerate(test_cases):
            print(f"\n--- Evaluating Test Case {i+1}: {case_params} ---")

            eval_scope = {'t': self.t_grid.squeeze(), 'torch': torch, **case_params}
            template = self.time_inputs_template['CA0_t'].format(**{k: k for k in case_params})
            ca0_t_test = eval(template, {}, eval_scope).unsqueeze(0).unsqueeze(-1)
            
            ics_test = torch.tensor([[case_params[f"{var}_ic"] for var in self.state_vars]], device=self.device, dtype=torch.float32)
            ics_test = ics_test.unsqueeze(1).expand(-1, self.num_time_steps, -1)
            
            model_input_test = torch.cat([ca0_t_test, ics_test], dim=-1)
            
            with torch.no_grad():
                u_transformer = self.model(model_input_test).squeeze(0).cpu().numpy()

            u_numerical = self.solve_single_instance_numerically(t_plot_np, case_params)

            fig, axes = plt.subplots(self.num_state_vars, 2, figsize=(16, 5 * self.num_state_vars), sharex=True)
            if self.num_state_vars == 1: 
                axes = np.array([axes])

            for j, var in enumerate(self.state_vars):
                axes[j, 0].plot(t_plot_np, u_numerical[:, j], 'k-', label='Numerical', linewidth=2.5, alpha=0.8)
                axes[j, 0].plot(t_plot_np, u_transformer[:, j], 'r--', label='Galerkin Transformer', linewidth=2)
                axes[j, 0].set_ylabel(var)
                axes[j, 0].legend()
                axes[j, 0].set_title(f'Solution for {var}')
                axes[j, 0].grid(True, alpha=0.3)

                error = np.abs(u_numerical[:, j] - u_transformer[:, j])
                axes[j, 1].plot(t_plot_np, error, 'b-', linewidth=2)
                axes[j, 1].set_yscale('log')
                axes[j, 1].set_ylabel(f'Absolute Error')
                axes[j, 1].set_title(f'Error for {var}')
                axes[j, 1].grid(True, which="both", ls="--", alpha=0.3)

            axes[-1, 0].set_xlabel('Time (t)')
            axes[-1, 1].set_xlabel('Time (t)')
            
            fig.suptitle(f'Galerkin Transformer Generalization - Test Case {i+1}', fontsize=16)
            plt.tight_layout(rect=[0, 0.03, 1, 0.95])
            
            plot_filename = f"{base_filename}_test_case_{i+1}.pdf"
            plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
            plt.close(fig)
            print(f"Test case plot saved to {plot_filename}")

            for j, var in enumerate(self.state_vars):
                mse = np.mean((u_numerical[:, j] - u_transformer[:, j])**2)
                max_error = np.max(np.abs(u_numerical[:, j] - u_transformer[:, j]))
                print(f"  {var}: MSE = {mse:.6e}, Max Error = {max_error:.6e}")

def main():
    parser = argparse.ArgumentParser(description="Galerkin Transformer Solver for ODEs")
    parser.add_argument("config_file", type=str, nargs='?', default="problem_config.json", 
                       help="Path to the JSON configuration file.")
    args = parser.parse_args()
    
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in configuration file: {e}")
        return
    
    solver = GalerkinTransformerSolver(config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()