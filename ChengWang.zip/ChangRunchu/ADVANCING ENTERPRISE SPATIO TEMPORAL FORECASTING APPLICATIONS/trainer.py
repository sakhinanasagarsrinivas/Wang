import torch
import wandb
import numpy as np
from typing import Dict, List, Optional
from torch.utils.data import DataLoader
from metrics import MetricsCalculator

class Trainer:
    """Trainer class for MultiTsNet"""
    def __init__(
        self,
        model: torch.nn.Module,
        config: Dict,
        train_loader: DataLoader,
        val_loader: DataLoader,
        test_loader: DataLoader,
        device: torch.device
    ):
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.device = device
        
        # Initialize optimizer
        self.optimizer = torch.optim.Adam(
            model.parameters(),
            lr=config['training']['optimizer']['learning_rate'],
            weight_decay=config['training']['optimizer']['weight_decay']
        )
        
        # Learning rate scheduler
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            factor=config['training']['scheduler']['factor'],
            patience=config['training']['scheduler']['patience'],
            min_lr=config['training']['scheduler']['min_lr']
        )
        
        # Metrics calculator
        self.metrics = MetricsCalculator()
        
        # Training state
        self.current_epoch = 0
        self.best_val_loss = float('inf')
        self.early_stopping_counter = 0
        
    def train_epoch(self) -> Dict[str, float]:
        """Train for one epoch"""
        self.model.train()
        self.metrics.reset()
        total_loss = 0
        
        for batch_idx, (x, y) in enumerate(self.train_loader):
            x, y = x.to(self.device), y.to(self.device)
            
            # Forward pass
            self.optimizer.zero_grad()
            output = self.model(x)
            
            # Calculate loss
            if isinstance(output, dict):  # Uncertainty model
                loss = self.model.gaussian_nll_loss(output, y)
            else:
                loss = torch.nn.functional.mse_loss(output, y)
                
            # Backward pass
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(),
                self.config['training']['gradient_clip_norm']
            )
            
            self.optimizer.step()
            
            # Update metrics
            self.metrics.update(output, y)
            total_loss += loss.item()
            
            # Log batch metrics
            if batch_idx % self.config['logging']['log_interval'] == 0:
                wandb.log({
                    'batch_loss': loss.item(),
                    'learning_rate': self.optimizer.param_groups[0]['lr']
                })
                
        # Compute epoch metrics
        metrics = self.metrics.compute()
        metrics['loss'] = total_loss / len(self.train_loader)
        
        return metrics
        
    def validate(self) -> Dict[str, float]:
        """Validate model"""
        self.model.eval()
        self.metrics.reset()
        total_loss = 0
        
        with torch.no_grad():
            for x, y in self.val_loader:
                x, y = x.to(self.device), y.to(self.device)
                output = self.model(x)
                
                # Calculate loss
                if isinstance(output, dict):
                    loss = self.model.gaussian_nll_loss(output, y)
                else:
                    loss = torch.nn.functional.mse_loss(output, y)
                    
                self.metrics.update(output, y)
                total_loss += loss.item()
                
        # Compute validation metrics
        metrics = self.metrics.compute()
        metrics['loss'] = total_loss / len(self.val_loader)
        
        return metrics
    
    def test(self) -> Dict[str, float]:
        """Test model performance"""
        self.model.eval()
        self.metrics.reset()
        
        predictions = []
        targets = []
        
        with torch.no_grad():
            for x, y in self.test_loader:
                x, y = x.to(self.device), y.to(self.device)
                output = self.model(x)
                
                self.metrics.update(output, y)
                
                # Store predictions and targets for uncertainty analysis
                predictions.append(output)
                targets.append(y)
                
        # Compute test metrics
        metrics = self.metrics.compute()
        
        # Calculate horizon-wise metrics
        predictions = torch.cat(predictions, dim=0)
        targets = torch.cat(targets, dim=0)
        horizon_metrics = self.metrics.get_horizon_metrics(predictions, targets)
        
        # If uncertainty model, calculate uncertainty metrics
        if isinstance(output, dict):
            uncertainty_metrics = self.metrics.calculate_uncertainty_metrics(
                predictions, targets
            )
            metrics.update(uncertainty_metrics)
            
        metrics['horizon_metrics'] = horizon_metrics
        
        return metrics
    
    def train(self):
        """Main training loop"""
        for epoch in range(self.config['training']['epochs']):
            self.current_epoch = epoch
            
            # Training
            train_metrics = self.train_epoch()
            
            # Validation
            val_metrics = self.validate()
            
            # Learning rate scheduling
            self.scheduler.step(val_metrics['loss'])
            
            # Early stopping check
            if val_metrics['loss'] < self.best_val_loss:
                self.best_val_loss = val_metrics['loss']
                self.early_stopping_counter = 0
                # Save best model
                torch.save(
                    self.model.state_dict(),
                    f"checkpoints/{self.config['model']['name']}_best.pt"
                )
            else:
                self.early_stopping_counter += 1
                
            # Log epoch metrics
            wandb.log({
                'epoch': epoch,
                'train': train_metrics,
                'val': val_metrics,
                'lr': self.optimizer.param_groups[0]['lr']
            })
            
            # Early stopping
            if self.early_stopping_counter >= self.config['training']['early_stopping_patience']:
                print(f"Early stopping triggered at epoch {epoch}")
                break
                
        # Final test evaluation
        self.model.load_state_dict(
            torch.load(f"checkpoints/{self.config['model']['name']}_best.pt")
        )
        test_metrics = self.test()
        
        wandb.log({'test': test_metrics})
        return test_metrics