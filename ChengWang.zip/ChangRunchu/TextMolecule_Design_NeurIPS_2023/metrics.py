import torch
from rdkit import Chem
from rdkit.DataStructs import TanimotoSimilarity
from typing import List, Tuple
import numpy as np

class MoleculeMetrics:
    """Metrics for evaluating molecule generation performance"""
    
    @staticmethod
    def fingerprint_tanimoto_similarity(
        generated_smiles: List[str], 
        ground_truth_smiles: List[str]
    ) -> float:
        """
        Calculate Fingerprint Tanimoto Similarity
        
        Args:
            generated_smiles: List of generated SMILES
            ground_truth_smiles: List of ground truth SMILES
        
        Returns:
            Average Tanimoto similarity
        """
        similarities = []
        for gen_smi in generated_smiles:
            mol1 = Chem.MolFromSmiles(gen_smi)
            if mol1 is None:
                continue
            
            gen_fp = Chem.RDKFingerprint(mol1)
            
            mol_similarities = []
            for true_smi in ground_truth_smiles:
                mol2 = Chem.MolFromSmiles(true_smi)
                if mol2 is None:
                    continue
                
                true_fp = Chem.RDKFingerprint(mol2)
                similarity = TanimotoSimilarity(gen_fp, true_fp)
                mol_similarities.append(similarity)
            
            if mol_similarities:
                similarities.append(max(mol_similarities))
        
        return np.mean(similarities) if similarities else 0.0
    
    @staticmethod
    def levenshtein_distance(
        generated_smiles: List[str], 
        ground_truth_smiles: List[str]
    ) -> float:
        """
        Calculate average Levenshtein distance
        
        Args:
            generated_smiles: List of generated SMILES
            ground_truth_smiles: List of ground truth SMILES
        
        Returns:
            Average Levenshtein distance
        """
        def _levenshtein(s1: str, s2: str) -> int:
            if len(s1) < len(s2):
                return _levenshtein(s2, s1)
            
            if len(s2) == 0:
                return len(s1)
            
            previous_row = range(len(s2) + 1)
            for i, c1 in enumerate(s1):
                current_row = [i + 1]
                for j, c2 in enumerate(s2):
                    insertions = previous_row[j + 1] + 1
                    deletions = current_row[j] + 1
                    substitutions = previous_row[j] + (c1 != c2)
                    current_row.append(min(insertions, deletions, substitutions))
                previous_row = current_row
            
            return previous_row[-1]
        
        distances = []
        for gen_smi in generated_smiles:
            min_distance = min(
                _levenshtein(gen_smi, true_smi) 
                for true_smi in ground_truth_smiles
            )
            distances.append(min_distance)
        
        return np.mean(distances) if distances else float('inf')
    
    @staticmethod
    def validity_score(smiles_list: List[str]) -> float:
        """
        Calculate percentage of valid molecules
        
        Args:
            smiles_list: List of SMILES strings
        
        Returns:
            Percentage of valid molecules
        """
        valid_molecules = [
            Chem.MolFromSmiles(smi) is not None 
            for smi in smiles_list
        ]
        return np.mean(valid_molecules) if valid_molecules else 0.0