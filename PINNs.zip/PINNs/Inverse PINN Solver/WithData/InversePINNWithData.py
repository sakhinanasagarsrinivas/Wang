import torch
import torch.nn as nn
import numpy as np
import json
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import time
import os

torch.manual_seed(42)
np.random.seed(42)

class FourierEmbedding(nn.Module):
    def __init__(self, input_dims, embed_dims, scale=10.0):
        super(FourierEmbedding, self).__init__()
        self.input_dims = input_dims
        self.embed_dims = embed_dims
        self.scale = scale
        self.B = nn.Parameter(torch.randn(input_dims, embed_dims // 2) * self.scale, requires_grad=False)

    def forward(self, x):
        x_proj = 2 * np.pi * x @ self.B
        return torch.cat([torch.sin(x_proj), torch.cos(x_proj)], dim=-1)

class EnhancedPINN(nn.Module):
    def __init__(self, num_inputs, num_outputs, hidden_layers, neurons_per_layer, activation_fn, t_domain, use_fourier=True, fourier_dims=64):
        super(EnhancedPINN, self).__init__()
        self.t_min, self.t_max = t_domain
        self.use_fourier = use_fourier

        if self.use_fourier:
            self.fourier_embedding = FourierEmbedding(num_inputs, fourier_dims)
            effective_input_dims = fourier_dims
        else:
            effective_input_dims = num_inputs
        
        self.input_transform = nn.Linear(effective_input_dims, neurons_per_layer)
        self.input_activation = activation_fn()
        self.hidden_layers = nn.ModuleList()
        for i in range(hidden_layers):
            layer = nn.Linear(neurons_per_layer, neurons_per_layer)
            nn.init.xavier_uniform_(layer.weight)
            nn.init.zeros_(layer.bias)
            self.hidden_layers.append(layer)
        
        self.output_layer = nn.Linear(neurons_per_layer, num_outputs)
        nn.init.xavier_uniform_(self.output_layer.weight)
        nn.init.zeros_(self.output_layer.bias)
        self.activation = activation_fn()
        self.dropout = nn.Dropout(0.1)

    def forward(self, t):
        t_scaled = 2.0 * (t - self.t_min) / (self.t_max - self.t_min) - 1.0
        if self.use_fourier:
            x_embedded = self.fourier_embedding(t_scaled)
            x = self.input_activation(self.input_transform(x_embedded))
        else:
            x = self.input_activation(self.input_transform(t_scaled))
        
        for i, layer in enumerate(self.hidden_layers):
            residual = x
            x = layer(x)
            x = self.activation(x)
            if i > 0: 
                x = x + 0.1 * residual
            x = self.dropout(x)
        
        output = self.output_layer(x)
        return output

class InversePINNSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._build_model()
        self.best_loss = float('inf')
        self.patience_counter = 0
        self.max_patience = 5000
        self.persistent_collocation_points = None
        self.rar_update_freq = 2000 

    def _parse_config(self):
        self.problem_name = self.config['problem_name']
        self.state_vars = self.config['state_variables']
        self.odes = self.config['odes']
        self.t_domain = torch.tensor(self.config['time_domain'], device=self.device)
        self.params = self.config.get('parameters', {})
        self.time_inputs = self.config.get('time_varying_inputs', {})
        self.ic_values = torch.tensor(
            [self.config['initial_conditions'][var] for var in self.state_vars],
            device=self.device
        ).float()
        
        self.learnable_params_config = self.config.get('learnable_parameters', {})
        self.learnable_params = nn.ParameterDict()
        self.true_params = {}
        for name, info in self.learnable_params_config.items():
            initial_guess = info['initial_guess']
            self.learnable_params[name] = nn.Parameter(torch.tensor(initial_guess, device=self.device).float())
            if 'true_value' in info:
                self.true_params[name] = info['true_value']
        
        hp = self.config['hyperparameters']
        self.hidden_layers = hp['hidden_layers']
        self.neurons_per_layer = hp['neurons_per_layer']
        self.lr = hp['learning_rate']
        self.lr_params = hp.get('parameter_learning_rate', self.lr * 5)
        self.epochs = hp['epochs']
        self.num_collocation = hp['num_collocation_points']
        self.loss_weights = hp['loss_weights']
        
        activation_map = {"tanh": nn.Tanh, "relu": nn.ReLU, "sigmoid": nn.Sigmoid, "silu": nn.SiLU}
        self.activation_fn = activation_map.get(hp['activation_function'], nn.Tanh)
        
        self.data_tensors = {}
        data_section = self.config.get('data', {})
        for var, points in data_section.items():
            if var.startswith('_') or not isinstance(points, list) or not points:
                continue
            if all(isinstance(p, (list, tuple)) and len(p) == 2 for p in points):
                tensor = torch.tensor(points, device=self.device).float()
                self.data_tensors[var] = (tensor[:, 0:1], tensor[:, 1:2])

    def _build_model(self):
        self.model = EnhancedPINN(
            num_inputs=1, num_outputs=len(self.state_vars), 
            hidden_layers=self.hidden_layers, neurons_per_layer=self.neurons_per_layer, 
            activation_fn=self.activation_fn, t_domain=self.t_domain.cpu().numpy(),
            use_fourier=True, fourier_dims=64
        ).to(self.device)
        
        optimizer_params = [{'params': self.model.parameters(), 'lr': self.lr}]
        if self.learnable_params:
             optimizer_params.append({'params': self.learnable_params.parameters(), 'lr': self.lr_params})

        self.optimizer = torch.optim.AdamW(optimizer_params, weight_decay=1e-6, betas=(0.9, 0.999))
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(self.optimizer, mode='min', factor=0.8, patience=2000, min_lr=1e-7)

    def _get_eval_scope(self, t, u=None):
        scope = {'t': t}
        if u is not None:
            for i, var in enumerate(self.state_vars):
                scope[var] = u[:, i:i+1]
        
        scope.update(self.params)
        scope.update(self.learnable_params)
        
        time_input_scope = {'t': t, 'sin': torch.sin, 'cos': torch.cos, 'exp': torch.exp, 'pi': torch.pi}
        for name, expr in self.time_inputs.items():
            scope[name] = eval(expr, {}, time_input_scope)
        return scope

    def _calculate_ode_residuals(self, t):
        t.requires_grad_(True)
        u = self.model(t)
        scope = self._get_eval_scope(t, u)
        
        total_residuals_per_point = torch.zeros_like(t)
        for i, var in enumerate(self.state_vars):
            du_dt = torch.autograd.grad(outputs=u[:, i], inputs=t, grad_outputs=torch.ones_like(u[:, i]), create_graph=True, retain_graph=True)[0]
            ode_key = f"d{var}dt"
            if ode_key in self.odes:
                rhs = eval(self.odes[ode_key], {}, scope)
                residual = du_dt - rhs
                total_residuals_per_point += residual**2
        return total_residuals_per_point

    def _ode_residual_loss(self, t):
        residuals_per_point = self._calculate_ode_residuals(t)
        return torch.mean(residuals_per_point)

    def _ic_loss(self):
        t_ic = self.t_domain[0].reshape(-1, 1)
        u_ic_pred = self.model(t_ic)
        return torch.mean((u_ic_pred.squeeze() - self.ic_values)**2)

    def _data_loss(self):
        total_data_loss = 0.0
        if not self.data_tensors:
            return torch.tensor(0.0, device=self.device)
        
        num_data_terms = 0
        for var, (t_data, y_data) in self.data_tensors.items():
            var_index = self.state_vars.index(var)
            y_pred = self.model(t_data)[:, var_index:var_index+1]
            mse_loss = torch.mean((y_pred - y_data)**2)
            mae_loss = torch.mean(torch.abs(y_pred - y_data))
            total_data_loss += mse_loss + 0.1 * mae_loss
            num_data_terms += 1
        return total_data_loss / num_data_terms if num_data_terms > 0 else torch.tensor(0.0, device=self.device)
    
    def _update_collocation_with_rar(self, num_new_points=100):
        print(f"  -> Performing RAR: Searching for {num_new_points} new hard points...")
        self.model.eval()
        
        num_candidates = 10 * self.num_collocation
        candidate_t = torch.linspace(self.t_domain[0], self.t_domain[1], num_candidates, device=self.device).view(-1, 1)

        residuals = self._calculate_ode_residuals(candidate_t)
        residuals_detached = residuals.detach()
        
        _, top_indices = torch.topk(residuals_detached.flatten(), num_new_points)
        new_hard_points = candidate_t[top_indices].detach()
        
        if self.persistent_collocation_points is None:
            self.persistent_collocation_points = new_hard_points
        else:
            combined_points = torch.cat([self.persistent_collocation_points, new_hard_points])
            self.persistent_collocation_points = torch.unique(combined_points, sorted=True).view(-1, 1)

        print(f"  -> RAR complete. Total persistent points: {len(self.persistent_collocation_points)}")
        self.model.train()

    def _generate_adaptive_collocation_points(self, epoch):
        if self.persistent_collocation_points is None:
            return self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(self.num_collocation, 1, device=self.device)
        
        num_persistent = len(self.persistent_collocation_points)
        num_random_needed = self.num_collocation - num_persistent
        
        if num_random_needed > 0:
            random_t = self.t_domain[0] + (self.t_domain[1] - self.t_domain[0]) * torch.rand(num_random_needed, 1, device=self.device)
            collocation_t = torch.cat([self.persistent_collocation_points, random_t])
        else:
            indices = torch.randperm(num_persistent)[:self.num_collocation]
            collocation_t = self.persistent_collocation_points[indices]
        return collocation_t

    def train(self):
        print(f"--- Starting Inverse PINN training for {self.problem_name} ---")
        start_time = time.time()
        self.model.train()
        
        final_data_weight = self.loss_weights.get('data', 1.0)
        data_weight_annealing_epochs = self.epochs // 3 

        for epoch in range(self.epochs):
            if epoch > 0 and epoch % self.rar_update_freq == 0:
                self._update_collocation_with_rar(num_new_points=self.num_collocation // 10)

            self.optimizer.zero_grad()
            collocation_t = self._generate_adaptive_collocation_points(epoch)
            
            loss_res = self._ode_residual_loss(collocation_t)
            loss_ic = self._ic_loss()
            loss_data = self._data_loss()
            current_data_weight = final_data_weight * min(1.0, epoch / data_weight_annealing_epochs)
            
            total_loss = (self.loss_weights['ode_residual'] * loss_res + self.loss_weights['initial_condition'] * loss_ic + current_data_weight * loss_data)
            
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            self.scheduler.step(total_loss)
            
            if total_loss.item() < self.best_loss:
                self.best_loss = total_loss.item()
                self.patience_counter = 0
            else:
                self.patience_counter += 1
            
            if (epoch + 1) % 2000 == 0:
                print(f'Epoch [{epoch+1}/{self.epochs}], Loss: {total_loss.item():.4e}, ODE: {loss_res.item():.4e}, IC: {loss_ic.item():.4e}, Data: {loss_data.item():.4e}')
                if self.learnable_params:
                    param_estimates = {name: p.item() for name, p in self.learnable_params.items()}
                    print(f"  -> Param Estimates: { {k: f'{v:.4f}' for k, v in param_estimates.items()} }")

            if self.patience_counter > self.max_patience and epoch > 20000:
                print(f"Early stopping at epoch {epoch+1}")
                break
        
        elapsed_time = time.time() - start_time
        print(f"--- Training finished in {elapsed_time:.2f} seconds ---")

    def solve_with_numerical_integrator(self, t_eval):
        print("Solving with SciPy using TRUE parameters as a baseline...")
        t_span = self.t_domain.cpu().numpy()
        y0 = self.ic_values.cpu().numpy()
        
        true_params_for_solver = self.params.copy()
        true_params_for_solver.update(self.true_params)

        def ode_system(t, y):
            scope = {'t': t}
            for i, var in enumerate(self.state_vars):
                scope[var] = y[i]
            scope.update(true_params_for_solver)
            time_input_scope = {'t': t, 'sin': np.sin, 'cos': np.cos, 'exp': np.exp, 'pi': np.pi}
            for name, expr in self.time_inputs.items():
                scope[name] = eval(expr, {}, time_input_scope)
            dydt = [eval(self.odes[f"d{var}dt"], {}, scope) for var in self.state_vars]
            return dydt
        
        sol = solve_ivp(ode_system, t_span, y0, method='RK45', dense_output=True, t_eval=t_eval, rtol=1e-8, atol=1e-10)
        return sol.y.T

    def evaluate_and_plot_results(self):
        self.model.eval()
        os.makedirs("results", exist_ok=True)
        base_filename = f"results/{self.problem_name.replace(' ', '_').lower()}"
        
        if self.learnable_params:
            print("\n--- Parameter Estimation Results ---")
            for name, p in self.learnable_params.items():
                true_val_str = ""
                if name in self.true_params:
                    true_val = self.true_params[name]
                    error = 100 * abs(p.item() - true_val) / abs(true_val) if abs(true_val) > 1e-9 else float('inf')
                    true_val_str = f" (True: {true_val:.4f}, Error: {error:.2f}%)"
                print(f"Estimated {name}: {p.item():.6f}{true_val_str}")
        
        t_plot = torch.linspace(self.t_domain[0], self.t_domain[1], 1000).view(-1, 1).to(self.device)
        with torch.no_grad():
            u_pinn = self.model(t_plot).cpu().numpy()
        
        t_plot_np = t_plot.cpu().numpy().flatten()
        u_numerical = self.solve_with_numerical_integrator(t_eval=t_plot_np)
        
        num_vars = len(self.state_vars)
        fig, axes = plt.subplots(num_vars, 1, figsize=(12, 6 * num_vars), sharex=True)
        if num_vars == 1: axes = [axes]
        
        for i, var in enumerate(self.state_vars):
            axes[i].plot(t_plot_np, u_numerical[:, i], 'k-', label='Ground Truth (from true params)', linewidth=2.5)
            axes[i].plot(t_plot_np, u_pinn[:, i], 'r--', label='Inverse PINN Solution', linewidth=2)
            if var in self.data_tensors:
                t_data, y_data = self.data_tensors[var]
                axes[i].plot(t_data.cpu().numpy(), y_data.cpu().numpy(), 'bo', markersize=8, mfc='lightblue', label=f'Measurement Data for {var}')
            axes[i].set_ylabel(var, fontsize=14)
            axes[i].legend(fontsize=12)
            axes[i].grid(True, which='both', linestyle='--', alpha=0.6)
        
        axes[-1].set_xlabel('Time (t)', fontsize=14)
        fig.suptitle(f'Inverse PINN vs. Ground Truth for "{self.problem_name}"', fontsize=16)
        plt.savefig(f"{base_filename}_solution.pdf", format='pdf', bbox_inches='tight', dpi=300)
        plt.close(fig)
        
        error = np.abs(u_pinn - u_numerical)
        print("\n--- Solution Error Analysis (vs. Ground Truth) ---")
        for i, var in enumerate(self.state_vars):
            print(f"{var}: Mean Absolute Error = {np.mean(error[:, i]):.6e}")

def main():
    config_file = "problem_config.json"
    try:
        with open(config_file, 'r') as f:
            full_config = json.load(f)
        
        config = full_config['problems'][0]
        config['hyperparameters'] = full_config['hyperparameters']
        config['problem_name'] = config.pop('problem_id')

    except FileNotFoundError:
        print(f"Error: Configuration file '{config_file}' not found.")
        return
    
    solver = InversePINNSolver(config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()