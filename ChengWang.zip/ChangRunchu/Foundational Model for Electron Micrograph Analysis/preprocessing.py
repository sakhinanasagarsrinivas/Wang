import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
import json
from transformers import LlamaTokenizer

class MAEMIDataset(Dataset):
    """Dataset class for MAEMI training"""
    def __init__(self, data_path, image_dir, tokenizer, config, split='train'):
        self.config = config
        self.tokenizer = tokenizer
        self.data = self.load_data(data_path)
        self.image_transforms = self.get_transforms(split)
        
    def load_data(self, data_path):
        with open(data_path, 'r') as f:
            return json.load(f)
    
    def get_transforms(self, split):
        if split == 'train':
            return transforms.Compose([
                transforms.RandomResizedCrop(224),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                  std=[0.229, 0.224, 0.225])
            ])
        else:
            return transforms.Compose([
                transforms.Resize(256),
                transforms.CenterCrop(224),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                  std=[0.229, 0.224, 0.225])
            ])
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        # Load and transform image
        image = Image.open(item['image_path']).convert('RGB')
        image = self.image_transforms(image)
        
        # Tokenize instruction
        encoded = self.tokenizer.encode_plus(
            item['instruction'],
            max_length=self.config.max_seq_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'pixel_values': image,
            'input_ids': encoded['input_ids'].squeeze(),
            'attention_mask': encoded['attention_mask'].squeeze(),
            'task_type': item['task_type']
        }
