import os
import torch
import yaml
import wandb
import argparse
from typing import Dict, Optional
from datetime import datetime

from loader import DatasetLoader
from multits_net import MultiTsNet, UncertainMultiTsNet
from trainer import Trainer
from utils import set_seed, setup_logging, create_experiment_dir

def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='MultiTsNet Training')
    parser.add_argument('--config', type=str, default='config.yaml', help='Path to config file')
    parser.add_argument('--gpu', type=int, default=0, help='GPU device ID')
    parser.add_argument('--uncertainty', action='store_true', help='Use uncertainty model variant')
    parser.add_argument('--exp_name', type=str, default=None, help='Experiment name')
    return parser.parse_args()

def load_config(config_path: str) -> Dict:
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config

def setup_experiment(config: Dict, args) -> str:
    """Setup experiment directory and logging"""
    # Create experiment name
    exp_name = args.exp_name or f"{config['model']['name']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    # Setup directories
    exp_dir = create_experiment_dir(config, exp_name)
    
    # Initialize wandb
    wandb.init(
        project=config['logging']['wandb']['project'],
        name=exp_name,
        config=config,
        tags=config['logging']['wandb']['tags']
    )
    
    # Setup logging
    setup_logging(config, exp_dir)
    
    return exp_dir

def main():
    # Parse arguments and load config
    args = parse_args()
    config = load_config(args.config)
    
    # Set random seed
    set_seed(config.get('seed', 42))
    
    # Setup experiment
    exp_dir = setup_experiment(config, args)
    
    # Set device
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    
    # Initialize dataset loader
    data_loader = DatasetLoader(config)
    
    # Train on each dataset
    for dataset_name in config['datasets']['names']:
        print(f"\nTraining on dataset: {dataset_name}")
        
        # Load dataset
        train_loader, val_loader, test_loader = data_loader.load_dataset(dataset_name)
        
        # Initialize model
        if args.uncertainty:
            model = UncertainMultiTsNet(config)
        else:
            model = MultiTsNet(config)
        model = model.to(device)
        
        # Initialize trainer
        trainer = Trainer(
            model=model,
            config=config,
            train_loader=train_loader,
            val_loader=val_loader,
            test_loader=test_loader,
            device=device
        )
        
        # Training
        trainer.train()
        
        # Testing
        test_metrics = trainer.test()
        
        # Save results
        results_path = os.path.join(exp_dir, f"{dataset_name}_results.yaml")
        with open(results_path, 'w') as f:
            yaml.dump(test_metrics, f)
        
        print(f"\nResults for {dataset_name}:")
        print(f"MAE: {test_metrics['MAE']:.4f}")
        print(f"RMSE: {test_metrics['RMSE']:.4f}")
        print(f"MAPE: {test_metrics['MAPE']:.4f}")
        
        if args.uncertainty:
            print(f"NLL: {test_metrics['NLL']:.4f}")
            print(f"PICP: {test_metrics['PICP']:.4f}")

if __name__ == "__main__":
    main()