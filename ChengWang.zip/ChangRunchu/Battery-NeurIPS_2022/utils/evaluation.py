

# utils/evaluation.py
class Evaluator:
    """
    Evaluation metrics implementation following Section 4.2
    """
    def __init__(self):
        self.metrics = {
            'rmse': self.rmse,
            'mae': self.mae
        }

    @staticmethod
    def rmse(pred, target):
        return torch.sqrt(torch.mean((pred - target) ** 2))

    @staticmethod
    def mae(pred, target):
        return torch.mean(torch.abs(pred - target))
    
    def evaluate_model(self, model, data_loader, uncertainty=False):
        model.eval()
        predictions = []
        targets = []
        variances = [] if uncertainty else None
        
        with torch.no_grad():
            for batch_x, batch_y in data_loader:
                if uncertainty:
                    mu, log_var = model(batch_x)
                    predictions.append(mu)
                    variances.append(torch.exp(log_var))
                else:
                    pred = model(batch_x)
                    predictions.append(pred)
                targets.append(batch_y)
        
        predictions = torch.cat(predictions)
        targets = torch.cat(targets)
        
        metrics = {
            'rmse': self.rmse(predictions, targets).item(),
            'mae': self.mae(predictions, targets).item()
        }
        
        if uncertainty:
            variances = torch.cat(variances)
            metrics.update(self._compute_uncertainty_metrics(predictions, variances, targets))
        
        return metrics

    def _compute_uncertainty_metrics(self, mu, var, target):
        std = torch.sqrt(var)
        within_1_std = torch.mean(((target >= mu - std) & (target <= mu + std)).float())
        within_2_std = torch.mean(((target >= mu - 2*std) & (target <= mu + 2*std)).float())
        
        return {
            'calibration_1_std': within_1_std.item(),
            'calibration_2_std': within_2_std.item()
        }
