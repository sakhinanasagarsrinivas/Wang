from typing import Dict, Any, List
import logging
from .metrics import Metrics

class Evaluator:
    def __init__(self):
        self.metrics = Metrics()
        
    def evaluate(self, predictions: List[Dict[str, Any]], 
                references: List[Dict[str, Any]]) -> Dict[str, float]:
        """Evaluate model predictions"""
        try:
            results = {
                'tool_usage_awareness': self.metrics.calculate_tool_usage_awareness(
                    predictions, references
                ),
                'pass_rate': self.metrics.calculate_pass_rate(
                    predictions, references
                ),
                'accuracy': self.metrics.calculate_accuracy(
                    predictions, references
                )
            }
            
            # Add tool selection metrics if available
            if 'tool_selections' in predictions[0]:
                results.update({
                    'recall@k': self.metrics.calculate_recall_at_k(
                        [p['tool_selections'] for p in predictions],
                        [r['tool_selections'] for r in references],
                        k=5
                    ),
                    'ndcg': self.metrics.calculate_ndcg(
                        [p['tool_selections'] for p in predictions],
                        [r['tool_selections'] for r in references],
                        k=5
                    )
                })
                
            return results
            
        except Exception as e:
            logging.error(f"Error in evaluation: {str(e)}")
            return {}
            
    def generate_report(self, evaluation_results: Dict[str, float]) -> str:
        """Generate evaluation report"""
        report = "Evaluation Results:\n"
        report += "=" * 50 + "\n\n"
        
        for metric, value in evaluation_results.items():
            report += f"{metric}: {value:.4f}\n"
            
        return report