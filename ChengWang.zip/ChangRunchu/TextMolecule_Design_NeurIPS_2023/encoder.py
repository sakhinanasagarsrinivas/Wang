import torch
import torch.nn as nn
from transformers import AutoModel
from typing import Dict, Tuple

class DualEncoder(nn.Module):
    """Encoder for both original text and explanations"""
    
    def __init__(
        self,
        pretrained_model: str,
        embedding_dim: int,
        dropout: float = 0.1
    ):
        super().__init__()
        
        # Load pre-trained model for both encoders
        self.org_encoder = AutoModel.from_pretrained(pretrained_model)
        self.exp_encoder = AutoModel.from_pretrained(pretrained_model)
        
        # Projection layers
        hidden_size = self.org_encoder.config.hidden_size
        self.org_projection = nn.Sequential(
            nn.Linear(hidden_size, embedding_dim),
            nn.LayerNorm(embedding_dim),
            nn.Dropout(dropout)
        )
        self.exp_projection = nn.Sequential(
            nn.Linear(hidden_size, embedding_dim),
            nn.LayerNorm(embedding_dim),
            nn.Dropout(dropout)
        )
        
        # Weighted pooling
        self.org_attention = nn.Linear(embedding_dim, 1)
        self.exp_attention = nn.Linear(embedding_dim, 1)
        
    def weighted_pooling(
        self,
        embeddings: torch.Tensor,
        attention_layer: nn.Module
    ) -> torch.Tensor:
        """Apply weighted pooling to sequence embeddings"""
        weights = torch.softmax(attention_layer(embeddings), dim=1)
        pooled = torch.sum(weights * embeddings, dim=1)
        return pooled
        
    def forward(
        self,
        org_input: Dict[str, torch.Tensor],
        exp_input: Dict[str, torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through both encoders
        
        Args:
            org_input: Original text input tensors
            exp_input: Explanation text input tensors
            
        Returns:
            Tuple of (original embeddings, explanation embeddings)
        """
        # Encode original text
        org_outputs = self.org_encoder(**org_input)
        org_hidden = org_outputs.last_hidden_state
        org_projected = self.org_projection(org_hidden)
        org_pooled = self.weighted_pooling(org_projected, self.org_attention)
        
        # Encode explanations
        exp_outputs = self.exp_encoder(**exp_input)
        exp_hidden = exp_outputs.last_hidden_state
        exp_projected = self.exp_projection(exp_hidden)
        exp_pooled = self.weighted_pooling(exp_projected, self.exp_attention)
        
        return org_pooled, exp_pooled

class PredictionEncoder(nn.Module):
    """Encoder for SMILES predictions"""
    
    def __init__(self, vocab_size: int, embedding_dim: int):
        super().__init__()
        
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.encoder = nn.LSTM(
            embedding_dim,
            embedding_dim // 2,
            num_layers=2,
            bidirectional=True,
            batch_first=True
        )
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through prediction encoder
        
        Args:
            x: Input tensor of token indices
            
        Returns:
            Encoded predictions
        """
        embedded = self.embedding(x)
        outputs, (hidden, _) = self.encoder(embedded)
        
        # Concatenate bidirectional outputs
        hidden = torch.cat([hidden[-2], hidden[-1]], dim=1)
        return hidden