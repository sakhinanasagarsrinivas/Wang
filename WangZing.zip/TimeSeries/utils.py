
import os
import torch
import logging
import warnings
import numpy as np
import pandas as pd
import torch.nn as nn
import seaborn as sns
import torch.nn.init as init
from scipy.stats import zscore
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from scipy.stats import gaussian_kde
from os.path import dirname, abspath, exists
from sklearn.preprocessing import OneHotEncoder
from typing import Dict, List, Union, Tuple


def create_synthetic_folder(base_path):
    """Creates a 'Synthetic' subfolder, handling potential errors, and returns the path.

    Args:
        base_path: The base directory path.

    Returns:
        The full path to the 'Synthetic' folder, or None if an error occurred.
    """
    synthetic_path = os.path.join(base_path, 'Synthetic')
    try:
        os.makedirs(synthetic_path, exist_ok=True)
        logging.info(f"Created directory: {synthetic_path}")
        return synthetic_path  # Return the path here
    except OSError as e:
        logging.error(f"Error creating directory '{synthetic_path}': {e}")
        return None  # Indicate failure by returning None


def split_data(data, test_size=0.2):
    """
    Split time series data into train and test sets while preserving temporal order.

    Args:
        data (pd.DataFrame or np.ndarray): The time series data to split.
        test_size (float): The proportion of data to use for testing.

    Returns:
        tuple: (train_data, test_data)
            Train and test data sets as the same type as the input.
    """
    split_index = int(len(data) * (1 - test_size))  # Calculate the split point
    
    # Handle both Pandas DataFrame and NumPy array
    if isinstance(data, pd.DataFrame):
        train_data = data.iloc[:split_index]
        test_data = data.iloc[split_index:]
    elif isinstance(data, np.ndarray):
        train_data = data[:split_index]
        test_data = data[split_index:]
    else:
        raise ValueError("Unsupported data type. Expected Pandas DataFrame or NumPy array.")
    
    return train_data, test_data


def one_hot_encode(df, discrete_columns, continuous_columns):
    """
    Applies One-Hot Encoding to discrete columns and combines them with continuous columns.

    Parameters:
        - df (DataFrame): Original data as a Pandas DataFrame.
        - discrete_columns (list): List of column names to be one-hot encoded.
        - continuous_columns (list): List of column names that are continuous.

    Returns:
        - preprocessed_df (numpy.ndarray): Array containing one-hot encoded discrete columns and continuous columns.
        - encoded_columns_indices_mapping (dict): Mapping of original discrete columns to one-hot encoded column indices.
        - one_hot_encoder (OneHotEncoder): Fitted OneHotEncoder object.
        - discrete_columns (list): List of discrete columns used for encoding.

    Raises:
        - ValueError: If any of the specified columns are missing from the DataFrame.
        - RuntimeError: If any error occurs during the one-hot encoding process.
    """
    # Initialize OneHotEncoder
    one_hot_encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
    
    try:
        # Apply One-Hot Encoding to the discrete columns
        if discrete_columns:
            # Ensure that all discrete columns are present in the DataFrame
            missing_columns = [col for col in discrete_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"The following discrete columns are missing from the DataFrame: {missing_columns}")

            # Fit and transform the discrete columns using OneHotEncoder
            one_hot_encoded = one_hot_encoder.fit_transform(df[discrete_columns])
            one_hot_encoded_columns = one_hot_encoder.get_feature_names_out(discrete_columns)
            one_hot_encoded_df = pd.DataFrame(one_hot_encoded, columns=one_hot_encoded_columns, index=df.index)

            # Create a mapping from the original discrete columns to one-hot encoded column indices
            start_idx = len(continuous_columns)  # Start after the continuous columns
            encoded_columns_indices_mapping = {}
            
            for col in discrete_columns:
                # Get the number of one-hot encoded columns for the current column
                num_encoded_cols = len([name for name in one_hot_encoded_columns if name.startswith(f"{col}_")])
                # Filter one_hot_encoded_columns for columns that start with the specific prefix
                # matching_columns = [name for name in one_hot_encoded_columns if name.startswith(f"{col}_")]
                # print(f"{col}: {matching_columns}")

                # Store the indices for the one-hot encoded columns for the current column
                end_idx = start_idx + num_encoded_cols
                encoded_columns_indices_mapping[col] = list(range(start_idx, end_idx))

                # Update start index for next discrete column
                start_idx = end_idx
        else:
            one_hot_encoded_df = pd.DataFrame(index=df.index)
            encoded_columns_indices_mapping = {}

        # Extract continuous columns
        if continuous_columns:
            # Ensure that all continuous columns are present in the DataFrame
            missing_columns = [col for col in continuous_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"The following continuous columns are missing from the DataFrame: {missing_columns}")
            continuous_df = df[continuous_columns]
        else:
            continuous_df = pd.DataFrame(index=df.index)

        # Combine one-hot encoded columns and continuous columns
        preprocessed_df = pd.concat([continuous_df, one_hot_encoded_df], axis=1)

    except ValueError as ve:
        raise ve  # Re-raise ValueErrors for missing columns
    except Exception as e:
        raise RuntimeError(f"An error occurred during one-hot encoding: {str(e)}")

    return preprocessed_df.values, encoded_columns_indices_mapping, one_hot_encoder, discrete_columns


def decode_one_hot(preprocessed_array, encoded_columns_indices_mapping, one_hot_encoder, discrete_columns):
    """
    Decodes one-hot encoded columns back to their original discrete values.

    Parameters:
        - preprocessed_array (np.array): The array containing the one-hot encoded and continuous data.
        - encoded_columns_indices_mapping (dict): Mapping of original discrete columns to one-hot encoded column indices.
        - one_hot_encoder (OneHotEncoder): The fitted OneHotEncoder used for encoding.
        - discrete_columns (list): List of original discrete column names.

    Returns:
        - decoded_array (np.array): NumPy array with decoded discrete columns and continuous columns.
    """

    try:
        # Validate input types
        if not isinstance(preprocessed_array, np.ndarray):
            raise TypeError("preprocessed_array must be a NumPy array.")
        if not isinstance(encoded_columns_indices_mapping, dict):
            raise TypeError("encoded_columns_indices_mapping must be a dictionary.")
        if not hasattr(one_hot_encoder, 'inverse_transform'):
            raise TypeError("one_hot_encoder must be a fitted OneHotEncoder instance.")
        if not isinstance(discrete_columns, list):
            raise TypeError("discrete_columns must be a list of column names.")

        # Extract indices of all one-hot encoded columns
        all_one_hot_indices = [idx for indices in encoded_columns_indices_mapping.values() for idx in indices]

        # Ensure that the extracted indices are valid
        if any(idx >= preprocessed_array.shape[1] for idx in all_one_hot_indices):
            raise IndexError("One or more indices in encoded_columns_indices_mapping exceed the number of columns in preprocessed_array.")

        # Extract one-hot encoded data for all discrete columns at once
        one_hot_encoded_data = preprocessed_array[:, all_one_hot_indices]

        # Clip values to be within valid range for one-hot encoding (0 or 1)
        one_hot_encoded_data_clipped = np.clip(one_hot_encoded_data, 0, 1)

        # Use one_hot_encoder to decode all one-hot encoded columns back to original values
        decoded_discrete_values = one_hot_encoder.inverse_transform(one_hot_encoded_data_clipped)

        # Create a DataFrame for the decoded discrete columns
        decoded_df = pd.DataFrame(decoded_discrete_values, columns=discrete_columns)

        # Extract continuous columns
        continuous_indices = [i for i in range(preprocessed_array.shape[1]) if i not in all_one_hot_indices]
        continuous_data = preprocessed_array[:, continuous_indices]

        # Create a DataFrame for the continuous columns
        decoded_continuous_df = pd.DataFrame(continuous_data, columns=[f"Column_{i}" for i in continuous_indices])

        # Concatenate the decoded discrete columns and continuous columns
        decoded_df = pd.concat([decoded_continuous_df.reset_index(drop=True), decoded_df.reset_index(drop=True)], axis=1)

        # Convert the final DataFrame into a NumPy array
        return decoded_df.to_numpy()

    except TypeError as e:
        print(f"TypeError: {e}")
    except IndexError as e:
        print(f"IndexError: {e}")
    except ValueError as e:
        print(f"ValueError: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def smooth_2d_matrix(data_matrix, window_size=3, method='mean'):
    """
    Smooth a 2D data matrix across all variables using a sliding window.
    
    Parameters:
    -----------
    data_matrix : numpy.ndarray
        2D array of shape (n_samples, n_variables)
    window_size : int
        Size of the sliding window (must be odd)
    method : str
        Smoothing method: 'mean' or 'median'
        
    Returns:
    --------
    numpy.ndarray
        Smoothed data matrix of the same shape as input
    """
    if not isinstance(window_size, int) or window_size < 1 or window_size % 2 == 0:
        raise ValueError("Window size must be a positive odd integer")
        
    if window_size > data_matrix.shape[0]:
        raise ValueError("Window size cannot be larger than the number of data points")
    
    # Convert to numpy array if input is pandas DataFrame
    if isinstance(data_matrix, pd.DataFrame):
        data_matrix = data_matrix.values
    
    # Create output array
    smoothed_matrix = np.zeros_like(data_matrix)
    
    # Half window size for indexing
    half_window = window_size // 2
    
    # Iterate through each point
    for i in range(data_matrix.shape[0]):
        # Calculate window boundaries
        start_idx = max(0, i - half_window)
        end_idx = min(data_matrix.shape[0], i + half_window + 1)
        
        # Extract window for all variables
        window = data_matrix[start_idx:end_idx, :]
        
        # Apply smoothing method
        if method == 'mean':
            smoothed_matrix[i, :] = np.mean(window, axis=0)
        elif method == 'median':
            smoothed_matrix[i, :] = np.median(window, axis=0)
        else:
            raise ValueError("Method must be either 'mean' or 'median'")
    
    return smoothed_matrix     


def remove_outlier_rows(data, threshold=6.0):
    """
    Remove rows from the data array if any value in the row is an outlier based on the Z-score.

    Parameters:
    - data (numpy.ndarray): The input array from which rows with outliers will be removed.
    - threshold (float): The Z-score threshold to use for detecting outliers. Default is 3.

    Returns:
    - numpy.ndarray: A filtered version of the input array with rows containing outliers removed.
    """
    # Compute the Z-scores for each column
    z_scores = np.abs(zscore(data, axis=0))

    # Create a boolean mask where rows without outliers are marked as True
    mask = np.all(z_scores < threshold, axis=1)

    # Apply the mask to data to filter out rows with outliers
    filtered_data = data[mask]

    return filtered_data        

def get_discrete_ranges(config):
    """
    Generate discrete ranges for columns based on the provided configuration.

    Args:
        config (dict): Configuration dictionary containing mappings of column names to their original indices. 
                       Example:
                       {
                           'mappings': {
                               'Column_1': [27, 28, 29, 30, 31, 32, 33, 34],
                               'Column_2': [35, 36, 37, 38, 39, 40, 41, 42]
                           }
                       }

    Returns:
        list: A list of tuples representing discrete ranges for each column group.
              Each tuple is of the form (start, range_size, num_classes), where:
                - start is the starting column index for the range (starting from 0).
                - range_size is the number of columns in this range.
                - num_classes is the number of unique classes in this range (assumed equal to `range_size`).

    Raises:
        ValueError: If the provided config is missing the 'mappings' key or if any of the mappings are invalid.
        TypeError: If the provided config is not a dictionary or mappings are not lists.
    """
    if not isinstance(config, dict):
        raise TypeError("The 'config' argument must be a dictionary.")

    if 'mappings' not in config:
        raise ValueError("The configuration dictionary must contain a 'mappings' key.")

    if not isinstance(config['mappings'], dict):
        raise TypeError("The 'mappings' value must be a dictionary.")

    discrete_ranges = []
    start_column = 0  # Start numbering from 0

    # Iterate over each column mapping in the config
    for column_name, original_indices in config['mappings'].items():
        if not isinstance(original_indices, list):
            raise TypeError(f"The mapping for column '{column_name}' must be a list of indices.")

        if not all(isinstance(idx, int) for idx in original_indices):
            raise ValueError(f"All elements in the mapping for column '{column_name}' must be integers.")

        range_size = len(original_indices)  # Calculate the number of columns in this range
        num_classes = range_size  # Assume each column corresponds to a unique class
        discrete_ranges.append((start_column, range_size, num_classes))  # Append the range details
        start_column += range_size  # Update the starting column for the next range

    return discrete_ranges


def initialize_weights(layer):
    """Initializes weights of a neural network layer based on its type.

    Attributes:
      - layer: PyTorch layer instance for which weights need to be initialized.

    Supported Layers:
      - nn.Linear: Initializes with Xavier uniform distribution for weights; zeros for biases.
      - nn.Conv*: Initializes weights with normal distribution; biases with zeros if present.
      - nn.BatchNorm*: Initializes weights with normal distribution centered at 1; biases with zeros if present.
      - nn.GRU: Initializes GRU weights using Xavier for input-hidden connections, orthogonal for hidden-hidden; zeros for biases.
    
    Raises:
      - TypeError: If the input is not a PyTorch layer.
      - RuntimeError: If weight or bias initialization fails for any supported layer type.
      - AttributeError: If expected weight or bias attributes are missing.
    """
    # Verify that 'layer' is an instance of nn.Module to avoid unsupported types.
    if not isinstance(layer, nn.Module):
        raise TypeError(f"Expected layer to be an instance of nn.Module, but got {type(layer).__name__}.")

    layer_name = layer.__class__.__name__
    try:
        # Initialize for fully connected layers
        if isinstance(layer, nn.Linear):
            if not hasattr(layer, 'weight') or not isinstance(layer.weight, torch.Tensor):
                raise AttributeError(f"Expected 'weight' attribute of type torch.Tensor in {layer_name}.")
            init.xavier_uniform_(layer.weight)  # Xavier initialization for weights
            
            # Initialize bias if available
            if hasattr(layer, 'bias') and layer.bias is not None:
                if not isinstance(layer.bias, torch.Tensor):
                    raise AttributeError(f"Expected 'bias' attribute of type torch.Tensor in {layer_name}.")
                layer.bias.data.fill_(0)
        
        # Initialize for convolutional layers (supports nn.Conv1d, nn.Conv2d, nn.Conv3d, etc.)
        elif 'Conv' in layer_name:
            if hasattr(layer, 'weight') and isinstance(layer.weight, torch.Tensor):
                layer.weight.data.normal_(0.01, 0.020)  # Normal distribution initialization for weights
            else:
                raise AttributeError(f"Layer {layer_name} missing 'weight' attribute or has incorrect type.")

            # Initialize bias if available
            if hasattr(layer, 'bias') and layer.bias is not None:
                if not isinstance(layer.bias, torch.Tensor):
                    raise AttributeError(f"Expected 'bias' attribute of type torch.Tensor in {layer_name}.")
                layer.bias.data.fill_(0)
        
        # Initialize for normalization layers (supports nn.BatchNorm1d, nn.BatchNorm2d, etc.)
        elif 'Norm' in layer_name:
            if hasattr(layer, 'weight') and isinstance(layer.weight, torch.Tensor):
                layer.weight.data.normal_(1.00, 0.020)  # Normal distribution initialization centered at 1 for weights
            else:
                raise AttributeError(f"Layer {layer_name} missing 'weight' attribute or has incorrect type.")
            
            # Initialize bias if available
            if hasattr(layer, 'bias') and layer.bias is not None:
                if not isinstance(layer.bias, torch.Tensor):
                    raise AttributeError(f"Expected 'bias' attribute of type torch.Tensor in {layer_name}.")
                layer.bias.data.fill_(0)
        
        # Initialize for GRU layers
        elif "GRU" in layer_name:
            if not isinstance(layer, nn.GRU):
                raise TypeError(f"Layer provided is not an nn.GRU instance but {type(gru_layer).__name__}.")

            try:
                # Iterate over each parameter in the GRU layer
                for parameter_name, parameter_tensor in layer.named_parameters():
                    if parameter_tensor is None or not isinstance(parameter_tensor, torch.Tensor):
                        raise AttributeError(f"GRU layer parameter '{parameter_name}' must be a torch.Tensor.")

                    # Initialize based on parameter type within GRU layer
                    if 'weight_ih' in parameter_name:  # Handle input-hidden weights
                        init.xavier_uniform_(parameter_tensor)
                    elif 'weight_hh' in parameter_name:  # Handle hidden-hidden weights
                        init.orthogonal_(parameter_tensor)
                    elif 'bias' in parameter_name:  # Initialize bias terms
                        parameter_tensor.data.zero_()
                    else:
                        warnings.warn(f"Unknown parameter '{parameter_name}' in GRU layer. No initialization applied.")
            except Exception as e:
                raise RuntimeError(f"Error initializing GRU layer weights: {e}")

    except AttributeError as attr_err:
        raise AttributeError(f"Missing attribute in layer {layer_name}: {str(attr_err)}")
    except TypeError as type_err:
        raise TypeError(f"Type error in layer {layer_name}: {str(type_err)}")
    except Exception as e:
        raise RuntimeError(f"Error initializing weights for layer {layer_name}: {str(e)}")


class FeatureEmbedder(nn.Module):
    """Transforms input features into a latent embedding space using a GRU-based encoder.

    Attributes:
      - encoder_rnn: Recurrent layer for temporal encoding.
      - embedding_fc: Fully connected layer to project RNN outputs to the latent dimension.
      - activation_fn: Activation function applied to the final output.

    Attributes:
      - config: Object with attributes `input_dim`, `latent_dim`, and `rnn_layers`.

    Raises:
      - AttributeError: If required attributes are missing from the configuration.
      - TypeError: If attributes in config are not integers.
      - ValueError: If config values are not positive integers.
      - RuntimeError: If there is an error during initialization.
    """
    def __init__(self, config):
        super(FeatureEmbedder, self).__init__()
        try:
            # Check that all required configuration attributes are present, of type int, and positive.
            required_attrs = ['input_dim', 'latent_dim', 'rnn_layers']
            for attr in required_attrs:
                if attr not in config:
                    raise AttributeError(f"Configuration is missing required attribute '{attr}'.")
                if not isinstance(config[attr], int):
                    raise TypeError(f"Configuration attribute '{attr}' must be an integer.")
                if config[attr] <= 0:
                    raise ValueError(f"Configuration attribute '{attr}' must be a positive integer.")
            
            # Initialize RNN layer for temporal encoding
            self.encoder_rnn = nn.GRU(
                input_size=config['input_dim'],
                hidden_size=config['latent_dim'],
                num_layers=config['rnn_layers']
            )
            
            # Initialize fully connected layer for projecting to latent dimension
            self.embedding_fc = nn.Linear(config['latent_dim'], config['latent_dim'])
            
            # Activation function applied on the final output
            self.activation_fn = nn.Sigmoid()
            
            # Apply weight initialization function to all parameters
            self.apply(initialize_weights)
            
        except AttributeError as attr_err:
            raise AttributeError(f"Initialization error in FeatureEmbedder: {str(attr_err)}")
        except TypeError as type_err:
            raise TypeError(f"Type error in FeatureEmbedder configuration: {str(type_err)}")
        except ValueError as val_err:
            raise ValueError(f"Value error in FeatureEmbedder configuration: {str(val_err)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during FeatureEmbedder initialization: {str(e)}")

    def forward(self, instances, apply_activation=True):
        """Computes latent embeddings from input features.

        Attributes:
          - instances: Input tensor of shape (seq_len, batch_size, feature_dim).
          - apply_activation: Flag to apply sigmoid activation to output.

        Outputs:
          - embeddings: Latent representations of input.

        Raises:
          - TypeError: If instances is not a torch.Tensor.
          - ValueError: If instances tensor does not have the correct dimensions.
          - RuntimeError: If an error occurs during the forward pass.
        """
        # Check if inputs is a tensor and has the correct dimensions
        if not isinstance(instances, torch.Tensor):
            raise TypeError("Input to forward method must be a torch.Tensor.")
        
        if instances.dim() != 3:
            raise ValueError("Input tensor must be 3-dimensional (sequence_length, batch_size, feature_dimension).")
        
        # Validate that the last dimension of instances matches the expected feature dimension
        expected_feature_dim = self.encoder_rnn.input_size
        if instances.size(-1) != expected_feature_dim:
            raise ValueError(
                f"Expected input feature dimension of {expected_feature_dim}, but got {instances.size(-1)}."
            )

        try:
            # Pass inputs through the RNN layer
            encoded_output, _ = self.encoder_rnn(instances)
            
            # Pass the RNN output through the fully connected layer
            embeddings = self.embedding_fc(encoded_output)
            
            # Optionally apply the activation function
            if apply_activation:
                embeddings = self.activation_fn(embeddings)
        
        except Exception as e:
            raise RuntimeError(f"Encountered an issue during the forward operation in FeatureEmbedder: {str(e)}")
        
        return embeddings


class LatentSynthesizer(nn.Module):
    """Synthesis time-series data in the latent space.

    Attributes:
      - generator_rnn: GRU layer to produce embeddings from noise inputs.
      - generator_fc: Linear layer to map GRU outputs to desired latent dimension.
      - activation_fn: Activation function applied on the generated embeddings.

    Attributes:
      - config: Object with attributes `input_dim`, `latent_dim`, and `rnn_layers`.

    Raises:
      - AttributeError: If required attributes are missing from the configuration.
      - TypeError: If attributes in config are not integers.
      - ValueError: If config values are not positive integers.
      - RuntimeError: If there is an error during initialization.
    """
    def __init__(self, config):
        super(LatentSynthesizer, self).__init__()
        try:
            # Validate configuration attributes
            required_attrs = ['input_dim', 'latent_dim', 'rnn_layers']
            for attr in required_attrs:
                if attr not in config:
                    raise AttributeError(f"Configuration is missing required attribute '{attr}'.")
                if not isinstance(config[attr], int):
                    raise TypeError(f"Configuration attribute '{attr}' must be an integer.")
                if config[attr] <= 0:
                    raise ValueError(f"Configuration attribute '{attr}' must be a positive integer.")

            # Initialize GRU layer for generating embeddings
            self.generator_rnn = nn.GRU(
                input_size=config['input_dim'],
                hidden_size=config['latent_dim'],
                num_layers=config['rnn_layers']
            )
            
            # Initialize fully connected layer to map RNN output to latent space dimension
            self.generator_fc = nn.Linear(config['latent_dim'], config['latent_dim'])
            
            # Activation function applied on the generated embeddings
            self.activation_fn = nn.Sigmoid()
            
            # Apply weight initialization function to all parameters
            self.apply(initialize_weights)
        
        except AttributeError as attr_err:
            raise AttributeError(f"Initialization error in LatentSynthesizer: {str(attr_err)}")
        except TypeError as type_err:
            raise TypeError(f"Type error in LatentSynthesizer configuration: {str(type_err)}")
        except ValueError as val_err:
            raise ValueError(f"Value error in LatentSynthesizer configuration: {str(val_err)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during LatentSynthesizer initialization: {str(e)}")

    def forward(self, noise_input, apply_activation=True):
        """Synthesis synthetic embeddings based on input noise.

        Attributes:
          - noise_input: Input tensor of shape (seq_len, batch_size, input_dim).
          - apply_activation: Flag to apply sigmoid activation to output.

        Outputs:
          - generated_embeddings: Synthetic embeddings in the latent space.

        Raises:
          - TypeError: If noise_input is not a torch.Tensor.
          - ValueError: If noise_input tensor does not have the correct dimensions.
          - RuntimeError: If an error occurs during the forward pass.
        """
        # Check if noise_input is a tensor and has the correct dimensions
        if not isinstance(noise_input, torch.Tensor):
            raise TypeError("Input to forward method must be a torch.Tensor.")
        
        if noise_input.dim() != 3:
            raise ValueError("Input tensor must be 3-dimensional (sequence_length, batch_size, input_dim).")
        
        # Validate that the last dimension of noise_input matches the expected noise dimension
        expected_input_dim = self.generator_rnn.input_size
        if noise_input.size(-1) != expected_input_dim:
            raise ValueError(
                f"Expected input feature dimension of {expected_input_dim}, but got {noise_input.size(-1)}."
            )

        try:
            # Pass noise input through the GRU layer for generating embeddings
            generated_output, _ = self.generator_rnn(noise_input)
            
            # Pass the RNN output through the fully connected layer
            generated_embeddings = self.generator_fc(generated_output)
            
            # Optionally apply the activation function
            if apply_activation:
                generated_embeddings = self.activation_fn(generated_embeddings)
        
        except Exception as e:
            raise RuntimeError(f"Error during forward pass in LatentSynthesizer: {str(e)}")
        
        return generated_embeddings


class SequentialLatentForecaster(nn.Module):
    """Synthesis the next sequence in a latent space informed by the prior pattern.

    Attributes:
      - supervisor_rnn: Recurrent layer to generate sequential outputs.
      - sequence_fc: Fully connected layer to map RNN outputs to the latent dimension.
      - activation_fn: Activation function applied to the final generated sequence.

    Attributes:
      - config: Configuration dictionary with attributes `latent_dim` and `rnn_layers`.

    Raises:
      - AttributeError: If required attributes are missing from the configuration.
      - TypeError: If attributes in config are not integers.
      - ValueError: If config values are not positive integers.
      - RuntimeError: If there is an unexpected error during initialization.
    """
    def __init__(self, config):
        super(SequentialLatentForecaster, self).__init__()
        try:
            # Validate configuration attributes
            required_attrs = ['latent_dim', 'rnn_layers']
            for attr in required_attrs:
                if attr not in config:
                    raise AttributeError(f"Configuration is missing required attribute '{attr}'.")
                if not isinstance(config[attr], int):
                    raise TypeError(f"Configuration attribute '{attr}' must be an integer.")
                if config[attr] <= 0:
                    raise ValueError(f"Configuration attribute '{attr}' must be a positive integer.")

            # Initialize RNN layer for sequence generation
            self.supervisor_rnn = nn.GRU(
                input_size=config['latent_dim'],
                hidden_size=config['latent_dim'],
                num_layers=config['rnn_layers']
            )

            # Initialize fully connected layer to map RNN outputs to latent dimension
            self.sequence_fc = nn.Linear(config['latent_dim'], config['latent_dim'])

            # Activation function applied to the final output
            self.activation_fn = nn.Sigmoid()
            
            # Apply weight initialization function to all parameters
            self.apply(initialize_weights)

        except AttributeError as attr_err:
            raise AttributeError(f"Initialization error in SequentialLatentForecaster: {str(attr_err)}")
        except TypeError as type_err:
            raise TypeError(f"Type error in SequentialLatentForecaster configuration: {str(type_err)}")
        except ValueError as val_err:
            raise ValueError(f"Value error in SequentialLatentForecaster configuration: {str(val_err)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during SequentialLatentForecaster initialization: {str(e)}")

    def forward(self, previous_sequence, apply_activation=True):
        """Synthesis the next latent sequence informed by the last segment (antecedent sequence).

        Attributes:
          - previous_sequence: Input tensor of shape (seq_len, batch_size, latent_dim).
          - apply_activation: Flag to apply sigmoid activation to output.

        Outputs:
          - generated_sequence: Generated sequence in the latent space.

        Raises:
          - TypeError: If previous_sequence is not a torch.Tensor.
          - ValueError: If previous_sequence tensor does not have the correct dimensions or latent dimension.
          - RuntimeError: If an error occurs during the forward pass.
        """
        # Validate previous_sequence input
        if not isinstance(previous_sequence, torch.Tensor):
            raise TypeError("Input to forward method must be a torch.Tensor.")
        
        if previous_sequence.dim() != 3:
            raise ValueError("Input tensor must be 3-dimensional (sequence_length, batch_size, latent_dim).")
        
        # Validate that the last dimension of previous_sequence matches the expected latent dimension
        expected_latent_dim = self.supervisor_rnn.input_size
        if previous_sequence.size(-1) != expected_latent_dim:
            raise ValueError(
                f"Expected input feature dimension of {expected_latent_dim}, but got {previous_sequence.size(-1)}."
            )

        try:
            # Pass previous sequence through the RNN layer
            supervisor_output, _ = self.supervisor_rnn(previous_sequence)
            
            # Pass the RNN output through the fully connected layer
            generated_sequence = self.sequence_fc(supervisor_output)
            
            # Optionally apply the activation function
            if apply_activation:
                generated_sequence = self.activation_fn(generated_sequence)
        
        except Exception as e:
            raise RuntimeError(f"Error during forward pass in SequentialLatentForecaster: {str(e)}")
        
        return generated_sequence


class LatentSequenceClassifier(nn.Module):
    """Classifies between real and synthetic sequences in the latent space.

    Attributes:
      - discriminator_rnn: Recurrent layer to encode sequences for discrimination.
      - classifier_fc: Fully connected layer to project RNN outputs for classification.
      - activation_fn: Activation function applied to the classification result.

    Attributes:
      - config: Configuration dictionary with attributes `latent_dim` and `rnn_layers`.

    Raises:
      - AttributeError: If required attributes are missing from the configuration.
      - TypeError: If attributes in config are not integers.
      - ValueError: If config values are not positive integers.
      - RuntimeError: If there is an unexpected error during initialization.
    """
    def __init__(self, config):
        super(LatentSequenceClassifier, self).__init__()
        try:
            # Validate configuration attributes
            required_attrs = ['latent_dim', 'rnn_layers']
            for attr in required_attrs:
                if attr not in config:
                    raise AttributeError(f"Configuration is missing required attribute '{attr}'.")
                if not isinstance(config[attr], int):
                    raise TypeError(f"Configuration attribute '{attr}' must be an integer.")
                if config[attr] <= 0:
                    raise ValueError(f"Configuration attribute '{attr}' must be a positive integer.")

            # Initialize GRU layer for encoding sequences for discrimination
            self.discriminator_rnn = nn.GRU(
                input_size=config['latent_dim'],
                hidden_size=config['latent_dim'],
                num_layers=config['rnn_layers']
            )

            # Initialize fully connected layer to project RNN outputs for classification
            self.classifier_fc = nn.Linear(config['latent_dim'], config['latent_dim'])

            # Activation function applied to the classification result
            self.activation_fn = nn.Sigmoid()
            
            # Apply weight initialization function to all parameters
            self.apply(initialize_weights)

        except AttributeError as attr_err:
            raise AttributeError(f"Initialization error in LatentSequenceClassifier: {str(attr_err)}")
        except TypeError as type_err:
            raise TypeError(f"Type error in LatentSequenceClassifier configuration: {str(type_err)}")
        except ValueError as val_err:
            raise ValueError(f"Value error in LatentSequenceClassifier configuration: {str(val_err)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during LatentSequenceClassifier initialization: {str(e)}")

    def forward(self, input_sequence, apply_activation=True):
        """Classifies a sequence as real or synthetic.

        Attributes:
          - input_sequence: Input tensor of shape (seq_len, batch_size, latent_dim).
          - apply_activation: Flag to apply sigmoid activation to output.

        Outputs:
          - classification_result: Classification probabilities or scores indicating real vs synthetic.

        Raises:
          - TypeError: If input_sequence is not a torch.Tensor.
          - ValueError: If input_sequence tensor does not have the correct dimensions.
          - RuntimeError: If an error occurs during the forward pass.
        """
        # Validate input_sequence input
        if not isinstance(input_sequence, torch.Tensor):
            raise TypeError("Input to forward method must be a torch.Tensor.")
        
        if input_sequence.dim() != 3:
            raise ValueError("Input tensor must be 3-dimensional (sequence_length, batch_size, latent_dim).")
        
        # Validate that the last dimension of input_sequence matches the expected latent dimension
        expected_latent_dim = self.discriminator_rnn.input_size
        if input_sequence.size(-1) != expected_latent_dim:
            raise ValueError(
                f"Expected input feature dimension of {expected_latent_dim}, but got {input_sequence.size(-1)}."
            )

        try:
            # Pass input sequence through the GRU layer for encoding
            discriminator_output, _ = self.discriminator_rnn(input_sequence)
            
            # Pass the RNN output through the fully connected layer
            classification_result = self.classifier_fc(discriminator_output)
            
            # Optionally apply the activation function
            if apply_activation:
                classification_result = self.activation_fn(classification_result)
        
        except Exception as e:
            raise RuntimeError(f"Error during forward pass in LatentSequenceClassifier: {str(e)}")
        
        return classification_result

class LatentToFeatureReconstructor(nn.Module):
    """Decodes latent embeddings back to the original feature space using a GRU-based network.

    Attributes:
      - recovery_rnn: Recurrent layer to decode latent embeddings.
      - reconstruction_continuous_fc: Fully connected layer to project RNN outputs to the continuous feature dimension.
      - reconstruction_discrete_fc: Fully connected layer to project RNN outputs to the discrete feature dimension (optional).
      - activation_continuous_fn: Activation function applied on the continuous feature output.
      - activation_discrete_fn: Softmax activation function for the discrete feature output.
      - total_columns: Number of categorical/discrete columns.
      - discrete_ranges: Discrete ranges for converting the decoded output into one-hot encoded vectors.

    Attributes (config):
      - latent_dim (int): Dimensionality of the latent space.
      - input_dim (int): Dimensionality of the original input feature space.
      - rnn_layers (int): Number of layers for the GRU.
      - mappings (dict): Mapping for discrete features with column names and their indices.

    Raises:
      - AttributeError: If required attributes are missing from the configuration.
      - TypeError: If attributes in the config are not integers.
      - ValueError: If config values are not positive integers.
      - RuntimeError: If there is an error during initialization.
    """

    def __init__(self, config):
        super(LatentToFeatureReconstructor, self).__init__()
        try:
            # Check that all required configuration attributes are present, of type int, and positive.
            required_attrs = ['latent_dim', 'input_dim', 'rnn_layers']
            for attr in required_attrs:
                if attr not in config:
                    raise AttributeError(f"Configuration is missing required attribute '{attr}'.")
                if not isinstance(config[attr], int):
                    raise TypeError(f"Configuration attribute '{attr}' must be an integer.")
                if config[attr] <= 0:
                    raise ValueError(f"Configuration attribute '{attr}' must be a positive integer.")

            # Initialize GRU layer for decoding latent embeddings
            self.recovery_rnn = nn.GRU(
                input_size=config['latent_dim'],
                hidden_size=config['input_dim'],
                num_layers=config['rnn_layers']
            )

            # Calculate the total number of columns (categorical variables)
            self.total_columns = len(config["mappings"]) if config["mappings"] is not None else 0

            if self.total_columns > 0:
                # Optional: Get total number of encoded indices across all columns
                total_indices = sum(len(indices) for indices in config["mappings"].values())

                # Get discrete ranges for one-hot encoding
                self.discrete_ranges = get_discrete_ranges(config)

                # Initialize fully connected layer for reconstructing to the original continuous feature dimension
                self.reconstruction_continuous_fc = nn.Linear(config['input_dim'], config['input_dim'] - total_indices)
            else:
                # Initialize fully connected layer for reconstructing to the original continuous feature dimension
                self.reconstruction_continuous_fc = nn.Linear(config['input_dim'], config['input_dim'])

            if self.total_columns > 0:
                # Initialize fully connected layer for reconstructing to the original discrete feature dimension
                self.reconstruction_discrete_fc = nn.Linear(config['input_dim'], total_indices)

                # Define the Softmax activation using torch.nn
                self.activation_discrete_fn = nn.Softmax(dim=-1)

            # Activation function applied to the continuous features
            self.activation_continuous_fn = nn.Sigmoid()

            # Apply weight initialization function to all parameters
            self.apply(initialize_weights)

        except AttributeError as attr_err:
            raise AttributeError(f"Initialization error in LatentToFeatureReconstructor: {str(attr_err)}")
        except TypeError as type_err:
            raise TypeError(f"Type error in LatentToFeatureReconstructor configuration: {str(type_err)}")
        except ValueError as val_err:
            raise ValueError(f"Value error in LatentToFeatureReconstructor configuration: {str(val_err)}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error during LatentToFeatureReconstructor initialization: {str(e)}")

    def forward(self, latent_embeddings, apply_activation=True):
        """Reconstructs original features from latent embeddings.

        Attributes:
          - latent_embeddings (torch.Tensor): Input tensor of shape (seq_len, batch_size, latent_dim).
          - apply_activation (bool): Flag to apply sigmoid activation to output.

        Outputs:
          - reconstructed_features (torch.Tensor): Reconstructed features matching the original input space.

        Raises:
          - TypeError: If latent_embeddings is not a torch.Tensor.
          - ValueError: If latent_embeddings tensor does not have the correct dimensions.
          - RuntimeError: If an error occurs during the forward pass.
        """
        # Check if latent_embeddings is a tensor and has the correct dimensions
        if not isinstance(latent_embeddings, torch.Tensor):
            raise TypeError("Input to forward method must be a torch.Tensor.")

        if latent_embeddings.dim() != 3:
            raise ValueError("Input tensor must be 3-dimensional (sequence_length, batch_size, latent_dim).")

        # Validate that the last dimension of latent_embeddings matches the expected latent dimension
        expected_latent_dim = self.recovery_rnn.input_size
        if latent_embeddings.size(-1) != expected_latent_dim:
            raise ValueError(
                f"Expected input feature dimension of {expected_latent_dim}, but got {latent_embeddings.size(-1)}."
            )

        try:
            # Pass latent embeddings through the GRU layer for decoding
            decoded_output, _ = self.recovery_rnn(latent_embeddings)

            # Pass the RNN output through the fully connected layer for reconstruction of continuous features
            reconstructed_continuousfeatures = self.reconstruction_continuous_fc(decoded_output)

            # Optionally apply the activation function
            if apply_activation:
                reconstructed_continuousfeatures = self.activation_continuous_fn(reconstructed_continuousfeatures)

            if self.total_columns > 0:
                # Pass the RNN output through the fully connected layer for reconstruction of discrete features
                reconstructed_discretefeatures = self.reconstruction_discrete_fc(decoded_output)

                # Placeholder for all one-hot encoded outputs
                one_hot_results = []

                for start, range_size, num_classes in self.discrete_ranges:
                    end = start + range_size  # Calculate the end index of the current range

                    # Slice the relevant part of the decoded output
                    discretefeatures = reconstructed_discretefeatures[..., start:end]  # Shape: [Batch, Seq, range_size]

                    # Apply softmax for differentiability
                    softmax_output = self.activation_discrete_fn(discretefeatures)

                    # Differentiable one-hot encoding using argmax
                    argmax_indices = torch.argmax(softmax_output, dim=-1)  # Shape: [Batch, Seq]
                    one_hot = torch.nn.functional.one_hot(argmax_indices, num_classes=num_classes).to(softmax_output.dtype)  # Ensure dtype consistency

                    # Store one-hot outputs
                    one_hot_results.append(one_hot)

                # Concatenate all one-hot results along the last dimension
                total_one_hot = torch.cat(one_hot_results, dim=-1)  # Shape: [Batch, Seq, total_discrete_classes]

                # Concatenate continuous features with discrete one-hot encodings
                reconstructed_features = torch.cat((reconstructed_continuousfeatures, total_one_hot), dim=-1)  # Final concatenation
            else:
                reconstructed_features = reconstructed_continuousfeatures

        except Exception as e:
            raise RuntimeError(f"Execution error detected during forward computation in LatentToFeatureReconstructor: {str(e)}")

        return reconstructed_features

def plot_data_projection(real_data_projection, synthetic_data_projection, title, x_label, y_label, x_limits=None, y_limits=None, save_path=None):
    """
    Helper function to plot the projections of real and synthetic data with optional axis limits.

    Parameters:
        real_data_projection (numpy.ndarray): 2D projected coordinates of real data.
        synthetic_data_projection (numpy.ndarray): 2D projected coordinates of synthetic data.
        title (str): Title of the plot.
        x_label (str): Label for the x-axis.
        y_label (str): Label for the y-axis.
        x_limits (tuple, optional): Limits for the x-axis in the form (min, max).
        y_limits (tuple, optional): Limits for the y-axis in the form (min, max).
    """
    plt.figure(figsize=(10, 7))
    plt.scatter(real_data_projection[:, 0], real_data_projection[:, 1], color='salmon', alpha=0.6, edgecolor='k', label="Real Data")
    plt.scatter(synthetic_data_projection[:, 0], synthetic_data_projection[:, 1], color='dodgerblue', alpha=0.6, edgecolor='k', label="Synthetic Data")
    plt.title(title, fontsize=15, fontweight='bold')
    plt.xlabel(x_label, fontsize=12)
    plt.ylabel(y_label, fontsize=12)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.5)
    
    # Set x and y axis limits if specified
    if x_limits is not None:
        plt.xlim(x_limits)
    if y_limits is not None:
        plt.ylim(y_limits)
    if save_path:
        plt.savefig(save_path, format='pdf')
    plt.close()

def perform_dimensionality_reduction_and_plot(real_data, synthetic_data, method, experiment_workspace, x_limits=None, y_limits=None):
    """
    Visualizes the relationship between real and synthetic data samples using dimensionality reduction techniques (PCA or t-SNE).
    
    Parameters:
        real_data (numpy.ndarray or list): Original dataset, expected to be 3D (sample_size, sequence_length, features).
        synthetic_data (numpy.ndarray or list): Generated synthetic dataset, expected to be the same shape as real_data.
        method (str): The dimensionality reduction method to use; either 'pca' for Principal Component Analysis or 'tsne' for t-Distributed Stochastic Neighbor Embedding.
        x_limits (tuple, optional): Limits for the x-axis in the form (min, max).
        y_limits (tuple, optional): Limits for the y-axis in the form (min, max).

    Raises:
        TypeError: If inputs are not numpy arrays or lists, or if method is not a string.
        ValueError: If input data is empty, shapes do not match, or data dimensions are not 3D.
        RuntimeError: For any exception occurring during data preprocessing, dimensionality reduction, or plotting.
    """
    # Input validation
    if not isinstance(real_data, (list, np.ndarray)) or not isinstance(synthetic_data, (list, np.ndarray)):
        raise TypeError("Both 'real_data' and 'synthetic_data' must be list or numpy array types.")
    if not isinstance(method, str):
        raise TypeError("'method' must be a string indicating the reduction technique (either 'pca' or 'tsne').")
    
    if method not in ['pca', 'tsne']:
        raise ValueError("'method' must be either 'pca' or 'tsne'.")
    if len(real_data) == 0 or len(synthetic_data) == 0:
        raise ValueError("'real_data' and 'synthetic_data' cannot be empty datasets.")

    # Convert data to numpy arrays and check shapes
    real_data = np.asarray(real_data)
    synthetic_data = np.asarray(synthetic_data)
    if real_data.shape != synthetic_data.shape:
        raise ValueError("'real_data' and 'synthetic_data' must have the same shape.")
    if real_data.ndim != 3:
        raise ValueError("Input data should be 3-dimensional: (samples, sequence_length, features).")

    # Subsample for computational efficiency
    sample_size = min(2000, len(real_data))
    selected_indices = np.random.permutation(len(real_data))[:sample_size]
    real_data_sampled = real_data[selected_indices]
    synthetic_data_sampled = synthetic_data[selected_indices]
    
    # Aggregate data by averaging across sequence length
    averaged_real_data = real_data_sampled.mean(axis=1)
    averaged_synthetic_data = synthetic_data_sampled.mean(axis=1)

    # Ensure results folder exists
    results_folder = os.path.join(experiment_workspace, "results")
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)

    # Dimensionality reduction
    if method == 'pca':
        try:
            pca_transformer = PCA(n_components=2)
            transformed_real = pca_transformer.fit_transform(averaged_real_data)
            transformed_synthetic = pca_transformer.transform(averaged_synthetic_data)
            
            # Plotting PCA results
            plot_path = os.path.join(results_folder, "pca_real_vs_synthetic.pdf")
            plot_data_projection(transformed_real, transformed_synthetic, 
                                 title="PCA Analysis of Real vs. Synthetic Data",
                                 x_label="Principal Component 1",
                                 y_label="Principal Component 2",
                                 x_limits=x_limits,
                                 y_limits=y_limits,
                                 save_path=plot_path)
        except Exception as e:
            raise RuntimeError(f"PCA analysis error: {str(e)}")
    
    elif method == 'tsne':
        try:
            tsne_transformer = TSNE(n_components=2, perplexity=40, n_iter=300, random_state=0)
            combined_data = np.vstack((averaged_real_data, averaged_synthetic_data))
            tsne_results = tsne_transformer.fit_transform(combined_data)
            
            # Separate t-SNE results for real and synthetic data
            transformed_real, transformed_synthetic = tsne_results[:sample_size], tsne_results[sample_size:]
            
            # Plotting t-SNE results
            plot_path = os.path.join(results_folder, "tsne_real_vs_synthetic.pdf")
            plot_data_projection(transformed_real, transformed_synthetic, 
                                 title="t-SNE Analysis of Real vs. Synthetic Data",
                                 x_label="t-SNE Dimension 1",
                                 y_label="t-SNE Dimension 2",
                                 x_limits=x_limits,
                                 y_limits=y_limits,
                                 save_path=plot_path)
        except Exception as e:
            raise RuntimeError(f"t-SNE analysis error: {str(e)}")

def generate_sample_batch(time_series_data, time_labels, sample_size):
    """
    Generate a randomized mini-batch of samples from time-series data for training or analysis.

    Parameters:
    ----------
    time_series_data : list or np.ndarray
        Sequence of data points representing time-series values.
    
    time_labels : list or np.ndarray
        Corresponding time-related information or labels for each data point in `time_series_data`.
    
    sample_size : int
        Number of randomly selected samples to include in each mini-batch. Must be a positive integer and not exceed
        the total data points available.
    
    Outputs:
    -------
    batch_data : list
        Subset of `time_series_data` with length equal to `sample_size`, representing the selected mini-batch data points.
    
    batch_time_labels : list
        Subset of `time_labels` matching `batch_data`, representing the corresponding time information for each data point.
    
   
    Notes:
    -----
    This function is intended for use in batch processing for deep learning models, where random sampling
    of time-series data enhances training generalization by presenting varied input patterns per epoch.
    """
    
    # --- Input Type Validation ---
    if not isinstance(time_series_data, (list, np.ndarray)) or not isinstance(time_labels, (list, np.ndarray)):
        raise TypeError("Both 'time_series_data' and 'time_labels' must be of type list or numpy array.")
    
    # --- Non-Empty and Length Consistency Checks ---
    if len(time_series_data) == 0 or len(time_labels) == 0:
        raise ValueError("Neither 'time_series_data' nor 'time_labels' can be empty.")
    
    if len(time_series_data) != len(time_labels):
        raise ValueError("The 'time_series_data' and 'time_labels' must have identical lengths.")
    
    # --- Batch Size Validation ---
    if not isinstance(sample_size, int) or sample_size <= 0:
        raise ValueError("Parameter 'sample_size' must be a positive integer.")
    
    if sample_size > len(time_series_data):
        raise ValueError("'sample_size' cannot exceed the number of available data points in 'time_series_data'.")
    
    try:
        # --- Random Index Generation ---
        # Total available samples in the dataset
        total_samples = len(time_series_data)
        
        # Generate a permutation of indices and select the first 'sample_size' indices
        random_indices = np.random.permutation(total_samples)
        selected_indices = random_indices[:sample_size]
    except Exception as e:
        raise RuntimeError(f"Error generating random indices for batch selection: {str(e)}")
    
    try:
        # --- Mini-Batch Data Sampling ---
        # Gather data points and corresponding time labels based on selected indices
        batch_data = [time_series_data[i] for i in selected_indices]
        batch_time_labels = [time_labels[i] for i in selected_indices]
    except Exception as e:
        raise RuntimeError(f"Error retrieving data for mini-batch: {str(e)}")
    
    return batch_data, batch_time_labels


def calculate_sequence_lengths(data_sequences):
    """
    Computes the length of each sequence in the dataset and identifies the maximum sequence length.
    
    Attributes:
        data_sequences (list or np.ndarray): A list or array of sequences, where each sequence is represented as a 2D numpy array.
    
    Outputs:
        tuple: Contains:
            - sequence_lengths (list of int): Lengths of each sequence in terms of rows.
            - max_sequence_length (int): The length of the longest sequence.
    
    Raises:
        ValueError: If `data_sequences` is not a non-empty list or numpy array.
        TypeError: If any sequence within `data_sequences` is not a numpy array.
        RuntimeError: For any other unexpected errors encountered during processing.
    """
    # Input validation to ensure non-empty list or numpy array
    if not isinstance(data_sequences, (list, np.ndarray)) or len(data_sequences) == 0:
        raise ValueError("Input must be a non-empty list or numpy array of sequences.")
    
    sequence_lengths = []
    max_sequence_length = 0
    
    try:
        for idx, sequence in enumerate(data_sequences):
            # Confirm each element is a 2D numpy array
            if not isinstance(sequence, np.ndarray) or sequence.ndim != 2:
                raise TypeError(f"Sequence at index {idx} is not a valid 2D numpy array.")
            
            # Compute sequence length as the number of rows (time steps)
            current_length = sequence.shape[0]
            max_sequence_length = max(max_sequence_length, current_length)
            sequence_lengths.append(current_length)
    except Exception as e:
        raise RuntimeError(f"Error while calculating sequence lengths: {str(e)}")
    
    return sequence_lengths, max_sequence_length


def generate_random_sequences(batch_size, latent_dim, sequence_lengths, max_length):
    """
    Generates a batch of random sequences with varying time lengths, padded to a specified maximum length.

    Attributes:
        batch_size (int): Number of sequences in the batch.
        latent_dim (int): Dimensionality of the feature space for each random vector.
        sequence_lengths (list of int): Desired lengths for each sequence in the batch.
        max_length (int): Maximum sequence length for padding.

    Outputs:
        np.ndarray: A 3D NumPy array of shape (batch_size, max_length, latent_dim) containing randomly generated sequences.
    
    Raises:
        ValueError: If any parameter is invalid or out of expected bounds.
        RuntimeError: For any other errors during sequence generation.
    """
    # Validate the batch generation parameters
    if not isinstance(batch_size, int) or batch_size <= 0:
        raise ValueError("batch_size must be a positive integer.")
    if not isinstance(latent_dim, int) or latent_dim <= 0:
        raise ValueError("latent_dim must be a positive integer.")
    if not isinstance(max_length, int) or max_length <= 0:
        raise ValueError("max_length must be a positive integer.")
    if not isinstance(sequence_lengths, list) or len(sequence_lengths) != batch_size:
        raise ValueError("sequence_lengths must be a list matching the batch size.")

    # Initialize a 3D array of zeros (batch_size, max_length, latent_dim)
    random_sequences = np.zeros((batch_size, max_length, latent_dim), dtype=np.float32)
    
    try:
        for i, length in enumerate(sequence_lengths):
            if length > max_length:
                raise ValueError(f"Sequence length {length} exceeds max_length {max_length}.")
            
            # Generate the random sequence part and insert it into the padded array
            random_sequence_part = np.random.uniform(0, 1, (length, latent_dim))
            random_sequences[i, :length, :] = random_sequence_part
    except Exception as e:
        raise RuntimeError(f"Error during random sequence generation: {str(e)}")
    
    return random_sequences

def classify_columns(data: pd.DataFrame, threshold: int = 4):
    """
    Classify columns of a DataFrame as discrete or continuous.

    Parameters:
    data (pd.DataFrame): The input DataFrame containing the dataset.
    threshold (int): The number of unique values below which a column is considered discrete. Default is 10.

    Returns:
    tuple: A tuple containing two lists - the first list contains discrete columns, and the second list contains continuous columns.
    """
    try:
        if not isinstance(data, pd.DataFrame):
            raise TypeError("Input data must be a pandas DataFrame.")
        if not isinstance(threshold, int) or threshold <= 0:
            raise ValueError("Threshold must be a positive integer.")

        discrete_columns = []
        continuous_columns = []

        for column in data.columns:
            if pd.api.types.is_numeric_dtype(data[column]):
                unique_values = data[column].nunique()
                if unique_values <= threshold:
                    discrete_columns.append(column)
                else:
                    continuous_columns.append(column)

        return discrete_columns, continuous_columns
    except Exception as e:
        print(f"An error occurred: {e}")
        return [], []  

def determine_depindep_variables(data, feature_names=None):
    """
    Determines the names of the dependent and independent variables in a given dataset using feature importance analysis.

    Parameters:
    data (numpy.ndarray): The dataset to analyze, where each row is a sample and each column is a feature.
    feature_names (list, optional): List of feature names corresponding to the dataset columns.

    Returns:
    tuple: (independent_vars_names, dependent_var_name)
    """

    # Compute the correlation matrix
    corr_matrix = data.corr()
    # Find the column with the highest average absolute correlation to all other columns (assumed to be the dependent variable)
    avg_corr = corr_matrix.abs().mean() - (1 / len(data.columns))  # Subtract self-correlation contribution
    dependent_var_name = avg_corr.idxmax()

    # Independent variables are all other columns except the dependent variable
    independent_vars_names = [col for col in data.columns if col != dependent_var_name]

    return independent_vars_names, dependent_var_name


def scale_to_unit_interval(array):
    """Normalize data using Min-Max scaling to range [0, 1].

    Attributes:
        - array (np.ndarray): The input data array for normalization.

    Outputs:
        - tuple: Scaled array with values in the range [0, 1], minimum values, and maximum values per feature.

    Raises:
        - TypeError: If input data is not a numpy array.
        - ValueError: If input is empty, contains NaN or inf, or if any feature has a constant value.
    """

    # Type and value checks for input array
    if not isinstance(array, np.ndarray):
        raise TypeError("Input must be a numpy array.")

    if array.size == 0:
        raise ValueError("Input array cannot be empty.")

    if np.isnan(array).any() or np.isinf(array).any():
        raise ValueError("Array contains NaN or infinite values.")

    # Calculate min-max scaling
    min_vals = np.min(array, axis=0)
    max_vals = np.max(array, axis=0)
    range_vals = max_vals - min_vals
     
    if np.any(range_vals == 0):
        raise ValueError("Zero range values encountered, potential division by zero.")

    scaled_array = (array - min_vals) / (range_vals + 2e-8)
    return np.asarray(scaled_array), min_vals, max_vals


def calculate_basic_statistics(data):
    """
    Calculate basic statistics including min, max, first quartile, median (second quartile), and third quartile
    for each column in the 2D data.

    Args:
        data (list or numpy.ndarray): Input 2D data for which statistics need to be calculated.

    Returns:
        dict: A dictionary containing min, max, Q1, median, Q3, mean, standard deviation, and variance for each column.
    """
    if not isinstance(data, (list, np.ndarray)):
        raise ValueError("Input data must be a list or numpy array.")

    data = np.array(data)
    if len(data.shape) != 2:
        raise ValueError("Input data must be a 2D list or numpy array.")

    stats = {
        'min': np.min(data, axis=0).tolist(),
        'max': np.max(data, axis=0).tolist(),
        'first_quartile': np.percentile(data, 25, axis=0).tolist(),
        'median': np.percentile(data, 50, axis=0).tolist(),
        'third_quartile': np.percentile(data, 75, axis=0).tolist(),
        'mean': np.mean(data, axis=0).tolist(),
        'std_dev': np.std(data, axis=0).tolist(),
        'variance': np.var(data, axis=0).tolist()
    }
    return stats


def load_real_data(dataset_type, sequence_length):
    """Loads and preprocesses real-world time-series datasets (e.g., energy or stock).
    
    Args:
        dataset_type (str): Type of dataset to load ('energy' or 'stock').
        sequence_length (int): Desired sequence length for each data sample.
    """

    # Validate input parameters
    if dataset_type not in ['energy', 'stock']:
        raise ValueError("dataset_type must be either 'energy' or 'stock'")
    
    if not isinstance(sequence_length, int) or sequence_length <= 0:
        raise ValueError("sequence_length must be a positive integer.")
    
    # Define base directory and file path
    base_directory = dirname(dirname(abspath(__file__)))
    file_name = f"{dataset_type}_data.csv"
    data_path = os.path.join(base_directory, 'Synthetic', 'data', file_name)
    
    # Check if data file exists
    if not exists(data_path):
        raise FileNotFoundError(f"Data file {data_path} not found.")

    # Load raw data
    try:
        raw_data = np.loadtxt(data_path, delimiter=",", skiprows=1)
        # Split data into train and test sets
        raw_data, test_data = split_data(raw_data, test_size=0.10)
        print(f"Without Removing outliers: {raw_data.shape}")
        if dataset_type in ['energy', 'stock']:
            raw_data = remove_outlier_rows(raw_data, threshold=5.0)  
            print(f"After Removing outliers: {raw_data.shape}")  
    except Exception as e:
        raise IOError(f"Error loading data from {data_path}: {str(e)}")
    
    # Validate loaded data
    if raw_data.size == 0:
        raise ValueError("Loaded dataset is empty.")
    
    if np.isnan(raw_data).any() or np.isinf(raw_data).any():
        raise ValueError("Loaded dataset contains NaN or infinite values.")

    # Create a DataFrame for column classification
    df = pd.DataFrame(raw_data, columns=[f"Column_{i}" for i in range(raw_data.shape[1])])

    # Compute discrete and continuous columns
    discrete_columns, continuous_columns = classify_columns(df)

    # Determine independent and dependent variables
    independent_vars_names, dependent_var_name = determine_depindep_variables(df)

    # One-hot encode discrete columns if present
    if len(discrete_columns) > 0:
        # Perform one-hot encoding for discrete columns
        raw_data, encoded_columns_indices_mapping, one_hot_encoder, discrete_columns = one_hot_encode(df, discrete_columns, continuous_columns)
    else:
        # Set encoded_columns_indices_mapping and one_hot_encoder to None if no discrete columns
        encoded_columns_indices_mapping = None
        one_hot_encoder = None

    # Normalize the dataset
    normalized_data, min_vals, max_vals = scale_to_unit_interval(raw_data)
    
    # Create time-series sequences
    data_sequences = [normalized_data[i:i + sequence_length] for i in range(0, len(normalized_data) - sequence_length)]
    
    # Validate generated sequences
    if not data_sequences:
        raise ValueError("No valid sequences could be generated with the specified sequence length.")
    
    # Randomly shuffle sequences to ensure i.i.d distribution
    shuffled_indices = np.random.permutation(len(data_sequences))
    shuffled_data = [data_sequences[idx] for idx in shuffled_indices]

    # Calculate basic statistics for reshaping
    _, _, num_variables = np.array(shuffled_data).shape
    ScaleUp_shuffled_data = (shuffled_data * ((max_vals - min_vals) + 2e-8) + min_vals)

    # Decode one-hot encoded columns if present
    if len(discrete_columns) > 0:
        original_shape = ScaleUp_shuffled_data.shape
        new_shape = (original_shape[0], original_shape[1], -1)
        # Decode one-hot encoded columns
        decoded_features = decode_one_hot(np.array(ScaleUp_shuffled_data).reshape(-1, num_variables), encoded_columns_indices_mapping, one_hot_encoder, discrete_columns)
        # Get total number of encoded indices across all columns
        total_indices = sum(len(indices) for indices in encoded_columns_indices_mapping.values())
        # Reshape decoded features to match the original structure
        reshaped_shuffled_data = decoded_features.reshape(new_shape).reshape(-1, num_variables-total_indices+len(discrete_columns))
    else:    
        # Reshape scaled-up data if no one-hot encoding was applied
        reshaped_shuffled_data = ScaleUp_shuffled_data.reshape(-1, num_variables)

    # Calculate basic statistics of reshaped data
    rawdata_statistics = calculate_basic_statistics(reshaped_shuffled_data)
    
    # Return all processed outputs
    return shuffled_data, min_vals, max_vals, reshaped_shuffled_data, rawdata_statistics, encoded_columns_indices_mapping, one_hot_encoder, discrete_columns


def retrieve_data_based_on_config(config):
    """Retrieve data based on the specified configuration.
    
    Attributes:
        config (dict): Configuration dictionary containing the following attributes:
            - `dataset_type` (str): The type of dataset to be used. Options: 'energy', 'stock'
            - `seq_len` (int): The sequence length for the dataset.
            
    """

    # Validate configuration attributes
    try:
        dataset_type = config['dataset_type']
        seq_len = config['seq_len']
    except KeyError as e:
        raise AttributeError(f"Missing required attribute in config: {str(e)}")

    # Validate types of configuration attributes
    if not isinstance(dataset_type, str):
        raise TypeError("dataset_type must be a string.")

    if not isinstance(seq_len, int) or seq_len <= 0:
        raise ValueError("seq_len must be a positive integer.")

    # Validate dataset_type value
    if dataset_type not in ['energy', 'stock']:
        raise ValueError("dataset_type must be either 'energy' or 'stock'")

    # Load or generate data based on config
    try:
        dataset, min_vals, max_vals, reshaped_shuffled_data, rawdata_statistics, encoded_columns_indices_mapping, one_hot_encoder, discrete_columns = load_real_data(dataset_type, seq_len)
    except Exception as e:
        raise RuntimeError(f"An error occurred while loading the dataset: {str(e)}")
    
    # Validate the loaded dataset
    if not dataset:
        raise ValueError("The dataset is empty after loading or generation.")

    print(f"{dataset_type.capitalize()} dataset loaded successfully.")

    return dataset, min_vals, max_vals, reshaped_shuffled_data, rawdata_statistics, encoded_columns_indices_mapping, one_hot_encoder, discrete_columns


def plot_statistics(rawdata_statistics, statistics_Syntheticdata, num_features, plots_storage_workspace):
    """
    Plots a comparison of statistics between raw and synthetic data and saves the figures in high-quality PDFs.

    Parameters:
    rawdata_statistics (dict): A dictionary containing the statistics for the raw data.
    statistics_Syntheticdata (dict): A dictionary containing the statistics for the synthetic data.
    num_features (int): Number of features to plot.

    The function creates multiple matrices of subplots for each feature and each statistic (min, max, first quartile, median, third quartile),
    comparing the raw data and the synthetic data for each feature.
    """
    # Labels for the statistics
    labels = ['min', 'max', 'first_quartile', 'median', 'third_quartile', 'mean', 'std_dev', 'variance']
    
    # Number of statistics
    n_labels = len(labels)

    # Calculate the number of rows of subplots to generate
    num_rows = (num_features // 6) + (1 if num_features % 6 != 0 else 0)
    
    # Create the results directory if it doesn't exist
    results_folder = os.path.join(plots_storage_workspace, 'results')
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)
    
    for row in range(num_rows):
        start_feature = row * 6
        end_feature = min(start_feature + 6, num_features)
        n_categories = end_feature - start_feature

        # Create subplots for the current batch of features
        fig, axs = plt.subplots(n_categories, n_labels, figsize=(30, 2 * n_categories))

        if n_categories == 1:
            axs = [axs]

        for i in range(n_categories):
            feature_idx = start_feature + i
            category = f'Feature {feature_idx + 1}'

            for j, label in enumerate(labels):
                raw_value = rawdata_statistics[label][feature_idx]
                synthetic_value = statistics_Syntheticdata[label][feature_idx]

                axs[i][j].bar(['Raw Data', 'Synthetic Data'], [raw_value, synthetic_value], color=['blue', 'orange'])
                axs[i][j].set_title(f'{category} - {label}', fontsize=12, fontweight='bold')
                axs[i][j].set_ylabel('Values', fontsize=12, fontweight='bold')
                axs[i][j].tick_params(axis='x', labelrotation=0, labelsize=12, width=2)
                axs[i][j].tick_params(axis='y', labelsize=12, width=2)
                axs[i][j].xaxis.label.set_size(12)
                axs[i][j].yaxis.label.set_size(12)
                axs[i][j].xaxis.label.set_fontweight('bold')
                axs[i][j].yaxis.label.set_fontweight('bold')

                # Set x-tick and y-tick labels to be bold
                for label in axs[i][j].get_xticklabels():
                    label.set_fontsize(12)
                    label.set_fontweight('bold')
                for label in axs[i][j].get_yticklabels():
                    label.set_fontsize(12)
                    label.set_fontweight('bold')

        plt.tight_layout()
        plt.subplots_adjust(hspace=0.6, wspace=0.4, top=0.95, bottom=0.05)

        # Save the figure as a high-quality PDF in the results folder
        pdf_filename = os.path.join(results_folder, f'statistics_comparison_features_{start_feature + 1}_to_{end_feature}.pdf')
        plt.savefig(pdf_filename, format='pdf', dpi=300)
        plt.close(fig)

def plot_timeseries(rawdata, syntheticdata, num_features, plots_storage_workspace):
    """
    Plots a comparison of time series data and their distributions between raw and synthetic datasets and saves the figures in high-quality PDFs.

    Parameters:
    rawdata (numpy.ndarray): Raw time series data. Shape: (time_steps, num_features)
    syntheticdata (numpy.ndarray): Synthetic time series data. Shape: (time_steps, num_features)
    num_features (int): Number of features to plot.
    """
    # Calculate the number of rows of subplots to generate
    num_rows = (num_features // 3) + (1 if num_features % 3 != 0 else 0)

    # Create the results directory if it doesn't exist
    results_folder = os.path.join(plots_storage_workspace, 'results')
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)

    for row in range(num_rows):
        start_feature = row * 3
        end_feature = min(start_feature + 3, num_features)
        n_categories = end_feature - start_feature

        # Create subplots for the current batch of features
        fig, axs = plt.subplots(n_categories, 2, figsize=(20, 4 * n_categories))

        if n_categories == 1:
            axs = np.array([axs])  # Ensure axs is iterable for consistent handling
        
        for i in range(n_categories):
            feature_idx = start_feature + i
            category = f'Feature {feature_idx + 1}'

            # Plot time series comparison
            axs[i, 0].plot(np.arange(rawdata.shape[0]), rawdata[:, feature_idx], label='Real', color='lightblue')
            axs[i, 0].plot(np.arange(syntheticdata.shape[0]), syntheticdata[:, feature_idx], 
                           label='Synthetic', color='lightsalmon', linestyle='dashed')
            axs[i, 0].set_title(f'{category} - Time Series', fontsize=14, fontweight='bold')
            axs[i, 0].set_xlabel('Time', fontsize=14, fontweight='bold')
            axs[i, 0].set_ylabel('Values', fontsize=14, fontweight='bold')
            legend = axs[i, 0].legend(fontsize=12, frameon=True, loc='best')
            for text in legend.get_texts():
                text.set_fontweight('bold')
            legend.get_frame().set_edgecolor('black')
            legend.get_frame().set_linewidth(2)
            axs[i, 0].tick_params(axis='x', labelrotation=45, labelsize=12, width=2)
            axs[i, 0].tick_params(axis='y', labelsize=12, width=2)

            # Set x-tick and y-tick labels to be bold
            for label in axs[i, 0].get_xticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')
            for label in axs[i, 0].get_yticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')

            # Plot histogram comparison for distributions
            axs[i, 1].hist(rawdata[:, feature_idx], bins=20, alpha=0.5, label='Real', color='lightblue', edgecolor='black')
            axs[i, 1].hist(syntheticdata[:, feature_idx], bins=20, alpha=0.5, label='Synthetic', color='lightsalmon', edgecolor='black')
            axs[i, 1].set_title(f'{category} - Distribution', fontsize=14, fontweight='bold')
            axs[i, 1].set_xlabel('Value', fontsize=14, fontweight='bold')
            axs[i, 1].set_ylabel('Frequency', fontsize=14, fontweight='bold')
            legend = axs[i, 1].legend(fontsize=12, frameon=True, loc='best')
            for text in legend.get_texts():
                text.set_fontweight('bold')
            legend.get_frame().set_edgecolor('black')
            legend.get_frame().set_linewidth(2)
            axs[i, 1].tick_params(axis='x', labelrotation=0, labelsize=12, width=2)
            axs[i, 1].tick_params(axis='y', labelsize=12, width=2)

            # Set x-tick and y-tick labels to be bold
            for label in axs[i, 1].get_xticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')
            for label in axs[i, 1].get_yticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')

        # Adjust layout with more bottom space for the last row
        plt.tight_layout()
        plt.subplots_adjust(hspace=0.7, wspace=0.5, top=0.95, bottom=0.1)

        # Save the figure as a high-quality PDF in the results folder
        pdf_filename = os.path.join(results_folder, f'timeseries_comparison_features_{start_feature + 1}_to_{end_feature}.pdf')
        plt.savefig(pdf_filename, format='pdf', dpi=300)
        plt.close(fig)

def plot_violin(rawdata, syntheticdata, num_features, plots_storage_workspace):
    """
    Generates overlapping violin plots for comparing the distributions of raw and synthetic time series data 
    and saves the figures as high-quality PDFs.

    Parameters:
    rawdata (numpy.ndarray): Raw time series data. Shape: (time_steps, num_features)
    syntheticdata (numpy.ndarray): Synthetic time series data. Shape: (time_steps, num_features)
    num_features (int): Number of features to plot.
    plots_storage_workspace (str): Directory to save the generated plots.
    """

    colors = {'Real': '#a8dadc', 'Synthetic': '#f4a261'}  # Define visually appealing light colors

    num_rows = (num_features // 3) + (1 if num_features % 3 != 0 else 0)

    # Create results directory if it doesn't exist
    results_folder = os.path.join(plots_storage_workspace, 'results')
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)

    for row in range(num_rows):
        start_feature = row * 3
        end_feature = min(start_feature + 3, num_features)
        n_categories = end_feature - start_feature

        # Create subplots for the current batch of features
        fig, axs = plt.subplots(1, n_categories, figsize=(6 * n_categories, 8))

        if n_categories == 1:
            axs = [axs]  # Ensure axs is iterable for consistent handling

        for i in range(n_categories):
            feature_idx = start_feature + i
            category = f'Feature {feature_idx + 1}'

            # Create individual DataFrames for 'Real' and 'Synthetic'
            real_data = pd.DataFrame({'Value': rawdata[:, feature_idx], 'Type': 'Real'})
            synthetic_data = pd.DataFrame({'Value': syntheticdata[:, feature_idx], 'Type': 'Synthetic'})

            # Overlay violin plots for each type separately
            sns.violinplot(
                x='Type', y='Value', data=real_data, ax=axs[i],
                scale='width', inner='quartile', color=colors['Real'], linewidth=1.5
            )
            sns.violinplot(
                x='Type', y='Value', data=synthetic_data, ax=axs[i],
                scale='width', inner='quartile', color=colors['Synthetic'], linewidth=1.5
            )

            # Labeling and customization
            axs[i].set_title(category, fontsize=14, fontweight='bold')
            axs[i].set_xlabel('', fontsize=14, fontweight='bold')
            axs[i].set_ylabel('Values', fontsize=14, fontweight='bold')
            axs[i].tick_params(axis='x', labelsize=12, width=2)
            axs[i].tick_params(axis='y', labelsize=12, width=2)

            # Set x-tick and y-tick labels to be bold
            for label in axs[i].get_xticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')
            for label in axs[i].get_yticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')

        plt.tight_layout()
        plt.subplots_adjust(hspace=0.4, wspace=0.5, top=0.95, bottom=0.05)

        # Save the figure as a high-quality PDF in the results folder
        pdf_filename = os.path.join(results_folder, f'overlapping_violin_comparison_features_{start_feature + 1}_to_{end_feature}.pdf')
        plt.savefig(pdf_filename, format='pdf', dpi=300)
        plt.figtext(0.5, 0.01, 'Overlapping violin plots comparing raw and synthetic data distributions.', ha='center', fontsize=12, fontweight='bold')
        plt.close(fig)


def plot_density(rawdata, syntheticdata, num_features, plots_storage_workspace):
    """
    Generates overlapping density plots with y-axis values normalized between 0 and 1 for comparing the 
    distributions of raw and synthetic time series data in a 3x3 grid layout. Saves the figures as PDFs.

    Parameters:
    rawdata (numpy.ndarray): Raw time series data. Shape: (time_steps, num_features)
    syntheticdata (numpy.ndarray): Synthetic time series data. Shape: (time_steps, num_features)
    num_features (int): Number of features to plot.
    plots_storage_workspace (str): Directory to save the generated plots.
    """

    # Updated colors with light tones
    colors = {'Real': '#a8dadc', 'Synthetic': '#f4a261'}  # Light teal and peach tones

    # Calculate number of plots per figure
    plots_per_figure = 9  # 3x3 grid
    num_figures = (num_features // plots_per_figure) + (1 if num_features % plots_per_figure != 0 else 0)

    # Create results directory if it doesn't exist
    results_folder = os.path.join(plots_storage_workspace, 'results')
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)

    for fig_idx in range(num_figures):
        start_feature = fig_idx * plots_per_figure
        end_feature = min(start_feature + plots_per_figure, num_features)
        n_plots = end_feature - start_feature

        # Create subplots for the current figure
        fig, axs = plt.subplots(3, 3, figsize=(18, 18))  # 3x3 grid
        axs = axs.flatten()  # Flatten to 1D for easier indexing

        for i in range(9):  # Loop through each subplot
            if i < n_plots:
                feature_idx = start_feature + i
                category = f'Feature {feature_idx + 1}'

                # Extract data for the current feature
                real_data = rawdata[:, feature_idx]
                synthetic_data = syntheticdata[:, feature_idx]

                # Compute KDE for real and synthetic data
                x_vals = np.linspace(min(real_data.min(), synthetic_data.min()),
                                     max(real_data.max(), synthetic_data.max()), 500)

                real_kde = gaussian_kde(real_data)
                synthetic_kde = gaussian_kde(synthetic_data)

                real_density = real_kde(x_vals)
                synthetic_density = synthetic_kde(x_vals)

                # Normalize densities to ensure max value is 1
                real_density /= real_density.max()
                synthetic_density /= synthetic_density.max()

                # Calculate area under the curve (AUC)
                real_auc = np.trapz(real_density, x_vals)
                synthetic_auc = np.trapz(synthetic_density, x_vals)

                # Plot the normalized densities
                axs[i].plot(x_vals, real_density, label=f'Real (AUC={real_auc:.2f})', color=colors['Real'], linewidth=2, alpha=0.7)
                axs[i].fill_between(x_vals, 0, real_density, color=colors['Real'], alpha=0.3)
                axs[i].plot(x_vals, synthetic_density, label=f'Synthetic (AUC={synthetic_auc:.2f})', color=colors['Synthetic'], linewidth=2, alpha=0.7)
                axs[i].fill_between(x_vals, 0, synthetic_density, color=colors['Synthetic'], alpha=0.3)

                # Labeling and customization
                axs[i].set_title(category, fontsize=14, fontweight='bold')
                axs[i].set_xlabel('Values', fontsize=12, fontweight='bold')
                axs[i].set_ylabel('Normalized Density', fontsize=12, fontweight='bold')
                axs[i].set_ylim(0, 1.1)  # Set y-axis between 0 and 1 with slight margin
                axs[i].tick_params(axis='x', labelsize=10)
                axs[i].tick_params(axis='y', labelsize=10)

                # Add legend
                axs[i].legend(fontsize=10, loc='upper right')
            else:
                # Hide unused subplots
                axs[i].axis('off')

        # Adjust layout
        plt.tight_layout()
        plt.subplots_adjust(hspace=0.4, wspace=0.4)

        # Save the figure as a high-quality PDF in the results folder
        pdf_filename = os.path.join(results_folder, f'overlapping_density_comparison_features_{start_feature + 1}_to_{end_feature}.pdf')
        plt.savefig(pdf_filename, format='pdf', dpi=300)
        plt.figtext(0.5, 0.01, 'Overlapping density plots comparing raw and synthetic data distributions (Normalized).', ha='center', fontsize=12, fontweight='bold')
        plt.close(fig)

def plot_box_whisker(rawdata, syntheticdata, num_features, plots_storage_workspace):
    """
    Generates separate box and whisker plots for raw and synthetic time series data
    in a 3x3 grid layout. Saves the figures as PDFs.

    Parameters:
    rawdata (numpy.ndarray): Raw time series data. Shape: (time_steps, num_features)
    syntheticdata (numpy.ndarray): Synthetic time series data. Shape: (time_steps, num_features)
    num_features (int): Number of features to plot.
    plots_storage_workspace (str): Directory to save the generated plots.
    """

    # Calculate number of plots per figure
    plots_per_figure = 9  # 3x3 grid
    num_figures = (num_features // plots_per_figure) + (1 if num_features % plots_per_figure != 0 else 0)

    # Create results directory if it doesn't exist
    results_folder = os.path.join(plots_storage_workspace, 'results')
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)

    for fig_idx in range(num_figures):
        start_feature = fig_idx * plots_per_figure
        end_feature = min(start_feature + plots_per_figure, num_features)
        n_plots = end_feature - start_feature

        # Create subplots for the current figure
        fig, axs = plt.subplots(3, 3, figsize=(18, 18))  # 3x3 grid
        axs = axs.flatten()  # Flatten to 1D for easier indexing

        for i in range(9):  # Loop through each subplot
            if i < n_plots:
                feature_idx = start_feature + i
                category = f'Feature {feature_idx + 1}'

                # Extract data for the current feature
                real_data = rawdata[:, feature_idx]
                synthetic_data = syntheticdata[:, feature_idx]

                # Create separate box plots for Real and Synthetic
                axs[i].boxplot(
                    real_data,
                    positions=[1],
                    vert=True,
                    patch_artist=True,
                    boxprops=dict(facecolor='lightblue', color='blue'),
                    medianprops=dict(color='black'),
                    whiskerprops=dict(color='blue'),
                    capprops=dict(color='blue'),
                    widths=0.5,
                )
                axs[i].boxplot(
                    synthetic_data,
                    positions=[2],
                    vert=True,
                    patch_artist=True,
                    boxprops=dict(facecolor='lightcoral', color='red'),
                    medianprops=dict(color='black'),
                    whiskerprops=dict(color='red'),
                    capprops=dict(color='red'),
                    widths=0.5,
                )

                # Customize x-axis for separate plots
                axs[i].set_xticks([1, 2])
                axs[i].set_xticklabels(['Real', 'Synthetic'])

                # Customize appearance
                axs[i].set_title(category, fontsize=14, fontweight='bold')
                axs[i].set_ylabel('Values', fontsize=14, fontweight='bold')  # Thicker y-axis label
                axs[i].set_xlabel('Dataset', fontsize=14, fontweight='bold')  # Thicker x-axis label
                
                # Make tick label values bold
                axs[i].tick_params(axis='x', labelsize=12, labelcolor='black', width=1.5, length=6)
                axs[i].tick_params(axis='y', labelsize=12, labelcolor='black', width=1.5, length=6)
            else:
                # Hide unused subplots
                axs[i].axis('off')

        # Adjust layout
        plt.tight_layout()
        plt.subplots_adjust(hspace=0.4, wspace=0.4)

        # Save the figure as a high-quality PDF in the results folder
        pdf_filename = os.path.join(results_folder, f'box_whisker_separate_features_{start_feature + 1}_to_{end_feature}.pdf')
        plt.savefig(pdf_filename, format='pdf', dpi=50)
        plt.figtext(0.5, 0.01, 'Separate box and whisker plots for raw and synthetic data.', ha='center', fontsize=12, fontweight='bold')
        plt.close(fig)

def plot_timeseries_with_anomalies(rawdata, syntheticdata, all_masks_2d, num_features, plots_storage_workspace):
    """
    Plots a comparison of time series data and their distributions between raw and synthetic datasets,
    and overlays anomaly masks as symbols on the time series plots. Saves the figures as high-quality PDFs.

    Parameters:
    rawdata (numpy.ndarray): Raw time series data. Shape: (time_steps, num_features)
    syntheticdata (numpy.ndarray): Synthetic time series data. Shape: (time_steps, num_features)
    all_masks_2d (numpy.ndarray): Anomaly mask data. Shape: (time_steps, num_features)
    num_features (int): Number of features to plot.
    plots_storage_workspace (str): Directory where the plots will be saved.
    """
    # Calculate the number of rows of subplots to generate
    num_rows = (num_features // 3) + (1 if num_features % 3 != 0 else 0)

    # Create the results directory if it doesn't exist
    results_folder = os.path.join(plots_storage_workspace, 'results')
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)

    for row in range(num_rows):
        start_feature = row * 3
        end_feature = min(start_feature + 3, num_features)
        n_categories = end_feature - start_feature

        # Create subplots for the current batch of features
        fig, axs = plt.subplots(n_categories, 2, figsize=(20, 4 * n_categories))

        if n_categories == 1:
            axs = np.array([axs])  # Ensure axs is iterable for consistent handling

        for i in range(n_categories):
            feature_idx = start_feature + i
            category = f'Feature {feature_idx + 1}'

            # Plot time series comparison
            axs[i, 0].plot(np.arange(rawdata.shape[0]), rawdata[:, feature_idx], label='Real', color='lightblue')
            axs[i, 0].plot(np.arange(syntheticdata.shape[0]), syntheticdata[:, feature_idx], 
                           label='Synthetic', color='lightsalmon', linestyle='dashed')
            
            # Overlay anomalies from all_masks_2d (symbols where mask == 0)
            anomaly_indices = np.where(all_masks_2d[:, feature_idx] == 0)[0]
            axs[i, 0].scatter(anomaly_indices, rawdata[anomaly_indices, feature_idx], 
                              color='red', marker='x', label='Anomaly', s=50)

            axs[i, 0].set_title(f'{category} - Time Series', fontsize=14, fontweight='bold')
            axs[i, 0].set_xlabel('Time', fontsize=14, fontweight='bold')
            axs[i, 0].set_ylabel('Values', fontsize=14, fontweight='bold')
            legend = axs[i, 0].legend(fontsize=12, frameon=True, loc='best')
            for text in legend.get_texts():
                text.set_fontweight('bold')
            legend.get_frame().set_edgecolor('black')
            legend.get_frame().set_linewidth(2)
            axs[i, 0].tick_params(axis='x', labelrotation=45, labelsize=12, width=2)
            axs[i, 0].tick_params(axis='y', labelsize=12, width=2)

            # Set x-tick and y-tick labels to be bold
            for label in axs[i, 0].get_xticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')
            for label in axs[i, 0].get_yticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')

            # Plot histogram comparison for distributions
            axs[i, 1].hist(rawdata[:, feature_idx], bins=20, alpha=0.5, label='Real', color='lightblue', edgecolor='black')
            axs[i, 1].hist(syntheticdata[:, feature_idx], bins=20, alpha=0.5, label='Synthetic', color='lightsalmon', edgecolor='black')
            axs[i, 1].set_title(f'{category} - Distribution', fontsize=14, fontweight='bold')
            axs[i, 1].set_xlabel('Value', fontsize=14, fontweight='bold')
            axs[i, 1].set_ylabel('Frequency', fontsize=14, fontweight='bold')
            legend = axs[i, 1].legend(fontsize=12, frameon=True, loc='best')
            for text in legend.get_texts():
                text.set_fontweight('bold')
            legend.get_frame().set_edgecolor('black')
            legend.get_frame().set_linewidth(2)
            axs[i, 1].tick_params(axis='x', labelrotation=0, labelsize=12, width=2)
            axs[i, 1].tick_params(axis='y', labelsize=12, width=2)

            # Set x-tick and y-tick labels to be bold
            for label in axs[i, 1].get_xticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')
            for label in axs[i, 1].get_yticklabels():
                label.set_fontsize(12)
                label.set_fontweight('bold')

        # Adjust layout with more bottom space for the last row
        plt.tight_layout()
        plt.subplots_adjust(hspace=0.7, wspace=0.5, top=0.95, bottom=0.1)

        # Save the figure as a high-quality PDF in the results folder
        pdf_filename = os.path.join(results_folder, f'timeseries_comparison_features_{start_feature + 1}_to_{end_feature}.pdf')
        plt.savefig(pdf_filename, format='pdf', dpi=300)
        plt.close(fig)