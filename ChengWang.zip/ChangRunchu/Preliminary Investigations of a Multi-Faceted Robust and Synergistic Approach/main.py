import torch
import torch.optim as optim
from torch.utils.data import DataLoader
import argparse
import os
from tqdm import tqdm

from config.config import ModelConfig
from data.dataset import get_data_loaders
from models.cm_emrl import CMEMRL
from utils.metrics import calculate_metrics

def parse_args():
    parser = argparse.ArgumentParser(description='Train CM-EMRL model')
    parser.add_argument('--data_path', type=str, required=True,
                      help='Path to SEM dataset')
    parser.add_argument('--checkpoint_dir', type=str, default='checkpoints',
                      help='Directory to save checkpoints')
    parser.add_argument('--resume', type=str, default=None,
                      help='Path to checkpoint to resume from')
    return parser.parse_args()

def train(config, model, train_loader, val_loader, optimizer, start_epoch=0, best_acc=0):
    """Training loop for the CM-EMRL model."""
    num_epochs = config.num_epochs
    device = config.device
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', patience=5)
    
    for epoch in range(start_epoch, num_epochs):
        model.train()
        train_loss = 0
        train_correct = 0
        train_total = 0
        
        # Training loop
        train_pbar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{num_epochs} [Train]')
        for batch in train_pbar:
            # Training step
            loss = model.train_step(batch, optimizer)
            
            # Update statistics
            train_loss += loss
            predicted = torch.max(outputs.data, 1)[1]
            train_total += labels.size(0)
            train_correct += predicted.eq(labels.data).sum().item()
            
            # Update progress bar
            train_pbar.set_postfix({
                'loss': f'{train_loss/(batch_idx+1):.4f}',
                'acc': f'{100.*train_correct/train_total:.2f}%'
            })
        
        # Validation loop
        model.eval()
        val_loss = 0
        val_correct = 0
        val_total = 0
        
        val_pbar = tqdm(val_loader, desc=f'Epoch {epoch+1}/{num_epochs} [Val]')
        with torch.no_grad():
            for batch in val_pbar:
                # Validation step
                loss, correct, total = model.validate_step(batch)
                
                # Update statistics
                val_loss += loss
                val_correct += correct
                val_total += total
                
                # Update progress bar
                val_pbar.set_postfix({
                    'loss': f'{val_loss/(batch_idx+1):.4f}',
                    'acc': f'{100.*val_correct/val_total:.2f}%'
                })
        
        # Calculate epoch statistics
        train_loss = train_loss / len(train_loader)
        train_acc = 100. * train_correct / train_total
        val_loss = val_loss / len(val_loader)
        val_acc = 100. * val_correct / val_total
        
        # Update learning rate scheduler
        scheduler.step(val_acc)
        
        # Save best model
        if val_acc > best_acc:
            best_acc = val_acc
            checkpoint_path = os.path.join(config.checkpoint_dir, 'best_model.pth')
            model.save_checkpoint(checkpoint_path, epoch, optimizer, best_acc)
        
        # Print epoch summary
        print(f'\nEpoch {epoch+1}/{num_epochs}:')
        print(f'Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}%')
        print(f'Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.2f}%')
        print(f'Best Val Acc: {best_acc:.2f}%')
        
    return best_acc

def main():
    args = parse_args()
    
    # Create checkpoint directory if it doesn't exist
    os.makedirs(args.checkpoint_dir, exist_ok=True)
    
    # Initialize config
    config = ModelConfig()
    config.train_data_path = args.data_path
    
    # Get data loaders
    train_loader, val_loader = get_data_loaders(config)
    
    # Initialize model
    model = CMEMRL(config).to(config.device)
    optimizer = optim.Adam(model.parameters(), lr=config.learning_rate, 
                         weight_decay=config.weight_decay)
    
    # Resume from checkpoint if specified
    start_epoch = 0
    best_acc = 0
    if args.resume:
        print(f"Resuming from checkpoint: {args.resume}")
        start_epoch, best_acc = model.load_checkpoint(args.resume, optimizer)
        print(f"Resumed from epoch {start_epoch} with best accuracy {best_acc:.2f}%")
    
    # Train model
    try:
        best_acc = train(config, model, train_loader, val_loader, optimizer, 
                        start_epoch, best_acc)
        print(f"\nTraining completed. Best validation accuracy: {best_acc:.2f}%")
    except KeyboardInterrupt:
        print("\nTraining interrupted by user")
        # Save checkpoint on interrupt
        checkpoint_path = os.path.join(args.checkpoint_dir, 'interrupted.pth')
        model.save_checkpoint(checkpoint_path, epoch, optimizer, best_acc)
        print(f"Saved checkpoint to {checkpoint_path}")
    
if __name__ == '__main__':
    main()