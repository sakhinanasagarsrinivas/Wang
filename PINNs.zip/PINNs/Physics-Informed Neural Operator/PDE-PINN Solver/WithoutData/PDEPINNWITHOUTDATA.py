import torch
import torch.nn as nn
import numpy as np
import json
import argparse
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import time
import os

torch.manual_seed(42)
np.random.seed(42)

class FourierFeatureMapping(nn.Module):
    def __init__(self, num_inputs, mapping_size, scale):
        super().__init__()
        self.B = nn.Parameter(torch.randn((num_inputs, mapping_size)) * scale, requires_grad=False)
    
    def forward(self, x):
        x_proj = (2. * torch.pi * x) @ self.B
        return torch.cat([x, torch.sin(x_proj), torch.cos(x_proj)], dim=-1)

class AdaptiveActivation(nn.Module):
    def __init__(self, activation_fn):
        super().__init__()
        self.activation = activation_fn()
        self.a = nn.Parameter(torch.ones(1))
    
    def forward(self, x):
        return self.a * self.activation(x)

class PINN(nn.Module):
    def __init__(self, config):
        super(PINN, self).__init__()
        self.state_vars = config['state_variables']
        num_inputs = len(config['spatial_dims']) + 1
        num_outputs = len(config['state_variables'])
        hp = config['hyperparameters']
        hidden_layers = hp['hidden_layers']
        neurons_per_layer = hp['neurons_per_layer']
        
        activation_map = {"tanh": nn.Tanh, "relu": nn.ReLU, "sigmoid": nn.Sigmoid, "swish": nn.SiLU}
        base_activation_fn = activation_map.get(hp['activation_function'], nn.Tanh)
        
        ff_config = hp.get('fourier_features', {'enabled': False})
        aa_config = hp.get('adaptive_activation', {'enabled': False})
        
        self.fourier_mapping = None
        if ff_config.get('enabled', False):
            self.fourier_mapping = FourierFeatureMapping(
                num_inputs, ff_config['mapping_size'], ff_config['scale']
            )
            processed_input_size = num_inputs + 2 * ff_config['mapping_size']
        else:
            processed_input_size = num_inputs

        layers = []
        layers.append(nn.Linear(processed_input_size, neurons_per_layer))
        
        if aa_config.get('enabled', False):
            layers.append(AdaptiveActivation(base_activation_fn))
        else:
            layers.append(base_activation_fn())
            
        for _ in range(hidden_layers - 1):
            layers.append(nn.Linear(neurons_per_layer, neurons_per_layer))
            if aa_config.get('enabled', False):
                layers.append(AdaptiveActivation(base_activation_fn))
            else:
                layers.append(base_activation_fn())
                
        layers.append(nn.Linear(neurons_per_layer, num_outputs))
        
        self.net = nn.Sequential(*layers)
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def _improved_temperature_constraint(self, T_raw):
        T_min = 0.5
        return T_min + torch.nn.functional.softplus(T_raw, beta=0.5)

    def forward(self, xt):
        if self.fourier_mapping is not None: 
            xt = self.fourier_mapping(xt)
        outputs = self.net(xt)
        
        outputs_constrained = outputs.clone()
        if len(self.state_vars) > 1 and 'T' in self.state_vars:
            T_idx = self.state_vars.index('T')
            outputs_constrained[:, T_idx] = self._improved_temperature_constraint(outputs[:, T_idx])
        
        return outputs_constrained

class PINNSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._build_model()
        self.loss_scaling_factors = {}
        self.prev_scales = {}

    def _parse_config(self):
        self.problem_name = self.config['problem_name']
        self.state_vars = self.config['state_variables']
        self.pde = self.config['pde']
        self.spatial_domain_def = self.config['spatial_domain']
        self.spatial_dims = list(self.spatial_domain_def.keys())
        self.t_domain = torch.tensor(self.config['time_domain'], device=self.device)
        self.params = self.config.get('parameters', {})
        self.ic_def = self.config['initial_conditions']
        self.bc_def = self.config['boundary_conditions']

        hp = self.config['hyperparameters']
        self.lr = hp['learning_rate']
        self.epochs_per_stage = hp['epochs_per_stage']
        self.lbfgs_max_iter = hp.get('lbfgs_max_iter', 20000)
        self.num_collocation = hp['num_collocation_points']
        self.num_ic = hp['num_ic_points']
        self.num_bc = hp['num_bc_points']
        self.loss_weights = hp['loss_weights']

        self.cl_config = hp.get('curriculum_learning', {'enabled': False})
        self.ar_config = hp.get('adaptive_refinement', {'enabled': False})
        self.adaptive_weights = hp.get('adaptive_weights', {'enabled': False})

    def _build_model(self):
        model_config = {
            'spatial_dims': self.spatial_dims,
            'state_variables': self.state_vars,
            'hyperparameters': self.config['hyperparameters']
        }
        self.model = PINN(model_config).to(self.device)
        
        self.optimizer_adam = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        self.optimizer_lbfgs = torch.optim.LBFGS(
            self.model.parameters(), 
            max_iter=self.lbfgs_max_iter,
            line_search_fn="strong_wolfe",
            tolerance_grad=1e-8,
            tolerance_change=1e-10
        )
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer_adam, 'min', factor=0.7, patience=2000, min_lr=1e-7
        )

    def _physics_informed_sampling(self, t_max):
        x_range = self.spatial_domain_def['x']
        
        n_uniform = int(0.5 * self.num_collocation)
        x_uniform = x_range[0] + (x_range[1] - x_range[0]) * torch.rand(n_uniform, 1, device=self.device)
        t_uniform = self.t_domain[0] + (t_max - self.t_domain[0]) * torch.rand(n_uniform, 1, device=self.device)
        
        n_physics = self.num_collocation - n_uniform
        x_physics = []
        for _ in range(n_physics):
            if torch.rand(1) < 0.4:
                x_val = x_range[0] + 0.2 * torch.rand(1) * (x_range[1] - x_range[0])
            else:
                x_val = x_range[0] + (0.2 + 0.6 * torch.rand(1)) * (x_range[1] - x_range[0])
            x_physics.append(x_val)
        
        x_physics = torch.stack(x_physics).to(self.device)
        t_physics = self.t_domain[0] + (t_max - self.t_domain[0]) * torch.rand(n_physics, 1, device=self.device)
        
        x_combined = torch.cat([x_uniform, x_physics], dim=0)
        t_combined = torch.cat([t_uniform, t_physics], dim=0)
        
        self.xt_collocation = torch.cat([x_combined, t_combined], dim=1)

    def _prepare_data_points(self, t_max):
        self._physics_informed_sampling(t_max)

        x_range = self.spatial_domain_def['x']
        x_ic = x_range[0] + (x_range[1] - x_range[0]) * torch.rand(self.num_ic, 1, device=self.device)
        t_ic = torch.zeros_like(x_ic, device=self.device)
        self.xt_ic = torch.cat([x_ic, t_ic], dim=1)

        t_bc = self.t_domain[0] + (t_max - self.t_domain[0]) * torch.rand(self.num_bc, 1, device=self.device)
        self.t_bc = t_bc

    def _get_eval_scope(self, scope_vars):
        scope = scope_vars.copy()
        scope.update(self.params)
        scope.update({'exp': torch.exp, 'sin': torch.sin, 'cos': torch.cos, 'pi': torch.pi})
        return scope

    def _compute_gradients(self, xt, outputs):
        gradients = {}
        for i, var_name in enumerate(self.state_vars):
            var = outputs[:, i]
            grad_outputs = torch.ones_like(var)
            
            first_grad = torch.autograd.grad(
                outputs=var, 
                inputs=xt,
                grad_outputs=grad_outputs,
                create_graph=True,
                retain_graph=True
            )[0]
            
            dvardx, dvardt = first_grad[:, 0], first_grad[:, 1]
            
            second_grad_x = torch.autograd.grad(
                outputs=dvardx,
                inputs=xt,
                grad_outputs=torch.ones_like(dvardx),
                create_graph=True,
                retain_graph=True
            )[0]
            dvardx2 = second_grad_x[:, 0]
            
            gradients[f'd{var_name}dt'] = dvardt
            gradients[f'd{var_name}dx'] = dvardx
            gradients[f'd{var_name}dx2'] = dvardx2
            
        return gradients

    def _get_pde_residuals(self, xt_collocation):
        xt_collocation.requires_grad_(True)
        outputs = self.model(xt_collocation)
        
        scope_vars = {'x': xt_collocation[:, 0], 't': xt_collocation[:, 1]}
        for i, var_name in enumerate(self.state_vars):
            scope_vars[var_name] = outputs[:, i]
        
        gradients = self._compute_gradients(xt_collocation, outputs)
        scope_vars.update(gradients)
        
        scope = self._get_eval_scope(scope_vars)
        
        residuals = []
        for pde_string in self.pde:
            residuals.append(eval(pde_string, {}, scope))
        return residuals

    def _pde_residual_loss(self):
        residuals = self._get_pde_residuals(self.xt_collocation)
        losses = [torch.mean(r**2) for r in residuals]
        return losses

    def _ic_loss(self):
        u_pred = self.model(self.xt_ic)
        total_ic_loss = 0.0
        scope_vars = {'x': self.xt_ic[:, 0].squeeze()}
        scope = self._get_eval_scope(scope_vars)
        
        for i, var_name in enumerate(self.state_vars):
            u_pred_var = u_pred[:, i]
            u_true_var = eval(self.ic_def[var_name], {}, scope)
            total_ic_loss += torch.mean((u_pred_var.squeeze() - u_true_var.squeeze())**2)
        return total_ic_loss

    def _bc_loss(self):
        total_bc_loss = 0.0
        x_min, x_max = self.spatial_domain_def['x']
        
        for bc in self.bc_def:
            x_bc = torch.full_like(self.t_bc, x_min if bc['location'] == 'x_min' else x_max)
            xt_bc = torch.cat([x_bc, self.t_bc], dim=1)
            
            scope_vars = {'t': self.t_bc.squeeze()}
            scope = self._get_eval_scope(scope_vars)
            true_val = eval(str(bc['value']), {}, scope)
            
            if isinstance(true_val, (int, float)):
                true_val = torch.full((self.t_bc.shape[0],), true_val, device=self.device)
            else:
                true_val = true_val.flatten()
            
            var_idx = self.state_vars.index(bc['variable'])
            
            if bc['type'] == 'Dirichlet':
                u_pred = self.model(xt_bc)[:, var_idx]
                loss = torch.mean((u_pred - true_val)**2)
            elif bc['type'] == 'Neumann':
                xt_bc.requires_grad_(True)
                var_pred = self.model(xt_bc)[:, var_idx]
                grad_var = torch.autograd.grad(
                    var_pred, xt_bc, 
                    grad_outputs=torch.ones_like(var_pred), 
                    create_graph=True
                )[0]
                dudx_pred = grad_var[:, 0]
                loss = torch.mean((dudx_pred - true_val)**2)
            
            total_bc_loss += loss
        return total_bc_loss

    def _compute_adaptive_weights(self, epoch):
        if not self.adaptive_weights.get('enabled', False):
            return
            
        with torch.no_grad():
            pde_losses = self._pde_residual_loss()
            ic_loss = self._ic_loss()
            bc_loss = self._bc_loss()
            
            pde_ca_scale = 1.0 / (pde_losses[0].item() + 1e-8)
            pde_t_scale = 1.0 / (pde_losses[1].item() + 1e-8)
            
            alpha = 0.9
            if hasattr(self, 'prev_scales') and self.prev_scales:
                self.loss_scaling_factors['pde_Ca'] = alpha * self.prev_scales['pde_Ca'] + (1-alpha) * pde_ca_scale
                self.loss_scaling_factors['pde_T'] = alpha * self.prev_scales['pde_T'] + (1-alpha) * pde_t_scale
            else:
                self.loss_scaling_factors['pde_Ca'] = pde_ca_scale
                self.loss_scaling_factors['pde_T'] = pde_t_scale
                
            self.prev_scales = self.loss_scaling_factors.copy()
    
    def _total_loss(self):
        loss_pde_list = self._pde_residual_loss()
        loss_pde_Ca = loss_pde_list[0]
        loss_pde_T = loss_pde_list[1]
        loss_ic = self._ic_loss()
        loss_bc = self._bc_loss()
        
        self.current_losses = {
            'pde_Ca': loss_pde_Ca.item(),
            'pde_T': loss_pde_T.item(),
            'ic': loss_ic.item(), 
            'bc': loss_bc.item()
        }
        
        if self.adaptive_weights.get('enabled', False) and self.loss_scaling_factors:
            pde_ca_weight = self.loss_weights['pde_Ca'] * self.loss_scaling_factors.get('pde_Ca', 1.0)
            pde_t_weight = self.loss_weights['pde_T'] * self.loss_scaling_factors.get('pde_T', 1.0)
        else:
            pde_ca_weight = self.loss_weights['pde_Ca']
            pde_t_weight = self.loss_weights['pde_T']
        
        total_loss = (pde_ca_weight * loss_pde_Ca +
                      pde_t_weight * loss_pde_T +
                      self.loss_weights['initial_condition'] * loss_ic +
                      self.loss_weights['boundary_condition'] * loss_bc)
        
        return total_loss
    
    def _refine_collocation_points(self, t_max):
        print("--- Running Adaptive Refinement ---")
        self.model.eval()
        num_candidates = self.num_collocation * self.ar_config['candidate_multiplier']
        x_range = self.spatial_domain_def['x']
        
        x_cand = x_range[0] + (x_range[1] - x_range[0]) * torch.rand(num_candidates, 1, device=self.device)
        t_cand = self.t_domain[0] + (t_max - self.t_domain[0]) * torch.rand(num_candidates, 1, device=self.device)
        xt_candidates = torch.cat([x_cand, t_cand], dim=1)
        xt_candidates.requires_grad_(True)
        
        residuals = self._get_pde_residuals(xt_candidates)
        total_residual_sq = sum(r**2 for r in residuals)
        
        _, top_indices = torch.topk(total_residual_sq.detach(), k=self.ar_config['points_to_add'])
        hard_points = xt_candidates.detach()[top_indices]
        
        self.xt_collocation = torch.cat([self.xt_collocation, hard_points], dim=0)
        print(f"Added {self.ar_config['points_to_add']} hard points. New total: {self.xt_collocation.shape[0]}")
        self.model.train()

    def train(self):
        print(f"--- Starting training for {self.problem_name} ---")
        start_time = time.time()
        self.model.train()

        time_windows = self.cl_config.get('time_windows', [self.t_domain[1].item()]) if self.cl_config['enabled'] else [self.t_domain[1].item()]

        for i, t_max_val in enumerate(time_windows):
            t_max = torch.tensor(t_max_val, device=self.device)
            print(f"\n--- Curriculum Stage {i+1}/{len(time_windows)}: Training up to t={t_max.item():.2f} ---")
            self._prepare_data_points(t_max)
            
            best_loss = float('inf')
            patience_counter = 0
            
            for epoch in range(self.epochs_per_stage):
                self._compute_adaptive_weights(epoch)
                
                self.optimizer_adam.zero_grad(set_to_none=True)
                total_loss = self._total_loss()
                total_loss.backward()
                
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.optimizer_adam.step()
                self.scheduler.step(total_loss)

                if total_loss.item() < best_loss:
                    best_loss = total_loss.item()
                    patience_counter = 0
                else:
                    patience_counter += 1

                if self.ar_config['enabled'] and (epoch + 1) % self.ar_config['refinement_frequency'] == 0:
                    self._refine_collocation_points(t_max)

                if (epoch + 1) % 2000 == 0:
                    current_lr = self.optimizer_adam.param_groups[0]['lr']
                    print(f'Epoch [{epoch+1}/{self.epochs_per_stage}], Loss: {total_loss.item():.4e}, LR: {current_lr:.2e}')
                    print(f"  PDE_Ca: {self.current_losses['pde_Ca']:.4e}, "
                          f"PDE_T: {self.current_losses['pde_T']:.4e}, "
                          f"IC: {self.current_losses['ic']:.4e}, "
                          f"BC: {self.current_losses['bc']:.4e}")

        print("\n--- Phase 2: L-BFGS Optimizer (Full Domain) ---")
        self._prepare_data_points(self.t_domain[1])
        
        def closure():
            self.optimizer_lbfgs.zero_grad()
            total_loss = self._total_loss()
            total_loss.backward()
            return total_loss
        
        try:
            self.optimizer_lbfgs.step(closure)
        except RuntimeError as e:
            print(f"L-BFGS failed: {e}")
        
        final_loss = self._total_loss()
        print(f'L-BFGS Final Loss: {final_loss.item():.4e}')
        
        elapsed_time = time.time() - start_time
        print(f"\n--- Training finished in {elapsed_time:.2f} seconds ---")

    def solve_with_numerical_integrator(self, x_grid, t_eval):
        print("Solving with SciPy (Method of Lines) as a baseline...")
        dx = x_grid[1] - x_grid[0]
        nx = len(x_grid)
        p = self.params
        
        def pde_system(t, y):
            Ca = y[:nx]
            T = y[nx:]
            dydt = np.zeros_like(y)
            
            T = np.maximum(T, 0.5)
            
            for i in range(1, nx-1):
                Ca_xx = (Ca[i+1] - 2*Ca[i] + Ca[i-1]) / dx**2
                T_xx = (T[i+1] - 2*T[i] + T[i-1]) / dx**2
                Ca_x = (Ca[i+1] - Ca[i-1]) / (2*dx)
                T_x = (T[i+1] - T[i-1]) / (2*dx)
                
                reaction_rate = p['k0'] * np.exp(-p['Ea_over_R'] / T[i]) * Ca[i]
                
                dydt[i] = p['D'] * Ca_xx - p['v'] * Ca_x - reaction_rate
                dydt[nx+i] = p['alpha'] * T_xx - p['v'] * T_x + p['beta'] * reaction_rate
            
            dydt[0] = 0
            dydt[nx] = 0
            
            Ca_x_end = 0.0
            T_x_end = 0.0
            Ca_xx_end = (Ca[-2] - Ca[-1]) / dx**2
            T_xx_end = (T[-2] - T[-1]) / dx**2
            
            reaction_rate_end = p['k0'] * np.exp(-p['Ea_over_R'] / T[-1]) * Ca[-1]
            
            dydt[nx-1] = p['D'] * Ca_xx_end - p['v'] * Ca_x_end - reaction_rate_end
            dydt[2*nx-1] = p['alpha'] * T_xx_end - p['v'] * T_x_end + p['beta'] * reaction_rate_end
            
            return dydt

        scope = self._get_eval_scope({'x': x_grid})
        scope.update({'exp': np.exp, 'sin': np.sin, 'cos': np.cos, 'pi': np.pi})
        
        Ca0 = eval(self.ic_def['Ca'], {}, scope)
        T0 = eval(self.ic_def['T'], {}, scope)
        
        Ca0[0] = p['Ca_in'] 
        T0[0] = p['T_in']
        T0 = np.maximum(T0, 0.5)
        
        y0 = np.concatenate([Ca0, T0])
        
        sol = solve_ivp(pde_system, (self.t_domain[0].item(), self.t_domain[1].item()), 
                       y0, t_eval=t_eval, method='Radau', rtol=1e-10, atol=1e-12,
                       max_step=0.005)
        
        if not sol.success:
            print(f"Integration failed: {sol.message}")
            return None, None
        
        Ca_sol = sol.y[:nx, :].T
        T_sol = sol.y[nx:, :].T
        return Ca_sol, T_sol

    def evaluate_and_plot_results(self):
        self.model.eval()
        os.makedirs("results", exist_ok=True)
        base_filename = f"results/{self.problem_name.replace(' ', '_').lower()}"

        x_range = self.spatial_domain_def['x']
        t_range = self.t_domain.cpu().numpy()
        x = torch.linspace(x_range[0], x_range[1], 101, device=self.device)
        t = torch.linspace(t_range[0], t_range[1], 51, device=self.device)
        X, T_grid = torch.meshgrid(x, t, indexing='ij')
        xt_grid = torch.stack([X.flatten(), T_grid.flatten()], dim=1)

        with torch.no_grad():
            u_pinn_flat = self.model(xt_grid).cpu().numpy()
            u_pinn = u_pinn_flat.reshape(X.shape[0], X.shape[1], len(self.state_vars))
        
        x_np = X.cpu().numpy()[:, 0]
        t_np = T_grid.cpu().numpy()[0, :]
        
        numerical_result = self.solve_with_numerical_integrator(x_np, t_np)
        if numerical_result[0] is None:
            print("Numerical integration failed, skipping comparison")
            return
            
        Ca_numerical, T_numerical = numerical_result
        
        fig, axes = plt.subplots(len(self.state_vars), 3, figsize=(18, 5 * len(self.state_vars)), squeeze=False)
        
        numerical_sols = [Ca_numerical, T_numerical]

        for i, var_name in enumerate(self.state_vars):
            pinn_sol = u_pinn[:, :, i]
            num_sol = numerical_sols[i].T 
            
            vmin = min(pinn_sol.min(), num_sol.min())
            vmax = max(pinn_sol.max(), num_sol.max())
            
            c1 = axes[i, 0].pcolormesh(T_grid.cpu(), X.cpu(), pinn_sol, cmap='viridis', shading='gouraud', vmin=vmin, vmax=vmax)
            fig.colorbar(c1, ax=axes[i, 0])
            axes[i, 0].set_title(f'PINN Solution {var_name}(x,t)')
            axes[i, 0].set_xlabel('Time (t)')
            axes[i, 0].set_ylabel('Space (x)')

            c2 = axes[i, 1].pcolormesh(T_grid.cpu(), X.cpu(), num_sol, cmap='viridis', shading='gouraud', vmin=vmin, vmax=vmax)
            fig.colorbar(c2, ax=axes[i, 1])
            axes[i, 1].set_title(f'Numerical Baseline {var_name}(x,t)')
            axes[i, 1].set_xlabel('Time (t)')
            axes[i, 1].set_ylabel('Space (x)')

            error = np.abs(pinn_sol - num_sol)
            c3 = axes[i, 2].pcolormesh(T_grid.cpu(), X.cpu(), error, cmap='inferno', shading='gouraud')
            fig.colorbar(c3, ax=axes[i, 2])
            axes[i, 2].set_title('Absolute Error')
            axes[i, 2].set_xlabel('Time (t)')
            axes[i, 2].set_ylabel('Space (x)')

            mse_error = np.mean((pinn_sol - num_sol)**2)
            max_error = np.max(np.abs(pinn_sol - num_sol))
            rel_error = np.mean(np.abs((pinn_sol - num_sol) / (num_sol + 1e-10)))
            
            print(f"Metrics for {var_name}:")
            print(f"  Mean Squared Error: {mse_error:.6e}")
            print(f"  Maximum Absolute Error: {max_error:.6e}")
            print(f"  Mean Relative Error: {rel_error:.6e}")

        plt.tight_layout()
        solution_filename = f"{base_filename}_solution.pdf"
        plt.savefig(solution_filename, format='pdf', bbox_inches='tight')
        plt.close(fig)
        print(f"\nSolution comparison plot saved to {solution_filename}")

def main():
    parser = argparse.ArgumentParser(description="Generic PDE-PINN Solver")
    parser.add_argument(
        "config_file", type=str,
        help="Path to the JSON configuration file.",
        default="problem_config_revised.json", nargs='?'
    )
    args = parser.parse_args()
    
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{args.config_file}' not found.")
        return
    
    solver = PINNSolver(config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()