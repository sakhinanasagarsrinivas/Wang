import torch
from torch_geometric.data import Dataset, Data
from rdkit import Chem
import numpy as np
from pathlib import Path
from typing import List, Tuple, Optional
import pandas as pd
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.chat_models import ChatOpenAI

class MoleculeDataset(Dataset):
    def __init__(self, 
                 root: str,
                 dataset_name: str,
                 transform=None,
                 pre_transform=None,
                 llm_model: str = "gpt-3.5-turbo"):
        """
        Initialize the dataset
        
        Args:
            root: Root directory where the dataset should be saved
            dataset_name: Name of the dataset (QM8 or QM9)
            transform: Transform to be applied to the data
            pre_transform: Transform to be applied to the data before saving
            llm_model: Name of the LLM model to use
        """
        self.dataset_name = dataset_name
        self.llm = ChatOpenAI(model_name=llm_model, temperature=0)
        self.prompt_template = self._create_prompt_template()
        self.chain = LLMChain(llm=self.llm, prompt=self.prompt_template)
        
        super().__init__(root, transform, pre_transform)

    def _create_prompt_template(self) -> PromptTemplate:
        """Create the prompt template for the LLM"""
        template = """
        Analyze the following molecule in SMILES notation: {smiles}
        
        Provide detailed information about:
        1. Molecular structure (atoms, bonds, functional groups)
        2. Physical properties
        3. Chemical reactivity
        4. Common reactions
        5. Applications
        
        Be specific and technical in your response.
        """
        return PromptTemplate(
            input_variables=["smiles"],
            template=template
        )

    @property
    def raw_file_names(self) -> List[str]:
        """List of raw file names"""
        if self.dataset_name == "QM9":
            return ['qm9.csv']
        return ['qm8.csv']

    @property
    def processed_file_names(self) -> List[str]:
        """List of processed file names"""
        return [f'data_{idx}.pt' for idx in range(len(self))]

    def download(self):
        """Download the dataset"""
        # Implement dataset specific download logic
        pass

    def _get_llm_description(self, smiles: str) -> str:
        """Get molecule description from LLM"""
        response = self.chain.run(smiles=smiles)
        return response

    def process(self):
        """Process the raw data"""
        raw_data = pd.read_csv(self.raw_paths[0])
        
        for idx, row in raw_data.iterrows():
            # Convert SMILES to molecule
            mol = Chem.MolFromSmiles(row['smiles'])
            
            # Get features
            x = self._get_node_features(mol)
            edge_index, edge_attr = self._get_edge_features(mol)
            
            # Get LLM description
            llm_desc = self._get_llm_description(row['smiles'])
            
            # Create data object
            data = Data(
                x=torch.FloatTensor(x),
                edge_index=torch.LongTensor(edge_index),
                edge_attr=torch.FloatTensor(edge_attr),
                y=torch.FloatTensor([row['target']]),
                smiles=row['smiles'],
                llm_desc=llm_desc
            )
            
            torch.save(data, Path(self.processed_dir) / f'data_{idx}.pt')

    def _get_node_features(self, mol: Chem.Mol) -> np.ndarray:
        """Extract node features from molecule"""
        features = []
        for atom in mol.GetAtoms():
            features.append([
                atom.GetAtomicNum(),
                atom.GetDegree(),
                atom.GetFormalCharge(),
                atom.GetNumRadicalElectrons(),
                atom.GetIsAromatic(),
                atom.GetHybridization(),
                atom.GetTotalNumHs(),
                atom.GetImplicitValence(),
                atom.GetIsInRing()
            ])
        return np.array(features)

    def _get_edge_features(self, mol: Chem.Mol) -> Tuple[np.ndarray, np.ndarray]:
        """Extract edge features from molecule"""
        edges = []
        edge_features = []
        
        for bond in mol.GetBonds():
            i = bond.GetBeginAtomIdx()
            j = bond.GetEndAtomIdx()
            
            edge_feature = [
                bond.GetBondTypeAsDouble(),
                bond.GetIsConjugated(),
                bond.GetIsAromatic(),
                bond.IsInRing()
            ]
            
            # Add both directions
            edges.extend([[i, j], [j, i]])
            edge_features.extend([edge_feature, edge_feature])

        return np.array(edges).T, np.array(edge_features)

    def len(self) -> int:
        """Return the length of the dataset"""
        return len(list(Path(self.processed_dir).glob('data_*.pt')))

    def get(self, idx: int) -> Data:
        """Get a single data point"""
        data = torch.load(Path(self.processed_dir) / f'data_{idx}.pt')
        return data