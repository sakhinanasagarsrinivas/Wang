"""
core.py - Core components for Temporal Knowledge Graph Forecasting
"""

import os
import logging
import torch
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Union
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TimeGranularity(str, Enum):
    """Time granularity for temporal knowledge graphs"""
    HOURS_24 = "24h"
    YEAR = "1y"

class ValidationError(Exception):
    """Base class for validation errors"""
    pass

@dataclass
class DatasetConfig:
    """Configuration for dataset processing"""
    name: str
    time_granularity: TimeGranularity
    train_ratio: float = 0.8
    val_ratio: float = 0.1
    test_ratio: float = 0.1
    min_frequency: int = 5
    window_size: int = 25

@dataclass
class Quadruple:
    """Single fact in temporal knowledge graph"""
    subject: str
    relation: str
    object: str
    timestamp: datetime

    def validate(self) -> bool:
        """Validate quadruple data"""
        if not all([self.subject, self.relation, self.object]):
            raise ValidationError("Missing required fields in quadruple")
        if not isinstance(self.timestamp, datetime):
            raise ValidationError("Invalid timestamp type")
        return True

@dataclass
class DatasetStats:
    """Statistics for temporal knowledge graph dataset"""
    num_entities: int
    num_relations: int
    num_timestamps: int
    time_range: Tuple[datetime, datetime]
    density: float
    fact_count: int
    entity_degrees: Dict[str, int]
    relation_counts: Dict[str, int]

    def validate(self) -> bool:
        """Validate dataset statistics"""
        try:
            assert self.num_entities > 0
            assert self.num_relations > 0
            assert self.num_timestamps > 0
            assert self.time_range[0] < self.time_range[1]
            assert 0 <= self.density <= 1
            assert self.fact_count > 0
            return True
        except AssertionError as e:
            logger.error(f"Statistics validation failed: {str(e)}")
            return False

def compute_dataset_stats(quadruples: List[Quadruple]) -> DatasetStats:
    """Compute comprehensive dataset statistics"""
    try:
        # Extract unique elements
        entities = set()
        relations = set()
        timestamps = set()
        entity_counts = {}
        relation_counts = {}

        for q in quadruples:
            entities.add(q.subject)
            entities.add(q.object)
            relations.add(q.relation)
            timestamps.add(q.timestamp)
            
            # Update counts
            entity_counts[q.subject] = entity_counts.get(q.subject, 0) + 1
            entity_counts[q.object] = entity_counts.get(q.object, 0) + 1
            relation_counts[q.relation] = relation_counts.get(q.relation, 0) + 1

        # Compute time range
        time_range = (min(timestamps), max(timestamps))
        
        # Compute density
        possible_edges = len(entities) * len(entities) * len(relations)
        density = len(quadruples) / possible_edges if possible_edges > 0 else 0

        return DatasetStats(
            num_entities=len(entities),
            num_relations=len(relations),
            num_timestamps=len(timestamps),
            time_range=time_range,
            density=density,
            fact_count=len(quadruples),
            entity_degrees=entity_counts,
            relation_counts=relation_counts
        )
    except Exception as e:
        logger.error(f"Failed to compute dataset statistics: {str(e)}")
        raise

def setup_logging(log_dir: Union[str, Path]) -> None:
    """Set up logging configuration"""
    log_dir = Path(log_dir)
    log_dir.mkdir(exist_ok=True)
    
    # Add file handler
    file_handler = logging.FileHandler(log_dir / "tkg_forecasting.log")
    file_handler.setFormatter(
        logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    )
    logger.addHandler(file_handler)