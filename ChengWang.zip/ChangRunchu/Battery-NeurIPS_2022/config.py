
import torch
import torch.nn as nn
import torch.nn.functional as F

# config.py
class Config:
    """Configuration parameters"""
    def __init__(self):
        # Model parameters
        self.num_nodes = 6  # number of battery parameters
        self.input_dim = 32  # C·T dimension
        self.hidden_dim = 32  # d=32 as mentioned in paper
        self.embed_dim = 32
        self.dropout = 0.5
        
        # Training parameters
        self.batch_size = 48
        self.num_epochs = 100
        self.learning_rate = 1e-3
        self.train_ratio = 0.7
        self.val_ratio = 0.15
        
        # Dataset parameters
        self.dataset_type = 'NASA'  # or 'UNIBO'
        self.data_path = 'path/to/data'
        
        # Other parameters
        self.use_uncertainty = True
        self.save_path = 'saved_models/'
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')