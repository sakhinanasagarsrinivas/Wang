import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import json
import argparse
import time
import os
import math
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from torch.utils.data import TensorDataset, DataLoader
from tqdm import tqdm
from einops import rearrange

torch.manual_seed(42)
np.random.seed(42)
plt.style.use('seaborn-v0_8-whitegrid')

def cosine_beta_schedule(timesteps, s=0.008):
    steps = timesteps + 1
    x = torch.linspace(0, timesteps, steps)
    alphas_cumprod = torch.cos(((x / timesteps) + s) / (1 + s) * math.pi * 0.5) ** 2
    alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
    betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
    return torch.clip(betas, 0.0001, 0.9999)

class SinusoidalPosEmb(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, time):
        device = time.device
        half_dim = self.dim // 2
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        embeddings = time[:, None] * embeddings[None, :]
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        return embeddings

class ResidualBlock1D(nn.Module):
    def __init__(self, in_channels, out_channels, time_emb_dim, cond_emb_dim):
        super().__init__()
        self.time_mlp = nn.Sequential(nn.SiLU(), nn.Linear(time_emb_dim, out_channels))
        self.cond_mlp = nn.Sequential(nn.SiLU(), nn.Linear(cond_emb_dim, out_channels))
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3, padding=1)
        self.norm1 = nn.GroupNorm(8, out_channels)
        self.norm2 = nn.GroupNorm(8, out_channels)
        self.activation = nn.SiLU()
        self.res_conv = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()

    def forward(self, x, time_emb, cond_emb):
        h = self.activation(self.norm1(self.conv1(x)))
        time_emb = self.time_mlp(time_emb)
        cond_emb = self.cond_mlp(cond_emb)
        emb = time_emb + cond_emb
        h = h + emb[..., None]
        h = self.activation(self.norm2(self.conv2(h)))
        return h + self.res_conv(x)

class AttentionBlock1D(nn.Module):
    def __init__(self, channels, num_heads=4):
        super().__init__()
        self.norm = nn.GroupNorm(8, channels)
        self.attn = nn.MultiheadAttention(channels, num_heads, batch_first=True)

    def forward(self, x):
        x_norm = self.norm(x)
        x_permuted = rearrange(x_norm, 'b c l -> b l c')
        attn_output, _ = self.attn(x_permuted, x_permuted, x_permuted)
        attn_output = rearrange(attn_output, 'b l c -> b c l')
        return x + attn_output

class UNet1D(nn.Module):
    def __init__(self, in_channels, out_channels, model_channels, num_res_blocks, time_emb_dim, cond_emb_dim, channel_mults=(1, 2, 4)):
        super().__init__()
        self.init_conv = nn.Conv1d(in_channels, model_channels, kernel_size=3, padding=1)
        self.time_mlp = nn.Sequential(SinusoidalPosEmb(time_emb_dim), nn.Linear(time_emb_dim, time_emb_dim * 4), nn.SiLU(), nn.Linear(time_emb_dim * 4, time_emb_dim))
        
        self.channel_mults = channel_mults
        self.num_res_blocks = num_res_blocks
        
        self.down_blocks = nn.ModuleList()
        self.up_blocks = nn.ModuleList()
        
        ch = model_channels
        input_block_chans = [model_channels]
        
        for level, mult in enumerate(channel_mults):
            for _ in range(num_res_blocks):
                out_ch = model_channels * mult
                self.down_blocks.append(ResidualBlock1D(ch, out_ch, time_emb_dim, cond_emb_dim))
                ch = out_ch
                input_block_chans.append(ch)
            
            if level != len(channel_mults) - 1:
                self.down_blocks.append(nn.Conv1d(ch, ch, kernel_size=3, stride=2, padding=1))
                input_block_chans.append(ch)
        
        self.mid_block1 = ResidualBlock1D(ch, ch, time_emb_dim, cond_emb_dim)
        self.mid_attn = AttentionBlock1D(ch)
        self.mid_block2 = ResidualBlock1D(ch, ch, time_emb_dim, cond_emb_dim)
        
        for level, mult in reversed(list(enumerate(channel_mults))):
            for i in range(num_res_blocks + 1):
                ich = input_block_chans.pop()
                out_ch = model_channels * mult
                self.up_blocks.append(ResidualBlock1D(ch + ich, out_ch, time_emb_dim, cond_emb_dim))
                ch = out_ch
            
            if level != 0:
                self.up_blocks.append(nn.Upsample(scale_factor=2, mode='linear', align_corners=False))
        
        self.final_conv = nn.Sequential(
            nn.GroupNorm(8, model_channels), 
            nn.SiLU(), 
            nn.Conv1d(model_channels, out_channels, kernel_size=3, padding=1)
        )

    def forward(self, x, time, cond_emb):
        original_length = x.shape[-1]
        t = self.time_mlp(time)
        
        x = self.init_conv(x)
        
        skip_connections = [x]
        
        for block in self.down_blocks:
            if isinstance(block, ResidualBlock1D):
                x = block(x, t, cond_emb)
            else:
                x = block(x)
            skip_connections.append(x)
        
        x = self.mid_block1(x, t, cond_emb)
        x = self.mid_attn(x)
        x = self.mid_block2(x, t, cond_emb)
        
        for block in self.up_blocks:
            if isinstance(block, ResidualBlock1D):
                skip = skip_connections.pop()
                if x.shape[-1] != skip.shape[-1]:
                    skip = F.interpolate(skip, size=x.shape[-1], mode='linear', align_corners=False)
                x = block(torch.cat([x, skip], dim=1), t, cond_emb)
            else:
                x = block(x)
        
        x = self.final_conv(x)
        
        if x.shape[-1] != original_length:
            x = F.interpolate(x, size=original_length, mode='linear', align_corners=False)
        
        return x

class DiffusionOperatorSolver:
    def __init__(self, config):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self._parse_config()
        self._setup_diffusion_schedule()
        self._generate_dataset()
        self._build_model()

    def _parse_config(self):
        problem_config = self.config['problems'][0]
        hp = self.config['hyperparameters']
        diff_hp = hp['diffusion']
        self.problem_name = problem_config['problem_id'].replace("Galerkin_Transformer", "Diffusion_Operator")
        self.state_vars = problem_config['state_variables']
        self.num_state_vars = len(self.state_vars)
        self.odes = problem_config['odes']
        self.t_domain = problem_config['time_domain']
        self.params = problem_config.get('parameters', {})
        self.time_inputs_template = problem_config.get('time_varying_inputs', {})
        self.param_space = problem_config['function_parameter_space']
        self.param_keys = sorted(self.param_space.keys())
        self.num_cond_params = len(self.param_keys)
        self.lr, self.epochs, self.batch_size = hp['learning_rate'], hp['epochs'], hp['batch_size']
        self.num_time_steps = hp['num_time_steps']
        self.timesteps = diff_hp['timesteps']
        self.dataset_size = diff_hp['dataset_size']
        self.cond_emb_dim = diff_hp['cond_emb_dim']
        self.model_save_path = f"models/{self.problem_name}_model.pt"
        os.makedirs("models", exist_ok=True)
        self.t_grid = np.linspace(self.t_domain[0], self.t_domain[1], self.num_time_steps)

    def _setup_diffusion_schedule(self):
        self.betas = cosine_beta_schedule(self.timesteps).to(self.device)
        self.alphas = 1. - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, axis=0)
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1. - self.alphas_cumprod)
        
    def _generate_dataset(self):
        dataset_file = f"cstr_dataset_{self.dataset_size}.pt"
        if os.path.exists(dataset_file):
            print(f"Loading existing dataset from {dataset_file}...")
            data = torch.load(dataset_file, weights_only=False)
            params_tensor, solutions_tensor = data['params'], data['solutions']
            self.solution_mean, self.solution_std = data['mean'], data['std']
        else:
            print(f"Generating dataset of size {self.dataset_size}...")
            all_params, all_solutions = [], []
            for _ in tqdm(range(self.dataset_size), desc="Generating Data"):
                sampled_params = {p: r[0] + (r[1] - r[0]) * np.random.rand() for p, r in self.param_space.items()}
                y0 = [sampled_params[f"{var}_ic"] for var in self.state_vars]
                sol = self.solve_single_instance_numerically(self.t_grid, sampled_params, y0)
                param_vector = torch.tensor([sampled_params[k] for k in self.param_keys], dtype=torch.float32)
                all_params.append(param_vector)
                all_solutions.append(torch.from_numpy(sol).float())
            params_tensor = torch.stack(all_params)
            solutions_tensor = torch.stack(all_solutions)
            self.solution_mean = solutions_tensor.mean([0, 1], keepdim=True)
            self.solution_std = solutions_tensor.std([0, 1], keepdim=True) + 1e-8
            torch.save({'params': params_tensor, 'solutions': solutions_tensor, 'mean': self.solution_mean, 'std': self.solution_std}, dataset_file)
            print("Dataset generated and saved.")
        solutions_normalized = (solutions_tensor - self.solution_mean) / self.solution_std
        dataset = TensorDataset(params_tensor, solutions_normalized)
        self.train_loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True, num_workers=4, pin_memory=True)

    def solve_single_instance_numerically(self, t_eval, instance_params, y0):
        def ode_system(t, y):
            scope = {'t': t, **self.params}
            for i, var in enumerate(self.state_vars): 
                scope[var] = y[i]
            
            eval_scope = {
                't': t, 
                'sin': np.sin, 
                'cos': np.cos, 
                'np': np,
                **instance_params
            }
            
            for input_name, template in self.time_inputs_template.items():
                numpy_expr = template.replace("torch.sin", "np.sin").replace("torch.cos", "np.cos")
                
                try:
                    formatted_expr = numpy_expr.format(**instance_params)
                except KeyError as e:
                    print(f"Missing parameter in template {input_name}: {e}")
                    print(f"Template: {numpy_expr}")
                    print(f"Available params: {list(instance_params.keys())}")
                    raise
                
                try:
                    scope[input_name] = eval(formatted_expr, {"__builtins__": {}}, eval_scope)
                except Exception as e:
                    print(f"Error evaluating {input_name}: {e}")
                    print(f"Original template: {template}")
                    print(f"Numpy expression: {numpy_expr}")
                    print(f"Formatted expression: {formatted_expr}")
                    print(f"Eval scope keys: {list(eval_scope.keys())}")
                    raise
            
            dydt = []
            for var in self.state_vars:
                try:
                    result = eval(self.odes[f"d{var}dt"], {"__builtins__": {}}, scope)
                    dydt.append(result)
                except Exception as e:
                    print(f"Error evaluating d{var}dt: {e}")
                    print(f"Expression: {self.odes[f'd{var}dt']}")
                    print(f"Scope keys: {list(scope.keys())}")
                    raise
            
            return dydt
        
        try:
            sol = solve_ivp(ode_system, (self.t_domain[0], self.t_domain[1]), y0, 
                          dense_output=True, t_eval=t_eval, method='DOP853', 
                          rtol=1e-8, atol=1e-10)
            
            if not sol.success:
                print(f"ODE solver failed: {sol.message}")
                sol = solve_ivp(ode_system, (self.t_domain[0], self.t_domain[1]), y0, 
                              dense_output=True, t_eval=t_eval, method='RK45', 
                              rtol=1e-6, atol=1e-8)
            
            return sol.y.T
        except Exception as e:
            print(f"Error in solve_single_instance_numerically: {e}")
            print(f"Parameters: {instance_params}")
            print(f"Initial conditions: {y0}")
            raise

    def _build_model(self):
        unet_hp = self.config['hyperparameters']['diffusion']['unet']
        self.cond_encoder = nn.Sequential(
            nn.Linear(self.num_cond_params, self.cond_emb_dim * 2), 
            nn.SiLU(), 
            nn.Linear(self.cond_emb_dim * 2, self.cond_emb_dim)
        ).to(self.device)
        
        self.model = UNet1D(
            in_channels=self.num_state_vars, 
            out_channels=self.num_state_vars, 
            model_channels=unet_hp['model_channels'], 
            num_res_blocks=unet_hp['num_res_blocks'], 
            channel_mults=tuple(unet_hp['channel_mults']), 
            time_emb_dim=unet_hp['time_emb_dim'], 
            cond_emb_dim=self.cond_emb_dim
        ).to(self.device)
        
        self.optimizer = torch.optim.AdamW(
            list(self.model.parameters()) + list(self.cond_encoder.parameters()), 
            lr=self.lr
        )

    def q_sample(self, x_start, t, noise=None):
        if noise is None: 
            noise = torch.randn_like(x_start)
        sqrt_alphas_cumprod_t = self.sqrt_alphas_cumprod[t].view(-1, 1, 1)
        sqrt_one_minus_alphas_cumprod_t = self.sqrt_one_minus_alphas_cumprod[t].view(-1, 1, 1)
        return sqrt_alphas_cumprod_t * x_start + sqrt_one_minus_alphas_cumprod_t * noise

    def train(self):
        if os.path.exists(self.model_save_path):
            print("Model weights found, skipping training.")
            return
        
        print(f"--- Starting training for {self.problem_name} ---")
        start_time = time.time()
        
        for epoch in range(self.epochs):
            self.model.train()
            self.cond_encoder.train()
            
            progress_bar = tqdm(self.train_loader, desc=f"Epoch {epoch+1}/{self.epochs}")
            epoch_loss = 0.0
            num_batches = 0
            
            for params_batch, solutions_batch in progress_bar:
                self.optimizer.zero_grad()
                params_batch = params_batch.to(self.device)
                solutions_batch = solutions_batch.to(self.device)
                
                t = torch.randint(0, self.timesteps, (solutions_batch.shape[0],), device=self.device).long()
                noise = torch.randn_like(solutions_batch)
                x_noisy = self.q_sample(x_start=solutions_batch, t=t, noise=noise)
                
                cond_emb = self.cond_encoder(params_batch)
                predicted_noise = self.model(rearrange(x_noisy, 'b l c -> b c l'), t, cond_emb)
                predicted_noise = rearrange(predicted_noise, 'b c l -> b l c')
                
                loss = F.mse_loss(noise, predicted_noise)
                loss.backward()
                
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                torch.nn.utils.clip_grad_norm_(self.cond_encoder.parameters(), max_norm=1.0)
                
                self.optimizer.step()
                
                epoch_loss += loss.item()
                num_batches += 1
                progress_bar.set_postfix(loss=loss.item())
            
            avg_loss = epoch_loss / num_batches
            print(f"Epoch {epoch+1}/{self.epochs}, Average Loss: {avg_loss:.6f}")
        
        elapsed_time = time.time() - start_time
        print(f"--- Training finished in {elapsed_time:.2f} seconds ---")
        
        torch.save({
            'model_state_dict': self.model.state_dict(), 
            'cond_encoder_state_dict': self.cond_encoder.state_dict(),
            'solution_mean': self.solution_mean,
            'solution_std': self.solution_std
        }, self.model_save_path)
        print(f"Model weights saved to {self.model_save_path}")

    @torch.no_grad()
    def solve(self, params_dict, num_inference_steps=50):
        self.model.eval()
        self.cond_encoder.eval()
        
        param_vector = torch.tensor([params_dict[k] for k in self.param_keys], dtype=torch.float32).unsqueeze(0).to(self.device)
        cond_emb = self.cond_encoder(param_vector)
        
        u_t = torch.randn((1, self.num_time_steps, self.num_state_vars), device=self.device)
        ts = torch.linspace(self.timesteps - 1, 0, steps=num_inference_steps + 1, device=self.device).long()
        
        for i in tqdm(range(num_inference_steps), desc="DDIM Sampling"):
            t, t_next = ts[i], ts[i+1]
            pred_noise = self.model(rearrange(u_t, 'b l c -> b c l'), t.expand(1), cond_emb)
            pred_noise = rearrange(pred_noise, 'b c l -> b l c')
            
            pred_x0 = (u_t - self.sqrt_one_minus_alphas_cumprod[t] * pred_noise) / self.sqrt_alphas_cumprod[t]
            pred_x0 = torch.clamp(pred_x0, -1.5, 1.5)
            
            direction_to_xt = torch.sqrt(1.0 - self.alphas_cumprod[t_next]) * pred_noise
            u_t = torch.sqrt(self.alphas_cumprod[t_next]) * pred_x0 + direction_to_xt
        
        u_0 = u_t * self.solution_std.to(self.device) + self.solution_mean.to(self.device)
        return u_0.squeeze(0).cpu().numpy()

    def evaluate_and_plot_results(self):
        if os.path.exists(self.model_save_path):
            print(f"Loading model weights from {self.model_save_path}")
            checkpoint = torch.load(self.model_save_path, map_location=self.device, weights_only=False)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.cond_encoder.load_state_dict(checkpoint['cond_encoder_state_dict'])
            
            if 'solution_mean' in checkpoint and 'solution_std' in checkpoint:
                self.solution_mean = checkpoint['solution_mean']
                self.solution_std = checkpoint['solution_std']
        else:
            print("WARNING: Model weights not found. Evaluation will use the randomly initialized model.")
        
        results_dir = "results"
        os.makedirs(results_dir, exist_ok=True)
        base_filename = os.path.join(results_dir, self.problem_name.replace(' ', '_').lower())
        
        test_cases = [
            {'mean': 1.0, 'amp': 0.75, 'freq': 0.4, 'phase': 1.5, 'CA1_ic': 0.15, 'CA2_ic': 0.08},
            {'mean': 0.9, 'amp': 0.3, 'freq': 0.15, 'phase': 4.0, 'CA1_ic': 0.05, 'CA2_ic': 0.01},
            {'mean': 1.1, 'amp': 0.5, 'freq': 0.25, 'phase': 0.0, 'CA1_ic': 0.0, 'CA2_ic': 0.0},
        ]
        
        for i, case_params in enumerate(test_cases):
            print(f"\n--- Evaluating Test Case {i+1}: {case_params} ---")
            
            try:
                u_diffusion = self.solve(case_params, num_inference_steps=200)
                y0_test = [case_params[f"{var}_ic"] for var in self.state_vars]
                u_numerical = self.solve_single_instance_numerically(self.t_grid, case_params, y0_test)
                
                fig, axes = plt.subplots(self.num_state_vars, 2, figsize=(16, 5 * self.num_state_vars), sharex=True)
                if self.num_state_vars == 1: 
                    axes = np.array([axes])
                
                for j, var in enumerate(self.state_vars):
                    axes[j, 0].plot(self.t_grid, u_numerical[:, j], 'k-', label='Numerical', linewidth=2.5, alpha=0.8)
                    axes[j, 0].plot(self.t_grid, u_diffusion[:, j], 'b--', label='Diffusion Operator', linewidth=2)
                    axes[j, 0].set_ylabel(var)
                    axes[j, 0].legend()
                    axes[j, 0].set_title(f'Solution for {var}')
                    axes[j, 0].grid(True, alpha=0.3)
                    
                    error = np.abs(u_numerical[:, j] - u_diffusion[:, j])
                    axes[j, 1].plot(self.t_grid, error, 'g-', linewidth=2)
                    axes[j, 1].set_yscale('log')
                    axes[j, 1].set_ylabel(f'Absolute Error')
                    axes[j, 1].set_title(f'Error for {var}')
                    axes[j, 1].grid(True, which="both", ls="--", alpha=0.3)
                
                axes[-1, 0].set_xlabel('Time (t)')
                axes[-1, 1].set_xlabel('Time (t)')
                fig.suptitle(f'Diffusion Operator Generalization - Test Case {i+1}', fontsize=16)
                plt.tight_layout(rect=[0, 0.03, 1, 0.95])
                
                plot_filename = f"{base_filename}_test_case_{i+1}.pdf"
                plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
                plt.close(fig)
                print(f"Test case plot saved to {plot_filename}")
                
                for j, var in enumerate(self.state_vars):
                    mse = np.mean((u_numerical[:, j] - u_diffusion[:, j])**2)
                    max_error = np.max(np.abs(u_numerical[:, j] - u_diffusion[:, j]))
                    print(f"  {var}: MSE = {mse:.6e}, Max Error = {max_error:.6e}")
                    
            except Exception as e:
                print(f"Error in test case {i+1}: {e}")
                continue

def main():
    parser = argparse.ArgumentParser(description="Diffusion Operator Solver for ODEs")
    parser.add_argument("config_file", type=str, nargs='?', default="problem_config.json", 
                       help="Path to the JSON configuration file for the Diffusion Operator.")
    args = parser.parse_args()
    
    try:
        with open(args.config_file, 'r') as f: 
            config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error reading configuration file: {e}")
        return
    
    solver = DiffusionOperatorSolver(config)
    solver.train()
    solver.evaluate_and_plot_results()

if __name__ == "__main__":
    main()