

import torch
import torch.nn as nn
import torch.nn.functional as F

def train_model(model, train_loader, val_loader, optimizer, criterion, 
                evaluator, config):
    """Training loop with validation"""
    best_val_rmse = float('inf')
    best_model_state = None
    patience = 10
    patience_counter = 0
    
    for epoch in range(config.num_epochs):
        # Training phase
        model.train()
        train_loss = 0.0
        
        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(config.device)
            batch_y = batch_y.to(config.device)
            
            optimizer.zero_grad()
            
            if config.use_uncertainty:
                mu, log_var = model(batch_x)
                loss = criterion(mu, log_var, batch_y)
            else:
                pred = model(batch_x)
                loss = criterion(pred, batch_y)
            
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        avg_train_loss = train_loss / len(train_loader)
        
        # Validation phase
        val_metrics = evaluator.evaluate_model(model, val_loader, config.use_uncertainty)
        val_rmse = val_metrics['rmse']
        
        # Save best model
        if val_rmse < best_val_rmse:
            best_val_rmse = val_rmse
            best_model_state = model.state_dict()
            patience_counter = 0
            
            # Save model checkpoint
            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_rmse': val_rmse,
                'config': config
            }
            torch.save(checkpoint, f"{config.save_path}/best_model.pth")
        else:
            patience_counter += 1
        
        # Early stopping
        if patience_counter >= patience:
            print(f"Early stopping triggered after {epoch + 1} epochs")
            break
        
        # Print epoch results
        print(f"Epoch [{epoch+1}/{config.num_epochs}]")
        print(f"Train Loss: {avg_train_loss:.4f}")
        print(f"Validation RMSE: {val_rmse:.4f}")
        print(f"Best Validation RMSE: {best_val_rmse:.4f}")
        print("-" * 50)
    
    return best_model_state

def test_model(model, test_loader, evaluator, config):
    """Evaluate model on test set"""
    model.eval()
    test_metrics = evaluator.evaluate_model(model, test_loader, config.use_uncertainty)
    
    print("\nTest Set Results:")
    for metric, value in test_metrics.items():
        print(f"{metric}: {value:.4f}")
    
    return test_metrics

def main():
    # Load configuration
    config = Config()
    
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f"{config.save_path}/training.log"),
            logging.StreamHandler()
        ]
    )
    
    # Create save directory if it doesn't exist
    os.makedirs(config.save_path, exist_ok=True)
    
    # Load dataset
    dataset = BatteryDataset(config.data_path, dataset_type=config.dataset_type)
    
    # Create data loaders
    train_loader, val_loader, test_loader = create_data_loaders(
        dataset,
        batch_size=config.batch_size,
        train_ratio=config.train_ratio,
        val_ratio=config.val_ratio
    )
    
    # Initialize model
    if config.use_uncertainty:
        model = BatteryGraphNetsUE(
            num_nodes=config.num_nodes,
            input_dim=config.input_dim,
            hidden_dim=config.hidden_dim,
            embed_dim=config.embed_dim,
            dropout=config.dropout
        )
        criterion = GaussianNLLLoss()
    else:
        model = BatteryGraphNets(
            num_nodes=config.num_nodes,
            input_dim=config.input_dim,
            hidden_dim=config.hidden_dim,
            embed_dim=config.embed_dim,
            dropout=config.dropout
        )
        criterion = nn.MSELoss()
    
    model = model.to(config.device)
    
    # Initialize optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate)
    
    # Initialize evaluator
    evaluator = Evaluator()
    
    # Train model
    logging.info("Starting training...")
    best_model_state = train_model(
        model, train_loader, val_loader, optimizer, criterion, evaluator, config
    )
    
    # Load best model for testing
    model.load_state_dict(best_model_state)
    
    # Test model
    logging.info("Evaluating on test set...")
    test_metrics = test_model(model, test_loader, evaluator, config)
    
    # Save test results
    with open(f"{config.save_path}/test_results.json", 'w') as f:
        json.dump(test_metrics, f, indent=4)
    
    # Save final model
    torch.save({
        'model_state_dict': model.state_dict(),
        'test_metrics': test_metrics,
        'config': config
    }, f"{config.save_path}/final_model.pth")
    
    logging.info("Training completed!")
    return test_metrics

def load_pretrained_model(model_path, config):
    """Load a pretrained model"""
    checkpoint = torch.load(model_path)
    
    if config.use_uncertainty:
        model = BatteryGraphNetsUE(
            num_nodes=config.num_nodes,
            input_dim=config.input_dim,
            hidden_dim=config.hidden_dim,
            embed_dim=config.embed_dim
        )
    else:
        model = BatteryGraphNets(
            num_nodes=config.num_nodes,
            input_dim=config.input_dim,
            hidden_dim=config.hidden_dim,
            embed_dim=config.embed_dim
        )
    
    model.load_state_dict(checkpoint['model_state_dict'])
    return model

if __name__ == "__main__":
    # Set random seeds for reproducibility
    torch.manual_seed(42)
    np.random.seed(42)
    random.seed(42)
    
    # If using CUDA, set cuda random seed
    if torch.cuda.is_available():
        torch.cuda.manual_seed(42)
        torch.cuda.manual_seed_all(42)  # for multi-GPU
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    
    main()