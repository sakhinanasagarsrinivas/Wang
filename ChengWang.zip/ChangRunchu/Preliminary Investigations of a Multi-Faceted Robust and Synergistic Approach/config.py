from dataclasses import dataclass

@dataclass
class ModelConfig:
    # ViT Configuration
    image_size: int = 224
    patch_size: int = 32
    num_channels: int = 3
    embed_dim: int = 768
    num_heads: int = 12
    num_layers: int = 12
    mlp_ratio: float = 4.0
    dropout: float = 0.1
    
    # LLM/LMM Configuration
    gpt4_api_key: str = "your-api-key"
    deberta_model: str = "microsoft/deberta-v3-base"
    max_text_length: int = 512
    
    # Unified Attention Configuration
    num_attention_heads: int = 4
    key_dim: int = 16
    
    # Training Configuration
    batch_size: int = 48
    num_epochs: int = 50
    learning_rate: float = 1e-3
    weight_decay: float = 0.01
    
    # Dataset Configuration
    train_data_path: str = "path/to/sem/dataset"
    num_classes: int = 10
    
    # Device Configuration
    device: str = "cuda"