# evaluate/evaluator.py
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Dict, List, Optional, Tuple
import logging
from tqdm import tqdm
from utils.metrics import Metrics
from utils.helpers import move_to_device

class Evaluator:
    def __init__(
        self,
        model: nn.Module,
        metrics: Optional[Metrics] = None,
        device: str = 'cuda',
        logger: Optional[logging.Logger] = None
    ):
        self.model = model.to(device)
        self.metrics = metrics or Metrics()
        self.device = device
        self.logger = logger or logging.getLogger(__name__)
    
    def evaluate(
        self,
        dataloader: DataLoader,
        tokenizer=None
    ) -> Dict[str, float]:
        """
        Evaluate model on dataset.
        """
        self.model.eval()
        all_predictions = []
        all_references = []
        
        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Evaluating"):
                batch = move_to_device(batch, self.device)
                
                # Generate predictions
                outputs = self.model.generate(
                    input_ids=batch['input_ids'],
                    attention_mask=batch['attention_mask'],
                    max_length=128,
                    num_beams=4,
                    early_stopping=True
                )
                
                # Decode predictions and references
                predictions = tokenizer.batch_decode(outputs, skip_special_tokens=True)
                references = tokenizer.batch_decode(batch['labels'], skip_special_tokens=True)
                
                all_predictions.extend(predictions)
                all_references.extend(references)
        
        # Calculate metrics
        metrics = self.metrics.calculate_all_metrics(all_references, all_predictions)
        
        # Log results
        self.logger.info("Evaluation Results:")
        for metric_name, value in metrics.items():
            self.logger.info(f"{metric_name}: {value:.4f}")
        
        return metrics
    
    def analyze_errors(
        self,
        dataloader: DataLoader,
        tokenizer=None,
        num_examples: int = 10
    ) -> List[Dict]:
        """
        Analyze model errors and provide examples.
        """
        self.model.eval()
        error_examples = []
        
        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Analyzing errors"):
                batch = move_to_device(batch, self.device)
                
                # Generate predictions
                outputs = self.model.generate(
                    input_ids=batch['input_ids'],
                    attention_mask=batch['attention_mask'],
                    max_length=128,
                    num_beams=4,
                    early_stopping=True
                )
                
                # Decode predictions and references
                predictions = tokenizer.batch_decode(outputs, skip_special_tokens=True)
                references = tokenizer.batch_decode(batch['labels'], skip_special_tokens=True)
                
                # Calculate metrics for each example
                for pred, ref in zip(predictions, references):
                    metrics = self.metrics.calculate_all_metrics([ref], [pred])
                    
                    # If any metric is below threshold, consider it an error
                    if any(v < 0.5 for v in metrics.values()):
                        error_examples.append({
                            'reference': ref,
                            'prediction': pred,
                            'metrics': metrics
                        })
                        
                        if len(error_examples) >= num_examples:
                            break
                
                if len(error_examples) >= num_examples:
                    break
        
        return error_examples
    
    def evaluate_categories(
        self,
        dataloader: DataLoader,
        categories: List[str],
        tokenizer=None
    ) -> Dict[str, Dict[str, float]]:
        """
        Evaluate model performance per category.
        """
        self.model.eval()
        category_metrics = {cat: [] for cat in categories}
        
        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Evaluating categories"):
                batch = move_to_device(batch, self.device)
                
                # Generate predictions
                outputs = self.model.generate(
                    input_ids=batch['input_ids'],
                    attention_mask=batch['attention_mask'],
                    max_length=128,
                    num_beams=4,
                    early_stopping=True
                )
                
                # Decode predictions and references
                predictions = tokenizer.batch_decode(outputs, skip_special_tokens=True)
                references = tokenizer.batch_decode(batch['labels'], skip_special_tokens=True)
                
                # Calculate metrics per category
                for pred, ref, cat in zip(predictions, references, batch['category']):
                    metrics = self.metrics.calculate_all_metrics([ref], [pred])
                    category_metrics[categories[cat]].append(metrics)
        

        # Average metrics per category
        averaged_metrics = {}
        for category in categories:
            if not category_metrics[category]:
                continue
                
            category_avg = {
                metric: sum(x[metric] for x in category_metrics[category]) / len(category_metrics[category])
                for metric in category_metrics[category][0].keys()
            }
            averaged_metrics[category] = category_avg
            
            # Log category results
            self.logger.info(f"\nResults for category: {category}")
            for metric_name, value in category_avg.items():
                self.logger.info(f"{metric_name}: {value:.4f}")
        
        return averaged_metrics
    
    def analyze_attention(
        self,
        dataloader: DataLoader,
        tokenizer=None,
        num_examples: int = 5
    ) -> List[Dict]:
        """
        Analyze attention patterns in the model.
        """
        self.model.eval()
        attention_patterns = []
        
        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Analyzing attention patterns"):
                batch = move_to_device(batch, self.device)
                
                # Forward pass with output_attentions=True
                outputs = self.model(
                    input_ids=batch['input_ids'],
                    attention_mask=batch['attention_mask'],
                    output_attentions=True
                )
                
                # Get attention weights
                attention_weights = outputs.attentions
                
                # Process each example in batch
                for idx in range(batch['input_ids'].size(0)):
                    # Decode input text
                    input_text = tokenizer.decode(batch['input_ids'][idx], skip_special_tokens=True)
                    
                    # Get attention maps for this example
                    example_attentions = [layer[idx] for layer in attention_weights]
                    
                    attention_patterns.append({
                        'text': input_text,
                        'attention_weights': example_attentions
                    })
                    
                    if len(attention_patterns) >= num_examples:
                        break
                
                if len(attention_patterns) >= num_examples:
                    break
        
        return attention_patterns
    
    def evaluate_robustness(
        self,
        dataloader: DataLoader,
        perturbation_types: List[str],
        tokenizer=None
    ) -> Dict[str, Dict[str, float]]:
        """
        Evaluate model robustness against different types of perturbations.
        """
        self.model.eval()
        robustness_metrics = {p_type: {} for p_type in perturbation_types}
        
        for p_type in perturbation_types:
            self.logger.info(f"\nEvaluating robustness against: {p_type}")
            
            perturbed_predictions = []
            references = []
            
            with torch.no_grad():
                for batch in tqdm(dataloader, desc=f"Testing {p_type}"):
                    batch = move_to_device(batch, self.device)
                    
                    # Apply perturbation
                    perturbed_batch = self._apply_perturbation(batch, p_type)
                    
                    # Generate predictions
                    outputs = self.model.generate(
                        input_ids=perturbed_batch['input_ids'],
                        attention_mask=perturbed_batch['attention_mask'],
                        max_length=128,
                        num_beams=4,
                        early_stopping=True
                    )
                    
                    # Decode predictions and references
                    predictions = tokenizer.batch_decode(outputs, skip_special_tokens=True)
                    batch_references = tokenizer.batch_decode(batch['labels'], skip_special_tokens=True)
                    
                    perturbed_predictions.extend(predictions)
                    references.extend(batch_references)
            
            # Calculate metrics for this perturbation type
            metrics = self.metrics.calculate_all_metrics(references, perturbed_predictions)
            robustness_metrics[p_type] = metrics
            
            # Log results
            for metric_name, value in metrics.items():
                self.logger.info(f"{metric_name}: {value:.4f}")
        
        return robustness_metrics
    
    def _apply_perturbation(self, batch: Dict[str, torch.Tensor], p_type: str) -> Dict[str, torch.Tensor]:
        """
        Apply specified perturbation to the input batch.
        """
        perturbed_batch = {k: v.clone() if isinstance(v, torch.Tensor) else v 
                          for k, v in batch.items()}
        
        if p_type == 'token_deletion':
            # Randomly delete tokens
            mask = torch.rand_like(perturbed_batch['input_ids'].float()) > 0.1
            perturbed_batch['input_ids'] = perturbed_batch['input_ids'] * mask.long()
            
        elif p_type == 'token_substitution':
            # Randomly substitute tokens
            mask = torch.rand_like(perturbed_batch['input_ids'].float()) > 0.9
            random_tokens = torch.randint_like(perturbed_batch['input_ids'], 0, 1000)
            perturbed_batch['input_ids'] = torch.where(mask, perturbed_batch['input_ids'], random_tokens)
            
        elif p_type == 'sequence_truncation':
            # Truncate sequence length
            max_length = perturbed_batch['input_ids'].size(1) // 2
            perturbed_batch['input_ids'] = perturbed_batch['input_ids'][:, :max_length]
            perturbed_batch['attention_mask'] = perturbed_batch['attention_mask'][:, :max_length]
            
        return perturbed_batch