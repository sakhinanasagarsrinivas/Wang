# data_processor.py

import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import MinMaxScaler
from typing import Tuple, Optional
import logging

logger = logging.getLogger(__name__)

class TimeSeriesDataset(Dataset):
    """Dataset class for multivariate time series data"""
    def __init__(
        self,
        data: np.ndarray,
        window_size: int,
        target_size: int = 1,
        stride: int = 1,
        transform = None
    ):
        """
        Args:
            data: Raw time series data (timesteps, features)
            window_size: Size of sliding window
            target_size: Size of prediction window
            stride: Stride for sliding window
            transform: Optional transform to apply to windows
        """
        self.data = torch.FloatTensor(data)
        self.window_size = window_size
        self.target_size = target_size
        self.stride = stride
        self.transform = transform
        
        # Calculate valid indices
        self.indices = list(range(0, len(data) - window_size - target_size + 1, stride))
        
    def __len__(self):
        return len(self.indices)
        
    def __getitem__(self, idx):
        start_idx = self.indices[idx]
        end_idx = start_idx + self.window_size
        
        # Get input window
        x = self.data[start_idx:end_idx]
        
        # Get target values
        y = self.data[end_idx:end_idx + self.target_size]
        
        if self.transform:
            x = self.transform(x)
        
        return x, y

class DataProcessor:
    """Data preprocessing and loading utilities"""
    def __init__(self, config):
        self.config = config
        self.scaler = MinMaxScaler()
        self._scalers = {}  # Store individual scalers for each feature
        
    def load_data(self, dataset_name: str) -> Tuple[DataLoader, DataLoader, DataLoader]:
        """
        Load and preprocess a dataset.
        
        Args:
            dataset_name: Name of dataset to load
            
        Returns:
            train_loader, val_loader, test_loader
        """
        logger.info(f"Loading dataset: {dataset_name}")
        
        # Load raw data
        df = self._load_raw_data(dataset_name)
        
        # Scale data
        data_scaled = self._scale_data(df.values)
        
        # Split data
        train_data, val_data, test_data = self._split_data(data_scaled)
        
        # Create datasets
        train_dataset = TimeSeriesDataset(
            train_data, 
            self.config.model.window_size,
            transform=self._transform_data
        )
        val_dataset = TimeSeriesDataset(
            val_data,
            self.config.model.window_size
        )
        test_dataset = TimeSeriesDataset(
            test_data,
            self.config.model.window_size
        )
        
        # Create dataloaders
        train_loader = DataLoader(
            train_dataset,
            batch_size=self.config.model.batch_size,
            shuffle=True,
            num_workers=self.config.training.num_workers,
            pin_memory=self.config.training.pin_memory
        )
        val_loader = DataLoader(
            val_dataset, 
            batch_size=self.config.model.batch_size
        )
        test_loader = DataLoader(
            test_dataset,
            batch_size=self.config.model.batch_size
        )
        
        return train_loader, val_loader, test_loader
    
    def _load_raw_data(self, dataset_name: str) -> pd.DataFrame:
        """Load raw data from file"""
        try:
            path = self.config.model.dataset_paths[dataset_name]
            df = pd.read_csv(path)
            logger.info(f"Successfully loaded {dataset_name} dataset")
            return df
        except Exception as e:
            logger.error(f"Error loading dataset {dataset_name}: {str(e)}")
            raise
    
    def _scale_data(self, data: np.ndarray) -> np.ndarray:
        """Scale data using MinMaxScaler"""
        # Fit scaler on all features
        data_scaled = self.scaler.fit_transform(data)
        
        # Store individual scalers for each feature
        for i in range(data.shape[1]):
            scaler_i = MinMaxScaler()
            scaler_i.fit(data[:, i:i+1])
            self._scalers[i] = scaler_i
            
        return data_scaled
    
    def _split_data(self, data: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Split data into train, validation and test sets"""
        train_size = int(len(data) * self.config.model.train_ratio)
        val_size = int(len(data) * self.config.model.val_ratio)
        
        train_data = data[:train_size]
        val_data = data[train_size:train_size + val_size]
        test_data = data[train_size + val_size:]
        
        return train_data, val_data, test_data
    
    def _transform_data(self, x: torch.Tensor) -> torch.Tensor:
        """Apply transformations to input data"""
        # Add random noise during training
        if self.config.training.use_mixed_precision:
            noise = torch.randn_like(x) * 0.01
            x = x + noise
        return x
    
    def inverse_transform(self, data: np.ndarray, feature_idx: Optional[int] = None):
        """Inverse transform scaled data back to original scale"""
        if feature_idx is not None:
            return self._scalers[feature_idx].inverse_transform(data)
        return self.scaler.inverse_transform(data)