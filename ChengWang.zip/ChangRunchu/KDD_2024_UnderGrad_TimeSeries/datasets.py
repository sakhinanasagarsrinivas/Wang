import torch
from torch.utils.data import Dataset
import numpy as np
import pandas as pd
from typing import Tuple, Dict, Optional, List
from sklearn.preprocessing import StandardScaler
from pathlib import Path
import logging
from constants import (
    TRAFFIC_DATASETS, 
    ANOMALY_DATASETS, 
    TaskConfig
)

class BaseMVTSDataset(Dataset):
    """Base Multivariate Time Series Dataset"""
    def __init__(
        self,
        data: np.ndarray,
        seq_length: int,
        scaler: Optional[StandardScaler] = None,
        device: str = "cuda"
    ):
        self.data = data
        self.seq_length = seq_length
        self.device = device
        
        if scaler is None:
            self.scaler = StandardScaler()
            self.data = self.scaler.fit_transform(data)
        else:
            self.scaler = scaler
            self.data = scaler.transform(data)

    def __len__(self) -> int:
        return len(self.data) - self.seq_length + 1

class ForecastingDataset(BaseMVTSDataset):
    """Dataset for traffic forecasting tasks (Section 2.1)"""
    def __init__(
        self,
        data: np.ndarray,
        seq_length: int,  # τ in paper
        pred_length: int,  # ν in paper
        **kwargs
    ):
        super().__init__(data, seq_length, **kwargs)
        self.pred_length = pred_length

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        # Using sliding window approach as per paper
        x = self.data[idx:idx + self.seq_length]
        y = self.data[idx + self.seq_length:idx + self.seq_length + self.pred_length]
        
        # Handle boundary cases
        if len(y) < self.pred_length:
            # Pad with last known values if necessary
            padding = self.pred_length - len(y)
            y = np.pad(y, ((0, padding), (0, 0)), mode='edge')
        
        return torch.FloatTensor(x), torch.FloatTensor(y)

class ImputationDataset(BaseMVTSDataset):
    """Dataset for missing data imputation (Section 2.2)"""
    def __init__(
        self,
        data: np.ndarray,
        mask: np.ndarray,  # Binary mask matrix M
        seq_length: int,
        **kwargs
    ):
        super().__init__(data, seq_length, **kwargs)
        self.mask = mask
        
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # Get sequence with missing values as per paper Section 2.2
        x = self.data[idx:idx + self.seq_length]
        mask = self.mask[idx:idx + self.seq_length]
        orig = x.copy()
        
        # Mask values according to M
        x[mask == 0] = 0  # Set missing values to 0
        
        return (
            torch.FloatTensor(x),
            torch.FloatTensor(mask),
            torch.FloatTensor(orig)
        )

class AnomalyDetectionDataset(BaseMVTSDataset):
    """Dataset for anomaly detection (Section 2.3)"""
    def __init__(
        self,
        data: np.ndarray,
        labels: np.ndarray,
        seq_length: int,
        train_timestamp: Optional[int] = None,  # Ttrain in paper
        **kwargs
    ):
        super().__init__(data, seq_length, **kwargs)
        self.labels = labels
        self.train_timestamp = train_timestamp

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        # Get sequence
        x = self.data[idx:idx + self.seq_length]
        
        # Get labels for the sequence
        y = self.labels[idx:idx + self.seq_length]
        
        # Calculate robust normalized anomaly scores for training data
        if self.train_timestamp is not None and idx < self.train_timestamp:
            scores = np.abs(x - np.mean(x, axis=0)) / np.std(x, axis=0)
            y = (scores > np.percentile(scores, 95)).astype(float)
        
        return torch.FloatTensor(x), torch.FloatTensor(y)

class ClassificationDataset(BaseMVTSDataset):
    """Dataset for regime classification (Section 2.4)"""
    def __init__(
        self,
        data: np.ndarray,
        labels: np.ndarray,  # K-means cluster labels
        seq_length: int,
        **kwargs
    ):
        super().__init__(data, seq_length, **kwargs)
        self.labels = labels

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        # Get sequence
        x = self.data[idx:idx + self.seq_length]
        
        # Get label for sequence (use most common label in sequence)
        y = self.labels[idx:idx + self.seq_length]
        label = np.bincount(y.astype(int)).argmax()
        
        return torch.FloatTensor(x), torch.LongTensor([label])

def load_traffic_dataset(
    dataset_name: str,
    task_config: TaskConfig,
    base_path: Path
) -> Tuple[Dataset, Dataset, Dataset]:
    """Load traffic datasets (PeMSD, METR-LA, PEMS-BAY)"""
    dataset_config = TRAFFIC_DATASETS[dataset_name]
    data_path = base_path / f"{dataset_name}.csv"
    
    # Load data
    df = pd.read_csv(data_path)
    data = df.values
    
    # Split according to paper's ratios
    train_ratio, val_ratio, test_ratio = dataset_config["split_ratio"]
    total_ratio = sum([train_ratio, val_ratio, test_ratio])
    
    train_size = int(len(data) * train_ratio / total_ratio)
    val_size = int(len(data) * val_ratio / total_ratio)
    
    train_data = data[:train_size]
    val_data = data[train_size:train_size + val_size]
    test_data = data[train_size + val_size:]
    
    # Create appropriate dataset based on task
    if task_config.task_type == "forecasting":
        train_dataset = ForecastingDataset(
            train_data, 
            seq_length=task_config.forecast_window_size,
            pred_length=task_config.forecast_horizon
        )
        val_dataset = ForecastingDataset(
            val_data,
            seq_length=task_config.forecast_window_size,
            pred_length=task_config.forecast_horizon,
            scaler=train_dataset.scaler
        )
        test_dataset = ForecastingDataset(
            test_data,
            seq_length=task_config.forecast_window_size,
            pred_length=task_config.forecast_horizon,
            scaler=train_dataset.scaler
        )
    # Add other task types...
    
    return train_dataset, val_dataset, test_dataset

def load_anomaly_dataset(
    dataset_name: str,
    task_config: TaskConfig,
    base_path: Path
) -> Tuple[Dataset, Dataset, Dataset]:
    """Load anomaly detection datasets (SWaT, WADI, SMAP, MSL, TEP, HAI)"""
    dataset_config = ANOMALY_DATASETS[dataset_name]
    data_path = base_path / f"{dataset_name}.csv"
    
    # Load data and labels
    df = pd.read_csv(data_path)
    data = df.iloc[:, :-1].values  # Last column contains labels
    labels = df.iloc[:, -1].values
    
    # Split according to paper's setup
    train_size = int(len(data) * 0.7)