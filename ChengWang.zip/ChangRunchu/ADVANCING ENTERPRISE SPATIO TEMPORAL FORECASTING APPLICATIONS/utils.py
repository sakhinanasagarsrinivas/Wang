import torch
import random
import numpy as np
from typing import Dict, Optional, Union
import yaml
import logging
import os
import torch.nn as nn
import numpy as np
from typing import List, Tuple

def chebyshev_polynomials(laplacian: torch.Tensor, k: int) -> List[torch.Tensor]:
    """
    Calculate Chebyshev polynomials up to order k
    
    Args:
        laplacian: Normalized graph Laplacian
        k: Maximum polynomial order
    
    Returns:
        List of Chebyshev polynomials of the Laplacian
    """
    polynomials = [torch.eye(laplacian.size(0)).to(laplacian.device)]
    if k > 0:
        polynomials.append(laplacian)
        for i in range(2, k + 1):
            polynomial = 2 * torch.mm(laplacian, polynomials[i-1]) - polynomials[i-2]
            polynomials.append(polynomial)
    return polynomials

def sparse_attention(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    """
    Compute sparse attention with optional masking
    
    Args:
        q: Query tensor
        k: Key tensor
        v: Value tensor
        mask: Optional attention mask
    
    Returns:
        Attention output
    """
    scores = torch.matmul(q, k.transpose(-2, -1)) / np.sqrt(k.size(-1))
    
    if mask is not None:
        scores = scores.masked_fill(mask == 0, float('-inf'))
    
    attention_weights = torch.softmax(scores, dim=-1)
    return torch.matmul(attention_weights, v)

def gated_fusion(x1: torch.Tensor, x2: torch.Tensor) -> torch.Tensor:
    """
    Gated fusion of two feature tensors
    
    Args:
        x1: First feature tensor
        x2: Second feature tensor
    
    Returns:
        Fused features
    """
    gate = torch.sigmoid(torch.add(x1, x2))
    return torch.add(torch.mul(gate, x1), torch.mul(1-gate, x2))

def temporal_attention_weights(x: torch.Tensor, hidden_size: int) -> torch.Tensor:
    """
    Compute temporal attention weights
    
    Args:
        x: Input tensor [batch_size, time_steps, features]
        hidden_size: Size of hidden representation
    
    Returns:
        Temporal attention weights
    """
    # Project input to query and key space
    query = nn.Linear(x.size(-1), hidden_size)(x)
    key = nn.Linear(x.size(-1), hidden_size)(x)
    
    # Compute attention scores
    scores = torch.matmul(query, key.transpose(-2, -1))
    scores = scores / np.sqrt(hidden_size)
    
    # Softmax to get attention weights
    return torch.softmax(scores, dim=-1)

def spatial_correlation_matrix(
    time_series: torch.Tensor,
    threshold: float = 0.1
) -> torch.Tensor:
    """
    Compute spatial correlation matrix from time series data
    
    Args:
        time_series: Input time series [num_nodes, time_steps]
        threshold: Correlation threshold
    
    Returns:
        Spatial correlation matrix
    """
    # Compute correlation matrix
    correlation = torch.corrcoef(time_series)
    
    # Apply threshold
    mask = torch.abs(correlation) > threshold
    correlation = correlation * mask.float()
    
    return correlation

def create_time_features(
    dates: torch.Tensor,
    num_features: int = 4
) -> torch.Tensor:
    """
    Create time-based features
    
    Args:
        dates: Tensor of timestamps
        num_features: Number of time features to generate
    
    Returns:
        Time-based features
    """
    # Hour of day
    hour = dates % 24
    hour_sin = torch.sin(2 * np.pi * hour / 24.0)
    hour_cos = torch.cos(2 * np.pi * hour / 24.0)
    
    # Day of week
    day = (dates // 24) % 7
    day_sin = torch.sin(2 * np.pi * day / 7.0)
    day_cos = torch.cos(2 * np.pi * day / 7.0)
    
    return torch.stack([hour_sin, hour_cos, day_sin, day_cos], dim=-1)

def mope_router(x: torch.Tensor, num_experts: int, hidden_size: int) -> torch.Tensor:
    """
    MoPE (Mixture of Parameter-Efficient Experts) router implementation
    
    Args:
        x: Input tensor
        num_experts: Number of experts
        hidden_size: Hidden layer size
    
    Returns:
        Router scores for each expert
    """
    # Project input to routing space
    router_weights = nn.Linear(x.size(-1), num_experts)(x)
    
    # Apply softmax to get expert weights
    return torch.softmax(router_weights, dim=-1)

def uncertainty_loss(
    pred_mean: torch.Tensor,
    pred_var: torch.Tensor,
    target: torch.Tensor
) -> torch.Tensor:
    """
    Compute uncertainty-aware loss
    
    Args:
        pred_mean: Predicted mean
        pred_var: Predicted variance
        target: Ground truth values
    
    Returns:
        Uncertainty-aware loss value
    """
    # Gaussian negative log likelihood
    return 0.5 * (
        torch.log(pred_var) +
        ((target - pred_mean) ** 2) / pred_var +
        torch.log(torch.tensor(2 * np.pi))
    ).mean()

def grouped_linear(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor] = None,
    num_groups: int = 8
) -> torch.Tensor:
    """
    Grouped linear transformation
    
    Args:
        x: Input tensor
        weight: Weight matrix
        bias: Optional bias term
        num_groups: Number of groups
    
    Returns:
        Transformed tensor
    """
    batch_size, seq_len, in_features = x.shape
    out_features = weight.size(0)
    
    # Reshape input and weight for grouped multiplication
    x = x.view(batch_size, seq_len, num_groups, -1)
    weight = weight.view(out_features, num_groups, -1)
    
    # Perform grouped linear transformation
    output = torch.einsum('bsgi,ogi->bsog', x, weight)
    output = output.reshape(batch_size, seq_len, out_features)
    
    if bias is not None:
        output = output + bias
        
    return output

def positional_encoding(
    seq_len: int,
    d_model: int,
    device: torch.device
) -> torch.Tensor:
    """
    Generate positional encoding
    
    Args:
        seq_len: Sequence length
        d_model: Model dimension
        device: Computation device
    
    Returns:
        Positional encoding matrix
    """
    position = torch.arange(seq_len, dtype=torch.float, device=device).unsqueeze(1)
    div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float, device=device) * 
                        -(torch.log(torch.tensor(10000.0)) / d_model))
    
    pos_encoding = torch.zeros(seq_len, d_model, device=device)
    pos_encoding[:, 0::2] = torch.sin(position * div_term)
    pos_encoding[:, 1::2] = torch.cos(position * div_term)
    
    return pos_encoding

def set_seed(seed: int):
    """Set random seeds for reproducibility"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True

def load_config(config_path: str) -> Dict:
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config

def setup_logging(config: Dict):
    """Setup logging configuration"""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f"{log_dir}/{config['model']['name']}.log"),
            logging.StreamHandler()
        ]
    )

def save_model(
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    config: Dict,
    path: str
):
    """Save model checkpoint"""
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'config': config
    }
    torch.save(checkpoint, path)

def load_model(
    model: torch.nn.Module,
    optimizer: Optional[torch.optim.Optimizer],
    path: str
) -> tuple:
    """Load model checkpoint"""
    checkpoint = torch.load(path)
    model.load_state_dict(checkpoint['model_state_dict'])
    if optimizer:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    return checkpoint['epoch'], checkpoint['config']

def create_adj_matrix(
    num_nodes: int,
    edges: Union[list, torch.Tensor],
    weight_type: str = "distance"
) -> torch.Tensor:
    """Create adjacency matrix from edge list"""
    adj_matrix = torch.zeros((num_nodes, num_nodes))
    
    if isinstance(edges, list):
        edges = torch.tensor(edges)
    
    if weight_type == "distance":
        # Create distance-based weights
        for i, j in edges:
            adj_matrix[i, j] = 1.0
            adj_matrix[j, i] = 1.0
    elif weight_type == "normalized":
        # Create normalized adjacency matrix
        for i, j in edges:
            adj_matrix[i, j] = 1.0
            adj_matrix[j, i] = 1.0
        # Normalization
        D = torch.diag(torch.sum(adj_matrix, dim=1))
        D_inv_sqrt = torch.inverse(torch.sqrt(D))
        adj_matrix = torch.mm(torch.mm(D_inv_sqrt, adj_matrix), D_inv_sqrt)
    
    return adj_matrix

def normalize_data(data: torch.Tensor) -> torch.Tensor:
    """Normalize data to zero mean and unit variance"""
    mean = data.mean(dim=0, keepdim=True)
    std = data.std(dim=0, keepdim=True)
    return (data - mean) / (std + 1e-8)

def compute_laplacian(adj_matrix: torch.Tensor) -> torch.Tensor:
    """Compute normalized Laplacian matrix"""
    # Degree matrix
    D = torch.diag(torch.sum(adj_matrix, dim=1))
    # Laplacian
    L = D - adj_matrix
    # Normalized Laplacian
    D_inv_sqrt = torch.inverse(torch.sqrt(D))
    L_norm = torch.mm(torch.mm(D_inv_sqrt, L), D_inv_sqrt)
    return L_norm

def get_batch_indices(
    total_size: int,
    batch_size: int,
    shuffle: bool = True
) -> list:
    """Generate batch indices"""
    indices = np.arange(total_size)
    if shuffle:
        np.random.shuffle(indices)
    
    for i in range(0, total_size, batch_size):
        yield indices[i:i + batch_size]

def calculate_complexity(model: torch.nn.Module) -> Dict[str, int]:
    """Calculate model complexity metrics"""
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    return {
        'total_parameters': total_params,
        'trainable_parameters': trainable_params
    }

def setup_device(gpu_id: Optional[int] = None) -> torch.device:
    """Setup computation device"""
    if gpu_id is not None and torch.cuda.is_available():
        device = torch.device(f'cuda:{gpu_id}')
    elif torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')
    return device

def create_experiment_dir(config: Dict) -> str:
    """Create directory for experiment results"""
    exp_dir = os.path.join(
        'experiments',
        f"{config['model']['name']}_{config.get('experiment_name', 'default')}"
    )
    os.makedirs(exp_dir, exist_ok=True)
    os.makedirs(os.path.join(exp_dir, 'checkpoints'), exist_ok=True)
    os.makedirs(os.path.join(exp_dir, 'logs'), exist_ok=True)
    
    return exp_dir