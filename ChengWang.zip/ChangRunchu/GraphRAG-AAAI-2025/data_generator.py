# data_generator.py

import openai
import json
import logging
from typing import List, Dict, Any, Optional, Union
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import asyncio
import aiohttp
from tenacity import retry, stop_after_attempt, wait_exponential

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DomainType(Enum):
    """Valid engineering domains for question generation"""
    THERMODYNAMICS = "thermodynamics"
    FLUID_MECHANICS = "fluid_mechanics"
    MASS_TRANSFER = "mass_transfer"
    REACTION_KINETICS = "reaction_kinetics"
    PROCESS_CONTROL = "process_control"
    UNIT_OPERATIONS = "unit_operations"

class ComplexityLevel(Enum):
    """Complexity levels for generated questions"""
    BASIC = "basic"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"

@dataclass
class QualityMetrics:
    """Data class for quality evaluation metrics"""
    technical_accuracy: float
    clarity: float
    completeness: float
    educational_value: float
    accept: bool

class DataGeneratorError(Exception):
    """Base exception class for DataGenerator errors"""
    pass

class APIError(DataGeneratorError):
    """Raised when there's an error with the OpenAI API"""
    pass

class ValidationError(DataGeneratorError):
    """Raised when data validation fails"""
    pass

class DataGenerator:
    """
    A class to generate synthetic question-answer pairs for process engineering using GPT-4.
    
    This class implements the data generation pipeline described in the PEOA framework,
    using GPT-4 as the teacher model to generate high-quality, domain-specific QA pairs.
    
    Attributes:
        api_key (str): OpenAI API key
        model (str): Model identifier (e.g., "gpt-4")
        quality_threshold (float): Minimum acceptable quality score (0-1)
        max_retries (int): Maximum number of retries for API calls
        cache_dir (Path): Directory for caching generated data
    """

    def __init__(
        self, 
        api_key: str,
        model: str = "gpt-4",
        quality_threshold: float = 0.8,
        max_retries: int = 3,
        cache_dir: Optional[str] = None
    ):
        """
        Initialize the DataGenerator.
        
        Args:
            api_key: OpenAI API key
            model: Model identifier to use
            quality_threshold: Minimum quality score for accepting generated pairs
            max_retries: Maximum number of retry attempts for failed API calls
            cache_dir: Optional directory path for caching generated data
        
        Raises:
            ValueError: If quality_threshold is not between 0 and 1
            DataGeneratorError: If initialization fails
        """
        if not 0 <= quality_threshold <= 1:
            raise ValueError("quality_threshold must be between 0 and 1")

        self.api_key = api_key
        self.model = model
        self.quality_threshold = quality_threshold
        self.max_retries = max_retries
        self.cache_dir = Path(cache_dir) if cache_dir else None
        
        # Initialize OpenAI client
        try:
            openai.api_key = api_key
        except Exception as e:
            raise DataGeneratorError(f"Failed to initialize OpenAI client: {str(e)}")
        
        # Create cache directory if specified
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def generate_qa_pair(
        self,
        domain: Union[str, DomainType],
        complexity: Union[str, ComplexityLevel]
    ) -> Optional[Dict[str, Any]]:
        """
        Generate a single QA pair using GPT-4 with automatic retries.
        
        Args:
            domain: Engineering domain for the question
            complexity: Desired complexity level
            
        Returns:
            Generated QA pair as a dictionary or None if generation fails
            
        Raises:
            APIError: If API call fails after retries
            ValidationError: If generated content fails validation
        """
        # Validate and normalize inputs
        if isinstance(domain, str):
            try:
                domain = DomainType(domain.lower())
            except ValueError:
                raise ValidationError(f"Invalid domain: {domain}")
                
        if isinstance(complexity, str):
            try:
                complexity = ComplexityLevel(complexity.lower())
            except ValueError:
                raise ValidationError(f"Invalid complexity: {complexity}")

        # Generate prompt
        prompt = self._create_generation_prompt(domain.value, complexity.value)
        
        try:
            # Make API call
            response = await openai.ChatCompletion.acreate(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert process engineering professor with extensive industry experience."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=2000,
                n=1
            )
            
            generated_content = response.choices[0].message.content
            
            # Parse and validate response
            qa_pair = self._parse_qa_response(generated_content)
            if qa_pair is None:
                logger.warning("Failed to parse generated content as JSON")
                return None
                
            # Validate quality
            quality_metrics = await self._validate_quality(qa_pair)
            if not quality_metrics.accept:
                logger.info(
                    f"Generated QA pair rejected. Metrics: {quality_metrics}"
                )
                return None
                
            # Add metadata
            qa_pair.update({
                'domain': domain.value,
                'complexity': complexity.value,
                'generated_at': datetime.utcnow().isoformat(),
                'model': self.model,
                'quality_metrics': quality_metrics.__dict__
            })
            
            # Cache if enabled
            if self.cache_dir:
                self._cache_qa_pair(qa_pair)
                
            return qa_pair
            
        except openai.error.OpenAIError as e:
            raise APIError(f"OpenAI API error: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error in generate_qa_pair: {str(e)}")
            raise

    async def generate_dataset(
        self,
        size: int,
        domain: Union[str, DomainType],
        complexity: Union[str, ComplexityLevel],
        batch_size: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Generate multiple QA pairs in parallel batches.
        
        Args:
            size: Number of QA pairs to generate
            domain: Engineering domain
            complexity: Complexity level
            batch_size: Number of concurrent generations
            
        Returns:
            List of generated QA pairs
            
        Raises:
            ValueError: If size or batch_size is invalid
            DataGeneratorError: If dataset generation fails
        """
        if size < 1:
            raise ValueError("size must be positive")
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
            
        dataset = []
        tasks = []
        
        # Generate in batches
        for i in range(0, size, batch_size):
            batch_tasks = [
                self.generate_qa_pair(domain, complexity)
                for _ in range(min(batch_size, size - i))
            ]
            results = await asyncio.gather(*batch_tasks, return_exceptions=True)
            
            # Filter out failures and exceptions
            valid_results = [
                r for r in results
                if isinstance(r, dict) and r is not None
            ]
            dataset.extend(valid_results)
            
            # Log progress
            logger.info(
                f"Generated {len(dataset)}/{size} QA pairs "
                f"({len(valid_results)}/{len(results)} successful in current batch)"
            )
            
        return dataset

    def _create_generation_prompt(self, domain: str, complexity: str) -> str:
        """Create a detailed prompt for QA generation."""
        return f"""
        Generate a high-quality question-answer pair for process engineering in the {domain} domain.
        Complexity level: {complexity}
        
        The response should be a JSON object with the following structure:
        {{
            "question": "Detailed problem statement",
            "solution": {{
                "approach": "Solution strategy explanation",
                "steps": [
                    {{
                        "number": 1,
                        "description": "Step description",
                        "equations": ["Any relevant equations"],
                        "calculation": "Calculation details"
                    }}
                ],
                "final_answer": "The complete solution",
                "key_concepts": ["List of key concepts used"],
                "references": ["Optional references"]
            }}
        }}
        
        Requirements:
        1. Question should be practical and industry-relevant
        2. Solution must include all necessary steps and equations
        3. Include proper units and significant figures
        4. Explain key assumptions and limitations
        5. Highlight safety considerations if applicable
        """

    def _parse_qa_response(self, response: str) -> Optional[Dict[str, Any]]:
        """
        Parse and validate the generated response.
        
        Args:
            response: Raw response string from API
            
        Returns:
            Parsed QA pair or None if parsing fails
        """
        try:
            data = json.loads(response)
            
            # Validate required fields
            required_fields = {'question', 'solution'}
            if not all(field in data for field in required_fields):
                logger.warning(f"Missing required fields: {required_fields - set(data.keys())}")
                return None
                
            return data
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {str(e)}")
            return None

    async def _validate_quality(self, qa_pair: Dict[str, Any]) -> QualityMetrics:
        """
        Validate the quality of generated QA pair using GPT-4.
        
        Args:
            qa_pair: Generated QA pair to validate
            
        Returns:
            QualityMetrics object with evaluation results
        """
        validation_prompt = f"""
        Evaluate this process engineering question-answer pair:
        
        Question: {qa_pair.get('question')}
        Solution: {json.dumps(qa_pair.get('solution'), indent=2)}
        
        Provide a detailed evaluation as JSON with the following metrics (1-5 scale):
        {{
            "technical_accuracy": "Score for correctness and accuracy",
            "clarity": "Score for clear explanation and presentation",
            "completeness": "Score for covering all aspects thoroughly",
            "educational_value": "Score for learning potential",
            "feedback": "Detailed feedback comments",
            "accept": "Boolean indicating if quality meets standards"
        }}
        """
        
        try:
            response = await openai.ChatCompletion.acreate(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a senior process engineering professor responsible for quality control."
                    },
                    {
                        "role": "user",
                        "content": validation_prompt
                    }
                ]
            )
            
            validation = json.loads(response.choices[0].message.content)
            
            metrics = QualityMetrics(
                technical_accuracy=validation['technical_accuracy'],
                clarity=validation['clarity'],
                completeness=validation['completeness'],
                educational_value=validation['educational_value'],
                accept=validation['accept']
            )
            
            # Log validation results
            logger.info(
                f"Quality metrics: {metrics}\n"
                f"Feedback: {validation.get('feedback')}"
            )
            
            return metrics
            
        except Exception as e:
            logger.error(f"Quality validation error: {str(e)}")
            return QualityMetrics(0, 0, 0, 0, False)

    def _cache_qa_pair(self, qa_pair: Dict[str, Any]) -> None:
        """Cache the generated QA pair to disk."""
        if not self.cache_dir:
            return
            
        try:
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            cache_file = self.cache_dir / f"qa_pair_{timestamp}.json"
            
            with open(cache_file, 'w') as f:
                json.dump(qa_pair, f, indent=2)
                
        except Exception as e:
            logger.warning(f"Failed to cache QA pair: {str(e)}")


