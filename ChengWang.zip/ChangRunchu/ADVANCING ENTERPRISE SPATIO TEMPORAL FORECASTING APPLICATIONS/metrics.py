import torch
import numpy as np
from typing import Dict, Union, Optional
from sklearn.metrics import mean_absolute_error, mean_squared_error

class MetricsCalculator:
    """Calculate and track various performance metrics"""
    
    def __init__(self, scaler: Optional[object] = None):
        """
        Initialize metrics calculator
        
        Args:
            scaler: StandardScaler for denormalization if needed
        """
        self.scaler = scaler
        self.reset()
        
    def reset(self):
        """Reset accumulated metrics"""
        self.total_samples = 0
        self.accumulated_metrics = {
            'MAE': 0.0,
            'RMSE': 0.0,
            'MAPE': 0.0
        }
        
    def _denormalize(self, data: torch.Tensor) -> torch.Tensor:
        """Denormalize data if scaler is provided"""
        if self.scaler is not None:
            data_shape = data.shape
            data = torch.FloatTensor(
                self.scaler.inverse_transform(
                    data.cpu().reshape(-1, 1)
                ).reshape(data_shape)
            ).to(data.device)
        return data
    
    def update(
        self,
        predictions: Union[torch.Tensor, Dict[str, torch.Tensor]],
        targets: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ):
        """
        Update metrics with new batch
        
        Args:
            predictions: Model predictions or dict with predictions
            targets: Ground truth values
            mask: Optional mask for missing values
        """
        # Handle dict predictions (for uncertainty model)
        if isinstance(predictions, dict):
            predictions = predictions['forecast']
            
        # Denormalize if needed
        predictions = self._denormalize(predictions)
        targets = self._denormalize(targets)
        
        # Apply mask if provided
        if mask is not None:
            predictions = predictions[mask]
            targets = targets[mask]
        
        # Calculate metrics
        mae = torch.mean(torch.abs(predictions - targets)).item()
        mse = torch.mean((predictions - targets) ** 2).item()
        
        # Calculate MAPE with epsilon to avoid division by zero
        epsilon = 1e-10
        mape = torch.mean(torch.abs((predictions - targets) / (targets + epsilon))) * 100.0
        
        # Update accumulated metrics
        batch_size = targets.size(0)
        self.total_samples += batch_size
        self.accumulated_metrics['MAE'] += mae * batch_size
        self.accumulated_metrics['RMSE'] += mse * batch_size
        self.accumulated_metrics['MAPE'] += mape.item() * batch_size
    
    def compute(self) -> Dict[str, float]:
        """
        Compute final metrics
        
        Returns:
            Dict containing averaged metrics
        """
        if self.total_samples == 0:
            return {key: 0.0 for key in self.accumulated_metrics.keys()}
            
        metrics = {
            'MAE': self.accumulated_metrics['MAE'] / self.total_samples,
            'RMSE': np.sqrt(self.accumulated_metrics['RMSE'] / self.total_samples),
            'MAPE': self.accumulated_metrics['MAPE'] / self.total_samples
        }
        return metrics
    
    def get_horizon_metrics(
        self, 
        predictions: torch.Tensor, 
        targets: torch.Tensor, 
        horizons: Optional[List[int]] = None
    ) -> Dict[str, List[float]]:
        """
        Calculate metrics for different prediction horizons
        
        Args:
            predictions: Model predictions [batch, horizon, nodes, features]
            targets: Ground truth values [batch, horizon, nodes, features]
            horizons: List of horizons to evaluate (default: all)
            
        Returns:
            Dict containing metrics for each horizon
        """
        if horizons is None:
            horizons = range(predictions.size(1))
            
        horizon_metrics = {
            'MAE': [],
            'RMSE': [],
            'MAPE': []
        }
        
        for h in horizons:
            pred_h = predictions[:, h]
            target_h = targets[:, h]
            
            # Denormalize
            pred_h = self._denormalize(pred_h)
            target_h = self._denormalize(target_h)
            
            # Calculate metrics
            mae = torch.mean(torch.abs(pred_h - target_h)).item()
            rmse = torch.sqrt(torch.mean((pred_h - target_h) ** 2)).item()
            
            epsilon = 1e-10
            mape = torch.mean(torch.abs((pred_h - target_h) / (target_h + epsilon))).item() * 100.0
            
            horizon_metrics['MAE'].append(mae)
            horizon_metrics['RMSE'].append(rmse)
            horizon_metrics['MAPE'].append(mape)
            
        return horizon_metrics
    
    @staticmethod
    def calculate_uncertainty_metrics(
        predictions: Dict[str, torch.Tensor],
        targets: torch.Tensor
    ) -> Dict[str, float]:
        """
        Calculate metrics for uncertainty estimation
        
        Args:
            predictions: Dict containing 'forecast' and 'variance'
            targets: Ground truth values
            
        Returns:
            Dict containing uncertainty metrics
        """
        mean = predictions['forecast']
        variance = predictions['variance']
        
        # Calculate negative log likelihood
        nll = 0.5 * (
            torch.log(variance) + 
            ((targets - mean) ** 2) / variance + 
            torch.log(torch.tensor(2 * np.pi))
        ).mean().item()
        
        # Calculate prediction interval coverage probability (PICP)
        z_score = 1.96  # 95% confidence interval
        interval_width = z_score * torch.sqrt(variance)
        lower_bound = mean - interval_width
        upper_bound = mean + interval_width
        
        coverage = torch.mean(
            ((targets >= lower_bound) & (targets <= upper_bound)).float()
        ).item()
        
        return {
            'NLL': nll,
            'PICP': coverage
        }