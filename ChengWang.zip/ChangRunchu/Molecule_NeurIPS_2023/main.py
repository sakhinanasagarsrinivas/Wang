import argparse
from pathlib import Path
import torch
import pandas as pd
from typing import Dict, Any

# Import custom modules
from data.preprocessing import MoleculePreprocessor, BatchSampler
from data.dataset import MoleculeDataset
from models.gnn import ChebyshevGNN
from models.llm import MoleculeLanguageProcessor
from models.fusion import CrossModalFusion, ModalityFusion
from models.moe import MOEOutput
from utils.helpers import (
    setup_experiment,
    get_optimizer,
    get_scheduler,
    train_epoch,
    validate,
    evaluate_model,
    get_device,
    setup_logging
)
from evaluation.metrics import MetricsCalculator, TrainingMetrics

def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Train MMF model')
    parser.add_argument('--config', type=str, required=True,
                       help='Path to configuration file')
    parser.add_argument('--experiment_name', type=str, required=True,
                       help='Name of experiment')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    return parser.parse_args()

def build_model(config: Dict[str, Any], device: str) -> torch.nn.Module:
    """Build model from configuration"""
    # Initialize components
    gnn = ChebyshevGNN(
        in_channels=config['model']['gnn']['in_channels'],
        hidden_channels=config['model']['gnn']['hidden_channels'],
        num_layers=config['model']['gnn']['num_layers'],
        dropout=config['model']['gnn']['dropout']
    )
    
    llm_processor = MoleculeLanguageProcessor(
        llm_model=config['model']['llm']['model_name'],
        embedding_model=config['model']['llm']['embedding_model'],
        device=device
    )
    
    fusion = ModalityFusion(
        hidden_dim=config['model']['fusion']['hidden_dim'],
        num_heads=config['model']['fusion']['num_heads'],
        num_layers=config['model']['fusion']['num_layers'],
        dropout=config['model']['fusion']['dropout']
    )
    
    output_layer = MOEOutput(
        input_dim=config['model']['moe']['input_dim'],
        hidden_dim=config['model']['moe']['hidden_dim'],
        num_tasks=config['model']['moe']['num_tasks'],
        num_experts=config['model']['moe']['num_experts'],
        dropout=config['model']['moe']['dropout']
    )
    
    # Create full model
    class MMFModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.gnn = gnn
            self.llm_processor = llm_processor
            self.fusion = fusion
            self.output_layer = output_layer
        
        def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
            # GNN forward pass
            graph_embedding, node_embeddings = self.gnn(
                batch['node_features'],
                batch['edge_index'],
                batch['batch_idx']
            )
            
            # LLM processing
            zero_shot_embedding, few_shot_embedding = self.llm_processor.process_molecule(
                batch['smiles']
            )
            
            # Fusion
            fused_embedding, attention_weights = self.fusion(
                graph_embedding,
                zero_shot_embedding,
                few_shot_embedding
            )
            
            # Output prediction
            predictions, auxiliary_outputs = self.output_layer(fused_embedding)
            
            # Calculate loss
            loss = torch.nn.functional.mse_loss(predictions, batch['targets'])
            loss = loss + auxiliary_outputs.get('load_balancing_loss', 0) * 0.1
            
            return {
                'loss': loss,
                'predictions': predictions,
                'attention_weights': attention_weights
            }
    
    model = MMFModel().to(device)
    return model

def main():
    """Main training function"""
    # Parse arguments and setup experiment
    args = parse_args()
    config, exp_dir = setup_experiment(args.config, args.experiment_name, args.seed)
    logger = setup_logging(exp_dir)
    device = get_device(config)
    
    logger.info(f"Using device: {device}")
    logger.info(f"Experiment directory: {exp_dir}")
    
    # Prepare data
    processor = MoleculePreprocessor(
        max_atoms=config['data']['max_atoms'],
        add_hs=config['data']['add_hs']
    )
    
    # Load and preprocess data
    data = pd.read_csv(config['data']['data_path'])
    train_data, valid_data, test_data = processor.process_dataset(
        data,
        smiles_col=config['data']['smiles_col'],
        target_cols=config['data']['target_cols']
    )
    
    # Create data loaders
    train_loader = BatchSampler(
        train_data,
        batch_size=config['training']['batch_size'],
        shuffle=True
    )
    valid_loader = BatchSampler(
        valid_data,
        batch_size=config['training']['batch_size'],
        shuffle=False
    )
    test_loader = BatchSampler(
        test_data,
        batch_size=config['training']['batch_size'],
        shuffle=False
    )
    
    # Build model
    model = build_model(config, device)
    logger.info(f"Model parameters: {sum(p.numel() for p in model.parameters())}")
    
    # Setup training
    optimizer = get_optimizer(model, config)
    scheduler = get_scheduler(optimizer, config)
    metrics_calculator = MetricsCalculator(processor.target_scaler)
    training_metrics = TrainingMetrics()
    
    # Training loop
    num_epochs = config['training']['num_epochs']
    best_val_loss = float('inf')
    patience = config['training']['patience']
    patience_counter = 0
    
    for epoch in range(num_epochs):
        logger.info(f"Epoch {epoch + 1}/{num_epochs}")
        
        # Training
        train_loss, train_metrics = train_epoch(
            model, train_loader, optimizer, device, metrics_calculator
        )
        
        # Validation
        val_loss, val_metrics = validate(
            model, valid_loader, device, metrics_calculator
        )
        
        # Update metrics
        should_stop = training_metrics.update(
            epoch, train_loss, val_loss,
            train_metrics, val_metrics,
            patience
        )
        
        # Learning rate scheduling
        if scheduler is not None:
            if isinstance(scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                scheduler.step(val_loss)
            else:
                scheduler.step()
        
        # Logging
        logger.info(f"Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
        logger.info(f"Train Metrics: {train_metrics}")
        logger.info(f"Val Metrics: {val_metrics}")
        
        # Save checkpoint
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            
            # Save model checkpoint
            checkpoint_path = exp_dir / 'best_model.pt'
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict() if scheduler else None,
                'val_loss': val_loss,
                'val_metrics': val_metrics,
                'config': config
            }, checkpoint_path)
            
            logger.info(f"Saved best model checkpoint to {checkpoint_path}")
        else:
            patience_counter += 1
        
        # Early stopping
        if should_stop:
            logger.info(f"Early stopping triggered after {epoch + 1} epochs")
            break
    
    # Load best model for testing
    checkpoint = torch.load(exp_dir / 'best_model.pt')
    model.load_state_dict(checkpoint['model_state_dict'])
    
    # Evaluate on test set
    logger.info("Evaluating on test set...")
    test_metrics = evaluate_model(
        model,
        test_loader,
        device,
        metrics_calculator,
        save_dir=exp_dir
    )
    
    # Log test results
    logger.info("Test Results:")
    for metric_name, value in test_metrics.items():
        logger.info(f"{metric_name}: {value:.4f}")
    
    # Save test results
    results = {
        'test_metrics': test_metrics,
        'best_val_loss': best_val_loss,
        'best_epoch': checkpoint['epoch'],
        'training_history': {
            'train_losses': training_metrics.train_losses,
            'val_losses': training_metrics.val_losses,
            'train_metrics': training_metrics.train_metrics,
            'val_metrics': training_metrics.val_metrics
        }
    }
    
    with open(exp_dir / 'results.json', 'w') as f:
        import json
        json.dump(results, f, indent=4)
    
    # Plot training curves
    training_metrics.plot_training_curves(save_path=str(exp_dir / 'training_curves.png'))
    
    logger.info("Training completed successfully!")
    logger.info(f"Results saved to {exp_dir}")

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        logging.error(f"Training failed with error: {str(e)}", exc_info=True)
        raise