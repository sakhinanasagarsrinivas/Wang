

import torch
import torch.nn.functional as F
from torch.nn import Parameter

class CustomGCNConv(torch.nn.Module):
    def __init__(self, in_channels, out_channels):
        super(CustomGCNConv, self).__init__()
        self.weight = Parameter(torch.Tensor(in_channels, out_channels))
        self.reset_parameters()
    
    def reset_parameters(self):
        torch.nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
    
    def forward(self, x, edge_index):
        # x is of shape [N, in_channels]
        # edge_index is of shape [2, E]
        
        # Step 1: Add self-loops to the adjacency matrix
        edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))
        
        # Step 2: Linear transformation
        x = torch.matmul(x, self.weight)
        
        # Step 3: Normalize edge weights (not shown for simplicity)
        # This would typically involve calculating the degree of each node
        # and normalizing the edges accordingly.
        
        # Step 4: Aggregate neighbor features
        row, col = edge_index
        out = torch.zeros_like(x)
        for i in range(x.size(0)):
            neighbors = col[row == i]
            out[i] = x[neighbors].mean(dim=0)
        
        return out

def add_self_loops(edge_index, num_nodes):
    self_loops = torch.arange(0, num_nodes, dtype=torch.long)
    self_loops = self_loops.unsqueeze(0).repeat(2, 1)
    return torch.cat([edge_index, self_loops], dim=1), None

class CustomTopKPooling(torch.nn.Module):
    def __init__(self, in_channels, ratio=0.5):
        super(CustomTopKPooling, self).__init__()
        self.ratio = ratio
        self.weight = Parameter(torch.Tensor(1, in_channels))
        self.reset_parameters()

    def reset_parameters(self):
        torch.nn.init.xavier_uniform_(self.weight)
    
    def forward(self, x, edge_index):
        # x is of shape [N, in_channels]
        
        # Step 1: Compute a scalar projection of node features onto a learnable vector
        score = torch.matmul(x, self.weight.t()).squeeze()
        
        # Step 2: Select the top k nodes based on the score
        num_nodes = int(self.ratio * x.size(0))
        _, idx = torch.topk(score, num_nodes, sorted=False)
        
        # Step 3: Filter nodes, edges, and return pooled graph
        x = x[idx]
        mask = torch.zeros(edge_index.max() + 1, dtype=torch.bool)
        mask[idx] = True
        edge_index = edge_index[:, mask[edge_index[0]] & mask[edge_index[1]]]
        
        return x, edge_index

class GraphEncoder(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(GraphEncoder, self).__init__()
        self.conv1 = CustomGCNConv(in_channels, hidden_channels)
        self.conv2 = CustomGCNConv(hidden_channels, out_channels)
    
    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = torch.relu(self.conv1(x, edge_index))
        x = self.conv2(x, edge_index)
        return x



class HierarchicalGraphEncoder(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(HierarchicalGraphEncoder, self).__init__()
        self.conv = CustomGCNConv(in_channels, hidden_channels)
        self.pool = CustomTopKPooling(hidden_channels, ratio=0.5)
        self.conv2 = CustomGCNConv(hidden_channels, out_channels)
    
    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = torch.relu(self.conv(x, edge_index))
        x, edge_index, _, _ = self.pool(x, edge_index)
        x = self.conv2(x, edge_index)
        return x

import torch
import torch.nn.functional as F
from torch.nn import Parameter, Module

class CliqueTreeEncoder(Module):
    def __init__(self, in_channels, out_channels):
        super(CliqueTreeEncoder, self).__init__()
        # Assuming each 'clique' is initially represented by an embedding vector
        # that aggregates or represents the features of the nodes within it.
        self.weight = Parameter(torch.Tensor(in_channels, out_channels))
        self.reset_parameters()

    def reset_parameters(self):
        torch.nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))

    def forward(self, x, edge_index):
        # x is of shape [N_cliques, in_channels], where N_cliques is the number of cliques
        # edge_index is of shape [2, E], representing the clique tree connectivity
        
        # Linear transformation
        x = torch.matmul(x, self.weight)

        # Message passing
        row, col = edge_index
        out = torch.zeros_like(x)
        for i in range(x.size(0)):
            # For each clique, find its neighbors in the clique tree
            neighbors = col[row == i]
            # Aggregate neighbor features. Here, we simply average them, but more sophisticated aggregations can be used.
            out[i] = x[neighbors].mean(dim=0) if len(neighbors) > 0 else x[i]

        # Non-linearity (e.g., ReLU)
        out = F.relu(out)

        return out




import torch
import torch.nn as nn
import torch.nn.functional as F

class EMCNet(nn.Module):
    def __init__(self, patch_feature_dim, num_classes):
        super(EMCNet, self).__init__()
        self.genc = GraphEncoder(patch_feature_dim, 128, 256)
        self.hgenc = HierarchicalGraphEncoder(256, 256, 512)
        # Assuming CliqueTreeEncoder is defined elsewhere and is compatible
        self.ctenc = CliqueTreeEncoder(512, 512)  # Adjust the dimensions as necessary
        self.output_layer = nn.Linear(512, num_classes)
    
    def forward(self, data):
        # Assume 'data' has attributes necessary for each step
        x, edge_index = data.x, data.edge_index
        
        # Step 1: Graph Encoder
        x = self.genc(x, edge_index)
        
        # Step 2: Hierarchical Graph Encoder (simulated data passed as same for simplicity)
        x = self.hgenc(x, edge_index)
        
        # Step 3: Clique Tree Encoder
        # Note: In a real implementation, you'd convert the output of HGEnc to a clique tree graph
        # This might involve a new 'data' object with its 'x' and 'edge_index' representing the clique tree
        # For demonstration, we reuse 'x' and 'edge_index', though in practice, these would come from the clique tree
        x = self.ctenc(x, edge_index)
        
        # Aggregation and Classification
        # Aggregating clique embeddings. In practice, you might aggregate differently based on your tree structure.
        x = torch.mean(x, dim=0)  # Assuming 'x' is now the embeddings from CTEnc
        out = self.output_layer(x)
        return torch.log_softmax(out, dim=-1)


from sklearn.model_selection import train_test_split

# Splitting dataset
train_val_dataset, test_dataset = train_test_split(dataset, test_size=0.2, random_state=42)
train_dataset, val_dataset = train_test_split(train_val_dataset, test_size=0.25, random_state=42) # 0.25 x 0.8 = 0.2

# Creating data loaders
from torch_geometric.data import DataLoader

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

import torch
import torch.nn.functional as F

def train(model, loader, optimizer):
    model.train()
    total_loss = 0
    for data in loader:
        optimizer.zero_grad()
        out = model(data)
        loss = F.nll_loss(out, data.y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(loader)

def evaluate(model, loader):
    model.eval()
    correct = 0
    with torch.no_grad():
        for data in loader:
            out = model(data)
            pred = out.argmax(dim=1)
            correct += int((pred == data.y).sum())
    return correct / len(loader.dataset)


learning_rates = [0.01, 0.001, 0.0001]
best_val_acc = 0
best_lr = 0

for lr in learning_rates:
    model = EMCNet(patch_feature_dim=..., num_classes=...)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    
    for epoch in range(10): # Example for 10 epochs, adjust as necessary
        train_loss = train(model, train_loader, optimizer)
        val_acc = evaluate(model, val_loader)
        
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_lr = lr

print(f'Best learning rate: {best_lr}, Validation accuracy: {best_val_acc}')


# Reinitialize the model with the best hyperparameters
model = EMCNet(patch_feature_dim=..., num_classes=...)
optimizer = torch.optim.Adam(model.parameters(), lr=best_lr)

# Final training
for epoch in range(20): # Assuming 20 epochs for final training
    train_loss = train(model, train_loader, optimizer)
    test_acc = evaluate(model, test_loader)
    print(f'Epoch: {epoch}, Test Acc: {test_acc:.4f}')
