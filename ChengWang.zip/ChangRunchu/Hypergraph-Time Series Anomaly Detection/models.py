# models.py
"""
Implementation of HgAD framework components.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional, List, Dict, Any


class HypergraphStructureLearning(nn.Module):
    """
    Dynamic hypergraph structure learning module as detailed in Section 2.2.
    Learns k-uniform hypergraph structure through inductive learning approach.
    """
    def __init__(self, num_nodes: int, embedding_dim: int, k_neighbors: int):
        super().__init__()
        self.num_nodes = num_nodes
        self.embedding_dim = embedding_dim
        self.k = k_neighbors
        
        # Learnable (low-dimensional) hypernode embeddings (Section 2.2)
        self.hypernode_embeddings = nn.Parameter(
            torch.randn(num_nodes, embedding_dim) / embedding_dim**0.5
        )
        
    def forward(self) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute hypergraph structure based on learned embeddings."""
        # Compute pairwise Euclidean distances (Equation 1)
        distances = self._compute_distances()
        
        # Get k-nearest neighbors while ensuring k-uniformity
        H = self._get_k_uniform_structure(distances)
        
        return H, self.hypernode_embeddings
        
    def _compute_distances(self) -> torch.Tensor:
        """Implementation of Equation 1 from paper."""
        z_i = self.hypernode_embeddings.unsqueeze(1) 
        z_j = self.hypernode_embeddings.unsqueeze(0)
        squared_diff = (z_i - z_j).pow(2)
        distances = torch.sqrt(squared_diff.sum(dim=-1) + 1e-8)
        return distances
        
    def _get_k_uniform_structure(self, distances: torch.Tensor) -> torch.Tensor:
        """Implementation of Equation 2 from paper."""
        values, indices = torch.topk(distances, self.k + 1, dim=1, largest=False)
        indices = indices[:, 1:]  # Remove self-loops
        
        H = torch.zeros(self.num_nodes, self.num_nodes, device=distances.device)
        
        for i in range(self.num_nodes):
            neighbors = indices[i]
            H[i, neighbors] = 1
            H[neighbors, i] = 1  # Make symmetric for bidirected hypergraph
        
        return H


class HypergraphConv(nn.Module):
    """Hypergraph Convolution layer implementing equations 3-5 in Section 2.4.1"""
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        self.W1 = nn.Linear(in_dim, out_dim)    # Node feature transform
        self.W2 = nn.Linear(2*out_dim, 1)       # Edge attention
        self.W3 = nn.Linear(in_dim, out_dim)    # Skip connection
        self.W4 = nn.Linear(out_dim, out_dim)   # Edge feature transform
        self.W5 = nn.Linear(3*out_dim, 1)       # Node attention
        
        self.activation = nn.ReLU()
        self.layer_norm = nn.LayerNorm(out_dim)
        
    def edge_attention(self, node_feats: torch.Tensor, edge_feats: torch.Tensor, 
                      H: torch.Tensor) -> torch.Tensor:
        """Implementation of Equation 4."""
        edge_nodes = (H > 0).float()
        node_proj = self.W1(node_feats)
        edge_proj = edge_feats.unsqueeze(1).expand(-1, H.size(0), -1, -1)
        
        g_i = node_feats
        g_i = self.W1(g_i)
        att_input = torch.cat([g_i.unsqueeze(2), edge_proj], dim=-1)
        scores = self.W2(att_input).squeeze(-1)
        
        masked_scores = scores.masked_fill(edge_nodes.unsqueeze(0) == 0, float('-inf'))
        attention = F.softmax(masked_scores, dim=-1)
        
        return attention
        
    def node_attention(self, node_feats: torch.Tensor, edge_feats: torch.Tensor, 
                      H: torch.Tensor) -> torch.Tensor:
        """Implementation of Equation 5."""
        incident_edges = (H > 0).float()
        g_i = torch.cat([node_feats, self.W1(node_feats)], dim=-1)
        g_p = self.W4(edge_feats)
        
        att_input = torch.cat([
            g_i.unsqueeze(2).expand(-1, -1, H.size(1), -1),
            g_p.unsqueeze(1).expand(-1, H.size(0), -1, -1)
        ], dim=-1)
        scores = self.W5(att_input).squeeze(-1)
        
        masked_scores = scores.masked_fill(incident_edges.unsqueeze(0) == 0, float('-inf'))
        attention = F.softmax(masked_scores, dim=-1)
        
        return attention
    
    def forward(self, x: torch.Tensor, H: torch.Tensor, 
                return_attention: bool = False) -> torch.Tensor:
        """Implementation of Equations 3-5."""
        # Edge feature computation (Equation 3)
        edge_attention = self.edge_attention(x, self.W1(x), H)
        edge_feats = torch.matmul(edge_attention.transpose(1, 2), self.W1(x))
        
        # Node feature update (Equation 5)
        node_attention = self.node_attention(x, edge_feats, H)
        node_update = self.W3(x) + torch.matmul(node_attention, self.W4(edge_feats))
        
        # Layer normalization and residual connection
        out = self.layer_norm(x + self.activation(node_update))
        
        if return_attention:
            return out, node_attention
        return out


class HypergraphPool(nn.Module):
    """Hypergraph pooling layer implementing Section 2.4.2"""
    def __init__(self, in_dim: int, ratio: float = 0.5):
        super().__init__()
        self.ratio = ratio
        self.score_layer = nn.Sequential(
            nn.Linear(in_dim, in_dim // 2),
            nn.ReLU(),
            nn.Linear(in_dim // 2, 1)
        )
        
    def forward(self, x: torch.Tensor, H: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Implementation of pooling operation described in Section 2.4.2"""
        # Equation 6: Compute hypernode representations
        scores = self.score_layer(x).squeeze(-1)
        
        # Equation 7: Select top nodes
        k = int(self.ratio * scores.size(1))
        _, idx = torch.topk(scores, k, dim=1)
        
        # Pool features and update incidence matrix
        x_pooled = torch.gather(x, 1, idx.unsqueeze(-1).expand(-1, -1, x.size(-1)))
        H_pooled = H[idx[0]]  # Use first batch for structure
        
        # Equations 8-9: Gating operation
        s_tilde = F.relu(torch.gather(scores, 1, idx))
        x_pooled = x_pooled * s_tilde.unsqueeze(-1)
        
        return x_pooled, H_pooled, idx


class HypergraphUnpool(nn.Module):
    """Hypergraph unpooling layer implementing Section 2.4.3"""
    def __init__(self, in_dim: int):
        super().__init__()
        self.W = nn.Linear(in_dim, in_dim)
        
    def forward(self, x: torch.Tensor, H: torch.Tensor, idx: torch.Tensor, 
                size: int) -> torch.Tensor:
        """Implementation of unpooling operation described in Section 2.4.3"""
        B, _, F = x.size()
        out = torch.zeros(B, size, F, device=x.device)
        out.scatter_(1, idx.unsqueeze(-1).expand(-1, -1, F), x)
        return self.W(out)


class HypergraphDeviation(nn.Module):
    """Implements deviation scoring from Section 2.6"""
    def __init__(self, window_size: int = 10):
        super().__init__()
        self.window_size = window_size
        
    def forward(self, predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """Compute anomaly scores as per Equation 19."""
        # Compute deviation scores
        dev = torch.abs(predictions - targets)
        
        # Compute robust statistics
        med = torch.median(dev, dim=1)[0]
        q75 = torch.quantile(dev, 0.75, dim=1)
        q25 = torch.quantile(dev, 0.25, dim=1)
        iqr = q75 - q25
        
        # Compute normalized anomaly scores
        scores = (dev - med.unsqueeze(1)) / (iqr.unsqueeze(1) + 1e-8)
        
        return scores


class HgAD(nn.Module):
    """Main HgAD model implementing the full architecture"""
    def __init__(self, config: Dict[str, Any], num_nodes: int):
        super().__init__()
        self.config = config
        
        # Structure learning module (Section 2.2)
        self.structure_learning = HypergraphStructureLearning(
            num_nodes=num_nodes,
            embedding_dim=config['embedding_dim'],
            k_neighbors=config['k_neighbors']
        )
        
        # Encoder (Section 2.4)
        self.encoder_convs = nn.ModuleList([
            HypergraphConv(
                config['embedding_dim'] if i == 0 else config['hidden_dim'],
                config['hidden_dim']
            ) for i in range(config['num_layers'])
        ])
        
        self.pool = HypergraphPool(config['hidden_dim'], config['pooling_ratio'])
        
        # Decoder (Section 2.4)
        self.decoder_convs = nn.ModuleList([
            HypergraphConv(config['hidden_dim'], config['hidden_dim'])
            for _ in range(config['num_layers'])
        ])
        
        self.unpool = HypergraphUnpool(config['hidden_dim'])
        
        # Output heads
        self.forecasting_head = nn.Sequential(
            nn.Linear(config['hidden_dim'], config['hidden_dim'] // 2),
            nn.ReLU(),
            nn.Linear(config['hidden_dim'] // 2, 1)
        )
        
        self.anomaly_head = nn.Sequential(
            nn.Linear(config['hidden_dim'], config['hidden_dim'] // 2),
            nn.ReLU(),
            nn.Linear(config['hidden_dim'] // 2, 1),
            nn.Sigmoid()
        )
        
        self.deviation = HypergraphDeviation(config['window_size'])
        self.dropout = nn.Dropout(config['dropout'])
        
    def forward(self, x: torch.Tensor, return_embeddings: bool = False):
        """Forward pass implementing the full pipeline."""
        # Learn hypergraph structure
        H, node_embeddings = self.structure_learning()
        
        # Initial node features
        node_feats = node_embeddings.unsqueeze(0).expand(x.size(0), -1, -1)
        
        # Encoder
        encoder_outs = []
        indices = []
        
        for conv in self.encoder_convs:
            node_feats = conv(node_feats, H)
            node_feats = self.dropout(node_feats)
            encoder_outs.append(node_feats)
            node_feats, H, idx = self.pool(node_feats, H)
            indices.append(idx)
        
        # Decoder
        for conv, enc_feats, idx in zip(
            self.decoder_convs,
            reversed(encoder_outs),
            reversed(indices)
        ):
            node_feats = self.unpool(node_feats, H, idx, enc_feats.size(1))
            node_feats = conv(node_feats + enc_feats, H)
            node_feats = self.dropout(node_feats)
        
        # Output predictions
        forecasts = self.forecasting_head(node_feats)
        anomaly_scores = self.anomaly_head(node_feats)
        
        if return_embeddings:
            return forecasts, anomaly_scores, node_feats
        return forecasts, anomaly_scores